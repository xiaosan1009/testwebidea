package co.jp.softbank.qqmx.logic.application.batch;

import java.text.NumberFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.codec.binary.Base64;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.util.StringUtils;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class DeployBatchLogic extends AbstractBaseLogic {
	
	private List<Map<String, Object>> list = null;
	private Integer deployId = null;
	private static final int ZERO = 0 ;
	
	public void insertDeployInfo()  throws SoftbankException{

		String job_name = context.getParam().get("job_name");
		int new_build_count = Integer.valueOf(context.getParam().get("count"));
		String url = org.apache.commons.lang.StringUtils.stripEnd(context.getParam().get("job_url"), "/");
		getDeployInfo(url,job_name,new_build_count);
		
		DeployDetailLogic deployDetail = new DeployDetailLogic(db);
		if(list.size() != 0){
			for (int n = 0;n < list.size();n++) {
				String sonar_url = list.get(n).get("sonar_url").toString();
				deployDetail.getDetaiInfo(url,sonar_url,deployId, getJenkinsSonarQubeUrl());
			}
		}
		
	}
	
	public void getDeployInfo(String url,String job_name,Integer new_build_count)  throws SoftbankException{
		Map<String, Object> conditions = Maps.newHashMap();
		String jenkinsStr = externalHttpServer.getStrUrl(url + "/api/json");
		JSONObject json = JSONObject.fromObject(jenkinsStr);
		String result = json.get("result").toString();
		Double timestamp = Double.valueOf(json.get("timestamp").toString());
		Double duration = Double.valueOf(json.get("duration").toString());
		conditions.put("job_name", job_name);
		conditions.put("new_build_count", new_build_count);
		conditions.put("result", result);
		conditions.put("new_build_time", timestamp);
		conditions.put("deploy_time", duration);
		conditions.put("jenkins_url", url);
		log.info("duration*"+duration);
		
		String url_job = org.apache.commons.lang.StringUtils.stripEnd(url, "/" + new_build_count);
		String scoreStr = externalHttpServer.getStrUrl(url_job + "/api/json");
		JSONObject scorejson = JSONObject.fromObject(scoreStr);
		String healthReport = scorejson.get("healthReport").toString();
		healthReport =healthReport.substring(1, healthReport.length()-1);
		JSONObject healthReportjson = JSONObject.fromObject(healthReport);
		int score = (Integer)healthReportjson.get("score");
		conditions.put("score", score);
		boolean isJenkinsData = true ;
		String junit = externalHttpServer.getStrUrl(url + "/testReport/api/json");
		if(!junit.contains("<html>")){
			JSONObject junitJson = JSONObject.fromObject(junit);
			int failCount = (Integer)junitJson.get("failCount");
			int skipCount = (Integer)junitJson.get("skipCount");
			long junitDuration = 0;
			int successCount = 0;
			int doCount = 0;
			if(junitJson.has("childReports")){
				String childReport  = junitJson.get("childReports").toString();
				JSONObject childReportJson = JSONObject.fromObject(childReport.substring(1, childReport.length()-1));
				JSONObject resultJson = JSONObject.fromObject(childReportJson.get("result").toString());
				Double d = Double.valueOf(resultJson.get("duration").toString());
				junitDuration = Math.round(d*1000);
				int totalCount = (Integer)junitJson.get("totalCount");
				doCount = totalCount- skipCount;
				successCount = totalCount- failCount-skipCount;
			}else{
				Double d = Double.valueOf(junitJson.get("duration").toString());
				junitDuration = Math.round(d*1000);
				successCount = (Integer)junitJson.get("passCount");
				doCount = failCount + skipCount+successCount;
			}
			conditions.put("successCount", successCount);
			conditions.put("doCount", doCount);
			conditions.put("test_time", junitDuration);
		} else { 
			isJenkinsData = false;
		}
		String checkStyle = externalHttpServer.getStrUrl(url +"/checkstyleResult/api/json");
		if(!checkStyle.contains("<html>")){
			JSONObject csjson = JSONObject.fromObject(checkStyle);
			int style_high_number = (Integer)csjson.get("numberOfHighPriorityWarnings");
			int style_middle_number = (Integer)csjson.get("numberOfNormalPriorityWarnings");
			int style_low_number = (Integer)csjson.get("numberOfLowPriorityWarnings");
			conditions.put("style_high_number", style_high_number);
			conditions.put("style_middle_number", style_middle_number);
			conditions.put("style_low_number", style_low_number);
		} else {
			isJenkinsData = false;
		}

		String findbugs = externalHttpServer.getStrUrl(url +"/findbugsResult/api/json");
		if(!findbugs.contains("<html>")){
			JSONObject fbjson = JSONObject.fromObject(findbugs);
			int bugs_high_number = (Integer)fbjson.get("numberOfHighPriorityWarnings");
			int bugs_middle_number = (Integer)fbjson.get("numberOfNormalPriorityWarnings");
			int bugs_low_number = (Integer)fbjson.get("numberOfLowPriorityWarnings");
			conditions.put("bugs_high_number", bugs_high_number);
			conditions.put("bugs_middle_number", bugs_middle_number);
			conditions.put("bugs_low_number", bugs_low_number);
		} else { 
			isJenkinsData = false;
		}
	
		String logUrl = url +"/consoleFull";
		Map<String, Object> checkFindBugsDate = getCheckFindBugsDate(logUrl);
		Long checktime = null;
		if(checkFindBugsDate.get("checktime") != null){
			checktime = Long.parseLong(checkFindBugsDate.get("checktime").toString());
		}
		Long bugtime = null;
		if(checkFindBugsDate.get("bugtime") != null){
			bugtime = Long.parseLong(checkFindBugsDate.get("bugtime").toString());
		}
		conditions.put("check_time", checktime);
		conditions.put("bug_time", bugtime);
		if(checkFindBugsDate.get("revision") != null){
			conditions.put("revision", checkFindBugsDate.get("revision").toString());
		}
		
		List<Map<String, Object>> issuesIdList = db.querys("deploy.getIssuesId", conditions);
		int issuse_id = 0;
		Integer project_id = null;
		if(issuesIdList.size() != 0){
			issuse_id = Integer.parseInt(issuesIdList.get(0).get("ticket_id").toString());
			project_id = Integer.parseInt(issuesIdList.get(0).get("project_id").toString());
		}
		
		Map<String, Object> projectInfo = getProjectInfo(issuse_id);
		if(project_id == null){
			String projectId = context.getParam().get("project_id");
			project_id = Integer.valueOf(projectId);
		}
		conditions.put("project_id",project_id);
		if(projectInfo != null){
			conditions.put("version_id", projectInfo.get("version_id"));
			if(projectInfo.get("system_id") != null){
				conditions.put("system_id", Integer.valueOf(projectInfo.get("system_id").toString()));
			}
			conditions.put("issue_id", issuse_id);
		}
		
		Long build_time = getBulidTime(logUrl);
		conditions.put("build_time", build_time);

		String jacoco = externalHttpServer.getStrUrl(url + "/jacoco/api/json");
		if(!jacoco.contains("<html>")){
			JSONObject jacocoJson = JSONObject.fromObject(jacoco);
			String branchCoverage = jacocoJson.get("branchCoverage").toString();
			JSONObject branchCoverageJson = JSONObject.fromObject(branchCoverage);
			String branchPercent = branchCoverageJson.get("percentage").toString();
			float f = Float.valueOf(branchPercent);
			conditions.put("branchPercent", f);
			
			String instructionCoverage = jacocoJson.get("instructionCoverage").toString();
			JSONObject instructionCoverageJson = JSONObject.fromObject(instructionCoverage);
			String instructionPercent = instructionCoverageJson.get("percentage").toString();
			float f1 = Float.valueOf(instructionPercent);
			conditions.put("instructionPercent", f1);
		} else { 
			isJenkinsData = false ;
		}
		Map<String, Boolean> jenkinsContainsResult = Maps.newHashMap();  
		jenkinsContainsResult.put("isJenkinsData", isJenkinsData) ; 
		
		conditions.put("isJenkinsData", isJenkinsData) ; 
		String sonar = externalHttpServer.getStrUrl(url + "/api/json");
		if(!sonar.contains("<html>")){
			JSONObject sonarJson = JSONObject.fromObject(sonar);
			String actions = sonarJson.get("actions").toString();
			JSONArray array = JSONArray.fromObject(actions);
			boolean isFind = false;
			for(int i = 0;i<array.size();i++){
				if(array.get(i).toString().contains("sonarqubeDashboardUrl")){
					isFind = true;
					String sonarqube = array.get(i).toString();
					JSONObject sonarqubeJson = JSONObject.fromObject(sonarqube);
					String sonarUrl = sonarqubeJson.get("sonarqubeDashboardUrl").toString();
					Map<String, Object> sonarMap =  getSonarqubeInfor(sonarUrl, jenkinsContainsResult);
					if(sonarMap != null && !sonarMap.isEmpty()){
						String str = sonarMap.get("duplications").toString();
						Float duplications = Float.valueOf(str);
						log.info("steps*"+ sonarMap.get("steps"));
						conditions.put("steps", sonarMap.get("steps"));
						conditions.put("complexity", sonarMap.get("complexity"));
						conditions.put("duplications", duplications);
						conditions.put("technical_debt", sonarMap.get("technical_debt"));
						int index = sonarUrl.lastIndexOf("/");
						sonarUrl = sonarUrl.substring(index+1, sonarUrl.length());
						conditions.put("sonar_url", sonarUrl);
						
						if(!isJenkinsData) {
							conditions.put("successCount", sonarMap.get("successCount"));
							conditions.put("doCount", sonarMap.get("doCount"));
							conditions.put("test_time", sonarMap.get("test_time"));
							conditions.put("test_success_density", sonarMap.get("test_success_density"));
							conditions.put("branchPercent", sonarMap.get("branchPercent"));
							conditions.put("instructionPercent", sonarMap.get("instructionPercent"));
						}
					}
				}
			}
			if (!isFind) {
				list = db.querys("deploy.getSonarUrl", conditions);
				if(list.size() != 0){
					for (int n = 0;n < list.size();n++) {
						String sonar_url = list.get(n).get("sonar_url").toString();
						Map<String, Object> sonarMap =  getSonarqubeInfor(sonar_url, jenkinsContainsResult);
						if(sonarMap != null && !sonarMap.isEmpty()){
							String str = sonarMap.get("duplications").toString();
							Float duplications = Float.valueOf(str);
							conditions.put("steps", sonarMap.get("steps"));
							conditions.put("complexity", sonarMap.get("complexity"));
							conditions.put("duplications", duplications);
							conditions.put("technical_debt", sonarMap.get("technical_debt"));
							
							if(!isJenkinsData) {
								conditions.put("successCount", sonarMap.get("successCount"));
								conditions.put("doCount", sonarMap.get("doCount"));
								conditions.put("test_time", sonarMap.get("test_time"));
								conditions.put("test_success_density", sonarMap.get("test_success_density"));
								conditions.put("branchPercent", sonarMap.get("branchPercent"));
								conditions.put("instructionPercent", sonarMap.get("instructionPercent"));
							}
							int index = sonar_url.lastIndexOf("/");
							sonar_url = sonar_url.substring(index+1, sonar_url.length());
							conditions.put("sonar_url", sonar_url);
							String id = list.get(n).get("id").toString();
							conditions.put("sonar_id", Integer.valueOf(id));
							if("SUCCESS".equals(result)){
								db.update("deploy.updateSonarQube",conditions);
							}
							
						}
					}
				}
			}
		}
		
		db.insert("deploy.insertDeployInfo", conditions);
		deployId = Integer.parseInt(StringUtils.toString(conditions.get("id")));
		
	}
	
	public Map<String, Object> getSonarqubeInfor (String strProjectPram, Map<String, Boolean> jenkinsData) throws SoftbankException{
		Map<String, Object> resultMap = Maps.newHashMap();
		if(!"".equals(strProjectPram) && strProjectPram != null && !"null".equals(strProjectPram)){
			boolean isJenkinsData = jenkinsData.get("isJenkinsData");
			int index = strProjectPram.lastIndexOf("/");
			strProjectPram = strProjectPram.substring(index+1, strProjectPram.length());
			
			Map<String, Object> map = getJenkinsSonarQubeUrl();
			Map<String, String> deployUrlInfo = new HashMap<String, String>();
			if ( map.get("sonarqube_user") == null ) {
				deployUrlInfo.put("Authorization", "Basic Y2hhcmdpbmc6cGFzc3dvcmQ=");
			} else {
				String userInfo = StringUtils.toString(map.get("sonarqube_user")) + ":" + StringUtils.toString("sonarqube_password");
				String user = "Basic " + Base64.encodeBase64String(userInfo.getBytes());
				deployUrlInfo.put("Authorization", user);
			}	
			String url = StringUtils.toString(map.get("sonarqube_url"));
			String sonarQubeUrl = url + "/api/measures/component?componentKey="+strProjectPram+"&metricKeys=duplicated_lines_density,duplicated_lines,lines,complexity,ncloc,sqale_index,line_coverage,branch_coverage,test_execution_time,tests,test_failures,test_errors,skipped_tests,test_success_density";
			String resultTemp = externalHttpServer.getStrUrl(sonarQubeUrl, deployUrlInfo);

			JSONObject js1 = new JSONObject();
			JSONObject js = new JSONObject();
			String strjs1 = "";
			String strjs = "";
			if(resultTemp.length()>0){
				js1 = JSONObject.fromObject(resultTemp);
				strjs1 = StringUtils.toString(js1.get("component"));
				if ( !"".equals(strjs1) ) {
					js = JSONObject.fromObject(strjs1);
					strjs = StringUtils.toString(js.get("measures"));
				} else {
					return null;
				}
			} else {
				return null;
			}
			
			JSONArray jsResult = JSONArray.fromObject(strjs);
			int skippedTest = ZERO;
			int failureTest = ZERO;
			int totalTest = ZERO;
			int errorTest = ZERO;
			int successTest = ZERO;
			for (int i = 0;i < jsResult.size();i++) {
				JSONObject object = JSONObject.fromObject(jsResult.get(i));
				NumberFormat nf1 = NumberFormat.getInstance();
				if("sqale_index".equals(object.getString("metric"))){
				
					Double sqale = StringUtils.toDouble(object.getString("value")) ;
					if (480 < sqale){
						int day = (int) (Math.floor(sqale / 8 / 60)) ;
						resultMap.put("technical_debt", day + "d");
					}
					else {
						int hours =  (int)(Math.round(sqale / 60)) ;
						resultMap.put("technical_debt", hours + "h");
					}

				}
				else if("ncloc".equals(object.getString("metric"))){
					resultMap.put("steps", nf1.format(StringUtils.toInt(object.getString("value"))));
				}
				else if("complexity".equals(object.getString("metric"))){
					resultMap.put("complexity", nf1.format(StringUtils.toInt(object.getString("value"))));
				}
				
				else if("duplicated_lines_density".equals(object.getString("metric"))){
					resultMap.put("duplications", object.getString("value"));
				}
				
				else if("line_coverage".equals(object.getString("metric")) && !isJenkinsData){
					resultMap.put("instructionPercent", Float.valueOf(object.getString("value")));
				}
				else if("branch_coverage".equals(object.getString("metric")) && !isJenkinsData){
					resultMap.put("branchPercent", Float.valueOf(object.getString("value")));
				}
				else if("test_execution_time".equals(object.getString("metric")) && !isJenkinsData){
					resultMap.put("test_time",  Long.valueOf(object.getString("value")));
				}
				else if("tests".equals(object.getString("metric")) && !isJenkinsData){
					totalTest = StringUtils.toInt(object.getString("value"));
					resultMap.put("doCount", totalTest);
				}
				else if("test_success_density".equals(object.getString("metric")) && !isJenkinsData){
					resultMap.put("test_success_density", Float.valueOf(object.getString("value")));
				}
				else if("test_failures".equals(object.getString("metric")) && !isJenkinsData){
					failureTest = StringUtils.toInt(object.getString("value"));
				}
				else if("test_errors".equals(object.getString("metric")) && !isJenkinsData){
					errorTest = StringUtils.toInt(object.getString("value"));
				}
				else if("skipped_tests".equals(object.getString("metric")) && !isJenkinsData){
					skippedTest = StringUtils.toInt(object.getString("value"));
				}
			}
			successTest = totalTest - failureTest - errorTest - skippedTest ;
			resultMap.put("successCount",  successTest);
	    }
		return resultMap;
	}
	
	
	// TODO
	public Map<String, Object> getProjectInfo(Integer issuse_id) throws SoftbankException{
		Map<String, Object> resultMap = Maps.newHashMap();
		resultMap.put("issues_id", issuse_id);
		Map<String, Object> info =  db.query("deploy.getProjectInfo",resultMap);
		return info;
	}
	
	
	public Map<String, Object> getCheckFindBugsDate(String url) throws SoftbankException {
		Map<String, Object> resultMap = Maps.newHashMap();
		String str = externalHttpServer
				.getStrUrl(url);
		String[] strs = str.split("(\r\n|\r|\n|\n\r)");
		String startRegex = "<span class=\"timestamp\">\\s*<b>([0-9:]+)</b>\\s*</span>.*(?=maven-mojo.*maven-checkstyle-plugin)";
		String endRegex = "<span class=\"timestamp\">\\s*<b>([0-9:]+)</b>\\s*</span>.*(?=\\[CHECKSTYLE\\]\\s+Successfully)";
		Pattern spattern = Pattern.compile(startRegex);
		Pattern epattern = Pattern.compile(endRegex);
		List<String[]> resultList = Lists.newArrayList();
		for (int i = 0; i < strs.length; i++) {
			String s = strs[i];
			if(s.contains("Checking out Revision")){
				String revision = s.substring(s.indexOf("Revision")+9,s.lastIndexOf(" "));
				resultMap.put("revision", revision);
			}
			Matcher matcher = spattern.matcher(s);
			if (matcher.find()) {
				String[] data = new String[2];
				data[0] = matcher.group(1);
				resultList.add(data);
			} else {
				matcher = epattern.matcher(s);
				if (matcher.find()) {
					resultList.get(resultList.size() - 1)[1] = matcher.group(1);
				}
			}
		}
		
		Date checkStartDate = null;
		Date checkEndDate = null;
		Long checktime = null;
		SimpleDateFormat sdf= new SimpleDateFormat("HH:mm:ss");
		for(int j = 0;j < resultList.size(); j++ ){
			String checkEnd = resultList.get(j)[1];
			if("".equals(checkEnd) || checkEnd == null){
				continue;
			}
			if(checktime == null){
				checktime = 0L;
			}
			String checkStart = resultList.get(j)[0];
			try {
				checkStartDate = sdf.parse(checkStart);
				checkEndDate = sdf.parse(checkEnd);
				checktime = checktime + checkEndDate.getTime()-checkStartDate.getTime();
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		
		
		startRegex = "<span class=\"timestamp\">\\s*<b>([0-9:]+)</b>\\s*</span>.*(?=maven-mojo.*findbugs-maven-plugin)";
		endRegex = "<span class=\"timestamp\">\\s*<b>([0-9:]+)</b>\\s*</span>.*(?=\\[FINDBUGS\\]\\s+Successfully)";
		spattern = Pattern.compile(startRegex);
		epattern = Pattern.compile(endRegex);
		resultList = Lists.newArrayList();
		for (int i = 0; i < strs.length; i++) {
			String s = strs[i];
			Matcher matcher = spattern.matcher(s);
			if (matcher.find()) {
				String[] data = new String[2];
				data[0] = matcher.group(1);
				resultList.add(data);
			} else {
				matcher = epattern.matcher(s);
				if (matcher.find()) {
					resultList.get(resultList.size() - 1)[1] = matcher.group(1);
				}
			}
		}
		
		Date bugStartDate = null;
		Date bugEndDate = null;
		Long bugtime = null;
		for(int j = 0;j < resultList.size(); j++ ){
			String bugEnd = resultList.get(j)[1];
			if("".equals(bugEnd) || bugEnd == null){
				continue;
			}
			String bugStart = resultList.get(j)[0];
			if(bugtime == null){
				bugtime = 0L;
			}
			try {
				bugStartDate = sdf.parse(bugStart);
				bugEndDate = sdf.parse(bugEnd);
				bugtime = bugtime + bugEndDate.getTime()-bugStartDate.getTime();
			} catch (ParseException e) {
				e.printStackTrace();
			}
		}
		
		resultMap.put("checktime", checktime);
		resultMap.put("bugtime", bugtime);
		
		return resultMap;
	}
	
	
	public Long getBulidTime(String url) throws SoftbankException{
		String str = externalHttpServer
				.getStrUrl(url);
		String[] strs = str.split("(\r\n|\r|\n|\n\r)");
		String endRegex = "Total time:\\s*([0-9\\.]+.*)";
		Pattern pattern = Pattern.compile(endRegex);
		Long build_time= null;
		for (int i = 0; i < strs.length; i++) {
			String s = strs[i];
			Matcher matcher = pattern.matcher(s);
			if(matcher.find()){
				String time = matcher.group(1);
				if(build_time == null){
					build_time = 0L;
				}
				if(time.contains("s")){
					time = time.substring(0, time.length()-2);
					int ss = Integer.parseInt(time.substring(0, time.indexOf(".")));
					int ms = Integer.parseInt(time.substring(time.indexOf(".")+1,time.length()));
					build_time = build_time + ss*1000 + ms;
					System.out.println(time + s +"s-------" + build_time);
				}else if(time.contains("min")){
					time = time.substring(0, time.length()-4);
					int min = Integer.parseInt(time.substring(0, time.indexOf(":")));
					int ss = Integer.parseInt(time.substring(time.indexOf(":")+1,time.length()));
					build_time = build_time + (min*60 + ss)*1000;
					System.out.println(time + s +"min-------" + build_time);
				}
				
			}
		}
		return build_time;
	}
	
	private Map<String, Object> getJenkinsSonarQubeUrl() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", context.getParam().get("project_id"));
		return  db.query("deploy.getJenkinsSonarQubeUrl", conditions);
	}
}
