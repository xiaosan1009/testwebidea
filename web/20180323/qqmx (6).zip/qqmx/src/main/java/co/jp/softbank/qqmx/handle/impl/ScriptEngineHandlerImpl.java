package co.jp.softbank.qqmx.handle.impl;

import co.jp.softbank.qqmx.handle.AbstractScriptEngineHandler;

public class ScriptEngineHandlerImpl extends AbstractScriptEngineHandler {

}
