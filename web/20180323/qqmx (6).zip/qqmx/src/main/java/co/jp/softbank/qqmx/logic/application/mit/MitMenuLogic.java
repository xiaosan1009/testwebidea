package co.jp.softbank.qqmx.logic.application.mit;

import java.util.Map;
import com.google.common.collect.Lists;
import com.google.common.collect.Maps;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.util.StringUtils;

public class MitMenuLogic extends AbstractBaseLogic {
	
	public void getSelectList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String selectId = context.getParam().get("selectFlg");
		String organizationCd = "10973960";
		
		//統括部
		String departmentId = null;
		if (StringUtils.isEmpty(context.getParam().get("departmentId"))) {
			departmentId = "9898";
		} else {
			departmentId = context.getParam().get("departmentId");
			if (!departmentId.equals("9898")) {
				organizationCd = departmentId;
			}
		}
		//部
		String regionId = null;
		if (StringUtils.isEmpty(context.getParam().get("regionId"))) {
			regionId = "9898";
		} else {
			regionId = context.getParam().get("regionId");
			if (!regionId.equals("9898")) {
				organizationCd = regionId;
			}
		}
		
		//ステータス
		String statusId = null;
		if (StringUtils.isEmpty(context.getParam().get("statusId"))) {
			statusId = "9898";
		} else {
			statusId = context.getParam().get("statusId");
		}
		
		if ("division".equals(selectId)){
			context.getResultBean().setData(db.querys("mitMenu.getDivisionList", conditions));
		} else if ("department".equals(selectId)){
			context.getResultBean().setData(db.querys("mitMenu.getDepartmentList", conditions));
		} else if ("region".equals(selectId)){
			conditions.put("department_Id", departmentId);
			context.getResultBean().setData(db.querys("mitMenu.getRegionList", conditions));
		} else if ("project".equals(selectId)){
//			conditions.put("project_Id", Integer.parseInt(projectId));
			String searchName = context.getParam().get("search_name");
			conditions.put("search_name", searchName);
			conditions.put("organization_cd", organizationCd);
			conditions.put("status_Id", Integer.valueOf(statusId));
			context.getResultBean().setData(db.querys("mitMenu.getProjectList", conditions));	
		} else {
			context.getResultBean().setData(Lists.newArrayList());
		}
	}
}
