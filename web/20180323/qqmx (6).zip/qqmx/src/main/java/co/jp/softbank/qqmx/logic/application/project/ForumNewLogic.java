package co.jp.softbank.qqmx.logic.application.project;

import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;

public class ForumNewLogic extends AbstractBaseLogic {
	
	//編集：表示
	public void getBoardsInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		
		conditions.put("id", context.getParam().get("id"));
		Map<String, Object> attachments = db.query("boards.getBoardsInfo", conditions);
		context.getResultBean().setData(attachments);
	}
	
	// 編集：作成
	public void saveBoardsInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		
		conditions.put("project_id", context.getParam().projectId);
		conditions.put("name", context.getParam().get("forum_name"));
		conditions.put("description", context.getParam().get("froum_description"));
		conditions.put("topics_count", 0);
		conditions.put("messages_count", 0);
		
		db.insert("boards.addBoardsInfo", conditions);	
	}
	
	// 編集：保存
	public void updateBoardsInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("id", context.getParam().get("boards_id"));
		conditions.put("name", context.getParam().get("forum_name"));
		conditions.put("description", context.getParam().get("froum_description"));
		
		db.update("boards.updateBoardsInfo", conditions);		
	}
	
	
}
