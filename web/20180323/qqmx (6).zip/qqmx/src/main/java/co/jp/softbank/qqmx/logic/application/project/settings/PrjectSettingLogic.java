package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

//import co.jp.softbank.qqmx.dao.project.settings.prjectSetting;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.PageListBean;
import co.jp.softbank.qqmx.util.StringUtils;

public class PrjectSettingLogic extends AbstractBaseLogic {

//	@Autowired
//	private prjectSetting prjectSetting;
	
	public void getProjectSettingList() throws SoftbankException {
		
		Map<String, Object> conditions = Maps.newHashMap();
		String projectIdString = context.getParam().get("projects-select-setting");
		conditions.put("project_id", Integer.parseInt(projectIdString));
		PageListBean pageListBean = pageList("prjectSetting.getProjectSettingList", conditions);
		context.getResultBean().setData(pageListBean);
	}
	
	public LogicBean getProjectSettingGroupList() throws SoftbankException {
		LogicBean wikiBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		String projectIdString = context.getParam().get("projects-select-setting");
		conditions.put("project_id", Integer.parseInt(projectIdString));
		wikiBean.setData(db.querys("prjectSetting.getProjectSettingGroupList", conditions));
		return wikiBean;
	}
	public LogicBean getProjectSettingRoleList() throws SoftbankException {
		LogicBean wikiBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("user_id", Integer.parseInt(context.getParam().get("user_id")));
		String projectIdString = context.getParam().get("projects-select-setting");
		conditions.put("project_id", Integer.parseInt(projectIdString));
		wikiBean.setData(db.querys("prjectSetting.getProjectSettingRoleList", conditions));
		return wikiBean;
	}
	public LogicBean getProjectSettingSelectList() throws SoftbankException {
		LogicBean wikiBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("input_date", context.getParam().get("input_date"));
		String projectIdString = context.getParam().get("projects-select-setting");
		conditions.put("project_id", Integer.parseInt(projectIdString));
		wikiBean.setData(db.querys("prjectSetting.getProjectSettingSelectList", conditions));
		return wikiBean;
	}
	public LogicBean saveProjectSettingRole() throws SoftbankException {
		LogicBean wikiBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		String projectIdString = context.getParam().get("projects-select-setting");
		conditions.put("project_id", Integer.parseInt(projectIdString));
		conditions.put("user_id", Integer.parseInt(context.getParam().get("user_id")));
		List<Map<String, Object>> selectMembersId = db.querys("prjectSetting.selectProjectSettingMembers", conditions);
		if (selectMembersId.size() > 0){
			String membersId = String.valueOf(selectMembersId.get(0).get("id"));
			String membersType = String.valueOf(selectMembersId.get(0).get("type"));
			String[] projectSettingRole = context.getParam().getList("member_role_ids");
			if (projectSettingRole != null) {
				Map<String, Object> conditionsRole = Maps.newHashMap();
				conditionsRole.put("member_id", Integer.parseInt(membersId));
				
				List<Map<String, Object>> selectMemberUsersList = db.querys("prjectSetting.selectProjectSettingMemberUsers", conditionsRole);
				if (selectMemberUsersList.size() != 0){
					db.delete("prjectSetting.deleteProjectSettingMemberUsers", conditionsRole);
				}
				for (int i = 0; i < projectSettingRole.length; i++) {
					if ("User".equals(membersType)){
						conditionsRole.put("role_id", Integer.parseInt(projectSettingRole[i]));
						List<Map<String, Object>> selectUsersList = db.querys("prjectSetting.selectProjectSettingUsers",conditionsRole);
						
						if (selectUsersList.size() == 0){
							conditionsRole.put("inherited_from", null);
							db.insert("prjectSetting.insertProjectSettingMembers", conditionsRole);
						}
					}else if ("Group".equals(membersType)){

						conditionsRole.put("role_id", Integer.parseInt(projectSettingRole[i]));
						conditionsRole.put("inherited_from", null);
						db.insert("prjectSetting.insertProjectSettingMembers",conditionsRole);
						final int roleId = Integer.parseInt(StringUtils.toString(conditionsRole.get("id")));
						
						Map<String, Integer> conditionsGroupUser = Maps.newHashMap();
						conditionsGroupUser.put("group_id", Integer.parseInt(context.getParam().get("user_id")));
						List<Map<String, Object>> selectGroupUserList = db.querys("prjectSetting.selectProjectSettingGroupUsers", conditionsGroupUser);
						for (int m = 0; m < selectGroupUserList.size(); m++) {
							
							Map<String, Object> conditionsUser = Maps.newHashMap();
							conditionsUser.put("project_id", Integer.parseInt(projectIdString));
							conditionsUser.put("user_id", StringUtils.toInt(selectGroupUserList.get(m).get("user_id")));
							List<Map<String, Object>> selectMemberGroupUsersId = db.querys("prjectSetting.selectProjectSettingMembers", conditionsUser);
							
							if (selectMemberGroupUsersId.size() > 0){
								
								Map<String, Object> conditionsGroupUserMembers = Maps.newHashMap();
								conditionsGroupUserMembers.put("member_id", Integer.parseInt(String.valueOf(selectMemberGroupUsersId.get(0).get("id"))));
								
								if (i == 0){
									db.delete("prjectSetting.deleteProjectSettingMemberGroupUsers", conditionsGroupUserMembers);
								}
								
								conditionsGroupUserMembers.put("inherited_from", roleId);
								conditionsGroupUserMembers.put("role_id", Integer.parseInt(projectSettingRole[i]));
								db.insert("prjectSetting.insertProjectSettingMembers", conditionsGroupUserMembers);
							}
						}
					}
				}
			}
		}
		return wikiBean;
	}

	public LogicBean saveProjectSettingNewUser() throws SoftbankException {
		LogicBean wikiBean = new LogicBean();
		String[] projectSettingUser = context.getParam().getList("member_user_ids");
		String[] projectSettingRole = context.getParam().getList("new_member_role_ids");
		
		if (projectSettingUser != null && projectSettingRole != null ){
			
			for (int i = 0; i < projectSettingUser.length; i++) {
				
				Map<String, Object> conditions = Maps.newHashMap();
				conditions.put("user_id", Integer.parseInt(projectSettingUser[i]));
				List<Map<String, Object>> selectMembersId = db.querys("prjectSetting.selectProjectSettingMembersUser", conditions);
				String projectIdString = context.getParam().get("projects-select-setting");
				conditions.put("project_id", Integer.parseInt(projectIdString));
				int membersId = selectMembersId(projectSettingUser[i], Integer.parseInt(projectIdString));
				Map<String, Object> conditionsMRole = Maps.newHashMap();
				conditionsMRole.put("member_id", membersId);
				int roleId = 0;
				for (int j = 0; j < projectSettingRole.length; j++) {
					conditionsMRole.put("role_id", Integer.parseInt(projectSettingRole[j]));
					conditionsMRole.put("inherited_from", null);
					db.insert("prjectSetting.insertProjectSettingMembers", conditionsMRole);
					roleId = Integer.parseInt(StringUtils.toString(conditionsMRole.get("id")));
				}
				
				if ("Group".equals(selectMembersId.get(0).get("type"))){
					
					Map<String, Integer> conditionsGroupUser = Maps.newHashMap();
					conditionsGroupUser.put("group_id", Integer.parseInt(projectSettingUser[i]));
//				conditionsGroupUser.put("project_id", Integer.parseInt(projectIdString));
					List<Map<String, Object>> selectGroupUserList = db.querys("prjectSetting.selectProjectSettingNewGroupUsers", conditionsGroupUser);
					for (int m = 0; m < selectGroupUserList.size(); m++) {
						
						Map<String, Object> conditions1 = Maps.newHashMap();
						conditions1.put("user_id", Integer.parseInt(String.valueOf(selectGroupUserList.get(m).get("user_id"))));
						conditions1.put("project_id", Integer.parseInt(projectIdString));
						db.delete("prjectSetting.deleteProjectSettingMemberGroupUsers1", conditions1);
						db.delete("prjectSetting.deleteProjectSettingMemberGroup1", conditions1);
						
						int membersUserId = selectMembersId(String.valueOf(selectGroupUserList.get(m).get("user_id")), Integer.parseInt(projectIdString));
						
						for (int j = 0; j < projectSettingRole.length; j++) {
							Map<String, Object> conditionsGroupUserMembers = Maps.newHashMap();
							conditionsGroupUserMembers.put("member_id", membersUserId);
							
							conditionsGroupUserMembers.put("inherited_from", roleId);
							conditionsGroupUserMembers.put("role_id", Integer.parseInt(projectSettingRole[j]));
							db.insert("prjectSetting.insertProjectSettingMembers", conditionsGroupUserMembers);
						}
					}
				}
			}
		}

		return wikiBean;
	}
	
	public LogicBean deleteProjectSettingUser() throws SoftbankException {
		LogicBean wikiBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		String projectIdString = context.getParam().get("projects-select-setting");
		conditions.put("user_id", Integer.parseInt(context.getParam().get("user_id")));
		conditions.put("project_id", Integer.parseInt(projectIdString));
		List<Map<String, Object>> selectMemberGroupUsersId = db.querys("prjectSetting.selectProjectSettingMembers", conditions);
		String deleteMemberId = StringUtils.toString(selectMemberGroupUsersId.get(0).get("id"));
		int delMemberId = StringUtils.toInt(selectMemberGroupUsersId.get(0).get("id"));
		
		delMembersId(deleteMemberId);
		delMembersRolesId(deleteMemberId);
		if ("Group".equals(selectMemberGroupUsersId.get(0).get("type"))) {
			
			Map<String, Integer> conditionsGroupUser = Maps.newHashMap();
			conditionsGroupUser.put("group_id", Integer.parseInt(context.getParam().get("user_id")));
			List<Map<String, Object>> selectGroupUserList = db.querys("prjectSetting.selectProjectSettingGroupUsers", conditionsGroupUser);
			for (int m = 0; m < selectGroupUserList.size(); m++) {
				
				Map<String, Object> conditionsGroup = Maps.newHashMap();
				conditionsGroup.put("user_id", StringUtils.toInt(selectGroupUserList.get(m).get("user_id")));
				conditionsGroup.put("project_id", Integer.parseInt(projectIdString));
				List<Map<String, Object>> selectMemberGUsersId = db.querys("prjectSetting.selectProjectSettingMembers", conditionsGroup);
				
				if (selectMemberGUsersId.size()>0){
					String deleteGroupMemberId = String.valueOf(selectMemberGUsersId.get(0).get("id"));
					Map<String, Object> delconditions = Maps.newHashMap();
					delconditions.put("member_id", Integer.parseInt(deleteGroupMemberId));
					
					List<Map<String, Object>> delUserList = db.querys("prjectSetting.selectProjectSettingMemberInfo", delconditions);
					if (delUserList.size() > 0) {
						db.delete("prjectSetting.deleteProjectSettingMemberUsersflg", delconditions);
					}else{
						delMembersId(deleteGroupMemberId);
						delMembersRolesId(deleteGroupMemberId);
					}
				}
			}	
		} else {
			// 削除できない存在すかを判断
			Map<String, Object> notMembersCnt = db.queryo("prjectSetting.selectProjectSettingNotMemberUsers", conditions);
			//　(membersを削除できない
			if (notMembersCnt != null && notMembersCnt.size() != 0) {
				// member_rolesを削除
				
			}
			
		}
		
		
		return wikiBean;
	}
	
	public void delMembersRolesId(String member_id) throws SoftbankException{
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("member_id", Integer.parseInt(member_id));
		db.delete("prjectSetting.deleteProjectSettingMemberUsersAll", conditions);
	}
	public void delMembersId(String member_id) throws SoftbankException{
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("member_id", Integer.parseInt(member_id));
		db.delete("prjectSetting.deleteProjectSettingUser", conditions);
	}
	
	public int selectMembersId(String user_id, int project_id) throws SoftbankException{
		int membersId = 0;
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("user_id", Integer.parseInt(user_id));
		conditions.put("project_id", project_id);
		db.insert("prjectSetting.insertProjectSettingUser", conditions);
		membersId = Integer.parseInt(StringUtils.toString(conditions.get("id")));
		return membersId;
	}
}
