package co.jp.softbank.qqmx.logic.application.test;

public class TestButton {

}
