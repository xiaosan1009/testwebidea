package co.jp.softbank.qqmx.logic.application.project;

import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.StringUtils;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class ForumAddLogic extends AbstractBaseLogic {

	public void setComments() throws SoftbankException {

		UserInfoData userInfo = this.context.getSessionData().getUserInfo();
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("parent_id", StringUtils.toInt(context.getParam().get("parent_id")));
		conditions.put("board_id", StringUtils.toInt(context.getParam().get("board_id")));
		conditions.put("subject", "RE: "+ context.getParam().get("subject"));
		conditions.put("content", context.getParam().get("content"));
		conditions.put("author_id", userInfo.getId());
		conditions.put("locked", Boolean.FALSE);
		conditions.put("sticky", "0");
		
		db.insert("messages.addMessagesInfo", conditions);
		
		// 添付ファイルを更新
		String upload_datas = StringUtils.toString(context.getParam().get("upload_datas"));
		updateAttachmentsData(upload_datas, StringUtils.toString(conditions.get("id")));
		
		// last_message_idを更新
		db.update("boards.updateLastMessageId", conditions);
		
		// replies_countを更新
		conditions.put("last_reply_id", StringUtils.toInt(conditions.get("id")));
		conditions.put("id", StringUtils.toInt(context.getParam().get("parent_id")));
		db.update("messages.updateRepliesCountUp", conditions);
	}
	
	// (編集)保存
	public void editComments() throws SoftbankException {
		
		Map<String, Object> conditions = Maps.newHashMap();
		
		String newsId = StringUtils.toString(context.getParam().get("news_id"));
		conditions.put("news_id", newsId);
		conditions.put("content", StringUtils.toString(context.getParam().get("content")));
		
		db.update("messages.updateMessagesInfo", conditions);
		
		// 添付ファイルを更新
		String upload_datas = StringUtils.toString(context.getParam().get("upload_datas"));
		updateAttachmentsData(upload_datas, newsId);
		
	}
	
	// 添付ファイルを保存
	public void updateAttachmentsData(String upload_datas, String newsId) throws SoftbankException {

		if (StringUtils.isNotEmpty(upload_datas)) {
			JSONArray importFile = JSONArray.fromObject(upload_datas);

			for (int i = 0; i < importFile.size(); i++) {
				JSONObject fileData = importFile.getJSONObject(i);

				String description = ConstantsUtil.Str.EMPTY;
				if (fileData.containsKey("description")) {
					description = fileData.getString("description");
				}

				Map<String, Object> dataMap = Maps.newHashMap();
				dataMap.put("attachments_id", fileData.getInt("file_id"));
				dataMap.put("container_type", "Message");
				dataMap.put("id", StringUtils.toInt(newsId));
				dataMap.put("description", description);

				// 既存ファイルを削除場合
				if (fileData.containsKey("delete")) {
					dataMap.put("id", fileData.getInt("file_id"));
					db.update("attachments.deleteFileInfo", dataMap);
				} else {
					db.update("attachments.updateAttachmentsByIdAfterInsert", dataMap);
				}
			}
		}
	}
	
	public void delComments() throws SoftbankException {
		
		Map<String, Object> conditions = Maps.newHashMap();
		int containerId = StringUtils.toInt(context.getParam().get("commented_id"));
		conditions.put("messages_id", containerId);
		db.delete("messages.deleteMessagesById", conditions);
		
		// last_message_idを更新
		conditions.put("board_id", StringUtils.toInt(context.getParam().get("board_id")));
		db.update("boards.updateLastMessageId", conditions);
		
		// replies_countを更新
		conditions.put("id", StringUtils.toInt(context.getParam().get("parent_id")));
		db.update("messages.updateRepliesCountDown", conditions);
		
		// realファイルを削除
		deleteAttachmentFileByContainer(containerId, "Message");
		
	}
}
