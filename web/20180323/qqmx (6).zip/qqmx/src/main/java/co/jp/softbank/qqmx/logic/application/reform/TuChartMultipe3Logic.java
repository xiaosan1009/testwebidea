package co.jp.softbank.qqmx.logic.application.reform;


import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URLDecoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.ControlDbMemory;
import co.jp.softbank.qqmx.util.StringUtils;

public class TuChartMultipe3Logic extends TuLogicBase {
	private static SimpleDateFormat SDF = new SimpleDateFormat("yyyyMM");
	private static final String ARTIFICIALNUMBER = "人工数";
	private static final String GYOUMUITAKU = "業務委託";
	private static final String JINKOU = "人工" ;
	
	private static final String MONEY = "金額";
	
	private static final String ARTIFICIAL = "artificial"; 
	private static final String BUDGET = "budget"; 
	private static final String DEFAULTVALUE = "9898"; 
	
	
//	private static final String AC_ARTIFICIAL = "ac_artificial"; 
//	private static final String AC_BUDGET = "ac_budget"; 
//	
//	private static final String PLAN_ARTIFICIAL = "plan_artificial"; 
//	private static final String PLAN_BUDGET = "plan_budget"; 
	
	private static final String SINKI ="新規";
	private static final String KIZON="既存";
	private static final String KOUZOUKAIKAKU ="構造改革";

	
	
	
	public  void getGyoumuItakuInfor() throws SoftbankException,UnsupportedEncodingException, ParseException {
		String statusId = null;
		if (!StringUtils.isEmpty(context.getParam().get("statusId"))) {
			statusId = URLDecoder.decode(context.getParam().get("statusId"),"utf-8");
		} 
		
		if (StringUtils.isEmpty(statusId)|| ARTIFICIALNUMBER.equals(statusId)) {
			getResouceTransitionSuiiInfor(ARTIFICIAL);
		}
		else if (MONEY.equals(statusId)) {
			getResouceTransitionSuiiInfor(BUDGET);
		}
	}
	
	public void setChartMultipeInfo() throws SoftbankException,UnsupportedEncodingException {
		//統括
		String headquartersId = null;
		if (StringUtils.isEmpty(context.getParam().get("headquartersId"))) {
			headquartersId = "9898";
		} else {
			headquartersId = context.getParam().get("headquartersId");
		}
		//本部
		String divisionId = null;
		if (StringUtils.isEmpty(context.getParam().get("divisionId"))) {
			divisionId = "9898";
		} else {
			divisionId = context.getParam().get("divisionId");
		}
		//統括部
		String departmentId = null;
		if (StringUtils.isEmpty(context.getParam().get("departmentId"))) {
			departmentId = "9898";
		} else {
			departmentId = context.getParam().get("departmentId");
		}
		//部
		String regionId = null;
		if (StringUtils.isEmpty(context.getParam().get("regionId"))) {
			regionId = "9898";
		} else {
			regionId = context.getParam().get("regionId");
		}
		//新規/既存
		String category = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("categoryId"))) {
			category = URLDecoder.decode(context.getParam().get("categoryId"),"utf-8");
		}
		
		//人工数/金額/施策数
		String status = "";
		if (!StringUtils.isEmpty(context.getParam().get("statusId"))) {
			status = URLDecoder.decode(context.getParam().get("statusId"),"utf-8");
		} 
		
		//保存履歴
		String study = "";
		if (!StringUtils.isEmpty(context.getParam().get("tuStudy"))) {
			if ("9898".equals(context.getParam().get("tuStudy"))) {
				study = ControlDbMemory.getInstance().getTuNewDate();
			} else {
				study = context.getParam().get("tuStudy");
			}
		}
		
		String jsonDate = context.getParam().get("jsonDate");
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("id", 2);
		conditions.put("headquarters_id", Integer.parseInt(headquartersId));
		conditions.put("division_id", Integer.parseInt(divisionId));
		conditions.put("department_id", Integer.parseInt(departmentId));
		conditions.put("region_id", Integer.parseInt(regionId));
		conditions.put("dispartch", GYOUMUITAKU);
		conditions.put("category", category);
		conditions.put("status", status);
		conditions.put("study", study);
		context.getResultBean().setData(db.delete("tuchartGyoumuitaku.delChartMultipeInfo", conditions));
		
		conditions.put("json_date", jsonDate);
		context.getResultBean().setData(db.insert("tuchartGyoumuitaku.setChartMultipeInfo", conditions));
	}
	public void delChartMultipeInfo() throws SoftbankException,UnsupportedEncodingException {
		//統括
		String headquartersId = null;
		if (StringUtils.isEmpty(context.getParam().get("headquartersId"))) {
			headquartersId = "9898";
		} else {
			headquartersId = context.getParam().get("headquartersId");
		}
		//本部
		String divisionId = null;
		if (StringUtils.isEmpty(context.getParam().get("divisionId"))) {
			divisionId = "9898";
		} else {
			divisionId = context.getParam().get("divisionId");
		}
		//統括部
		String departmentId = null;
		if (StringUtils.isEmpty(context.getParam().get("departmentId"))) {
			departmentId = "9898";
		} else {
			departmentId = context.getParam().get("departmentId");
		}
		//部
		String regionId = null;
		if (StringUtils.isEmpty(context.getParam().get("regionId"))) {
			regionId = "9898";
		} else {
			regionId = context.getParam().get("regionId");
		}
		//新規/既存
		String category = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("categoryId"))) {
			category = URLDecoder.decode(context.getParam().get("categoryId"),"utf-8");
		}
		
		//人工数/金額/施策数
		String status = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("statusId"))) {
			status = URLDecoder.decode(context.getParam().get("statusId"),"utf-8");
		} 
		
		//保存履歴
		String study = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("tuStudy"))) {
			if ("9898".equals(context.getParam().get("tuStudy"))) {
				study = ControlDbMemory.getInstance().getTuNewDate();
			} else {
				study = context.getParam().get("tuStudy");
			}
		}
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("id", 2);
		conditions.put("headquarters_id", Integer.parseInt(headquartersId));
		conditions.put("division_id", Integer.parseInt(divisionId));
		conditions.put("department_id", Integer.parseInt(departmentId));
		conditions.put("region_id", Integer.parseInt(regionId));
		conditions.put("dispartch", GYOUMUITAKU);
		conditions.put("category", category);
		conditions.put("status", status);
		conditions.put("study", study);

		context.getResultBean().setData(db.delete("tuchartGyoumuitaku.delChartMultipeInfo", conditions));
	}
	
	private void getResouceTransitionSuiiInfor(String statusflg) throws SoftbankException,UnsupportedEncodingException, ParseException {
		
		Map<String, Object> conditions = Maps.newHashMap();
		
		// 統括
		String headquartersId = "9898";
		if (StringUtils.isEmpty(context.getParam().get("headquartersId"))) {
			headquartersId = DEFAULTVALUE;
		} else {
			headquartersId = context.getParam().get("headquartersId");
		}
		// 本部
		String divisionId = null;
		if (StringUtils.isEmpty(context.getParam().get("divisionId"))) {
			divisionId = DEFAULTVALUE;
		} else {
			divisionId = context.getParam().get("divisionId");
		}
		// 統括部
		String departmentId = null;
		if (StringUtils.isEmpty(context.getParam().get("departmentId"))) {
			departmentId = DEFAULTVALUE;
		} else {
			departmentId = context.getParam().get("departmentId");
		}
		// 部
		String regionId = null;
		if (StringUtils.isEmpty(context.getParam().get("regionId"))) {
			regionId = DEFAULTVALUE;
		} else {
			regionId = context.getParam().get("regionId");
		}
		// 新規/既存
		String category = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("categoryId"))) {
			category = URLDecoder.decode(context.getParam().get("categoryId"),"utf-8");
		}
		
		// 人工数/金額/施策数
		String statusId = null;
		if (!StringUtils.isEmpty(context.getParam().get("statusId"))) {
			statusId = URLDecoder.decode(context.getParam().get("statusId"),"utf-8");
		}
		Map<String, Object> listResult = Maps.newHashMap() ;
		String study = null;
		if (!StringUtils.isEmpty(context.getParam().get("tuStudy"))) {
			if ("9898".equals(context.getParam().get("tuStudy"))) {
				study = ControlDbMemory.getInstance().getTuNewDate();
			} else {
				study = context.getParam().get("tuStudy");
			}
		}
		
		String dateDt = null;
		if (StringUtils.isEmpty(context.getParam().get("dateInfor"))) {
			dateDt = study.substring(0, 6);
		} else {
			dateDt = context.getParam().get("dateInfor");
		}
		
		conditions.put("study", study);
		conditions.put("headquarters_id", Integer.parseInt(headquartersId));
		conditions.put("division_id", Integer.parseInt(divisionId));
		conditions.put("department_id", Integer.parseInt(departmentId));
		conditions.put("region_id", Integer.parseInt(regionId));
		conditions.put("dispartch", GYOUMUITAKU);
		conditions.put("category", category);
		if ("".equals(statusId) || statusId == null || ARTIFICIALNUMBER.equals(statusId)) {
			statusId = ARTIFICIALNUMBER ;
		}
		listResult.put("nowDate", dateDt) ;
		conditions.put("status", statusId);
		String lastMonthTemp = dateDt;
		String headNowTitle = dateDt.substring(4, 6) + "月末"  ;
		
		
		if (headNowTitle.startsWith("0")) {
			headNowTitle = headNowTitle.replace("0", "") ;
		}
		listResult.put("headNowTitle", headNowTitle) ;	
		
		String lastMonth = getLastMonth(lastMonthTemp );
		String keyMonth = lastMonth.substring(2, 6) ;
		
		String headLastTitle = lastMonth.substring(4, 6) + "月末" ;
		if (headLastTitle.startsWith("0")) {
			headLastTitle = headLastTitle.replace("0", "") ;
		}
		listResult.put("headLastTitle", headLastTitle) ;	
		
		conditions.put("lastMonth", "TU50経営会議"+keyMonth);
		conditions.put("id", 2);
		
		Map<String, Object> graph = db.query("tuchartGyoumuitaku.getChartMultipeInfo", conditions);
		listResult.put("graph", graph);

		
		// 計画人工値
		conditions.put("artificial_unit", JINKOU);
		List<Map<String,Object>> total = db.querys("tuchartGyoumuitaku.getTotalInfor", conditions);
		BigDecimal sinkiArtificialTotal1704 = BigDecimal.ZERO ;
		BigDecimal kizonArtificialTotal1704 = BigDecimal.ZERO  ;
		BigDecimal sinkiBudgetTotal1704 = BigDecimal.ZERO  ;
		BigDecimal kizonBudgetTotal1704 = BigDecimal.ZERO  ;
		
		
		for (Map<String, Object> map : total) {
			String new_exist_update = (String) map.get("new_exist_update");
			if (SINKI.equals(new_exist_update)) {
				sinkiArtificialTotal1704 = ((objectToBigDecimal(map.get("plan_artificial1704"))));
				continue ;
			}else if (KIZON.equals(new_exist_update) || KOUZOUKAIKAKU.equals(new_exist_update)) {
				kizonArtificialTotal1704 = kizonArtificialTotal1704.add (objectToBigDecimal(map.get("plan_artificial1704")));
				continue ;
			}
			
		}
		
		
		// 計画予算値
		conditions.remove("artificial_unit");
		List<Map<String,Object>> totalBud = db.querys("tuchartGyoumuitaku.getTotalInfor", conditions);
		
		
		for (Map<String, Object> map : totalBud) {
			String new_exist_update = (String) map.get("new_exist_update");
			if (SINKI.equals(new_exist_update)) {
				sinkiBudgetTotal1704 = ((objectToBigDecimal(map.get("sum_plan_budget17"))));
				continue ;
			}else if (KIZON.equals(new_exist_update) || KOUZOUKAIKAKU.equals(new_exist_update)) {
				kizonBudgetTotal1704 = kizonBudgetTotal1704.add (objectToBigDecimal(map.get("sum_plan_budget17")));
				continue ;
			}
			
		}
		listResult.put("sinkiArtificialTotal1704", sinkiArtificialTotal1704.setScale(0, RoundingMode.HALF_UP)) ;
		listResult.put("sinkiBudgetTotal1704", millionToHrdMil(sinkiBudgetTotal1704)) ;
		listResult.put("kizonArtificialTotal1704", kizonArtificialTotal1704.setScale(0, RoundingMode.HALF_UP)) ;
		listResult.put("kizonBudgetTotal1704", millionToHrdMil(kizonBudgetTotal1704)) ;
		conditions.remove("study");
		
		// 先月削減値(予算)を取得
		
		List<Map<String,Object>> sengetuTotal = db.querys("tuchartGyoumuitaku.getGyoumuItakuInfor", conditions);
		BigDecimal sinkiSengetuArtificialSengetuTotal1704 = BigDecimal.ZERO ;
		BigDecimal kizonSengetuArtificialSengetuTotal1704 = BigDecimal.ZERO ;
		BigDecimal sinkiSengetuBudgetSengetuTotal1704 = BigDecimal.ZERO ;
		BigDecimal kizonSengetuBudgetSengetuTotal1704 = BigDecimal.ZERO ;
		
		
		for (Map<String, Object> map : sengetuTotal) {
			String new_exist_update = (String) map.get("new_exist_update");
			if (SINKI.equals(new_exist_update)) {
				sinkiSengetuBudgetSengetuTotal1704 = (objectToBigDecimal(map.get("plan_budget1904")));
				continue ;
			}else if (KIZON.equals(new_exist_update) || KOUZOUKAIKAKU.equals(new_exist_update)) {
				kizonSengetuBudgetSengetuTotal1704 = kizonSengetuBudgetSengetuTotal1704.add (objectToBigDecimal(map.get("plan_budget1904")));
				continue ;
			}
			
		}
		
		// 先月削減値(人工)を取得
		conditions.put("artificial_unit", JINKOU);
		List<Map<String,Object>> sengetuJinkouTotal = db.querys("tuchartGyoumuitaku.getGyoumuItakuInfor", conditions);
		
		
		for (Map<String, Object> map : sengetuJinkouTotal) {
			String new_exist_update = (String) map.get("new_exist_update");
			if (SINKI.equals(new_exist_update)) {
				sinkiSengetuArtificialSengetuTotal1704 = (objectToBigDecimal(map.get("plan_artificial1904")));
				continue ;
			}else if (KIZON.equals(new_exist_update) || KOUZOUKAIKAKU.equals(new_exist_update)) {
				kizonSengetuArtificialSengetuTotal1704 = kizonSengetuArtificialSengetuTotal1704 .add (objectToBigDecimal(map.get("plan_artificial1904")));
				continue ;
			}
			
		}
		
		listResult.put("sinkiSengetuArtificialSengetuTotal1704", sinkiSengetuArtificialSengetuTotal1704.setScale(0, RoundingMode.HALF_UP)) ;
		listResult.put("sinkiSengetuBudgetSengetuTotal1704", millionToHrdMil(sinkiSengetuBudgetSengetuTotal1704)) ;
		listResult.put("kizonSengetuArtificialSengetuTotal1704", kizonSengetuArtificialSengetuTotal1704.setScale(0, RoundingMode.HALF_UP)) ;
		listResult.put("kizonSengetuBudgetSengetuTotal1704", millionToHrdMil(kizonSengetuBudgetSengetuTotal1704)) ;
		
		// 今月削減値(人工)を取得
		conditions.remove("lastMonth");
		conditions.put("study", study);
		List<Map<String,Object>> kongetuTotal = db.querys("tuchartGyoumuitaku.getGyoumuItakuInfor", conditions);
		BigDecimal sinkiKongetuArtificialSengetuTotal1704 = BigDecimal.ZERO ;
		BigDecimal kizonKongetuArtificialSengetuTotal1704 = BigDecimal.ZERO ;
		BigDecimal sinkiKongetuBudgetSengetuTotal1704 = BigDecimal.ZERO ;
		BigDecimal kizonKongetuBudgetSengetuTotal1704 = BigDecimal.ZERO ;
		
		
		for (Map<String, Object> map : kongetuTotal) {
			String new_exist_update = (String) map.get("new_exist_update");
			if (SINKI.equals(new_exist_update)) {
				sinkiKongetuArtificialSengetuTotal1704 = (objectToBigDecimal(map.get("plan_artificial1904")));
				continue ;
			}else if (KIZON.equals(new_exist_update) || KOUZOUKAIKAKU.equals(new_exist_update)) {
				kizonKongetuArtificialSengetuTotal1704 = kizonKongetuArtificialSengetuTotal1704.add (objectToBigDecimal(map.get("plan_artificial1904")));
				continue ;
			}
			
		}
		
		
		
		// 今月削減値(予算)を取得
		conditions.remove("artificial_unit");
		List<Map<String,Object>> kongetuBudTotal = db.querys("tuchartGyoumuitaku.getGyoumuItakuInfor", conditions);
		
		
		for (Map<String, Object> map : kongetuBudTotal) {
			String new_exist_update = (String) map.get("new_exist_update");
			if (SINKI.equals(new_exist_update)) {
				sinkiKongetuBudgetSengetuTotal1704 = (objectToBigDecimal(map.get("plan_budget1904")));
				continue ;
			}else if (KIZON.equals(new_exist_update) || KOUZOUKAIKAKU.equals(new_exist_update)) {
				kizonKongetuBudgetSengetuTotal1704 = kizonKongetuBudgetSengetuTotal1704.add(objectToBigDecimal(map.get("plan_budget1904")));
				continue ;
			}
			
		}
				
		listResult.put("sinkiKongetuArtificialSengetuTotal1704", sinkiKongetuArtificialSengetuTotal1704.setScale(0, RoundingMode.HALF_UP)) ;
		listResult.put("sinkiKongetuBudgetSengetuTotal1704", millionToHrdMil(sinkiKongetuBudgetSengetuTotal1704)) ;
		listResult.put("kizonKongetuArtificialSengetuTotal1704", kizonKongetuArtificialSengetuTotal1704.setScale(0, RoundingMode.HALF_UP)) ;
		listResult.put("kizonKongetuBudgetSengetuTotal1704", millionToHrdMil(kizonKongetuBudgetSengetuTotal1704)) ;
		
		
		String title = ("9898".equals(category) ? "既存＋新規" : category ) + ",業託" ;
		listResult.put("title", title) ;
		context.getResultBean().setData(listResult);
	}
	
	
	private String getLastMonth(String lastMonthTemp) throws ParseException{
		
		Date dt = SDF.parse(lastMonthTemp) ;
		
		Calendar cal = Calendar.getInstance();
		cal.setTime(dt);
		cal.set(Calendar.DAY_OF_MONTH, 1);
		cal.add(Calendar.MONTH, -1);
		Date lastMonthDt = cal.getTime();
		return SDF.format(lastMonthDt);
	}
	/**
	 * objectからBigDecimalへ換える
	 * @return BigDecimal
	 */
	private BigDecimal objectToBigDecimal(Object obj){
		BigDecimal result = new BigDecimal(StringUtils.toString(obj));
		return result;
	}
	/**
	 * 百万から億へ計算
	 * @return 億の値
	 */
	private BigDecimal millionToHrdMil(BigDecimal bg){
		BigDecimal result = bg.divide(new BigDecimal(100));
		
		result = result.setScale(0, RoundingMode.HALF_UP);
		return result ;
	}
}
