package co.jp.softbank.qqmx.logic.application.common;

import java.util.HashMap;
import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.dao.IDaoInterface;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.Param;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.StringUtils;

public class LoginLogic extends AbstractBaseLogic {
	
	public LogicBean userLogin() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		
		Param param = context.getParam();
		
		UserInfoData userInfoData = new UserInfoData();
		Map<String, String> params = Maps.newHashMap();
		params.put("username", param.get("userLogin"));
		params.put("password", param.get("userPwd"));
		Map<String, String> userInfo = externalHttpServer.post("login.json", params, true);
		
		if (userInfo == null) {
			logicBean.setResultFlg(false);
			logicBean.setResultMsg("無効なアカウントまたはパスワードです。入力し直してください。");
			return logicBean;
		}
		userInfoData.setId(Integer.parseInt(userInfo.get("id")));
		userInfoData.setLogin(userInfo.get("login"));
		userInfoData.setApiToken(userInfo.get("api_token"));
		userInfoData.setAdmin("true".equals(userInfo.get("admin")));
		userInfoData.setName(userInfo.get("lastname") + " " + userInfo.get("firstname"));
		userInfoData.setFirstName(userInfo.get("firstname"));
		userInfoData.setLastName(userInfo.get("lastname"));
		context.getSessionData().set(UserInfoData.USER_INFO_KEY, userInfoData);
		
		Map<String, String> data = new HashMap<String, String>();
		data.put("userLogin", userInfoData.getLogin());
		data.put("userName", userInfoData.getName());
		String forwardUrl = context.getForwardUrlPath();
		if (StringUtils.isNotEmpty(forwardUrl)) {
			data.put("forwardUrl", forwardUrl);
		}
		logicBean.setData(data);
		context.setLang(ConstantsUtil.Lang.JAPAN);
		return logicBean;
	}

	@Override
	protected IDaoInterface getDao() {
		return null;
	}

}
