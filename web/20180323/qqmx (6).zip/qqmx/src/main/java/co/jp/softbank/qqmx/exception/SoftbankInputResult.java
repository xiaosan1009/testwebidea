package co.jp.softbank.qqmx.exception;

import org.springframework.validation.AbstractBindingResult;
import org.springframework.validation.FieldError;

import co.jp.softbank.qqmx.application.bean.HttpContext;

public class SoftbankInputResult extends AbstractBindingResult {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private HttpContext context;

	public SoftbankInputResult(HttpContext context) {
		super("");
		this.context = context;
	}

	@Override
	protected Object getActualFieldValue(String arg0) {
		return null;
	}

	@Override
	public Object getTarget() {
		return null;
	}
	
	public void rejectValue(String field, String errorCode, Object[] errorArgs, String defaultMessage) {
		String fixedField = fixedField(field);
		Object newVal = getActualFieldValue(fixedField);
		FieldError fe = new FieldError(
				getObjectName(), fixedField, newVal, false,
				resolveMessageCodes(errorCode, field), errorArgs, defaultMessage);
		addError(fe);
	}
	
}
