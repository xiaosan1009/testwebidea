package co.jp.softbank.qqmx.task.face;

public enum ICollectorStatus {
	
	END

}
