package co.jp.softbank.qqmx.info.face;

import java.util.List;
import java.util.Map;

import org.apache.poi.hssf.usermodel.HSSFPatriarch;
import org.apache.poi.ss.usermodel.Cell;
import org.apache.poi.ss.usermodel.CellStyle;
import org.apache.poi.ss.usermodel.Sheet;
import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.xssf.streaming.SXSSFDrawing;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.face.IExcelWriter.CellErrorStyle;
import co.jp.softbank.qqmx.logic.bean.ExportFileInfo;

public interface IExcelWriter {

	ExportFileInfo create(List<Map<String, Object>> headerColumns, List<Map<String, Object>> datas) throws SoftbankException;

	ExportFileInfo getExport(Map<String, String> optMap, List<Map<String, Object>> datas, Map<String, Object> templateMap) throws SoftbankException;
	
	public static interface CellAnalysis {
		void analysis(Cell cell, Map<String, Object> data, String key, String cellValue, int index);
	}
	
	public static interface CellFormat {
		CellStyle format(Workbook wb, Cell cell, Map<String, Object> data, String key, CellStyle style);
	}
	
	public static interface CellErrorStyle {
		CellStyle format(Workbook wb, SXSSFDrawing patriarch, Cell cell, Map<String, Object> data, String key, CellStyle style, int x, int y);
	}
	
	public static interface CreateFileName {
		String create() throws SoftbankException;
	}
	
	IExcelWriter setCellAnalysis(CellAnalysis analysis);
	
	IExcelWriter setCellFormat(CellFormat format);
	
	IExcelWriter setCreateFileName(CreateFileName create);
	
	IExcelWriter setCellErrorStyle(CellErrorStyle cellErrorStyle);
	
}
