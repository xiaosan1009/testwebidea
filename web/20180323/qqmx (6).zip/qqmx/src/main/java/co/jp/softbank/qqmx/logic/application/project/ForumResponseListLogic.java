package co.jp.softbank.qqmx.logic.application.project;

import co.jp.softbank.qqmx.logic.AbstractBaseLogic;

public class ForumResponseListLogic extends AbstractBaseLogic {
/*
	public void getMessageList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		int projectId = context.getParam().projectId;
		conditions.put("project_id", projectId);
		context.getResultBean().setData(pageList("forumList.getMessageList", conditions));
	}*/

	
}
