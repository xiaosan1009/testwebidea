package co.jp.softbank.qqmx.logic.application.project;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Maps;

public class NewsLogic extends AbstractBaseLogic {
	public void getNewsListInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		int projectId = context.getParam().projectId;
		
		//　リンクからprojectId
		if (StringUtils.isNotEmpty(context.getParam().get("projectId"))) {
			projectId = StringUtils.toInt(context.getParam().get("projectId"));
		}
		conditions.put("project_id", projectId);
		List<Map<String, Object>> attachments = db.querys("newsAdd.selectNews", conditions);
		context.getResultBean().setData(attachments);
	}
}
