package co.jp.softbank.qqmx.filter;

import java.io.IOException;

import javax.servlet.Filter;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;

import org.slf4j.Logger;

import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.dao.common.IDbExecute;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.LogUtil;
import co.jp.softbank.qqmx.util.StringUtils;

public abstract class AbstractCommonFilter implements Filter {
	
	protected Logger log = new LogUtil(this.getClass()).getLog();
	
	protected IDbExecute db;
    
    protected void sessionTimeOut(HttpContext httpContext)
        throws IOException, ServletException {
    	forwardError(httpContext, SoftbankExceptionType.SessionTimeout);
    }
    
    protected void rolesException(HttpContext httpContext)
    		throws IOException, ServletException {
    	forwardError(httpContext, SoftbankExceptionType.RolesException);
    }
    
    protected void forwardError(HttpContext httpContext, SoftbankExceptionType errorType) throws IOException, ServletException {
    	LogicBean logicBean = new LogicBean();
    	logicBean.setResultFlg(false);
    	logicBean.setResultCode(errorType.getErrCode());
    	if (httpContext.getResultBean() != null) {
    		logicBean.setShowPanel(httpContext.getResultBean().isShowPanel());
    	}
    	if (httpContext.getResultBean() != null && StringUtils.isNotEmpty(httpContext.getResultBean().getResultMsg())) {
    		logicBean.setResultMsg(httpContext.getResultBean().getResultMsg());
		} else {
			logicBean.setResultMsg(errorType.getErrMsg());
		}
    	httpContext.getRequest().setAttribute(LogicBean.RESPONSE_DATA, logicBean);
    	// Ajax
    	if ("1".equals(httpContext.getParam().clientType)) {
    		final RequestDispatcher rd = httpContext.getRequest().getRequestDispatcher(ConstantsUtil.Jsp.DEFAULT_JSP_PATH + ConstantsUtil.Jsp.JSON_JSP_PATH);
    		rd.forward(httpContext.getRequest(), httpContext.getResponse());
    	} else {
    		final RequestDispatcher rd = httpContext.getRequest().getRequestDispatcher(ConstantsUtil.Jsp.DEFAULT_JSP_PATH + ConstantsUtil.Jsp.ERROR_JSP_PATH);
    		rd.forward(httpContext.getRequest(), httpContext.getResponse());
    	}
    }
    
    public void setDb(IDbExecute db) {
		this.db = db;
	}

}
