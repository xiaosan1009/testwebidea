package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;

import java.util.Map;

import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Maps;

//import co.jp.softbank.qqmx.dao.project.settings.groupList;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.PageListBean;

public class GroupListLogic extends AbstractBaseLogic {

//	@Autowired
//	private groupList groupList;

	public void getGroupList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("group_name", context.getParam().get("group_name"));
		PageListBean pageListBean = pageList("groupList.getGroupList", conditions);
		context.getResultBean().setData(pageListBean);
	}
	
	public void saveGroup() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("group_name", context.getParam().get("group_name"));
		db.insert("groupList.saveGroup" , conditions);
		
	}
	
	public LogicBean checkNameExists() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("group_name", context.getParam().get("group_name"));
		
		if (StringUtils.isNotEmpty(context.getParam().get("group_id"))) {
			conditions.put("group_id", StringUtils.toInt(context.getParam().get("group_id")));
		} else {
			conditions.put("group_id", 0);
		}
		
		Integer getGroupCount = db.queryo("groupList.getGroupCount", conditions);
		if (getGroupCount > 0) {
			logicBean.setResultFlg(false);
			logicBean.setResultCode("301413.group_name_error_result");
		}
		return logicBean;
	}
	
	public LogicBean deleteGroup() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Integer> conditions = Maps.newHashMap();
		conditions.put("group_id", Integer.parseInt(context.getParam().get("group_id")));
		db.delete("groupList.deleteGroup", conditions);
		db.delete("groupList.deleteGroupUsers", conditions);
		
		List<Map<String, Object>> selectMemberUsersList = db.querys("groupList.selectProjectSettingMembers",conditions);
		for (int i = 0; i < selectMemberUsersList.size(); i++) {
			int member_id = StringUtils.toInt(selectMemberUsersList.get(i).get("id"));
			Map<String, Integer> conditionMember = Maps.newHashMap();
			conditionMember.put("group_id", member_id);
			db.delete("groupList.deleteProjectSettingMemberUsers",conditionMember);
			db.delete("groupList.deleteProjectSettingUser", conditionMember);
		}
		return logicBean;
	}
	
}
