package co.jp.softbank.qqmx.sockect.face;

import net.sf.json.JSONObject;

import org.springframework.web.socket.WebSocketSession;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.sockect.bean.WebSocketClientInfo;

public interface IWebSocketLogic {
 
 void recieve(WebSocketClientInfo clientInfo, JSONObject message) throws SoftbankException;
 
 void connect(WebSocketClientInfo clientInfo) throws SoftbankException;
 
 void closed(WebSocketClientInfo clientInfo) throws SoftbankException;

}
