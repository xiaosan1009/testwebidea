package co.jp.softbank.qqmx.logic.application.face;

public interface CustomFieldType {
	
	String LIST = "list";
	
	String LISTLINK = "listlink";
	
	String STRING = "string";
	
	String FLOAT = "float";
	
	String DATE = "date";
	
	String BOOL = "bool";
	
	String INT = "int";
	
	String PHASE = "phase";
	
	String TEXT = "text";
	
	String USER = "user";

}
