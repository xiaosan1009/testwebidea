package co.jp.softbank.qqmx.dao.project.settings;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.dao.IDaoInterface;

public interface ProjectListDao extends IDaoInterface {
	
	List<Map<String, Object>> getProjectList();
	void updateProjectSave(Map<String, Object> conditions);
	
	List<Map<String, Object>> selectProjectIdList(Map<String, Object> conditions);
	
	// Issues関連テーブル
	void deleteProjectIssuesJournalDetails(Map<String, Object> conditions);
	void deleteProjectIssuesJournals(Map<String, Object> conditions);
	void deleteProjectIssuesIssueRelations(Map<String, Object> conditions);
	void deleteProjectIssuesCustomValues(Map<String, Object> conditions);
	void deleteProjectIssuesWatchers(Map<String, Object> conditions);
	void deleteProjectIssuesAttachments(Map<String, Object> conditions);
	void deleteProjectIssuesUserIssueMonths(Map<String, Object> conditions);
	void deleteProjectIssues(Map<String, Object> conditions);
	
	List<Map<String, Object>> selectProjectWikis(Map<String, Object> conditions);
	void deleteProjectWikiRedirects(Map<String, Object> conditions);
	void deleteProjectWatchers(Map<String, Object> conditions);
	void deleteProjectWikiAttachments(Map<String, Object> conditions);
	void deleteProjectWikiPages(Map<String, Object> conditions);
	void deleteProjectWikiContents(Map<String, Object> conditions);
	void deleteProjectWikis(Map<String, Object> conditions);
	
	void deleteProjectChanges(Map<String, Object> conditions);
	void deleteProjectChangesetsIssues(Map<String, Object> conditions);
	void deleteProjectChangesets(Map<String, Object> conditions);
	void deleteProjectRepositories(Map<String, Object> conditions);
	
	// 削除テーブル
	void deleteProjectWtMemberOrders(Map<String, Object> conditions);
	void deleteProjectGraphPatterns(Map<String, Object> conditions);
	void deleteProjectDashboards(Map<String, Object> conditions);
	void deleteProjectMetricsLinks(Map<String, Object> conditions);
	void deleteProjectBoards(Map<String, Object> conditions);
	void deleteProjectNews(Map<String, Object> conditions);
	void deleteProjectDocuments(Map<String, Object> conditions);
	void deleteProjectVersions(Map<String, Object> conditions);
	void deleteProjectEnabledModules(Map<String, Object> conditions);
	void deleteProjectTimeEntries(Map<String, Object> conditions);
	void deleteProjectQueries(Map<String, Object> conditions);
	void deleteProjectIssueCategories(Map<String, Object> conditions);
	void deleteProjectCustomValues(Map<String, Object> conditions);
	void deleteProjectMemberRoles(Map<String, Object> conditions);
	void deleteProjectMembers(Map<String, Object> conditions);
	void deleteProjectCustomFieldsProjects(Map<String, Object> conditions);
	void deleteProjectProjectsTrackers(Map<String, Object> conditions);
	void deleteProjectAttachments(Map<String, Object> conditions);
	void deleteProjectProjects(Map<String, Object> conditions);
}
