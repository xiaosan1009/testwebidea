package co.jp.softbank.qqmx.task.face;

import co.jp.softbank.qqmx.application.bean.HttpContext;

public interface ITaskLogic {

	int execute(HttpContext httpContext);
}
