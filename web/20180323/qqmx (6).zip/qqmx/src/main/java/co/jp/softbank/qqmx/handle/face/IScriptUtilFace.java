package co.jp.softbank.qqmx.handle.face;

import java.util.Map;

import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.exception.SoftbankException;

public interface IScriptUtilFace {
    
    /**
     * @Description: 
     * @author king
     * @version V1.0
     * @param method method
     * @return value
     * @throws SoftbankException SoftbankException
     */
    Object execute(String method) throws SoftbankException;
    
    /**
     * @Description: 
     * @author king
     * @since May 10, 2013 11:22:08 AM 
     * @version V1.0
     * @param value value
     * @param method method
     * @param params params
     * @return value
     * @throws SoftbankException SoftbankException
     */
    Object execute(String method, Map<String, Object> params) throws SoftbankException;
    
    void setHandlerMethod(HttpContext httpContext);
    
}
