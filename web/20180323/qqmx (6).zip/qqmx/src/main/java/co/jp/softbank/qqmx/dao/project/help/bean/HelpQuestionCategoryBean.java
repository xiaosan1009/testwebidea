package co.jp.softbank.qqmx.dao.project.help.bean;

import net.sf.json.JSONObject;
import co.jp.softbank.qqmx.dao.common.bean.DaoBeanInterface;

public class HelpQuestionCategoryBean implements DaoBeanInterface {
	
	private int id;
	
	private String name;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public void toJson(JSONObject dataObj) {
		dataObj.put("id", this.id);
		dataObj.put("name", this.name);
	}

}
