package co.jp.softbank.qqmx.dao.project.settings;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.dao.IDaoInterface;
import co.jp.softbank.qqmx.dao.project.settings.bean.CustomFieldsBean;

public interface NewProjectDao extends IDaoInterface {
	
	List<CustomFieldsBean> getCustomFieldsBeans();
	
	List<CustomFieldsBean> getCustomFieldsBeanValues(Map<String, Object> conditions);
	
	List<Map<String, Object>> getSettings();
	
	List<Map<String, Object>> getTrackers();
	
	List<Map<String, Object>> getIssuesCustomFields();
	
	List<Map<String, Object>> checkProjectIdentifierExist(Map<String, Object> conditions);
	
	List<Map<String, Object>> checkProjectNameExist(Map<String, Object> conditions);
	
	List<Map<String, String>> getEnabledModules(Map<String, Object> conditions);

	List<Map<String, String>> getProjectTrackers(Map<String, Object> conditions);

	List<Map<String, String>> getProjectIssuesCustomFields(Map<String, Object> conditions);

	void insertProjectInfo(Map<String, Object> conditions);
	
	void insertEnabledModulesInfos(Map<String, Object> conditions);
	
	void insertWikisInfos(Map<String, Object> conditions);
	
	void insertProjectsTrackersInfos(Map<String, Object> conditions);
	
	void insertProjectsCustomFields(Map<String, Object> conditions);
	
	void insertProjectsCustomValues(Map<String, Object> conditions);

}
