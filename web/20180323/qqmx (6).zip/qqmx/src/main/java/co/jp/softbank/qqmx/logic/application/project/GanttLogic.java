package co.jp.softbank.qqmx.logic.application.project;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Stack;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.ControlDbMemory;
import co.jp.softbank.qqmx.info.ControlSettingMap;
import co.jp.softbank.qqmx.info.bean.TimestampData;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.application.face.IssueKey;
import co.jp.softbank.qqmx.logic.application.project.bean.UpdateTicketBean;
import co.jp.softbank.qqmx.logic.application.project.bean.UpdateTicketBean.JournalizedBean;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.DateUtils;
import co.jp.softbank.qqmx.util.StringUtils;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class GanttLogic extends TicketBaseLogic {
	
	/**
	 * チケット検索の閾値
	 */
	private static final int UPDATE_ISSUE_LIMIT = 10000;
	
	/**
	 * チケットデータを保存する
	 * 
	 * @throws SoftbankException 
	 */
	@SuppressWarnings("unchecked")
	public void saveGanttInfo() throws SoftbankException {
		String ganttInfo = context.getParam().get("gantt_info");
		String mailFlag = context.getParam().get("mail_flag");
		long token = Long.parseLong(context.getParam().get("token"));
		boolean changeFlg = false;
		Map<String, Integer> addIdMap = Maps.newHashMap();
		Map<String, Integer> conflictMap = Maps.newHashMap();
		JSONObject ganttJsonObject = JSONObject.fromObject(ganttInfo);
		JSONArray linkDatas = ganttJsonObject.getJSONArray("b");
		JSONObject colorDatas = ganttJsonObject.getJSONObject("d");
		JSONArray milestonesDatas = ganttJsonObject.getJSONArray("e");
		JSONObject changeModel = ganttJsonObject.getJSONObject(IssueKey.PROCESS.CHANGE_MODEL);
		IssuesChangeInfo issuesChangeInfo = new IssuesChangeInfo();
		UpdateTicketBean updateTicketBean = new UpdateTicketBean();
		
		if (changeModel != null && changeModel.containsKey(IssueKey.CHANGE_MODEL.GANTT_COLOR)) {
			try {
				updateColorInfos(colorDatas);
			} catch (Exception e) {
				log.error(e.getMessage(), e);
			}
		}
		
		updateMilestoneInfos(milestonesDatas);
		
		// チケットの順番を整理する
		if (!sortTicket(ganttJsonObject, issuesChangeInfo, token, updateTicketBean)) {
			return;
		}
		
		for (int i = 0; i < issuesChangeInfo.getRootList().size(); i++) {
			String rootId = issuesChangeInfo.getRootList().get(i);
			// チケットデータを分析する
			analyzeIssuse(rootId, issuesChangeInfo, true, token);
			changeAllParentNode(issuesChangeInfo, token);
		}
		List<Integer> issueSeqs = null;
		if (issuesChangeInfo.hasAdds()) {
			List<Map<String, Object>> adds = issuesChangeInfo.getAdds();
			Map<String, Object> conditons = Maps.newHashMap();
			conditons.put("count", adds.size());
			issueSeqs = db.queryos("issues.queryIssueSeqs", conditons);
			List<Map<String, Object>> customFieldList = Lists.newArrayList();
			for (int i = 0; i < adds.size(); i++) {
				Map<String, Object> data = adds.get(i);
				int newId = issueSeqs.get(i);
				if (StringUtils.isEmpty(data.get(IssueKey.AUTHOR_ID.KEY))) {
					data.put(IssueKey.AUTHOR_ID.KEY, getUserInfos().getId());
				}
				renderParentId(addIdMap, data, newId);
				insertIssue(data, customFieldList, newId);
			}
			db.inserts("issues.insertIssueInfoForGantt", adds);
			db.inserts("custom_values.insertIssueCustomValues", customFieldList);
			changeFlg = true;
		}
		
		if (issuesChangeInfo.hasDeletes()) {
			List<Map<String, Object>> deletes = issuesChangeInfo.getDeletes();
			for (int i = 0; i < deletes.size(); i++) {
				Map<String, Object> data = deletes.get(i);
				deleteTicketOnlyById(StringUtils.toInt(data.get(IssueKey.ISSUE_ID.KEY)));
			}
			changeFlg = true;
		}
		List<Integer> journalsSeqs = null;
		if (issuesChangeInfo.hasUpdates()) {
			List<Map<String, Object>> updates = issuesChangeInfo.getUpdates();
			if (updates.size() > UPDATE_ISSUE_LIMIT) {
				//　閾値と比べて更新のチケット数が大きい場合、プロジェクトに全部チケット検索する
				updateTicketBean.createOldIssueDataMap(db.querys("issues.selectIssueByProjectId"));
				updateTicketBean.createIssuesCustomValuesMap(db.querys("issues.selectIssueCustomFieldsAndValuesByProjectId"));
			} else {
				Map<String, Object> conditons = Maps.newHashMap();
				List<Integer> idList = Lists.newArrayList();
				for (int i = 0; i < updates.size(); i++) {
					Map<String, Object> data = updates.get(i);
					idList.add(StringUtils.toInt(data.get(IssueKey.ISSUE_ID.KEY)));
				}
				conditons.put("idList", idList);
				updateTicketBean.createOldIssueDataMap(db.querys("issues.selectIssueByIds", conditons));
				updateTicketBean.createIssuesCustomValuesMap(db.querys("issues.selectIssueCustomFieldsAndValuesByIssueIds", conditons));
			}
			for (int i = 0; i < updates.size(); i++) {
				Map<String, Object> data = updates.get(i);
				String tid = StringUtils.toString(data.get(IssueKey.ISSUE_ID.KEY));
				if (!isConflict(conflictMap, data, issuesChangeInfo)) {
					renderParentId(addIdMap, data, 0);
					if (!updateTicket(data, (Map<Integer, Object>)data.get(IssueKey.CUSTOMVALUES.KEY), updateTicketBean)) {
						issuesChangeInfo.putConflict(data);
						conflictMap.put(tid, 1);
					} else {
						changeFlg = true;
					}
				}
			}
			List<Map<String, Object>> updateIssueOrderList = updateTicketBean.getUpdateIssueOrderValues();
			if (updateIssueOrderList.size() > 0) {
				db.updates("issues.updateIssuesOrderById", updateIssueOrderList);
			}
			List<Map<String, Object>> updateIssueList = updateTicketBean.getUpdateIssueValues();
			if (updateIssueList.size() > 0) {
				db.updates("issues.updateIssuesById", updateIssueList);
			}
			List<Map<String, Object>> deleteCustomValueIdList = updateTicketBean.getDeleteCustomValueIds();
			if (deleteCustomValueIdList.size() > 0) {
				db.deletes("issues.deleteCustomValuesById", deleteCustomValueIdList);
			}
			List<JournalizedBean> journalizedList = updateTicketBean.getJournalizedList();
			if (journalizedList.size() > 0) {
				Map<String, Object> conditons = Maps.newHashMap();
				conditons.put("count", journalizedList.size());
				journalsSeqs = db.queryos("journals.queryjournalsSeqs", conditons);
				List<Map<String, Object>> journalizedUpdateList = Lists.newArrayList();
				List<Map<String, Object>> journalDetailsUpdateList = Lists.newArrayList();
				for (int i = 0; i < journalizedList.size(); i++) {
					JournalizedBean bean = journalizedList.get(i);
					Map<String, Object> data = bean.getData();
					int id = journalsSeqs.get(i);
					data.put("id", id);
					journalizedUpdateList.add(data);
					for (Map<String, Object> changeItem : bean.getChangeList()) {
						changeItem.put("journal_id", id);
						journalDetailsUpdateList.add(changeItem);
					}
				}
				db.inserts("journals.insertJournals", journalizedUpdateList);
				db.inserts("issues.insertJournalDetails", journalDetailsUpdateList);
			}
		}
		
		if (issuesChangeInfo.hasRoots()) {
			List<String> roots = issuesChangeInfo.getRoots();
			for (int i = 0; i < roots.size(); i++) {
				String root = roots.get(i);
				if (root.startsWith("n")) {
					if (addIdMap.containsKey(root)) {
						ControlDbMemory.getInstance().setRootToken(StringUtils.toInt(addIdMap.get(root)), DateUtils.getNowTime());
					}
				} else {
					ControlDbMemory.getInstance().setRootToken(StringUtils.toInt(root), DateUtils.getNowTime());
				}
			}
		}
		db.update("issue_relations.deleteLinkDatasByProjectId");
		if (linkDatas != null && linkDatas.size() > 0) {
			for (int i = 0; i < linkDatas.size(); i++) {
				JSONObject data = linkDatas.getJSONObject(i);
				Map<String, Object> conditions = Maps.newHashMap();
				conditions.put("issue_from_id", renderIssueId(addIdMap, data.getString("a")));
				conditions.put("issue_to_id", renderIssueId(addIdMap, data.getString("b")));
				conditions.put("relation_type", data.get("c"));
				if (StringUtils.isNotEmpty(data.get("d"))) {
					conditions.put("delay", data.get("d"));
				}
				boolean check = false;
				if (StringUtils.isNotEmpty(data.get("e"))) {
					check = data.getBoolean("e");
				}
				conditions.put("check", check);
				db.insert("issue_relations.insertLinkData", conditions);
			}
		}
		
//		if (changeFlg && issuesChangeInfo.hasProjects()) {
//			List<Integer> projects = issuesChangeInfo.getProjects();
//			for (int i = 0; i < projects.size(); i++) {
//				ControlDbMemory.getInstance().refreshProjects(projects.get(i), context.getSessionData().getUserInfo().getId());
//			}
//		}
		
		Map<String, Object> resultMap = Maps.newHashMap();
		
		if (issuesChangeInfo.hasConflicts()) {
			resultMap.put("conflicts", issuesChangeInfo.getConflicts());
		}
		resultMap.put("refreshDatas", createRefreshDatas(issuesChangeInfo));
		resultMap.put("newIdMapping", addIdMap);
		resultMap.put("token", DateUtils.getNowTime());
		resultMap.put("watcher", getProjectWatcher());
		context.getResultBean().setData(resultMap);
		if (issuesChangeInfo.hasAdds()) {
			// send mail
			if (!ControlSettingMap.getInstance().getBoolean(ControlSettingMap.SettingKey.DEBUG_MODEL) && issueSeqs != null && !"1".equals(mailFlag)) {
				for (int i = 0; i < issueSeqs.size(); i++) {
					sendMailSync(StringUtils.toString(issueSeqs.get(i)), "add");
				}
			}
		}
		if (issuesChangeInfo.hasUpdates()) {
			if (!ControlSettingMap.getInstance().getBoolean(ControlSettingMap.SettingKey.DEBUG_MODEL) && journalsSeqs != null && !"1".equals(mailFlag)) {
				for (int i = 0; i < journalsSeqs.size(); i++) {
					sendMailSync(StringUtils.toString(journalsSeqs.get(i)), "edit");
					
				}
			}
		}
	}
	
	public void saveGanttInfoForPortal() throws SoftbankException {
		String ganttInfo = context.getParam().get("gantt_info");
		JSONObject ganttJsonObject = JSONObject.fromObject(ganttInfo);
		JSONArray issuesDatas = ganttJsonObject.getJSONArray("a");
		JSONArray linkDatas = ganttJsonObject.getJSONArray("b");
		List<Map<String, Object>> checkDatas = Lists.newArrayList();
		IssuesChangeInfo issuesChangeInfo = new IssuesChangeInfo();
		for (int i = 0; i < issuesDatas.size(); i++) {
			JSONObject data = issuesDatas.getJSONObject(i);
			Map<String, Object> issueData = issuesChangeInfo.createIssueMap(data);
			issuesChangeInfo.putProject(StringUtils.toInt(issueData.get(IssueKey.PROJECT_ID.KEY)));
			checkDatas.add(issueData);
		}
		doValidateMap(checkDatas);
		issuesChangeInfo.setConflicts(updateIssueWithParent(checkDatas));
//		if (issuesChangeInfo.hasProjects()) {
//			List<Integer> projects = issuesChangeInfo.getProjects();
//			for (int i = 0; i < projects.size(); i++) {
//				ControlDbMemory.getInstance().refreshProjects(projects.get(i), context.getSessionData().getUserInfo().getId());
//			}
//		}
		
		Map<String, Object> resultMap = Maps.newHashMap();
		
		if (issuesChangeInfo.hasConflicts()) {
			resultMap.put("conflicts", issuesChangeInfo.getConflicts());
		} else {
			Map<String, Object> datas = Maps.newHashMap();
			
			for (int i = 0; i < checkDatas.size(); i++) {
				Map<String, Object> data = checkDatas.get(i);
				datas.put(StringUtils.toString(data.get(IssueKey.ISSUE_ID.KEY)), getPortalResultMap(data));
			}
			resultMap.put("refreshDatas", datas);
		}
		context.getResultBean().setData(resultMap);
	}
	
	public void ganttInit() throws SoftbankException {
		context.getResultBean().setData(DateUtils.getNowTime());
	}
	
	public void watchIssueChange() throws SoftbankException {
		context.getResultBean().setData("0");
		String watcher = context.getParam().get("watcher");
		if (StringUtils.isEmpty(watcher)) {
			return;
		}
		JSONArray watcherArray = JSONArray.fromObject(watcher);
		for (int i = 0; i < watcherArray.size(); i++) {
			JSONObject project = watcherArray.getJSONObject(i);
			TimestampData timestampData = ControlDbMemory.getInstance().getTimestampMap().get(project.getInt("project_id"));
			if (timestampData == null || timestampData.isSkip()) {
				continue;
			}
			Date projectDate = timestampData.getTimestamp();
			if (projectDate == null) {
				continue;
			}
			long projectTimestamp = projectDate.getTime();
			long currentTimestamp = project.getLong("timestamp");
			if (projectTimestamp > currentTimestamp) {
				List<Integer> userList = timestampData.getUserList();
				if (userList != null && userList.size() == 1 && userList.get(0) == getUserInfos().getId()) {
					continue;
				}
				context.getResultBean().setData("1");
				return;
			}
		}
	}
	
	public void getProjectTimestamp() throws SoftbankException {
		context.getResultBean().setData(getProjectWatcher());
	}
	
	public LogicBean checkAssignedTo(Map<String, Object> param) throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		if (!ControlSettingMap.getInstance().isAssignedRequired(context.getParam().projectId)) {
			return logicBean;
		}
		if (StringUtils.isEmpty(param.get(IssueKey.ASSIGNED_TO_ID.KEY))) {
			logicBean.setResultFlg(false);
			logicBean.setResultCode("errors.required");
		}
		return logicBean;
	}

	public class IssuesChangeInfo {
		private int projectId;
		private int rootSeq;
		private int left;
		private int right;
		private List<Map<String, Object>> adds = Lists.newArrayList();
		private List<Map<String, Object>> updates = Lists.newArrayList();
		private List<Map<String, Object>> deletes = Lists.newArrayList();
		private List<String> roots = Lists.newArrayList();
		private List<Map<String, Object>> conflicts = Lists.newArrayList();
		private List<Integer> projects = Lists.newArrayList();
		
		private Map<String, List<String>> orderMap = Maps.newHashMap();
		private Map<String, Map<String, Object>> dataMap = Maps.newHashMap();
		private List<String> rootList = Lists.newArrayList();
		
		private JSONObject projectMap;
		private JSONObject rootMap;
		private Map<String, Object> changeRootMap;
	
		public int prevFloor;
	
		private Stack<Map<String, Object>> parentNode = new Stack<Map<String, Object>>();
		
		public void init() {
			left = 0;
			right = 0;
			prevFloor = 0;
		}
		
		/**
		 * 
		 * @param data 
		 * @return
		 * @throws SoftbankException 
		 */
		public Map<String, Object> createIssueMap(JSONObject data) throws SoftbankException {
			return createIssueMap(data, null);
		}
		
		/**
		 * 
		 * @param data 
		 * @return
		 * @throws SoftbankException 
		 */
		public Map<String, Object> createIssueMap(JSONObject data, Map<Integer, Map<String, Object>> issuesMap) throws SoftbankException {
			Map<String, Object> result = Maps.newHashMap();
			final Map<Integer, Object> customValues = Maps.newHashMap();
			
			String issueId = data.getString(IssueKey.ISSUE_ID.KEY_JSON);
			result.put(IssueKey.ISSUE_ID.KEY, issueId);
			
			if (data.containsKey(IssueKey.PROCESS.ISDELETE)) {
				result.put(IssueKey.PROCESS.ISDELETE, true);
				return result;
			}
			
			String pid = data.getString(IssueKey.PROCESS.FLOOR_ID);
			String[] pids = pid.split(ConstantsUtil.Str.SPACE);
			int projectId = 0;
			if (pids[1].startsWith("p") && pids[1].indexOf("v") == -1) {
				projectId = StringUtils.toInt(pids[1].substring(1));
			} else if (pids[0].startsWith("p") && pids[0].indexOf("v") == -1) {
				projectId = StringUtils.toInt(pids[0].substring(1));
			}
			if (data.containsKey(IssueKey.PROCESS.ADDFLG)) {
				result.put(IssueKey.PROCESS.ADDFLG, true);
				if (data.containsKey(IssueKey.AUTHOR_ID.KEY_JSON)) {
					result.put(IssueKey.AUTHOR_ID.KEY, data.getString(IssueKey.AUTHOR_ID.KEY_JSON));
				} else {
					result.put(IssueKey.AUTHOR_ID.KEY, ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId());
				}
			} else {
				if (data.containsKey(IssueKey.PROCESS.ISUPDATE)) {
					result.put(IssueKey.PROCESS.ISUPDATE, true);
					int tid = StringUtils.toInt(issueId);
					Map<String, Object> issueData = null;
					if (issuesMap != null) {
						issueData = issuesMap.get(tid);
					} else {
						issueData = getTicketById(tid, projectId);
					}
					for (String key : issueData.keySet()) {
						if (key.startsWith(IssueKey.CUSTOMVALUES.KEY_JSON)) {
							int cusKey = StringUtils.toInt(key.substring(IssueKey.CUSTOMVALUES.KEY_JSON.length()));
							if (data.containsKey(key)) {
								customValues.put(cusKey, data.get(key));
							} else {
								customValues.put(cusKey, issueData.get(key));
							}
						}
					}
					result.put(IssueKey.DESCRIPTION.KEY, issueData.get(IssueKey.DESCRIPTION.KEY_MAP));
				}
			}
			
			if (data.containsKey(IssueKey.PROCESS.ISPARENT)) {
				result.put(IssueKey.PROCESS.ISPARENT, true);
			}
			
			result.put(IssueKey.PROJECT_ID.KEY, projectId);
			result.put(IssueKey.PROCESS.FLOOR_ID, pid);
			
			if (data.containsKey(IssueKey.TRACKER_ID.KEY_JSON)) {
				result.put(IssueKey.TRACKER_ID.KEY, data.getString(IssueKey.TRACKER_ID.KEY_JSON));
			}
			
			if (data.containsKey(IssueKey.PROCESS.WATCHER_USER_IDS)) {
				result.put(IssueKey.PROCESS.WATCHER_USER_IDS, data.getString(IssueKey.PROCESS.WATCHER_USER_IDS));
			}
			
			if (data.containsKey(IssueKey.PROCESS.NOTES)) {
				result.put(IssueKey.PROCESS.NOTES, data.getString(IssueKey.PROCESS.NOTES));
			}
			
			if (data.containsKey(IssueKey.SUBJECT.KEY_JSON)) {
				result.put(IssueKey.SUBJECT.KEY, data.getString(IssueKey.SUBJECT.KEY_JSON));
			}
			
			if (data.containsKey(IssueKey.DESCRIPTION.KEY_JSON)) {
				result.put(IssueKey.DESCRIPTION.KEY, data.getString(IssueKey.DESCRIPTION.KEY_JSON));
			} else {
				if (StringUtils.isEmpty(result.get(IssueKey.DESCRIPTION.KEY))) {
					result.put(IssueKey.DESCRIPTION.KEY, IssueKey.PROCESS.NOT_CHANGED);
				} else {
					result.put(IssueKey.DESCRIPTION.KEY, null);
				}
			}
			
			if (data.containsKey(IssueKey.DUE_DATE.KEY_JSON)) {
				result.put(IssueKey.DUE_DATE.KEY, data.getString(IssueKey.DUE_DATE.KEY_JSON));
			}
			
			if (data.containsKey(IssueKey.CATEGORY_ID.KEY_JSON)) {
				result.put(IssueKey.CATEGORY_ID.KEY, data.getString(IssueKey.CATEGORY_ID.KEY_JSON));
			} else {
				result.put(IssueKey.CATEGORY_ID.KEY, IssueKey.PROCESS.NOT_CHANGED);
			}
			
			if (data.containsKey(IssueKey.STATUS_ID.KEY_JSON)) {
				result.put(IssueKey.STATUS_ID.KEY, data.getString(IssueKey.STATUS_ID.KEY_JSON));
			}
			
			if (data.containsKey(IssueKey.ASSIGNED_TO_ID.KEY_JSON)) {
				result.put(IssueKey.ASSIGNED_TO_ID.KEY, data.getString(IssueKey.ASSIGNED_TO_ID.KEY_JSON));
			}
			
			if (data.containsKey(IssueKey.PRIORITY_ID.KEY_JSON)) {
				result.put(IssueKey.PRIORITY_ID.KEY, data.getString(IssueKey.PRIORITY_ID.KEY_JSON));
			}
			
			if (data.containsKey(IssueKey.FIXED_VERSION_ID.KEY_JSON)) {
				if (StringUtils.isEmpty(data.getString(IssueKey.FIXED_VERSION_ID.KEY_JSON))) {
					result.put(IssueKey.FIXED_VERSION_ID.KEY, null);
				} else {
					result.put(IssueKey.FIXED_VERSION_ID.KEY, data.getString(IssueKey.FIXED_VERSION_ID.KEY_JSON));
				}
			} else {
				result.put(IssueKey.FIXED_VERSION_ID.KEY, null);
			}
			
			if (data.containsKey(IssueKey.START_DATE.KEY_JSON)) {
				result.put(IssueKey.START_DATE.KEY, data.getString(IssueKey.START_DATE.KEY_JSON));
			}
			
			if (data.containsKey(IssueKey.DONE_RATIO.KEY_JSON)) {
				result.put(IssueKey.DONE_RATIO.KEY, data.getString(IssueKey.DONE_RATIO.KEY_JSON));
			}
			
			if (data.containsKey(IssueKey.ESTIMATED_HOURS.KEY_JSON)) {
				result.put(IssueKey.ESTIMATED_HOURS.KEY, data.getString(IssueKey.ESTIMATED_HOURS.KEY_JSON));
			}
			
			if (data.containsKey(IssueKey.PARENT_ID.KEY_JSON)) {
				result.put(IssueKey.PARENT_ID.KEY, data.getString(IssueKey.PARENT_ID.KEY_JSON));
			}
			
			if (data.containsKey(IssueKey.ROOT_ID.KEY_JSON)) {
				String rootId = data.getString(IssueKey.ROOT_ID.KEY_JSON);
				if (rootId.startsWith("p") || rootId.startsWith("v")) {
					rootId = "";
				}
				result.put(IssueKey.ROOT_ID.KEY, rootId);
			}
			
			if (data.containsKey(IssueKey.LFT.KEY_JSON)) {
				result.put(IssueKey.LFT.KEY, data.getString(IssueKey.LFT.KEY_JSON));
			}
			
			if (data.containsKey(IssueKey.RGT.KEY_JSON)) {
				result.put(IssueKey.RGT.KEY, data.getString(IssueKey.RGT.KEY_JSON));
			}
			
			if (data.containsKey(IssueKey.ROOT_SEQ.KEY_JSON)) {
				result.put(IssueKey.ROOT_SEQ.KEY, data.getString(IssueKey.ROOT_SEQ.KEY_JSON));
			}
			
			if (data.containsKey(IssueKey.ORGANIZATION_CD.KEY_JSON)) {
				result.put(IssueKey.ORGANIZATION_CD.KEY, data.getString(IssueKey.ORGANIZATION_CD.KEY_JSON));
			}
			
			if (data.containsKey(IssueKey.LOCK_VERSION.KEY_JSON)) {
				result.put(IssueKey.LOCK_VERSION.KEY, data.getString(IssueKey.LOCK_VERSION.KEY_JSON));
			}
			
			for (Object key : data.keySet()) {
				String keyString = StringUtils.toString(key);
				if (keyString.startsWith(IssueKey.CUSTOMVALUES.KEY_JSON)) {
					int cusKey = StringUtils.toInt(keyString.substring(IssueKey.CUSTOMVALUES.KEY_JSON.length()));
					customValues.put(cusKey, data.get(key));
				}
			}
			
			result.put(IssueKey.CUSTOMVALUES.KEY, customValues);
			
			return result;
		}
	
		public int getProjectId() {
			return projectId;
		}
	
		public void setProjectId(int projectId) {
			this.projectId = projectId;
		}
	
		public int getRootSeq() {
			return rootSeq;
		}
	
		public void setRootSeq(int rootSeq) {
			this.rootSeq = rootSeq;
		}
	
		public int getLeft() {
			return left;
		}
	
		public void setLeft(int left) {
			this.left = left;
		}
	
		public int getRight() {
			return right;
		}
	
		public void setRight(int right) {
			this.right = right;
		}
	
		public void leftIncrease() {
			this.left++;
		}
	
		public void rightIncrease() {
			this.right = ++this.left;
		}
	
		public void rootSeqIncrease() {
			this.rootSeq++;
		}
	
		public boolean isLeftChange(int l) {
			return this.left != l;
		}
	
		public boolean isRightChange(int r) {
			return this.right != r;
		}
	
		public boolean isRootSeqChange(int rs) {
			return this.rootSeq != rs;
		}
	
		public List<Map<String, Object>> getAdds() {
			return adds;
		}
		
		public boolean hasAdds() {
			return adds != null && adds.size() > 0;
		}
	
		public List<Map<String, Object>> getUpdates() {
			return updates;
		}
		
		public boolean hasUpdates() {
			return updates != null && updates.size() > 0;
		}
		
		public boolean hasRoots() {
			return roots != null && roots.size() > 0;
		}
	
		public List<Map<String, Object>> getDeletes() {
			return deletes;
		}
		
		public List<String> getRoots() {
			return roots;
		}
		
		public List<Map<String, Object>> getConflicts() {
			return conflicts;
		}
		
		public void setConflicts(List<Map<String, Object>> conflicts) {
			this.conflicts = conflicts;
		}
	
		public List<Integer> getProjects() {
			return projects;
		}
		
		public boolean hasDeletes() {
			return deletes != null && deletes.size() > 0;
		}
		
		public boolean hasConflicts() {
			return conflicts != null && conflicts.size() > 0;
		}
		
		public boolean hasProjects() {
			return projects != null && projects.size() > 0;
		}
	
		public void putAddIssue(Map<String, Object> issue) {
			this.adds.add(issue);
		}
	
		public void putUpdateIssue(Map<String, Object> issue) {
			this.updates.add(issue);
		}
		
		public void putConflict(Map<String, Object> issueData) {
			Map<String, Object> data = Maps.newHashMap();
			data.put(IssueKey.ISSUE_ID.KEY, issueData.get(IssueKey.ISSUE_ID.KEY));
			data.put(IssueKey.SUBJECT.KEY, issueData.get(IssueKey.SUBJECT.KEY));
			this.conflicts.add(data);
		}
	
		public void putRoot(String rootId) {
			if (!roots.contains(rootId)) {
				this.roots.add(rootId);
			}
		}
		
		public void putProject(Integer projectId) {
			if (!projects.contains(projectId)) {
				this.projects.add(projectId);
			}
		}
		
		public void putDeleteIssue(Map<String, Object> issue) {
			this.deletes.add(issue);
		}
	
		public void addParentNode(Map<String, Object> node) {
			this.parentNode.push(node);
		}
	
		public Map<String, Object> deleteParentNode() {
			if (parentNode.size() == 0) {
				return null;
			}
			return this.parentNode.pop();
		}
	
		public Map<String, List<String>> getOrderMap() {
			return orderMap;
		}
	
		public Map<String, Map<String, Object>> getDataMap() {
			return dataMap;
		}
	
		public List<String> getRootList() {
			return rootList;
		}
	
		public JSONObject getProjectMap() {
			return projectMap;
		}
	
		public void setProjectMap(JSONObject projectMap) {
			this.projectMap = projectMap;
		}
	
		public JSONObject getRootMap() {
			return rootMap;
		}
	
		public void setRootMap(JSONObject rootMap) {
			this.rootMap = rootMap;
		}
	
		public Map<String, Object> getChangeRootMap() {
			return changeRootMap;
		}
	
		public void setChangeRootMap(Map<String, Object> changeRootMap) {
			this.changeRootMap = changeRootMap;
		}
		
	}

	/**
	 * 競合かどうかと判断する
	 * @param conflictMap
	 * @param data
	 * @param issuesChangeInfo
	 * @return
	 */
	private boolean isConflict(Map<String, Integer> conflictMap, Map<String, Object> data, IssuesChangeInfo issuesChangeInfo) {
		String tid = StringUtils.toString(data.get(IssueKey.ISSUE_ID.KEY));
		String parentId = StringUtils.toString(data.get(IssueKey.PARENT_ID.KEY));
		if (conflictMap.containsKey(parentId)) {
			conflictMap.put(tid, 1);
			issuesChangeInfo.putConflict(data);
			return true;
		}
		return false;
	}

	private void updateColorInfos(JSONObject colorDatas) throws SoftbankException {
		db.update("issues_gantt_color.deleteIssuesGanttColorInfoByProject");
		if (colorDatas != null && colorDatas.size() > 0) {
			for (Object key : colorDatas.keySet()) {
				Map<String, Object> colorMap = Maps.newHashMap();
				JSONObject colorData = colorDatas.getJSONObject(StringUtils.toString(key));
				if (StringUtils.toString(key).startsWith("n")) {
					continue;
				}
				colorMap.put("issue_id", StringUtils.toInt(key));
				JSONObject bgcolor = colorData.getJSONObject("z10");
				if (!bgcolor.isEmpty()) {
					colorMap.put("background_color", bgcolor.toString());
				}
				JSONObject ftcolor = colorData.getJSONObject("z11");
				if (!ftcolor.isEmpty()) {
					colorMap.put("font_color", ftcolor.toString());
				}
				db.insert("issues_gantt_color.insertIssuesGanttColorInfo", colorMap);
			}
		}
	}
	
	private void updateMilestoneInfos(JSONArray milestonesDatas) throws SoftbankException {
		db.update("milestones.deleteMilestoneInfoByProjectId");
		if (milestonesDatas != null && milestonesDatas.size() > 0) {
			for (int i = 0; i < milestonesDatas.size(); i++) {
				JSONObject data = milestonesDatas.getJSONObject(i);
				Map<String, Object> condition = Maps.newHashMap();
				condition.put("project_id", data.getInt("project_id"));
				condition.put("milestone_date", DateUtils.formatToDate(data.getString("milestone_date"), DateUtils.FORMAT_YYYYMMDD_DASH));
				condition.put("color", data.getInt("color"));
				condition.put("comment", data.getString("comment"));
				condition.put("display", data.getBoolean("display"));
				db.insert("milestones.addMilestoneInfo", condition);
			}
		}
	}
	
	private String renderIssueId(Map<String, Integer> addIdMap, String issueId) {
		if (addIdMap.containsKey(issueId)) {
			return StringUtils.toString(addIdMap.get(issueId));
		}
		return issueId;
	}
	
	private void renderParentId(Map<String, Integer> addIdMap, Map<String, Object> data, int newId) {
		String oldId = StringUtils.toString(data.get(IssueKey.ISSUE_ID.KEY));
		String parentId = StringUtils.toString(data.get(IssueKey.PARENT_ID.KEY));
		String rootId = StringUtils.toString(data.get(IssueKey.ROOT_ID.KEY));
		if (newId != 0) {
			data.put(IssueKey.ISSUE_ID.KEY, newId);
			addIdMap.put(oldId, newId);
		}
		if (addIdMap.containsKey(parentId)) {
			data.put(IssueKey.PARENT_ID.KEY, addIdMap.get(parentId));
		}
		if (rootId.startsWith("n")) {
			if (addIdMap.containsKey(rootId)) {
				data.put(IssueKey.ROOT_ID.KEY, StringUtils.toString(addIdMap.get(rootId)));
			} else if (oldId.equals(rootId)) {
				data.put(IssueKey.ROOT_ID.KEY, IssueKey.PROCESS.NOT_CHANGED);
			}
		}
	}
	
	private Map<String, Object> createRefreshDatas(IssuesChangeInfo issuesChangeInfo) {
		Map<String, Object> datas = Maps.newHashMap();
		if (issuesChangeInfo.hasAdds()) {
			List<Map<String, Object>> adds = issuesChangeInfo.getAdds();
			for (int i = 0; i < adds.size(); i++) {
				Map<String, Object> data = adds.get(i);
				datas.put(StringUtils.toString(data.get(IssueKey.ISSUE_ID.KEY)), getResultMap(data, false));
			}
		}
		
		if (issuesChangeInfo.hasUpdates()) {
			List<Map<String, Object>> updates = issuesChangeInfo.getUpdates();
			for (int i = 0; i < updates.size(); i++) {
				Map<String, Object> data = updates.get(i);
				datas.put(StringUtils.toString(data.get(IssueKey.ISSUE_ID.KEY)), getResultMap(data, true));
			}
		}
		return datas;
	}
	
	private Map<String, Object> getPortalResultMap(Map<String, Object> data) {
		Map<String, Object> result = Maps.newHashMap();
		result.put(IssueKey.LOCK_VERSION.KEY_JSON, getLockVersion(data, true));
		return result;
	}
	
	private Map<String, Object> getResultMap(Map<String, Object> data, boolean isUpdate) {
		Map<String, Object> result = Maps.newHashMap();
		result.put(IssueKey.LFT.KEY_JSON, data.get(IssueKey.LFT.KEY));
		result.put(IssueKey.RGT.KEY_JSON, data.get(IssueKey.RGT.KEY));
		result.put(IssueKey.ROOT_SEQ.KEY_JSON, data.get(IssueKey.ROOT_SEQ.KEY));
		result.put(IssueKey.LOCK_VERSION.KEY_JSON, getLockVersion(data, isUpdate));
		return result;
	}
	
	private int getLockVersion(Map<String, Object> data, boolean isUpdate) {
		if (!isUpdate) {
			return 0;
		}
		int version = StringUtils.toInt(data.get(IssueKey.LOCK_VERSION.KEY));
		if (data.containsKey(IssueKey.PROCESS.ONLY_ORDER_CHANGED)) {
			return version;
		}
		return ++version;
	}
	
	private List<Map<String, Object>> getProjectWatcher()
			throws SoftbankException {
		List<Map<String, Object>> resultList = Lists.newArrayList();
		Map<String, Object> conditions = Maps.newHashMap();
		resultList.add(getProjectTimestamp(context.getParam().projectId));
		conditions.put("project_id", context.getParam().projectId);
		List<Map<String, Object>> projectInfos = db.querys("projects.getProjectIdByParent", conditions);
		if (projectInfos != null) {
			for (int i = 0; i < projectInfos.size(); i++) {
				Map<String, Object> data = projectInfos.get(i);
				resultList.add(getProjectTimestamp(StringUtils.toInt(data.get("id"))));
			}
		}
		return resultList;
	}
	
	private Map<String, Object> getProjectTimestamp(int projectId) throws SoftbankException {
		Map<String, Object> result = Maps.newHashMap();
		Date timestamp = ControlDbMemory.getInstance().getTimestampMap().get(projectId).getTimestamp();
		if (timestamp == null) {
			timestamp = new Date();
		}
		result.put("project_id", projectId);
		result.put("timestamp", timestamp.getTime());
		return result;
	}
	
	/**
	 * チケットの順番を整理する
	 * 
	 * @param ganttJsonArray 
	 * @param issuesChangeInfo 
	 * @throws SoftbankException 
	 */
	private boolean sortTicket(JSONObject ganttJsonObject, IssuesChangeInfo issuesChangeInfo, long currentToken, UpdateTicketBean updateTicketBean) throws SoftbankException {
		List<Map<String, Object>> checkDatas = Lists.newArrayList();
		JSONArray issuesDatas = ganttJsonObject.getJSONArray("a");
		if (issuesDatas.size() == 0) {
			return false;
		}
		JSONObject changedMap = ganttJsonObject.getJSONObject("c");
		JSONObject projectMap = changedMap.getJSONObject("project");
		JSONObject rootMap = changedMap.getJSONObject("root");
		issuesChangeInfo.setProjectMap(projectMap);
		issuesChangeInfo.setRootMap(rootMap);
		Map<Integer, Map<String, Object>> issuesMap = createDbIssuesMap(issuesDatas);
		updateTicketBean.setIssuesMap(issuesMap);
		for (int i = 0; i < issuesDatas.size(); i++) {
			JSONObject data = issuesDatas.getJSONObject(i);
			String tid = data.getString(IssueKey.ISSUE_ID.KEY_JSON);
			Map<String, Object> issueData = issuesChangeInfo.createIssueMap(data, issuesMap);
			if (data.containsKey(IssueKey.PROCESS.ISDELETE)) {
				toAction(issuesChangeInfo, issueData, currentToken);
				continue;
			}
			if (issueData.containsKey(IssueKey.PROCESS.ISUPDATE) || issueData.containsKey(IssueKey.PROCESS.ADDFLG)) {
				checkDatas.add(issueData);
			}
			issuesChangeInfo.getDataMap().put(tid, issueData);
			if (projectMap.containsKey(StringUtils.toString(issueData.get(IssueKey.PROJECT_ID.KEY))) 
					|| rootMap.containsKey(StringUtils.toString(issueData.get(IssueKey.ROOT_ID.KEY)))) {
				String pid = data.getString(IssueKey.PROCESS.FLOOR_ID);
				if (isRoot(data)) {
					issuesChangeInfo.getRootList().add(tid);
				} else {
					String[] pids = pid.split(ConstantsUtil.Str.SPACE);
					String parentID = pids[pids.length - 2];
					if (!issuesChangeInfo.getOrderMap().containsKey(parentID)) {
						List<String> parentList = Lists.newArrayList();
						issuesChangeInfo.getOrderMap().put(parentID, parentList);
					}
					issuesChangeInfo.getOrderMap().get(parentID).add(tid);
				}
				List<String> parentList = Lists.newArrayList();
				issuesChangeInfo.getOrderMap().put(tid, parentList);
			} else {
				if (issueData.containsKey(IssueKey.PROCESS.ISUPDATE) || issueData.containsKey(IssueKey.PROCESS.ADDFLG)) {
					issueData.put(IssueKey.PROCESS.DATA_IS_CHANGED, true);
					toAction(issuesChangeInfo, issueData, currentToken);
				}
			}
		}
		doValidateMap(checkDatas);
		return true;
	}

	/**
	 * 画面のチケットIDによりチケット情報を検索する
	 * @param issuesDatas
	 * @return
	 * @throws SoftbankException
	 */
	private Map<Integer, Map<String, Object>> createDbIssuesMap(JSONArray issuesDatas) throws SoftbankException {
		Map<Integer, Map<String, Object>> result = Maps.newHashMap();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", context.getParam().projectId);
		List<Map<String, Object>> customFields = db.querysC("issues.getCustomFieldsForIssues", conditions);
		conditions.put("customFields", customFields);
		List<Map<String, Object>> issueDatas = null;
		if (issuesDatas.size() > UPDATE_ISSUE_LIMIT) {
			issueDatas = db.querys("issues.getTicketAllInfoByProjectId", conditions);
		} else {
			List<Integer> idList = Lists.newArrayList();
			for (int i = 0; i < issuesDatas.size(); i++) {
				String tid = issuesDatas.getJSONObject(i).getString(IssueKey.ISSUE_ID.KEY_JSON);
				if (!tid.startsWith("n")) {
					idList.add(StringUtils.toInt(tid));
				}
			}
			if (idList.size() > 0) {
				conditions.put("idList", idList);
				issueDatas = db.querys("issues.getTicketAllInfoByIds", conditions);
			}
		}
		if (issueDatas != null) {
			for (int i = 0; i < issueDatas.size(); i++) {
				Map<String, Object> data = issueDatas.get(i);
				result.put(StringUtils.toInt(data.get("issue_id")), data);
			}
		}
		return result;
	}
	
	/**
	 * チケットデータを分析する
	 * 
	 * @param tid チケットID
	 * @param issuesChangeInfo 
	 * @param isRoot ルートフラグ
	 * @throws SoftbankException 
	 */
	private void analyzeIssuse(String tid, IssuesChangeInfo issuesChangeInfo, boolean isRoot, long currentToken) throws SoftbankException {
		Map<String, Object> issueData = issuesChangeInfo.getDataMap().get(tid);
		String proId = StringUtils.toString(issueData.get(IssueKey.PROJECT_ID.KEY));
		int rootSeq = 0;
		if (issueData.containsKey(IssueKey.ROOT_SEQ.KEY) 
				&& StringUtils.isNotEmpty(issueData.get(IssueKey.ROOT_SEQ.KEY)) 
				&& !"null".equals(StringUtils.toString(issueData.get(IssueKey.ROOT_SEQ.KEY)))) {
			rootSeq = StringUtils.toInt(issueData.get(IssueKey.ROOT_SEQ.KEY));
		}
		if (isRoot && !issuesChangeInfo.getProjectMap().containsKey(proId) 
				&& issuesChangeInfo.getRootMap().containsKey(tid)) {
			issuesChangeInfo.setRootSeq(rootSeq - 1);
			issuesChangeInfo.setProjectId(StringUtils.toInt(proId));
		} else {
			if (issuesChangeInfo.getProjectId() != StringUtils.toInt(proId)) {
				issuesChangeInfo.setRootSeq(0);
				issuesChangeInfo.setProjectId(StringUtils.toInt(proId));
			}
		}
		
		if (issueData.containsKey(IssueKey.PROCESS.ISDELETE)) {
			toAction(issuesChangeInfo, issueData, currentToken);
			return;
		}
		int left = 0;
		int right = 0;
		if (issueData.containsKey(IssueKey.LFT.KEY) 
				&& StringUtils.isNotEmpty(issueData.get(IssueKey.ROOT_SEQ.KEY)) 
				&& !"null".equals(StringUtils.toString(issueData.get(IssueKey.ROOT_SEQ.KEY)))) {
			left = StringUtils.toInt(issueData.get(IssueKey.LFT.KEY));
		}
		if (issueData.containsKey(IssueKey.RGT.KEY) 
				&& StringUtils.isNotEmpty(issueData.get(IssueKey.ROOT_SEQ.KEY)) 
				&& !"null".equals(StringUtils.toString(issueData.get(IssueKey.ROOT_SEQ.KEY)))) {
			right = StringUtils.toInt(issueData.get(IssueKey.RGT.KEY));
		}
		
		if (issueData.containsKey(IssueKey.PROCESS.ADDFLG)) {
			toAction(issuesChangeInfo, issueData, currentToken);
		}
		
		if (issueData.containsKey(IssueKey.PROCESS.ISUPDATE)) {
			issueData.put(IssueKey.PROCESS.DATA_IS_CHANGED, true);
			toAction(issuesChangeInfo, issueData, currentToken);
		}
		
		// 階層数を取得する
		int floorInfo = getFloorInfo(issueData);
		
		// 前の階層数より現在の階層数を比較する
		if (issuesChangeInfo.prevFloor > floorInfo) {
			for (int i = 0; i < (issuesChangeInfo.prevFloor - floorInfo); i++) {
				if (!changeParentNode(issuesChangeInfo, currentToken)) {
					break;
				}
			}
		}
		
		issuesChangeInfo.prevFloor = floorInfo;
		
		if (isRoot) {
			issuesChangeInfo.rootSeqIncrease();
			issuesChangeInfo.init();
		}
		if (issuesChangeInfo.isRootSeqChange(rootSeq)) {
			issueData.put(IssueKey.ROOT_SEQ.KEY, issuesChangeInfo.getRootSeq());
			issueData.put(IssueKey.PROCESS.ISUPDATE, true);
			toAction(issuesChangeInfo, issueData, currentToken);
		}
		
		issuesChangeInfo.leftIncrease();
		
		if (issuesChangeInfo.isLeftChange(left)) {
			issueData.put(IssueKey.LFT.KEY, issuesChangeInfo.getLeft());
			issueData.put(IssueKey.PROCESS.ISUPDATE, true);
			toAction(issuesChangeInfo, issueData, currentToken);
		}
		
		//　親チケットない、子供場合
		if (issuesChangeInfo.getOrderMap().get(tid).size() == 0) {
			issuesChangeInfo.rightIncrease();
			if (issuesChangeInfo.isRightChange(right)) {
				issueData.put(IssueKey.RGT.KEY, issuesChangeInfo.getRight());
				issueData.put(IssueKey.PROCESS.ISUPDATE, true);
				toAction(issuesChangeInfo, issueData, currentToken);
			}
		} else {
			// 親チケット保存、ループ用
			issuesChangeInfo.addParentNode(issueData);
			List<String> childrenList = issuesChangeInfo.getOrderMap().get(tid);
			for (int i = 0; i < childrenList.size(); i++) {
				analyzeIssuse(childrenList.get(i), issuesChangeInfo, false, currentToken);
			}
		}
	}

	private boolean changeParentNode(IssuesChangeInfo issuesChangeInfo,
			long currentToken) throws SoftbankException {
		Map<String, Object> parentMap = issuesChangeInfo.deleteParentNode();
		if (parentMap == null) {
			return false;
		}
		int pright = StringUtils.toInt(parentMap.get(IssueKey.RGT.KEY));
		issuesChangeInfo.rightIncrease();
		if (issuesChangeInfo.isRightChange(pright)) {
			parentMap.put(IssueKey.RGT.KEY, issuesChangeInfo.getRight());
			parentMap.put(IssueKey.PROCESS.ISUPDATE, true);
			toAction(issuesChangeInfo, parentMap, currentToken);
		}
		return true;
	}
	
	private void changeAllParentNode(IssuesChangeInfo issuesChangeInfo, long currentToken) throws SoftbankException {
		while (changeParentNode(issuesChangeInfo, currentToken)) {
		}
	}
	
	/**
	 * ルートを判断する
	 * 
	 * @param data チケットデータ
	 * @return　判断結果
	 */
	private boolean isRoot(JSONObject data) {
		return !data.containsKey(IssueKey.PARENT_ID.KEY_JSON) || StringUtils.isEmpty(data.getString(IssueKey.PARENT_ID.KEY_JSON));
	}
	
	/**
	 * 階層数を取得する
	 * 
	 * @param data チケットデータ
	 * @return　階層数
	 */
	private int getFloorInfo(Map<String, Object> data) {
		String floorId = StringUtils.toString(data.get(IssueKey.PROCESS.FLOOR_ID));
		return floorId.split(ConstantsUtil.Str.SPACE).length;
	}
	
	/**
	 * 処理タイプを設定する
	 * 
	 * @param issuesChangeInfo 
	 * @param dataMap 
	 * @throws SoftbankException 
	 */
	private void toAction(IssuesChangeInfo issuesChangeInfo, Map<String, Object> dataMap, long currentToken) throws SoftbankException {
		if (dataMap.containsKey("added")) {
			return;
		}
		if (!checkRootToken(issuesChangeInfo, dataMap, currentToken)) {
			return;
		}
		issuesChangeInfo.putProject(StringUtils.toInt(dataMap.get(IssueKey.PROJECT_ID.KEY)));
		if (dataMap.containsKey(IssueKey.PROCESS.ADDFLG)) {
			issuesChangeInfo.putAddIssue(dataMap);
		} else if (dataMap.containsKey(IssueKey.PROCESS.ISDELETE)) {
			issuesChangeInfo.putDeleteIssue(dataMap);
		} else if (dataMap.containsKey(IssueKey.PROCESS.ISUPDATE)) {
			if (!dataMap.containsKey(IssueKey.PROCESS.DATA_IS_CHANGED)) {
				dataMap.put(IssueKey.PROCESS.ONLY_ORDER_CHANGED, true);
				String rootId = StringUtils.toString(dataMap.get(IssueKey.ROOT_ID.KEY));
				issuesChangeInfo.putRoot(rootId);
			} else {
				dataMap.remove(IssueKey.PROCESS.DATA_IS_CHANGED);
			}
			issuesChangeInfo.putUpdateIssue(dataMap);
		} 
		dataMap.put("added", true);
	}

	private boolean checkRootToken(IssuesChangeInfo issuesChangeInfo, Map<String, Object> dataMap, long currentToken)
		throws SoftbankException {
		if (!checkToken(currentToken, StringUtils.toString(dataMap.get(IssueKey.ROOT_ID.KEY)))) {
			issuesChangeInfo.putConflict(dataMap);
			return false;
		}
		return true;
	}
	
	private boolean checkToken(long currentToken, String root) throws SoftbankException {
		if (root.startsWith("n")) {
			return true;
		}
		int rootId = StringUtils.toInt(root);
		if (ControlDbMemory.getInstance().getRootToken(rootId) > currentToken) {
			return false;
		}
		return true;
	}

}
