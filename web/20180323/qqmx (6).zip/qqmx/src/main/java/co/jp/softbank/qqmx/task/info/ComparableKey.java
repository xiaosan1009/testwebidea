package co.jp.softbank.qqmx.task.info;

import java.util.Map;
import java.util.Map.Entry;
import java.util.TreeMap;

import co.jp.softbank.qqmx.task.face.IKey;

import com.google.common.base.MoreObjects;
import com.google.common.base.Objects;

public class ComparableKey<T> implements Comparable<T>, IKey {
	
	private Map<String, Comparable<?>> values = new TreeMap<String, Comparable<?>>();
	
	public ComparableKey<T> add(String name, Comparable<?> value) {
        values.put(name, value);
        return this;
    }
	
	public Map<String, Comparable<?>> getValues() {
        return new TreeMap<String, Comparable<?>>(values);
   }
	
	@Override
	public int hashCode() {
		return Objects.hashCode(values);
	}
	
	@SuppressWarnings("unchecked")
	@Override
	public boolean equals(Object obj) {
		if (!(obj instanceof ComparableKey)) {
            return false;
        }
        return Objects.equal(values, ((ComparableKey<T>) obj).values);
	}
	
	@Override
    public String toString() {
        MoreObjects.ToStringHelper helper = MoreObjects.toStringHelper(this);
        for (Entry<String, Comparable<?>> entry : values.entrySet()) {
            helper.add(entry.getKey(), entry.getValue());
        }
        return helper.toString();
    }

	@Override
	public int compareTo(T o) {
		if (o == null) {
            return -1;
        }
        return hashCode() - o.hashCode();
	}

}
