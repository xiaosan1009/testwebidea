package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.Map;

import com.google.common.collect.Maps;

//import co.jp.softbank.qqmx.dao.project.settings.prjectSetting;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;

public class UserRoleSettingLogic extends AbstractBaseLogic {

	public void deleteUserPublicRoleList() throws SoftbankException {
		int userId = context.getParam().getInt("user_id");
		String userType = context.getParam().get("user_type");
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("user_id", userId);
		if ("Group".equals(userType)) {
			db.delete("user_roles.deleteUserRoleByGroupId", conditions);
		} else {
			db.delete("user_roles.deleteUserRoleByUserId", conditions);
		}
	}
}
