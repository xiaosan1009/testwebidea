package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

//import co.jp.softbank.qqmx.dao.project.settings.ProjectActionDao;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.ControlDbMemory;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;

public class ActionLogic extends AbstractBaseLogic {
	
//	@Autowired
//	private ProjectActionDao projectActionDao;
	
	public LogicBean getProjectAction() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, Object> conditions = Maps.newHashMap();
		String projectIdString = context.getParam().get("projectId");
		conditions.put("project_id", Integer.parseInt(projectIdString));
		
		List<Map<String, Object>> enabledModulesList = db.querys("actionProject.getEnabledModules", conditions) ;
		Map<String, String> settingsMap = Maps.newHashMap();
		
		for (int i = 0; i < enabledModulesList.size(); i++) {
			Map<String, Object> settingsData = enabledModulesList.get(i);
			settingsMap.put(String.valueOf(settingsData.get("name")), String.valueOf(settingsData.get("name")));
		}

		resultMap.put("settings", settingsMap);
		resultMap.put("plugins", ControlDbMemory.getInstance().getPluginInfoBeans());
		logicBean.setData(resultMap);
		return logicBean;
	}
	
	public LogicBean saveProjectAction() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();

		final int projectId = Integer.parseInt(context.getParam().get("projectId"));
		log.info("projectId = " + projectId);
		
		Map<String, Object> conditionsDelete = Maps.newHashMap();
		conditionsDelete = Maps.newHashMap();
		conditionsDelete.put("project_id", projectId);
		db.delete("actionProject.deleteAction", conditionsDelete);
		
		
		String[] enabledModulesInfos = context.getParam().getList("project_enabled_selected_name");
		if (enabledModulesInfos != null) {
			List<Map<String, Object>> enabledModulesInfoList = Lists.newArrayList();
			for (int i = 0; i < enabledModulesInfos.length; i++) {
				Map<String, Object> enabledModulesInfo = Maps.newHashMap();
				enabledModulesInfo.put("name", enabledModulesInfos[i]);
				enabledModulesInfo.put("project_id", projectId);
				enabledModulesInfoList.add(enabledModulesInfo);
			}
			conditions = Maps.newHashMap();
			conditions.put("enabledModulesInfos", enabledModulesInfoList);
			db.insert("actionProject.insertEnabledModulesAction", conditions);
		}
		
		return logicBean;
	}
	
}
