package co.jp.softbank.qqmx.logic;

public class ScriptLogic extends AbstractBaseLogic {

}
