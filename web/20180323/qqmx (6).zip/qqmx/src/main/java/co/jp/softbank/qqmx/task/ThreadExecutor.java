package co.jp.softbank.qqmx.task;

import java.util.List;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;
import java.util.concurrent.atomic.AtomicInteger;

import co.jp.softbank.qqmx.task.bean.Worker;

import com.google.common.collect.Lists;

public class ThreadExecutor {
	
	private ThreadPoolExecutor executor;
	
	private int threads;
	
	private AtomicInteger lines;
	
	private List<Worker> workers = Lists.newLinkedList();
	
	public ThreadExecutor(int threads) {
		this.threads = threads;
		lines = new AtomicInteger(0);
		executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(threads, new ThreadFactory() {
            int count = 0;

            @Override
            public Thread newThread(Runnable r) {
                Thread t = new Thread(r);
                t.setName("line-worker-" + count++);
                return t;
            }
        });
	}

}
