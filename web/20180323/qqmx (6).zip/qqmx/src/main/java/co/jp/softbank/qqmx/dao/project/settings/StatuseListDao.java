package co.jp.softbank.qqmx.dao.project.settings;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.dao.IDaoInterface;

public interface StatuseListDao extends IDaoInterface {
	List<Map<String, Object>> getStatuseListInfo();
	List<Map<String, Object>> getStatuseListIdInfo(Map<String, Object> conditions);
	
	
	
	
	void delStatuseListId(Map<String, Object> conditions);
	void updataStatuses(Map<String, Object> conditions);
	void saveStatuses(Map<String, Object> conditions);
	void upStatuses(Map<String, Object> conditions);

	void upCommonMSort(Map<String, Object> conditions);
	void upCommonPSort(Map<String, Object> conditions);
	void upCommonSort(Map<String, Object> conditions);
}
