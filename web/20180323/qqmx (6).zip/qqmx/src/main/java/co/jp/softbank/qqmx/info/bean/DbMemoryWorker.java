package co.jp.softbank.qqmx.info.bean;

import co.jp.softbank.qqmx.info.ControlDbMemory;
import co.jp.softbank.qqmx.task.face.IWorker;

public class DbMemoryWorker implements IWorker {
    
    private ProjectWorkerBean workerBean;

    public DbMemoryWorker(ProjectWorkerBean workerBean) throws Exception {
        this.workerBean = workerBean;
    }
    
    public void cleanup() throws Exception {
    }
    
	@Override
	public DbMemoryWorker call() throws Exception {
		if (workerBean.getType() == null) {
			return this;
		}
		switch (workerBean.getType()) {
		case normal:
			ControlDbMemory.getInstance().refreshTickets(workerBean.getProjectId(), true);
			break;
		case watchable:
			ControlDbMemory.getInstance().refreshTicketsForWatchable(workerBean.getProjectId());
			break;
		case mit:
			ControlDbMemory.getInstance().refreshTicketsForMit(workerBean.getProjectId());
			break;

		default:
			break;
		}
        return this;
	}

	public ProjectWorkerBean getWorkerBean() {
		return workerBean;
	}

	public void setWorkerBean(ProjectWorkerBean workerBean) {
		this.workerBean = workerBean;
	}

}
