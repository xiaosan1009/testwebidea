package co.jp.softbank.qqmx.info.bean;

public class FilterRequestData {
	
	private String method;

	public String getMethod() {
		return method;
	}

	public void setMethod(String method) {
		this.method = method;
	}
	

}
