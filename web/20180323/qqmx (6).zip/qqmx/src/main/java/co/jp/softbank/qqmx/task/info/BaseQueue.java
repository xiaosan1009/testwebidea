package co.jp.softbank.qqmx.task.info;

import java.io.Closeable;
import java.io.IOException;
import java.util.AbstractQueue;
import java.util.Iterator;
import java.util.Queue;
import java.util.concurrent.ConcurrentLinkedQueue;

public abstract class BaseQueue<E> extends AbstractQueue<E> implements Closeable {
	
	private Queue<E> delegate;
	
	public BaseQueue() {
		this.delegate = new ConcurrentLinkedQueue<E>();
	}
	
	public Queue<E> getDelegate() {
        return delegate;
    }

	@Override
	public boolean offer(E e) {
		return delegate.offer(e);
	}

	@Override
	public E poll() {
		return delegate.poll();
	}

	@Override
	public E peek() {
		return delegate.peek();
	}

	@Override
	public void close() throws IOException {
		try {
            doClose();
        } finally {
            delegate.clear();
        }
	}

	@Override
	public Iterator<E> iterator() {
		return delegate.iterator();
	}

	@Override
	public int size() {
		return delegate.size();
	}
	
	protected abstract void doClose() throws IOException;

}
