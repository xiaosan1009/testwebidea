package co.jp.softbank.qqmx.dao.common.bean;

import java.util.Date;

import net.sf.json.JSONObject;

public class HolidaysBean implements DaoBeanInterface {
	
	private Date holiday;
	
	private String holidayStr;
	
	private String name;

	public Date getHoliday() {
		return holiday;
	}

	public void setHoliday(Date holiday) {
		this.holiday = holiday;
	}

	public String getHolidayStr() {
		return holidayStr;
	}

	public void setHolidayStr(String holidayStr) {
		this.holidayStr = holidayStr;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	@Override
	public void toJson(JSONObject dataObj) {
		dataObj.put("holiday", this.holidayStr);
		dataObj.put("name", this.name);
	}

	@Override
	public void setId(int id) {
	}

}
