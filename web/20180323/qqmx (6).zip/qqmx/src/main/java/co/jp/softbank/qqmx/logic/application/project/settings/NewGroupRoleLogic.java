package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.util.StringUtils;

public class NewGroupRoleLogic extends AbstractBaseLogic {

	public LogicBean getProjectSettingRoleList() throws SoftbankException {
		LogicBean groupBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();					 
		conditions.put("member_id", Integer.parseInt(context.getParam().get("memberId")));
		groupBean.setData(db.querys("newGroupRole.getProjectSettingRoleList", conditions));
		return groupBean;
	}
	
	public LogicBean saveProjectSettingRole() throws SoftbankException {
		LogicBean groupBean = new LogicBean();
		String membersId = context.getParam().get("memberId");
		String[] projectSettingRole = context.getParam().getList("user_role_fields_selected_name") ;
		if (projectSettingRole != null) {
			Map<String, Object> conditionsRole = Maps.newHashMap();
			conditionsRole.put("member_id", Integer.parseInt(membersId));
			List<Map<String, Object>> selectMemberUsersList = db.querys("newGroupRole.selectProjectSettingMemberUsers", conditionsRole);
			int project_id = context.getParam().getInt("project_id");
			if (selectMemberUsersList.size() != 0){
				db.delete("newGroupRole.deleteProjectSettingMemberUsers", conditionsRole);
			}
			for (int i = 0; i < projectSettingRole.length; i++) {
				conditionsRole.put("role_id", Integer.parseInt(projectSettingRole[i]));
				conditionsRole.put("inherited_from", null);
				db.insert("newGroupRole.insertProjectSettingMembers",conditionsRole);
				final int roleId = Integer.parseInt(StringUtils.toString(conditionsRole.get("id")));
				
				Map<String, Integer> conditionsMemberRole = Maps.newHashMap();
				conditionsMemberRole.put("member_id", Integer.parseInt(membersId));
				List<Map<String, Object>> selectGroupUserList = db.querys("newGroupRole.selectProjectSettingGroupMemberUsers",conditionsMemberRole);
				for (int m = 0; m < selectGroupUserList.size(); m++) {
					
					Map<String, Object> conditionsUser = Maps.newHashMap();
					conditionsUser.put("user_id", StringUtils.toInt(selectGroupUserList.get(m).get("user_id")));
					conditionsUser.put("project_id", project_id);
					List<Map<String, Object>> selectMemberGroupUsersId = db.querys("newGroupRole.selectProjectGroupMembers", conditionsUser);
					
					for (int n = 0; n < selectMemberGroupUsersId.size(); n++) {
						
						Map<String, Object> conditionsGroupUserMembers = Maps.newHashMap();
						conditionsGroupUserMembers.put("member_id", Integer.parseInt(String.valueOf(selectMemberGroupUsersId.get(n).get("id"))));
						db.delete("newGroupRole.deleteProjectSettingMemberUsers", conditionsGroupUserMembers);
						conditionsGroupUserMembers.put("role_id", Integer.parseInt(projectSettingRole[i]));
						conditionsGroupUserMembers.put("inherited_from", roleId);
						db.insert("newGroupRole.insertProjectSettingMembers" ,conditionsGroupUserMembers);
					}
				}
			}
		}
		return groupBean;
	}
}
