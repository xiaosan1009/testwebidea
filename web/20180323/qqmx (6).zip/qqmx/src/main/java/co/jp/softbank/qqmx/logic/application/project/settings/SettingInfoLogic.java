package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.yaml.snakeyaml.Yaml;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.PageListBean;
import co.jp.softbank.qqmx.logic.bean.Param;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.StringUtils;

public class SettingInfoLogic extends AbstractBaseLogic {
	
//	@Autowired
//	private newProject newProject;
	
	public void getRepositoriesList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String projectIdString = context.getParam().get("projectId");
		int project_id = Integer.parseInt(projectIdString);
		conditions.put("project_id", project_id);
		PageListBean pageListBean = pageList("settingInfo.getRepositoriesList", conditions);
		context.getResultBean().setData(pageListBean);
	}
	
	public void saveRepositorie() throws SoftbankException {
		String str_is_default = "";
		boolean is_default = false;
		String url = "";
		String login = "";
		String password = "";
		String root_url = "";
		String path_encoding = "";
		String log_encoding = "";
		String extra_info = "";
		String type = context.getParam().get("scm");
		String identifier = context.getParam().get("identifier");
		str_is_default = context.getParam().get("is_default");
		String projectIdString = context.getParam().get("projectId");
		if ("true".equals(str_is_default)){is_default = true;}
		
		if ("Subversion".equals(type)){
			url = context.getParam().get("url_sub");
			login = context.getParam().get("login");
			password = context.getParam().get("password");
		}else if ("Git".equals(type)){
			url = context.getParam().get("url_git");
			path_encoding = context.getParam().get("path_encoding");
			extra_info = context.getParam().get("extra_report_last_commit");
		}

		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", Integer.parseInt(projectIdString));
		conditions.put("url", url);
		conditions.put("login", login);
		conditions.put("password", password);
		conditions.put("root_url", root_url);
		conditions.put("type", type);
		conditions.put("path_encoding", path_encoding);
		conditions.put("log_encoding", log_encoding);
		conditions.put("extra_info", extra_info);
		conditions.put("identifier", identifier);
		conditions.put("is_default", is_default);
		
		String typeFlag = context.getParam().get("id");
		
		if ("undefined".equals(typeFlag)){
			db.insert("settingInfo.saveRepositorie" , conditions);
		}else{
			conditions.put("id", Integer.parseInt(typeFlag));
			db.update("settingInfo.updateRepositorie" , conditions);
		}
	}
	
	public void deleteRepositorie() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("repository_id", Integer.parseInt(context.getParam().get("repository_id")));
		db.delete("settingInfo.deleteRepositorie" , conditions);
	}
	
	public void editRepositorie() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("repository_id", Integer.parseInt(context.getParam().get("repository_id")));
		context.getResultBean().setData(db.querys("settingInfo.editRepositorie" , conditions));
	}
	
	
	public void getProjectInitInfo() throws SoftbankException {
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, Object> conditions = Maps.newHashMap();
		String projectIdString = context.getParam().get("projectId");
		int project_id = Integer.parseInt(projectIdString);
		conditions.put("projectId", project_id);
		
		resultMap.put("projectInfo", db.query("settingInfo.getProjectInfo", conditions));
		resultMap.put("section_msts", db.querys("section_msts.selectSectionMstsInfo"));
		context.getResultBean().setData(resultMap);
		
	}
	
	@SuppressWarnings("unchecked")
	public LogicBean getProjectCustomListInfo() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, String> settingsMap = Maps.newHashMap();
		String projectIdString = context.getParam().get("projectId");
		int project_id = Integer.parseInt(projectIdString);
		Map<String, Object> customFieldsBeanValues = Maps.newHashMap();
		customFieldsBeanValues.put("project_id", project_id);
		resultMap.put("customFields", db.querys("newProject.getCustomFieldsBeanValues", customFieldsBeanValues));
		// TODO project_id判断
		if ("".equals(project_id)){
			
			List<Map<String, Object>> settingsList = db.querys("newProject.getSettings");
			Map<String, Object> settingsData = settingsList.get(0);
			String settingsValue = StringUtils.toString(settingsData.get("value"));
			Yaml yaml = new Yaml();
			List<String> settingsList2 = (List<String>)yaml.load(settingsValue);
			for (int i = 0; i < settingsList2.size(); i++) {
				settingsMap.put(settingsList2.get(i), settingsList2.get(i));
			}
			resultMap.put("trackers", db.querys("newProject.getTrackers"));
			resultMap.put("issuesCustomFields",  db.querys("newProject.getIssuesCustomFields"));
		}else{
			Map<String, Object> conditions = Maps.newHashMap();
			Map<String, Object> enabledModulesMap = Maps.newHashMap();
			conditions.put("project_id", project_id);
			List<Map<String, Object>> enabledModulesList =  db.querys("newProject.getEnabledModules",conditions);
			for (int e = 0; e < enabledModulesList.size(); e++) {
				enabledModulesMap = enabledModulesList.get(e);
				settingsMap.put(StringUtils.toString(enabledModulesMap.get("name")), StringUtils.toString(enabledModulesMap.get("name")));
			}
			resultMap.put("trackers",  db.querys("newProject.getProjectTrackers",conditions));
			resultMap.put("issuesCustomFields",  db.querys("newProject.getProjectIssuesCustomFields", conditions));
		}
		
		resultMap.put("settings", settingsMap);
//		resultMap.put("plugins", ControlDbMemory.getInstance().getPluginInfoBeans());
		logicBean.setData(resultMap);
		return logicBean;
	}
	
	public void getProjectWiki() throws SoftbankException {
		String projectIdString = context.getParam().get("projectId");
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", Integer.parseInt(projectIdString));
		context.getResultBean().setData(db.querys("settingInfo.getProjectWikiInfo" , conditions));
	}
	
	public void deleteProjectWiki() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();

		String projectIdString = context.getParam().get("projectId");
		conditions = Maps.newHashMap();
		conditions.put("project_id", Integer.parseInt(projectIdString));
		db.delete("settingInfo.deleteWikisInfos" , conditions);
	}
	
	public void submitProjectInfo() throws SoftbankException {
		String flg = context.getParam().get("flgId");
		// INFOの場合
		if ("setting-tab-info".equals(flg)){
			Map<String, Object> conditions = Maps.newHashMap();
			Integer parentId = null;
			if (StringUtils.isNotEmpty(context.getParam().get("project_parent_id"))) {
				parentId = Integer.parseInt(context.getParam().get("project_parent_id"));
			}
			String projectIdString = context.getParam().get("projectId");
			conditions.put("project_id", Integer.parseInt(projectIdString));
			conditions.put("project_name", context.getParam().get("project_name"));
			conditions.put("project_parent_id", parentId);
			conditions.put("project_description", context.getParam().get("project_description"));
			conditions.put("project_identifier", context.getParam().get("project_identifier"));
			conditions.put("project_is_public", ("1".equals(context.getParam().get("project_is_public")) ? true : false));
			conditions.put("project_homepage", context.getParam().get("project_homepage"));
			conditions.put("project_landingpage", ConstantsUtil.Str.EMPTY);
			conditions.put("project_status", 1);
			
			List<Map<String, Object>> getSettingsProjectInfo = db.querys("newProject.getProjectInfo", conditions);
			
			String parent_id = StringUtils.toString(getSettingsProjectInfo.get(0).get("parent_id"));
			conditions.put("project_lft", StringUtils.toInt(getSettingsProjectInfo.get(0).get("lft")));
			conditions.put("project_rgt", StringUtils.toInt(getSettingsProjectInfo.get(0).get("rgt")));
			
			if (parentId == null) {
				if ( parent_id != "" ) {
					Map<String, Object> projectMapBakInfo = Maps.newHashMap();
					projectMapBakInfo.put("project_id", StringUtils.toInt(parent_id));
					List<Map<String, Object>> getSettingsProjectBakInfo = db.querys("newProject.getProjectInfo", projectMapBakInfo);
					int rgt = StringUtils.toInt(getSettingsProjectBakInfo.get(0).get("rgt"));
					projectMapBakInfo.put("project_rgt", rgt);
					
					db.update("newProject.upDelProjectInfos", projectMapBakInfo);
					
					conditions.put("project_lft", rgt - 1);
					conditions.put("project_rgt", rgt);
				}
			} else {
				Map<String, Object> projectMapNewInfo = Maps.newHashMap();
				Map<String, Object> projectMapBakInfo = Maps.newHashMap();
				projectMapNewInfo.put("project_id", parentId);
				List<Map<String, Object>> getSettingsProjectNewInfo = db.querys("newProject.getProjectInfo", projectMapNewInfo);
				if ( parent_id != "" ) {
					if (!parentId.equals(parent_id)) {
						
						projectMapBakInfo.put("project_id", StringUtils.toInt(parent_id));
						
						List<Map<String, Object>> getSettingsProjectBakInfo = db.querys("newProject.getProjectInfo", projectMapBakInfo);
						int new_rgt = StringUtils.toInt(getSettingsProjectNewInfo.get(0).get("rgt"));
						int bak_rgt = StringUtils.toInt(getSettingsProjectBakInfo.get(0).get("rgt"));
						if (new_rgt > bak_rgt) {
							projectMapBakInfo.put("project_rgt", bak_rgt);
							projectMapBakInfo.put("project_rgt_bak", new_rgt);
							db.update("newProject.upEditDelLftProjectInfos", projectMapBakInfo);
							db.update("newProject.upDelProjectInfos", projectMapBakInfo);
							
							projectMapNewInfo.put("project_rgt", new_rgt);
							db.update("newProject.upLftProjectInfos", projectMapNewInfo);
							projectMapNewInfo.put("project_rgt", new_rgt - 2);
							db.update("newProject.upProjectInfos", projectMapNewInfo);
							
							conditions.put("project_lft", new_rgt - 2);
							conditions.put("project_rgt", new_rgt - 2 + 1);
							
						} else {
							projectMapBakInfo.put("project_rgt", new_rgt);
							projectMapBakInfo.put("project_rgt_bak", bak_rgt);
							db.update("newProject.upEditLftProjectInfos", projectMapBakInfo);
							db.update("newProject.upProjectInfos", projectMapBakInfo);
							
//							projectMapNewInfo.put("project_rgt", bak_rgt);
//							db.update("newProject.upDelProjectInfos", projectMapNewInfo);
//							db.update("newProject.upDelLftProjectInfos", projectMapNewInfo);
							
							conditions.put("project_lft", new_rgt);
							conditions.put("project_rgt", new_rgt + 1);
						}
						
					}
				} else {
					Map<String, Object> projectMapInfo = Maps.newHashMap();
					int rgt = StringUtils.toInt(getSettingsProjectNewInfo.get(0).get("rgt"));
					int rgt1 = StringUtils.toInt(getSettingsProjectInfo.get(0).get("rgt"));
					
					Map<String, Object> projectMap1Info = Maps.newHashMap();
					projectMap1Info.put("project_rgt", rgt1);
					db.update("newProject.upDelLftProjectInfos", projectMap1Info);
					
					projectMapInfo.put("project_rgt", rgt);
					projectMapInfo.put("project_id", parentId);
					db.update("newProject.upLftProjectInfos", projectMapInfo);
					db.update("newProject.upProjectInfos", projectMapInfo);
					
					conditions.put("project_lft", rgt);
					conditions.put("project_rgt", rgt + 1);
				}
			}
			
			db.update("settingInfo.updateProjectInfo", conditions);
			
			// 統括部を更新
			Integer projectOrganizationId = null;
			
			if (StringUtils.isNotEmpty(context.getParam().get("project_organization_id"))) {
				projectOrganizationId = StringUtils.toInt(context.getParam().get("project_organization_id"));
			}
			conditions.put("project_organization_id", projectOrganizationId);
			db.update("newProject.upProjectRelation", conditions);
			
			context.getParam().each(new Param.EachFilter() {
				@Override
				public void filter(String key, String value) throws SoftbankException {
					if (key.startsWith("project_custom_field_values_")) {
						String pIdString = context.getParam().get("projectId");
						Map<String, Object> customValueInfo = Maps.newHashMap();
						customValueInfo.put("customized_id", Integer.parseInt(pIdString));
						customValueInfo.put("custom_field_id", Integer.parseInt(key.substring("project_custom_field_values_".length())));
						customValueInfo.put("value", value);
						List<Map<String, Object>> projectInfos = null;
						try {
							projectInfos = db.querys("settingInfo.selectProjectsCustomValues", customValueInfo);
						} catch (SoftbankException e) {
							e.printStackTrace();
						}
						if (projectInfos.size() == 0){
							db.insert("settingInfo.insertProjectsCustomValues", customValueInfo);
						}else{
							db.update("settingInfo.updateProjectsCustomValues", customValueInfo);
						}
					}
				}
			});
			
			String[] projectsTrackers = context.getParam().getList("tracker_ids_selected_name");
			if (projectsTrackers != null) {
				Map<String, Object> projectTrackers = Maps.newHashMap();
				projectTrackers.put("project_id", Integer.parseInt(projectIdString));
				db.delete("settingInfo.delProjectTrackerIds", projectTrackers);
				
				List<Map<String, Object>> projectsTrackerList = Lists.newArrayList();
				for (int i = 0; i < projectsTrackers.length; i++) {
					Map<String, Object> projectsTrackerInfo = Maps.newHashMap();
					projectsTrackerInfo.put("project_id", Integer.parseInt(projectIdString));
					projectsTrackerInfo.put("tracker_id", Integer.parseInt(projectsTrackers[i]));
					projectsTrackerList.add(projectsTrackerInfo);
				}
				conditions = Maps.newHashMap();
				conditions.put("projectsTrackers", projectsTrackerList);
				db.insert("newProject.insertProjectsTrackersInfos", conditions);
			}
			
			String[] customFields = context.getParam().getList("custom__selected_name");
			if (customFields != null) {
				Map<String, Object> projectIssueCustomFields = Maps.newHashMap();
				projectIssueCustomFields.put("project_id", Integer.parseInt(projectIdString));
				db.delete("settingInfo.delProjectIssueCustomFields", projectIssueCustomFields);
				
				List<Map<String, Object>> customFieldList = Lists.newArrayList();
				for (int i = 0; i < customFields.length; i++) {
					Map<String, Object> customFieldInfo = Maps.newHashMap();
					customFieldInfo.put("project_id", Integer.parseInt(projectIdString));
					customFieldInfo.put("custom_field_id", Integer.parseInt(customFields[i]));
					customFieldList.add(customFieldInfo);
				}
				conditions = Maps.newHashMap();
				conditions.put("customFields", customFieldList);
				db.insert("newProject.insertProjectsCustomFields", conditions);
			}
		} else if ("setting-tab-wiki".equals(flg)){
			Map<String, Object> conditions = Maps.newHashMap();
			
			String projectIdString = context.getParam().get("projectId");
			String start_page = context.getParam().get("wiki_start_page");
			String data_start_page = context.getParam().get("data_start_page");
			conditions = Maps.newHashMap();
			conditions.put("project_id", Integer.parseInt(projectIdString));
			conditions.put("start_page", start_page);
			
			if (!"".equals(data_start_page) && null != data_start_page){
				db.update("settingInfo.updateWikisInfos", conditions);
			}else{
				db.insert("settingInfo.insertWikisInfos", conditions);
			}
		}

	}
}
