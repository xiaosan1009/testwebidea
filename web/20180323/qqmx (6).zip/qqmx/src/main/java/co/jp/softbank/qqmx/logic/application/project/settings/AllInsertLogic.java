package co.jp.softbank.qqmx.logic.application.project.settings;

import java.io.File;
import java.util.Map;

import org.apache.commons.fileupload.FileItem;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.UploadFileInfo;

public class AllInsertLogic extends AbstractBaseLogic {

//	@Autowired
//	private AllInsertDao allInsertDao;
	
	private static final String UPLOAD_FILE_PATH = "userinsert";
	
	/**
	 * ユーザーデータのファイルを読み込む
	 * @throws SoftbankException 
	 */
	public void addUserInfo() throws SoftbankException {
		if (context.getUploadFileItems() != null && context.getUploadFileItems().size() > 0) {
			for (int i = 0; i < context.getUploadFileItems().size(); i++) {
				FileItem fileItem = context.getUploadFileItems().get(i);
				if (fileItem.getSize() > 0) {
					UploadFileInfo fileInfo = doUpload(fileItem, UPLOAD_FILE_PATH, UploadType.all);
					Map<String, Object> resultMap = Maps.newHashMap();
					resultMap.put("fileRealPath", fileInfo.getRealPath() + File.separator + fileInfo.getNewFileName());
					resultMap.put("fileRealName", fileInfo.getFileName());
					context.getResultBean().setData(resultMap);
				}
			}
		}
	}
	
}
