package co.jp.softbank.qqmx.task;

import co.jp.softbank.qqmx.task.face.IContextFactory;
import co.jp.softbank.qqmx.task.face.ITaskContext;

public class BasicContextFactory implements IContextFactory {

	@Override
	public ITaskContext getTaskContext() {
		BasicTaskContext context = new BasicTaskContext();
		return context;
	}

}
