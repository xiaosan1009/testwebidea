package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import org.ho.yaml.Yaml;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.dao.project.settings.bean.NewRoleBean;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class RoleReportLogic extends AbstractBaseLogic {
	
	public LogicBean getReportList() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		
		Map<String, Object> roleMap = Maps.newHashMap();
		List<Map<String, Object>> roledataListMap = Lists.newArrayList();
		Map<String, Object> roleDataMap = Maps.newHashMap();

		List<Map<String, Object>> getRoleListInfo = db.querys("roleReport.getRoleListInfo1");
		NewRoleBean roleListBean = new NewRoleBean();
		List<String> roleList = Lists.newArrayList();
		for (int n = 0; n < getRoleListInfo.size(); n++){
			roleList.add(String.valueOf(getRoleListInfo.get(n).get("name")));
		}
		roleListBean.setNewRoleMap(roleList);
		
		List<NewRoleBean> resultBean = Lists.newArrayList();
		List<Map<String, Object>> rolesBaseSubList =  db.querys("roleReport.getRolesBaseSubList1");
		
		for (int j = 0; j < rolesBaseSubList.size(); j++) {
			NewRoleBean newRoleBean = new NewRoleBean();
			Map<String, Object> rolesBaseSubData = rolesBaseSubList.get(j);
				
			newRoleBean.setId(Integer.valueOf(String.valueOf(rolesBaseSubData.get("id"))));
			newRoleBean.setName(String.valueOf(rolesBaseSubData.get("name")));
			newRoleBean.setValue(String.valueOf(rolesBaseSubData.get("value")));
			newRoleBean.setFlg(String.valueOf(rolesBaseSubData.get("value_id")));
			
			resultBean.add(newRoleBean);	
		}

		roleDataMap.put("data", resultBean);
		roleDataMap.put("roleHeadList", roleListBean);
		roledataListMap.add(roleDataMap);
			
		roleMap.put("roleList", roledataListMap);
		logicBean.setData(roleMap);
		return logicBean;
	}
	
	
	public void editRoleList() throws SoftbankException {
		
		List<Map<String, Object>> getRoleListInfo =  db.querys("roleReport.getRoleListInfo1");
		List<Map<String, Object>> getRoleBaseListInfo =  db.querys("roleReport.getRoleBaseListInfo");
		String selected = context.getParam().get("selected");
		JSONObject s1Json = JSONObject.fromObject(selected);

		for (int n = 0; n < getRoleListInfo.size(); n++){
			Map<String, Object> roleMap = Maps.newHashMap();
			String selected1 = s1Json.get(String.valueOf(getRoleListInfo.get(n).get("name"))).toString();
			roleMap.put("name", String.valueOf(getRoleListInfo.get(n).get("name")));
			List<String> permissionsList = Lists.newArrayList(); 
			JSONObject s2Json = JSONObject.fromObject(selected1);
			for (int p = 0; p < getRoleBaseListInfo.size(); p++) {
				String roleBaseValue = s2Json.get(String.valueOf(getRoleBaseListInfo.get(p).get("value"))).toString();
				if ("1".equals(roleBaseValue)) {
					permissionsList.add(":" + String.valueOf(getRoleBaseListInfo.get(p).get("value")));
				}
			}
			roleMap.put("permissions", Yaml.dump(permissionsList));
			db.update("roleReport.updateRoleListInfo1", roleMap);
		}
	}
	
}
