package co.jp.softbank.qqmx.logic.application.reform;


import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.net.URLDecoder;
import java.text.ParseException;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.ControlDbMemory;
import co.jp.softbank.qqmx.util.StringUtils;

public class TuChartVdbarLogic extends TuLogicBase {
	private static final Map<String,Integer> listMap ;
	
	static {
		listMap = new HashMap<String,Integer>();
		listMap.put("1704",0) ;
		listMap.put("1705",1) ;
		listMap.put("1706",2) ;
		listMap.put("1707",3) ;
		listMap.put("1708",4) ;
		listMap.put("1709",5) ;
		listMap.put("1710",6) ;
		listMap.put("1711",7) ;
		listMap.put("1712",8) ;
		listMap.put("1701",9) ;
		listMap.put("1702",10) ;
		listMap.put("1703",11) ;
		listMap.put("1804",12) ;
		listMap.put("1805",13) ;
		listMap.put("1806",14) ;
		listMap.put("1807",15) ;
		listMap.put("1808",16) ;
		listMap.put("1809",17) ;
		listMap.put("1810",18) ;
		listMap.put("1811",19) ;
		listMap.put("1812",20) ;
		listMap.put("1801",21) ;
		listMap.put("1802",22) ;
		listMap.put("1803",23) ;
		listMap.put("1904",24) ;
		
	};
	private static final String ARTIFICIALNUMBER = "人工数";
	private static final String MONEY = "金額";
	private static final String ARTIFICIAL = "artificial"; 
	private static final String BUDGET = "budget"; 
	private static final String AC = "ac"; 
	private static final String PLAN = "plan"; 
	private static final String CONSIGNMENT = "業務委託"; 
	private static final String REGULARMEMBER = "正社員"; 
	private static final String NEWLY = "新規"; 
	
	
	
	public  void getResouceTransitionInfor() throws SoftbankException,UnsupportedEncodingException, ParseException {
		String statusId = null;
		if (!StringUtils.isEmpty(context.getParam().get("statusId"))) {
			statusId = URLDecoder.decode(context.getParam().get("statusId"),"utf-8");
		} 
		
		if(StringUtils.isEmpty(statusId)|| ARTIFICIALNUMBER.equals(statusId)){
			getResouceTransitionSuiiInfor(ARTIFICIAL);
		}
		else if(MONEY.equals(statusId)){
			getResouceTransitionSuiiInfor(BUDGET);
		}
	}
	
	
	private void getResouceTransitionSuiiInfor(String statusflg) throws SoftbankException,UnsupportedEncodingException, ParseException {
		
		Map<String, Object> conditions = Maps.newHashMap();
		
		// 統括
		String headquartersId = null;
		if (StringUtils.isEmpty(context.getParam().get("headquartersId"))) {
			headquartersId = "9898";
		} else {
			headquartersId = context.getParam().get("headquartersId");
		}
		// 本部
		String divisionId = null;
		if (StringUtils.isEmpty(context.getParam().get("divisionId"))) {
			divisionId = "9898";
		} else {
			divisionId = context.getParam().get("divisionId");
		}
		// 統括部
		String departmentId = null;
		if (StringUtils.isEmpty(context.getParam().get("departmentId"))) {
			departmentId = "9898";
		} else {
			departmentId = context.getParam().get("departmentId");
		}
		// 部
		String regionId = null;
		if (StringUtils.isEmpty(context.getParam().get("regionId"))) {
			regionId = "9898";
		} else {
			regionId = context.getParam().get("regionId");
		}
		// 全従業員/社員/業託
		String dispartch = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("dispartchId"))) {
			dispartch = URLDecoder.decode(context.getParam().get("dispartchId"),"utf-8");
		}
		// 新規/既存
		String category = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("categoryId"))) {
			category = URLDecoder.decode(context.getParam().get("categoryId"),"utf-8");
		}
		
		// 人工数/金額/施策数
		String statusId = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("statusId"))) {
			statusId = URLDecoder.decode(context.getParam().get("statusId"),"utf-8");
		} 
		
		String study = null;
		if (!StringUtils.isEmpty(context.getParam().get("tuStudy"))) {
			if ("9898".equals(context.getParam().get("tuStudy"))) {
				study = ControlDbMemory.getInstance().getTuNewDate();
			} else {
				study = context.getParam().get("tuStudy");
			}
		}
		conditions.put("study", study);
		conditions.put("headquarters_id", Integer.parseInt(headquartersId));
		conditions.put("division_id", Integer.parseInt(divisionId));
		conditions.put("department_id", Integer.parseInt(departmentId));
		conditions.put("region_id", Integer.parseInt(regionId));
		conditions.put("dispartch", dispartch);
		conditions.put("category", category);
		if("".equals(statusId) || statusId == null || "人工数".equals(statusId)){
			conditions.put("artificial_unit", "人工");
		}
		conditions.put("status", statusId);
		conditions.put("id", 4);
		Map<String, Object> graph = db.query("tuChartVdbar.getChartMultipeInfo", conditions);
	
		
		conditions.put("statusId", statusId);
		List<Map<String,Object>> datalList = Lists.newArrayList() ;
		if(BUDGET.equals(statusflg)){
			datalList = db.querys("tuChartVdbar.getResouceBudgetTransitionInfor", conditions);
		}
		else if(ARTIFICIAL.equals(statusflg)){
			datalList = db.querys("tuChartVdbar.getResouceArtificialTransitionInfor", conditions);
		}
		List<Map<String,Object>> initList = db.querys("tuChartVdbar.getResouceInitTransitionInfor", conditions);
		
		
		List<BigDecimal[]> initArray = dataProcess(initList, PLAN, statusflg);
		
		// 計画
		List<BigDecimal[]> planArray = dataProcess(datalList, PLAN, statusflg);

		List<BigDecimal[]> factArray = dataProcess(datalList, AC, statusflg);

		Map<String, Object> listMapResult = Maps.newHashMap() ;
		
		listMapResult.put("graph", graph);
		Map<String,List<BigDecimal[]>> dataResult = Maps.newHashMap(); 
		dataResult.put("splan", initArray);
		dataResult.put("plan", planArray);
		dataResult.put("actual", factArray);
		
		listMapResult.put("dataResult", dataResult);
		listMapResult.put("selectFlg", statusflg);
		context.getResultBean().setData(listMapResult);
	}
	private List<BigDecimal[]> dataProcess (List<Map<String,Object>> plan, String planFlg,String statusFlg) throws ParseException{
		String param = planFlg +"_"+ statusFlg ;
		List<BigDecimal[]> result = Lists.newArrayList();
		BigDecimal[] newCommission = new BigDecimal[25] ;
		bigDecimalArrayInit(newCommission);
		BigDecimal[] commission = new BigDecimal[25] ;
		bigDecimalArrayInit(commission);
		BigDecimal[] newRegularMember = new BigDecimal[25] ;
		bigDecimalArrayInit(newRegularMember);
		BigDecimal[] regularMember = new BigDecimal[25] ;
		bigDecimalArrayInit(regularMember);
		for (int i = 0; i < plan.size(); i++) {
			Map<String,Object> infor = plan.get(i);
			String dispartch = (String) infor.get("dispartch") ;
			String new_exist_update = (String) infor.get("new_exist_update") ;
			if (CONSIGNMENT.equals(dispartch) && NEWLY.equals(new_exist_update)) {
				for (Map.Entry<String, Object> entry : infor.entrySet()) {
					String key = entry.getKey();
					if (key.contains(param)) {
						String artificial = key.substring(key.length() - 4, key.length());
						Integer order = listMap.get(artificial);
						BigDecimal data = objectToBigDecimal(entry.getValue());
						newCommission[order] = newCommission[order].add(data);
					}
				}
			}
			else if (CONSIGNMENT.equals(dispartch) && !NEWLY.equals(new_exist_update)) {
				for (Map.Entry<String, Object> entry : infor.entrySet()) {
					String key = entry.getKey();
					if (key.contains(param)) {
						String artificial = key.substring(key.length() - 4, key.length());
						Integer order = listMap.get(artificial);
						BigDecimal data = (objectToBigDecimal(entry.getValue()));
						commission[order] = commission[order].add(data);
					}
				}
			} else if (REGULARMEMBER.equals(dispartch) && NEWLY.equals(new_exist_update)) {
				for (Map.Entry<String, Object> entry : infor.entrySet()) {
					String key = entry.getKey();
					if (key.contains(param)) {
						String artificial = key.substring(key.length() - 4, key.length());
						Integer order = listMap.get(artificial);
						BigDecimal data =  (objectToBigDecimal(entry.getValue()));
						newRegularMember[order] = newRegularMember[order].add(data);
					}
				}
			} else if (REGULARMEMBER.equals(dispartch) && !NEWLY.equals(new_exist_update)) {
				for (Map.Entry<String, Object> entry : infor.entrySet()) {
					String key = entry.getKey();
					if (key.contains(param)) {
						String artificial = key.substring(key.length() - 4, key.length());
						Integer order = listMap.get(artificial);
						BigDecimal data =  (objectToBigDecimal(entry.getValue()));
						regularMember[order] = regularMember[order].add(data);
					}
				}

			}
		}
		result.add(regularMember) ;
		result.add(newRegularMember) ;
		result.add(commission) ;
		result.add(newCommission) ;
		
		return result ;
	}
	
	public void setChartVdbarInfo() throws SoftbankException,UnsupportedEncodingException {
		//統括
		String headquartersId = null;
		if (StringUtils.isEmpty(context.getParam().get("headquartersId"))) {
			headquartersId = "9898";
		} else {
			headquartersId = context.getParam().get("headquartersId");
		}
		//本部
		String divisionId = null;
		if (StringUtils.isEmpty(context.getParam().get("divisionId"))) {
			divisionId = "9898";
		} else {
			divisionId = context.getParam().get("divisionId");
		}
		//統括部
		String departmentId = null;
		if (StringUtils.isEmpty(context.getParam().get("departmentId"))) {
			departmentId = "9898";
		} else {
			departmentId = context.getParam().get("departmentId");
		}
		//部
		String regionId = null;
		if (StringUtils.isEmpty(context.getParam().get("regionId"))) {
			regionId = "9898";
		} else {
			regionId = context.getParam().get("regionId");
		}
		//新規/既存
		String category = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("categoryId"))) {
			category = URLDecoder.decode(context.getParam().get("categoryId"),"utf-8");
		}
		// 全従業員/社員/業託
		String dispartch = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("dispartchId"))) {
			dispartch = URLDecoder.decode(context.getParam().get("dispartchId"),"utf-8");
		}
		//人工数/金額/施策数
		String status = "";
		if (!StringUtils.isEmpty(context.getParam().get("statusId"))) {
			status = URLDecoder.decode(context.getParam().get("statusId"),"utf-8");
		} 
		
		//保存履歴
		String study = "";
		if (!StringUtils.isEmpty(context.getParam().get("tuStudy"))) {
			if ("9898".equals(context.getParam().get("tuStudy"))) {
				study = ControlDbMemory.getInstance().getTuNewDate();
			} else {
				study = context.getParam().get("tuStudy");
			}
		}
		
		String jsonDate = context.getParam().get("jsonDate");
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("id", 4);
		conditions.put("headquarters_id", Integer.parseInt(headquartersId));
		conditions.put("division_id", Integer.parseInt(divisionId));
		conditions.put("department_id", Integer.parseInt(departmentId));
		conditions.put("region_id", Integer.parseInt(regionId));
		conditions.put("dispartch", dispartch);
		conditions.put("category", category);
		conditions.put("status", status);
		conditions.put("study", study);
		context.getResultBean().setData(db.delete("tuChartVdbar.delChartMultipeInfo", conditions));
		
		conditions.put("json_date", jsonDate);
		context.getResultBean().setData(db.insert("tuChartVdbar.setChartMultipeInfo", conditions));
	}
	
	public void delChartVdbarInfo() throws SoftbankException,UnsupportedEncodingException {
		//統括
		String headquartersId = null;
		if (StringUtils.isEmpty(context.getParam().get("headquartersId"))) {
			headquartersId = "9898";
		} else {
			headquartersId = context.getParam().get("headquartersId");
		}
		//本部
		String divisionId = null;
		if (StringUtils.isEmpty(context.getParam().get("divisionId"))) {
			divisionId = "9898";
		} else {
			divisionId = context.getParam().get("divisionId");
		}
		//統括部
		String departmentId = null;
		if (StringUtils.isEmpty(context.getParam().get("departmentId"))) {
			departmentId = "9898";
		} else {
			departmentId = context.getParam().get("departmentId");
		}
		//部
		String regionId = null;
		if (StringUtils.isEmpty(context.getParam().get("regionId"))) {
			regionId = "9898";
		} else {
			regionId = context.getParam().get("regionId");
		}
		//新規/既存
		String category = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("categoryId"))) {
			category = URLDecoder.decode(context.getParam().get("categoryId"),"utf-8");
		}
		
		//人工数/金額/施策数
		String status = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("statusId"))) {
			status = URLDecoder.decode(context.getParam().get("statusId"),"utf-8");
		} 
		// 全従業員/社員/業託
		String dispartch = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("dispartchId"))) {
			dispartch = URLDecoder.decode(context.getParam().get("dispartchId"),"utf-8");
		}
		//保存履歴
		String study = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("tuStudy"))) {
			if ("9898".equals(context.getParam().get("tuStudy"))) {
				study = ControlDbMemory.getInstance().getTuNewDate();
			} else {
				study = context.getParam().get("tuStudy");
			}
		}
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("id", 4);
		conditions.put("headquarters_id", Integer.parseInt(headquartersId));
		conditions.put("division_id", Integer.parseInt(divisionId));
		conditions.put("department_id", Integer.parseInt(departmentId));
		conditions.put("region_id", Integer.parseInt(regionId));
		conditions.put("dispartch", dispartch);
		conditions.put("category", category);
		conditions.put("status", status);
		conditions.put("study", study);

		context.getResultBean().setData(db.delete("tuChartVdbar.delChartMultipeInfo", conditions));
	}
	private BigDecimal objectToBigDecimal(Object obj){
		return new BigDecimal(StringUtils.toString(obj));
	}
	private void bigDecimalArrayInit(BigDecimal[] array){
		for (int i = 0; i < array.length; i++) {
			array[i] = BigDecimal.ZERO ;
		}
	}
}
