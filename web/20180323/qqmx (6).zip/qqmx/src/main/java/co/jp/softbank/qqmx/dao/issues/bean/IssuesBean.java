package co.jp.softbank.qqmx.dao.issues.bean;

import java.util.Date;

import co.jp.softbank.qqmx.dao.common.bean.DaoBeanInterface;

import net.sf.json.JSONObject;

public class IssuesBean implements DaoBeanInterface {
	
	private int id;
	
	private int tracker_id;
	
	private int project_id;
	
	private String subject;
	
	private String tracker;
	
	private String description;
	
	private String due_date;
	
	private int category_id;
	
	private int status_id;
	
	private int assigned_to_id;
	
	private int priority_id;
	
	private int fixed_version_id;
	
	private String organization_cd;
	
	private int author_id;
	
	private int lock_version;
	
	private Date created_on;
	
	private Date updated_on;
	
	private String start_date;
	
	private int done_ratio;
	
	private double estimated_hours;
	
	private int parent_id;
	
	private int root_id;
	
	private int lft;
	
	private int rgt;
	
	private boolean is_private;
	
	private int position;
	
	private double remaining_hours;
	
	private double story_points;
	
	private int root_seq;
	
	private String issues_type;
	
	private int workDay;
	
	private int passDay;
	
	private int left_minute;
	
	private boolean is_closed;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getTracker_id() {
		return tracker_id;
	}

	public void setTracker_id(int tracker_id) {
		this.tracker_id = tracker_id;
	}

	public int getProject_id() {
		return project_id;
	}

	public void setProject_id(int project_id) {
		this.project_id = project_id;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getTracker() {
		return tracker;
	}

	public void setTracker(String tracker) {
		this.tracker = tracker;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getDue_date() {
		return due_date;
	}

	public void setDue_date(String due_date) {
		this.due_date = due_date;
	}

	public int getCategory_id() {
		return category_id;
	}

	public void setCategory_id(int category_id) {
		this.category_id = category_id;
	}

	public int getStatus_id() {
		return status_id;
	}

	public void setStatus_id(int status_id) {
		this.status_id = status_id;
	}

	public int getAssigned_to_id() {
		return assigned_to_id;
	}

	public void setAssigned_to_id(int assigned_to_id) {
		this.assigned_to_id = assigned_to_id;
	}

	public int getPriority_id() {
		return priority_id;
	}

	public void setPriority_id(int priority_id) {
		this.priority_id = priority_id;
	}

	public int getFixed_version_id() {
		return fixed_version_id;
	}

	public void setFixed_version_id(int fixed_version_id) {
		this.fixed_version_id = fixed_version_id;
	}

	public String getOrganization_cd() {
		return organization_cd;
	}

	public void setOrganization_cd(String organization_cd) {
		this.organization_cd = organization_cd;
	}

	public int getAuthor_id() {
		return author_id;
	}

	public void setAuthor_id(int author_id) {
		this.author_id = author_id;
	}

	public int getLock_version() {
		return lock_version;
	}

	public void setLock_version(int lock_version) {
		this.lock_version = lock_version;
	}

	public Date getCreated_on() {
		return created_on;
	}

	public void setCreated_on(Date created_on) {
		this.created_on = created_on;
	}

	public Date getUpdated_on() {
		return updated_on;
	}

	public void setUpdated_on(Date updated_on) {
		this.updated_on = updated_on;
	}

	public String getStart_date() {
		return start_date;
	}

	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}

	public int getDone_ratio() {
		return done_ratio;
	}

	public void setDone_ratio(int done_ratio) {
		this.done_ratio = done_ratio;
	}

	public double getEstimated_hours() {
		return estimated_hours;
	}

	public void setEstimated_hours(double estimated_hours) {
		this.estimated_hours = estimated_hours;
	}

	public int getParent_id() {
		return parent_id;
	}

	public void setParent_id(int parent_id) {
		this.parent_id = parent_id;
	}

	public int getRoot_id() {
		return root_id;
	}

	public void setRoot_id(int root_id) {
		this.root_id = root_id;
	}

	public int getLft() {
		return lft;
	}

	public void setLft(int lft) {
		this.lft = lft;
	}

	public int getRgt() {
		return rgt;
	}

	public void setRgt(int rgt) {
		this.rgt = rgt;
	}

	public boolean isIs_private() {
		return is_private;
	}

	public void setIs_private(boolean is_private) {
		this.is_private = is_private;
	}

	public int getPosition() {
		return position;
	}

	public void setPosition(int position) {
		this.position = position;
	}

	public double getRemaining_hours() {
		return remaining_hours;
	}

	public void setRemaining_hours(double remaining_hours) {
		this.remaining_hours = remaining_hours;
	}

	public double getStory_points() {
		return story_points;
	}

	public void setStory_points(double story_points) {
		this.story_points = story_points;
	}

	public int getRoot_seq() {
		return root_seq;
	}

	public void setRoot_seq(int root_seq) {
		this.root_seq = root_seq;
	}

	public String getIssues_type() {
		return issues_type;
	}

	public void setIssues_type(String issues_type) {
		this.issues_type = issues_type;
	}

	public int getWorkDay() {
		return workDay;
	}

	public void setWorkDay(int workDay) {
		this.workDay = workDay;
	}

	public int getPassDay() {
		return passDay;
	}

	public void setPassDay(int passDay) {
		this.passDay = passDay;
	}

	public int getLeft_minute() {
		return left_minute;
	}

	public void setLeft_minute(int left_minute) {
		this.left_minute = left_minute;
	}

	public boolean isIs_closed() {
		return is_closed;
	}

	public void setIs_closed(boolean is_closed) {
		this.is_closed = is_closed;
	}

	@Override
	public void toJson(JSONObject dataObj) {
		dataObj.put("id", this.id);
		dataObj.put("tracker_id", this.tracker_id);
		dataObj.put("project_id", this.project_id);
		dataObj.put("subject", this.subject);
		dataObj.put("description", this.description);
		dataObj.put("due_date", this.due_date);
		dataObj.put("category_id", this.category_id);
		dataObj.put("status_id", this.status_id);
		dataObj.put("assigned_to_id", this.assigned_to_id);
		dataObj.put("priority_id", this.priority_id);
		dataObj.put("start_date", this.start_date);
		dataObj.put("issues_type", this.issues_type);
		dataObj.put("done_ratio", this.done_ratio);
		dataObj.put("workDay", this.workDay);
		dataObj.put("passDay", this.passDay);
		dataObj.put("left_minute", this.left_minute);
	}
	
}
