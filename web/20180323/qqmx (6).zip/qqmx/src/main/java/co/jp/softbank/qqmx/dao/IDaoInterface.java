package co.jp.softbank.qqmx.dao;

public interface IDaoInterface {

}
