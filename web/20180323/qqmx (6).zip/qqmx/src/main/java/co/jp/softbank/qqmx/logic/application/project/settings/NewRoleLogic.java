package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.Arrays;
import java.util.List;
import java.util.Map;

import org.ho.yaml.Yaml;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

//import co.jp.softbank.qqmx.dao.project.settings.NewRoleDao;
import co.jp.softbank.qqmx.dao.project.settings.bean.NewRoleBean;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.StringUtils;

public class NewRoleLogic extends AbstractBaseLogic {

	public LogicBean getNewRoleInfo() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		String roleId = context.getParam().get("roleId");
		if ("".equals(roleId)){
			roleId = "2";
		}
		List<Map<String, Object>> rolesBaseList = db.querys("newRoleDao.getRolesBaseList");
		
		Map<String, Object> roleMap = Maps.newHashMap();
		List<Map<String, Object>> roledataListMap = Lists.newArrayList();
		
		for (int i = 0; i < rolesBaseList.size(); i++) {
			Map<String, Object> roledataMap = Maps.newHashMap();
			List<NewRoleBean> resultBean = Lists.newArrayList();
			Map<String, Object> rolesBaseData = rolesBaseList.get(i);
			
			
			Map<String, Object> rolesBaseSub = Maps.newHashMap();
			rolesBaseSub.put("id", rolesBaseData.get("id"));
			List<Map<String, Object>> rolesBaseSubList = db.querys("newRoleDao.getRolesBaseSubList", rolesBaseSub);
			
			for (int j = 0; j < rolesBaseSubList.size(); j++) {
				NewRoleBean newRoleBean = new NewRoleBean();
				Map<String, Object> rolesBaseSubData = rolesBaseSubList.get(j);
				newRoleBean.setId(Integer.valueOf(String.valueOf(rolesBaseSubData.get("id"))));
				newRoleBean.setName(String.valueOf(rolesBaseSubData.get("name")));
				newRoleBean.setValue(String.valueOf(rolesBaseSubData.get("value")));
				
				Map<String, Object> rolesCheck = Maps.newHashMap();
				rolesCheck.put("value", rolesBaseSubData.get("value"));
				rolesCheck.put("id", Integer.valueOf(roleId));
				List<Map<String, Object>> rolesCheckFlg = db.querys("newRoleDao.getRolesCheckFlg", rolesCheck);
				if (rolesCheckFlg.size()>0) {
					newRoleBean.setFlg("t");
				}else{
					newRoleBean.setFlg("f");
				}
				resultBean.add(newRoleBean);
			}
			roledataMap.put("data", resultBean);
			roledataMap.put("name", rolesBaseData.get("name"));
			roledataMap.put("value", rolesBaseData.get("value"));
			roledataListMap.add(roledataMap);
			
		}
		roleMap.put("newRole", roledataListMap);
		logicBean.setData(roleMap);
		return logicBean;
	}
	
	private void selectBaseRolesInfo(Map<String, Object> resultMap) throws SoftbankException {
		String roleId = context.getParam().get("roleId");
		if (StringUtils.isEmpty(roleId)) {
			roleId = "1";
		}
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("role_id", roleId);
		List<Map<String, Object>> rolesBaseList = db.querys("roles.selectBaseRolesForRole", conditions);
		resultMap.put("baseRolesInfo", rolesBaseList);
		resultMap.put("baseRolesPublicInfo", db.querys("roles.selectBaseRolesForPublic", conditions));
	}
	
	public void getRoleList() throws SoftbankException {
		Map<String, Object> resultMap = Maps.newHashMap();
		List<Map<String, Object>> roleList = db.querys("newRoleDao.getRoleList");
		resultMap.put("roleList", roleList);
		selectBaseRolesInfo(resultMap);
		context.getResultBean().setData(resultMap);
	}
	
	public void getRoleIdInfo() throws SoftbankException {
		Map<String, Object> resultMap = Maps.newHashMap();
		String roleId = context.getParam().get("roleId");
		Map<String, Object> roles = Maps.newHashMap();
		roles.put("id", Integer.valueOf(roleId));
		Map<String, Object> roleInfo = db.query("newRoleDao.getRoleIdInfo",roles);
		resultMap.put("roleInfo", roleInfo);
		selectBaseRolesInfo(resultMap);
		context.getResultBean().setData(resultMap);
	}
	
	public LogicBean checkNameExists() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("name", context.getParam().get("role_name"));
		
		if (StringUtils.isNotEmpty(context.getParam().get("roleId"))) {
			conditions.put("id", StringUtils.toInt(context.getParam().get("roleId")));
		} else {
			conditions.put("id", 0);
		}
		
		Integer getGroupCount = db.queryo("newRoleDao.getRolesCount", conditions);
		if (getGroupCount > 0) {
			logicBean.setResultFlg(false);
			logicBean.setResultCode("301417.role_name_error_result");
		}
		return logicBean;
	}
	
	public void saveRole() throws SoftbankException {
		Map<String, Object> roleMap = Maps.newHashMap();
		String role_name = context.getParam().get("role_name");
		String role_issues_visibility = context.getParam().get("role_issues_visibility");
		String role_assignable = context.getParam().get("role_assignable");
		String role_setting_type = context.getParam().get("role_setting_type");
		String[] base_role_ids = context.getParam().getList("base_role_id");
		String[] base_role_public_id = context.getParam().getList("base_role_public_id");
		List<String> permissionsList = Lists.newArrayList();
		List<String> publicPermissionsList = Lists.newArrayList();
		if (base_role_ids != null) {
			for (int i = 0; i < base_role_ids.length; i++) {
				permissionsList.add(ConstantsUtil.Str.COLON + base_role_ids[i]);
			}
		}
		if (base_role_public_id != null) {
			for (int i = 0; i < base_role_public_id.length; i++) {
				publicPermissionsList.add(ConstantsUtil.Str.COLON + base_role_public_id[i]);
			}
		}
		if ("1".equals(role_setting_type)) {
			roleMap.put("permissions", Yaml.dump(permissionsList).replaceAll("\"", ""));
		} else {
			roleMap.put("permissions", Yaml.dump(publicPermissionsList).replaceAll("\"", ""));
		}
		roleMap.put("name", role_name);
		roleMap.put("issues_visibility", role_issues_visibility);
		roleMap.put("assignable", "1".equals(role_assignable) ? true : false);
		roleMap.put("is_public", "2".equals(role_setting_type) ? true : false);
		
		String roleId = context.getParam().get("roleId");
		int newRoleId = 0;
		if (StringUtils.isNotEmpty(roleId)) {
			newRoleId = Integer.valueOf(roleId);
			roleMap.put("id", newRoleId);
			db.update("newRoleDao.updateRole",roleMap);
		} else {
			db.insert("newRoleDao.saveRole",roleMap);
			newRoleId = StringUtils.toInt(roleMap.get("id"));
			
			String copy_workflow_role_from = context.getParam().get("copy_workflow_role_from");
			if (StringUtils.isEmpty(copy_workflow_role_from)) {
				copy_workflow_role_from = "1";
			}
			List<Map<String, Object>> selectTrackersList = db.querys("newRoleDao.selectTrackers");
			for (int i = 0; i < selectTrackersList.size(); i++) {
				Map<String, Object> workflowsMap = Maps.newHashMap();
				String tracker_id = String.valueOf(selectTrackersList.get(i).get("id"));
				workflowsMap.put("tracker_id", Integer.valueOf(tracker_id));
				workflowsMap.put("new_role_id", Integer.valueOf(newRoleId));
				workflowsMap.put("bak_role_id", Integer.valueOf(copy_workflow_role_from));
				db.delete("newRoleDao.deleteWorkflows", workflowsMap);
				db.insert("newRoleDao.inserWorkflows", workflowsMap);
			}
		}
		
		
	}
}
