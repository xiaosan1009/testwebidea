package co.jp.softbank.qqmx.handle;

import java.util.HashMap;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.slf4j.Logger;

import co.jp.softbank.qqmx.dao.common.IDbExecute;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.handle.face.ITaskScriptFace;
import co.jp.softbank.qqmx.info.ControlScriptHandler;
import co.jp.softbank.qqmx.task.face.ITaskContext;
import co.jp.softbank.qqmx.util.LogUtil;
import co.jp.softbank.qqmx.util.ScriptEngineUtil;

public abstract class AbstractTaskScriptHandler implements ITaskScriptFace {
	
	public static final String FORMAT_SCRIPT_METHOD = "execute";
    
	protected Logger log = new LogUtil(this.getClass()).getLog();
    
    protected ITaskContext context;
    
    protected IDbExecute db;
    
    public AbstractTaskScriptHandler() {
	}
    
    public Object execute(String project, String action, String model, String method) throws SoftbankException {
    	return execute(project, action, model, method, new HashMap<String, Object>());
    }
    
    public Object execute(String project, String action, String model, String method, Object... args) throws SoftbankException {
    	Object returnValue = null;
        try {
        	if (scriptExist(project, action, model, method, args)) {
        		returnValue = executeScriptUtil(project, action, model, method, args);
    			return returnValue;
			}
        } catch (SecurityException e) {
            log.error(createErrorMessage(project, action, model, method, args), e);
            e.printStackTrace();
            throw new SoftbankException(SoftbankExceptionType.SecurityException, e);
        } catch (NoSuchMethodException e) {
            log.error(createErrorMessage(project, action, model, method, args), e);
            e.printStackTrace();
            throw new SoftbankException(SoftbankExceptionType.NoSuchMethodException, e);
        } catch (IllegalArgumentException e) {
            log.error(createErrorMessage(project, action, model, method, args), e);
            e.printStackTrace();
            throw new SoftbankException(SoftbankExceptionType.IllegalArgumentException, e);
        } catch (ScriptException e) {
        	log.error(createErrorMessage(project, action, model, method, args), e);
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.ScriptException, e);
		}
        return returnValue;
    }
    
    private String createErrorMessage(String project, String action, String model, String method, Object... args) {
    	StringBuilder sBuilder = new StringBuilder();
    	sBuilder.append("\n■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n");
    	sBuilder.append("【『パラメータ』project = ");
    	sBuilder.append(project);
    	sBuilder.append(";");
    	sBuilder.append("action = ");
    	sBuilder.append(action);
    	sBuilder.append(";");
    	sBuilder.append("model = ");
    	sBuilder.append(model);
    	sBuilder.append(".js;");
    	sBuilder.append("method = ");
    	sBuilder.append(method);
    	sBuilder.append(";】\n");
    	sBuilder.append("■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n");
    	return sBuilder.toString();
    }
    
    private String createMethodMessageS() {
    	StringBuilder sBuilder = new StringBuilder();
    	sBuilder.append("\n■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n");
    	sBuilder.append("▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼Start▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼\n");
    	sBuilder.append("【『パラメータ』project = {};action = {};model = {}.js;method = {};】\n");
    	sBuilder.append("■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n");
    	return sBuilder.toString();
    }
    
    private String createMethodMessageE() {
    	StringBuilder sBuilder = new StringBuilder();
    	sBuilder.append("\n■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n");
    	sBuilder.append("【『パラメータ』project = {};action = {};model = {}.js;method = {};】\n");
    	sBuilder.append("【『実行時間』{}ms\n");
    	sBuilder.append("▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲End▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲▲\n");
    	sBuilder.append("■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■■\n");
    	return sBuilder.toString();
    }

	private Object executeScriptUtil(String project, String action, String model, String method, Object... args) throws ScriptException, NoSuchMethodException, SoftbankException {
		log.info(createMethodMessageS(), project, action, model, method);
		long startTime = System.currentTimeMillis();
		ScriptEngineManager manager = new ScriptEngineManager();
		ScriptEngine scriptEngine = manager.getEngineByName("js");
		String script = getScript(project, action, model, method, args);
		StringBuilder sb = new StringBuilder(ScriptEngineUtil.createScriptImport());
		sb.append(script);
		scriptEngine.eval(sb.toString());
		scriptEngine.put("_log", log);
		scriptEngine.put("_context", context);
		scriptEngine.put("_db", db);
		scriptEngine.put("_sutil", this);
		Invocable invocable = (Invocable)scriptEngine;
		Object result = invocable.invokeFunction(method, args);
		long endTime = System.currentTimeMillis();
		log.info(createMethodMessageE(), project, action, model, method, (endTime - startTime));
		return result;
	}
    
	@Override
	public void setHandlerMethod(ITaskContext context) {
		this.context = context;
	}
	
	public void setDb(IDbExecute db) {
		this.db = db;
	}
	
	protected String getScript(String project, String action, String model, String method, Object... args) throws SoftbankException {
		return ControlScriptHandler.getInstance().getScriptUtil(model);
	}
	
	protected boolean scriptExist(String project, String action, String model, String method, Object... args) throws SoftbankException {
		return ControlScriptHandler.getInstance().containsScriptUtilMethod(model);
	}
    
}
