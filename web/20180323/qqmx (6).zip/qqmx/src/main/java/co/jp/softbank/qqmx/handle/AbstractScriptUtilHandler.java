package co.jp.softbank.qqmx.handle;

import java.util.HashMap;
import java.util.Map;

import javax.script.Invocable;
import javax.script.ScriptEngine;
import javax.script.ScriptEngineManager;
import javax.script.ScriptException;

import org.slf4j.Logger;

import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.dao.common.IDbExecute;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.handle.face.IScriptUtilFace;
import co.jp.softbank.qqmx.info.ControlScriptHandler;
import co.jp.softbank.qqmx.util.EngineScriptUtil;
import co.jp.softbank.qqmx.util.LogUtil;
import co.jp.softbank.qqmx.util.ScriptEngineUtil;

public abstract class AbstractScriptUtilHandler implements IScriptUtilFace {

	private static final String FORMAT_SCRIPT_METHOD_START = "function execute(_data) {";
	
	private static final String FORMAT_SCRIPT_METHOD_END = "}";
	
	private static final String FORMAT_SCRIPT_METHOD = "execute";
    
	protected Logger log = new LogUtil(this.getClass()).getLog();
    
    protected ScriptEngine scriptEngine;
    
    protected HttpContext context;
    
    protected IDbExecute db;
    
    public AbstractScriptUtilHandler() {
    	ScriptEngineManager manager = new ScriptEngineManager();
    	scriptEngine = manager.getEngineByName("js");
	}
    
    public Object execute(String method) throws SoftbankException {
    	return execute(method, new HashMap<String, Object>());
    }
    
    public Object execute(String method, Map<String, Object> params) throws SoftbankException {
    	Object returnValue = null;
        try {
        	if (ControlScriptHandler.getInstance().containsScriptUtilMethod(method)) {
        		returnValue = executeScriptUtil(method, params);
    			return returnValue;
			}
        } catch (SecurityException e) {
            log.error(e.toString(), e);
            e.printStackTrace();
            throw new SoftbankException(SoftbankExceptionType.SecurityException, e);
        } catch (NoSuchMethodException e) {
            log.error(e.toString(), e);
            e.printStackTrace();
            throw new SoftbankException(SoftbankExceptionType.NoSuchMethodException, e);
        } catch (IllegalArgumentException e) {
            log.error(e.toString(), e);
            e.printStackTrace();
            throw new SoftbankException(SoftbankExceptionType.IllegalArgumentException, e);
        } catch (ScriptException e) {
        	log.error(e.toString(), e);
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.ScriptException, e);
		}
        return returnValue;
    }

	private Object executeScriptUtil(String method, Map<String, Object> params) throws ScriptException, NoSuchMethodException, SoftbankException {
		String script = ControlScriptHandler.getInstance().getScriptUtil(method);
		StringBuilder sb = new StringBuilder(ScriptEngineUtil.createScriptImport());
		sb.append(FORMAT_SCRIPT_METHOD_START);
		sb.append(script);
		sb.append(FORMAT_SCRIPT_METHOD_END);
		scriptEngine.eval(sb.toString());
		ScriptEngineUtil.setScriptContext(context, scriptEngine);
		scriptEngine.put("_log", log);
		Invocable invocable = (Invocable)scriptEngine;  
		return invocable.invokeFunction(FORMAT_SCRIPT_METHOD, params);
	}
    
	@Override
	public void setHandlerMethod(HttpContext httpContext) {
		this.context = httpContext;
		db.setContext(httpContext);
		scriptEngine.put("_log", log);
		scriptEngine.put("_util", new EngineScriptUtil(httpContext));
		scriptEngine.put("_context", httpContext);
		scriptEngine.put("_request", httpContext.getParam());
		scriptEngine.put("_session", httpContext.getSessionData());
		scriptEngine.put("_application", httpContext.getContext());
		scriptEngine.put("_result", httpContext.getResultBean());
		scriptEngine.put("_db", db);
		scriptEngine.put("_sutil", this);
//		scriptEngine.put("_format", handlerMethod.getFormat());
//		scriptEngine.put("_external", handlerMethod.getExternal());
//		scriptEngine.put("_dataSource", handlerMethod.getDataSource());
	}
	
	public void setDb(IDbExecute db) {
		this.db = db;
	}
    
}
