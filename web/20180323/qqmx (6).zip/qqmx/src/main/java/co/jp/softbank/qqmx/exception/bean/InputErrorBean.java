package co.jp.softbank.qqmx.exception.bean;

import net.sf.json.JSONObject;
import co.jp.softbank.qqmx.dao.common.bean.DaoBeanInterface;

public class InputErrorBean implements DaoBeanInterface {
	
	private String targetId;
	
	private String message;

	public String getTargetId() {
		return targetId;
	}

	public void setTargetId(String targetId) {
		this.targetId = targetId;
	}

	public String getMessage() {
		return message;
	}

	public void setMessage(String message) {
		this.message = message;
	}

	@Override
	public void toJson(JSONObject dataObj) {
		dataObj.put("targetId", this.targetId);
		dataObj.put("message", this.message);
	}

	@Override
	public void setId(int id) {
	}

}
