package co.jp.softbank.qqmx.logic.bean;

import java.util.HashMap;
import java.util.Map;

import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.util.StringUtils;

public class SessionData {
	
	public static final String APPLICATION_SESSION_KEY = "APPLICATION_SESSION_KEY";
	
	public static final String ROLES_KEY = "ROLES_KEY";

	private Map<String, Object> data = new HashMap<String, Object>();
	
	public Object get(String key) {
		return data.get(key);
	}
	
	public <T> T get(String key, Class<T> clazz) {
		return clazz.cast(data.get(key));
	}
	
	public String getString(String key) {
		return StringUtils.toString(data.get(key));
	}
	
	public int getInt(String key) {
		return StringUtils.toInt(data.get(key));
	}
	
	public void set(String key, Object value) {
		data.put(key, value);
	}
	
	public Object remove(String key) {
		return data.remove(key);
	}
	
	public boolean containsKey(String key) {
		return data.containsKey(key);
	}
	
	public UserInfoData getUserInfo() {
		return get(UserInfoData.USER_INFO_KEY, UserInfoData.class);
	}
	
	public void setRoles(Map<String, Object> roleMap) {
		set(ROLES_KEY, roleMap);
		UserInfoData userInfoData = getUserInfo();
		if (userInfoData != null) {
			userInfoData.setRoleMap(roleMap);
		}
	}
	
	@SuppressWarnings("unchecked")
	public Map<String, Object> getRoles() {
		return get(ROLES_KEY, Map.class);
	}
	
	public SessionData clone() {
		SessionData copyData = null;
		try {
			copyData = (SessionData)super.clone();
		} catch (CloneNotSupportedException e) {
			throw new InternalError(e.getMessage());
		}
		return copyData;
	}
	
}
