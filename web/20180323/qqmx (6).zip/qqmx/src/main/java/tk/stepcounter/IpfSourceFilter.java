package tk.stepcounter;


//package jp.go.ipa.ipf.sourcescale.sourcefilter;

import java.util.ArrayList;
import java.util.List;

import tk.stepcounter.StepCounter;

/**
 * Amateras StepCounter のソースフィルタカスタマイズ用抽象クラス
 * StepCounter が標準で対応していないファイル用のソースフィルタを追加する場合
 * このクラスを実装したクラスを jp.go.ipa.sourcescale.sourcefilter.custom パッケージに
 * 配置することで、集計対象ファイルの種類を追加できる。
 */
public abstract class IpfSourceFilter {
	
    /** ソースフィルタ対象ファイルの拡張子リスト */
	private final List<String> fileExtList = new ArrayList<String>() ;
	
	/** ステップカウンタ */
	private StepCounter stepCounter;
	
	/**
	 * コンストララクタ
	 */
	public IpfSourceFilter() {
		this.setFileExt(this.fileExtList);
		this.stepCounter = this.setSourceFilter();
	}
	
	/**
	 * このソースフィルタクラスで対象となるファイルの拡張子をリストに追加する。
	 * 
	 * @param fileExtList ソースフィルタ対象ファイルの拡張子リスト
	 */
	public abstract void setFileExt(List<String> fileExtList);
	
	/**
	 * このソースフィルタクラスで利用するステップカウンタのインスタンスを生成して返す。
	 * 
	 * @return ステップカウンタのインスタンス
	 */
	public abstract StepCounter setSourceFilter();
	
	/**
	 * ソースフィルタ対象ファイルの拡張子リストを返す。
	 * 
	 * @return ソースフィルタ対象ファイルの拡張子リスト
	 */
	public List<String> getFileExtList() {
		return this.fileExtList;
	}

	/**
	 * ステップカウンタを返す。
	 * 
	 * @return ステップカウンタ
	 */
	public StepCounter getStepCounter() {
	    return stepCounter;
	}
	
}
