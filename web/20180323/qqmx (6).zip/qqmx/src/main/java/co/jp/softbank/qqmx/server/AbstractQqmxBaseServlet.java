package co.jp.softbank.qqmx.server;

import java.io.File;
import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.FileUploadException;
import org.slf4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.core.io.Resource;

import co.jp.softbank.qqmx.application.CustomLoaderListener;
import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.handle.AbstractScriptEngineHandler;
import co.jp.softbank.qqmx.info.ControlFileMemory;
import co.jp.softbank.qqmx.info.ControlRequestMap;
import co.jp.softbank.qqmx.info.ControlResourceMap;
import co.jp.softbank.qqmx.info.ControlScriptHandler;
import co.jp.softbank.qqmx.info.ControlSettingMap;
import co.jp.softbank.qqmx.info.ControlUserInfoMap;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.message.IMessageAccessor;
import co.jp.softbank.qqmx.server.face.IQqmxServletFace;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.LogUtil;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;

public abstract class AbstractQqmxBaseServlet implements IQqmxServletFace {
	
	private Logger log = new LogUtil(this.getClass()).getLog();
	
	private ServletContext context;
	
	protected IMessageAccessor messageAccessor;
	
	private Resource dispScript;
	
	private Resource utilScript;
	
	@Override
	public void init(ServletContext servletContext) throws ServletException {
		try {
			synchronized (this) {
				if (context == null) {
					context = servletContext;
				}
			}
			
			String realPath = context.getRealPath(File.separator);
			
			log.info("realPath = {}", Lists.newArrayList(realPath).toArray());
			
			ControlResourceMap.getInstance();
			
			ControlRequestMap.setPath(realPath);
			ControlRequestMap.getInstance();
			
			ControlUserInfoMap.setPath(realPath);
			ControlUserInfoMap.getInstance();
			
			ControlFileMemory.setPath(realPath);
			ControlFileMemory.getInstance();
			
			ControlSettingMap.getInstance().analyze(realPath);
			
			if (dispScript != null) {
            	ControlScriptHandler.getInstance().initScript(this.dispScript.getFile());
			}
			
			if (utilScript != null) {
				ControlScriptHandler.getInstance().initScriptUtil(this.utilScript.getFile());
			}
			
			initialize(context);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage(), e);
			throw new ServletException();
		}
	}

	@Override
	public void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}

	@Override
	public void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		processRequest(request, response);
	}
	
	protected void processRequest(HttpServletRequest request, HttpServletResponse response) throws ServletException {
		SoftbankException th = null;
		HttpContext httpContext = null;
		try {
//			HttpSession session = request.getSession(false);
//			if (session == null) {
//				session = request.getSession(true);
//			}
//			SessionData sessionData = (SessionData)session.getAttribute(SessionData.APPLICATION_SESSION_KEY);
//			if (sessionData == null) {
//				sessionData = new SessionData();
//				session.setAttribute(SessionData.APPLICATION_SESSION_KEY, sessionData);
//			}
			
			httpContext = new HttpContext(request, response);
			httpContext.setContext(context);
			httpContext.createSession();
//			httpContext.getRequest().setAttribute("qqmxLocale", httpContext.getLang());
			doAction(httpContext);
		} catch (SoftbankException e) {
			th = e;
		} catch (NoSuchMethodException e) {
			th = new SoftbankException(SoftbankExceptionType.NoSuchMethodException, e);
		} catch (SecurityException e) {
			th = new SoftbankException(SoftbankExceptionType.SecurityException, e);
		} catch (IllegalAccessException e) {
			th = new SoftbankException(SoftbankExceptionType.IllegalAccessException, e);
		} catch (IllegalArgumentException e) {
			th = new SoftbankException(SoftbankExceptionType.IllegalArgumentException, e);
		} catch (InvocationTargetException e) {
			if (e.getTargetException() instanceof SoftbankException) {
				th = (SoftbankException)e.getTargetException();
			} else {
				th = new SoftbankException(SoftbankExceptionType.InvocationTargetException, e);
			}
		} catch (FileUploadException e) {
			th = new SoftbankException(SoftbankExceptionType.IllegalArgumentException, e);
		} catch (Exception e) {
			th = new SoftbankException(SoftbankExceptionType.SystemException, e);
		}
		
		if (th != null) {
			if (th.getExceptionType() != null && !th.getExceptionType().equals(SoftbankExceptionType.InputError)) {
				log.error(th.getMessage(), th);
			}
			forwardToError(httpContext, th);
		} else {
			forwardToJsp(httpContext);
		}
	}
	
	private void doAction(HttpContext httpContext) throws SoftbankException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		final String logicName = ControlRequestMap.getInstance().getLogic(httpContext.getParam());
		if (httpContext.isEngineTest()) {
			log.info("logicName = {}", logicName);
		}
		final ApplicationContext wac = CustomLoaderListener.getApplicationContext();
		final Object logic = wac.getBean(logicName);
		if (logic instanceof AbstractBaseLogic) {
			AbstractBaseLogic baseLogic = ((AbstractBaseLogic)logic);
			final Class<? extends Object> clazz = logic.getClass();
			baseLogic.applicationInit(httpContext);
			baseLogic.doValidate();
			
			final String methodStr = ControlRequestMap.getInstance().getMethod(httpContext.getParam());
			if (httpContext.isEngineTest()) {
				log.info("methodStr = {}", methodStr);
			}
			if (StringUtils.isEmpty(methodStr)) {
				((AbstractBaseLogic)logic).execute();
				setResult(httpContext, httpContext.getResultBean());
			} else {
				if (logic instanceof AbstractScriptEngineHandler) {
					((AbstractScriptEngineHandler)logic).execute(methodStr);
					setResult(httpContext, httpContext.getResultBean());
				} else {
					final Method method = clazz.getMethod(methodStr, new Class[]{});
					Object result = method.invoke(logic, new Object[]{});
					if (result == null) {
						setResult(httpContext, httpContext.getResultBean());
					} else {
						if (result instanceof LogicBean) {
							setResult(httpContext, ((LogicBean)result));
						}
					}
				}
			}
		}
	}

	private void setResult(HttpContext httpContext, LogicBean result) throws SoftbankException {
		if (StringUtils.isEmpty(result.getResultMsg())) {
			String success = ControlRequestMap.getInstance().getSuccess(httpContext.getParam());
			success = getMessage(httpContext, success);
			if (StringUtils.isNotEmpty(success)) {
				result.setResultMsg(success);
			}
		}
		if (ControlRequestMap.getInstance().isIgnoreAccessLog(httpContext.getParam())) {
			result.setIgnore(true);
		}
		httpContext.getRequest().setAttribute(LogicBean.RESPONSE_DATA, result);
	}
	
	private String getMessage(HttpContext httpContext, String key) {
		return messageAccessor.getMessage(key, null, key, httpContext);
	}
	
	private void forwardToJsp(HttpContext httpContext) throws ServletException {
		try {
			String jsp = ControlRequestMap.getInstance().getJsp(httpContext.getParam());
			if (StringUtils.isNotEmpty(jsp)) {
				jsp = ConstantsUtil.Jsp.DEFAULT_JSP_PATH + jsp;
			} else {
				jsp = ConstantsUtil.Jsp.DEFAULT_JSP_PATH + ConstantsUtil.Jsp.JSON_JSP_PATH;
			}
			final RequestDispatcher rd = context.getRequestDispatcher(jsp);
			rd.forward(httpContext.getRequest(), httpContext.getResponse());
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServletException();
		}
	}
	
	private void forwardToError(HttpContext httpContext, SoftbankException th) throws ServletException {
		try {
			// Ajax
	    	if ("1".equals(httpContext.getParam().clientType)) {
	    		LogicBean logicBean = new LogicBean();
	    		logicBean.setResultFlg(!th.isError());
	    		String code = null;
	    		if (StringUtils.isNotEmpty(th.getErrorCode())) {
	    			code = th.getErrorCode();
	    		} else if (th.getExceptionType() != null) {
	    			code = th.getExceptionType().getErrCode();
	    			logicBean.setResultCode(code);
				}
	    		String message = null;
	    		if (StringUtils.isNotEmpty(code)) {
	    			message = ControlRequestMap.getInstance().getMessage(httpContext.getParam(), code);
	    			message = getMessage(httpContext, message);
				}
	    		if (StringUtils.isEmpty(message)) {
	    			if (StringUtils.isNotEmpty(th.getErrorMsg())) {
	    				message = th.getErrorMsg();
	    			} else if (th.getExceptionType() != null) {
	    				message = th.getExceptionType().getErrMsg();
	    			}
	    		}
	    		if (StringUtils.isNotEmpty(message)) {
	    			logicBean.setResultMsg(message);
	    		}
	    		logicBean.setData(th.getErrorInfos());
	    		httpContext.getRequest().setAttribute(LogicBean.RESPONSE_DATA, logicBean);
	    		final RequestDispatcher rd = httpContext.getRequest().getRequestDispatcher(ConstantsUtil.Jsp.DEFAULT_JSP_PATH + ConstantsUtil.Jsp.JSON_JSP_PATH);
	    		rd.forward(httpContext.getRequest(), httpContext.getResponse());
	    	} else {
	    		final RequestDispatcher rd = context.getRequestDispatcher(ConstantsUtil.Jsp.DEFAULT_JSP_PATH + ConstantsUtil.Jsp.ERROR_JSP_PATH);
	    		rd.forward(httpContext.getRequest(), httpContext.getResponse());
	    	}
		} catch (Exception e) {
			e.printStackTrace();
			throw new ServletException();
		}
	}
	
	public void setMessageAccessor(IMessageAccessor messageAccessor) {
		this.messageAccessor = messageAccessor;
	}

	public void setDispScript(Resource dispScript) {
		this.dispScript = dispScript;
	}

	public void setUtilScript(Resource utilScript) {
		this.utilScript = utilScript;
	}

}
