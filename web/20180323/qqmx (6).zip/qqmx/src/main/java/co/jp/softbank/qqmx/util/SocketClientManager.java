package co.jp.softbank.qqmx.util;

import java.io.IOException;
import java.util.concurrent.ConcurrentHashMap;

import javax.websocket.Session;

import net.sf.json.JSONArray;

import org.slf4j.Logger;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.server.bean.SocketClientInfo;

public class SocketClientManager {
	
	private Logger log = new LogUtil(this.getClass()).getLog();
	
	private static SocketClientManager me;
	
	private ConcurrentHashMap<String, SocketClientInfo> socketClientSessions = new ConcurrentHashMap<String, SocketClientInfo>();
	
	private ConcurrentHashMap<String, String> socketClientMapping = new ConcurrentHashMap<String, String>();
	
	public interface ExecuteLisener {
		void execute(SocketClientInfo clientInfo);
	}
	
	public SocketClientManager() {
	}
	
	public static SocketClientManager getInstance() {
		synchronized (SocketClientManager.class) {
			if (me == null) {
				me = new SocketClientManager();
			}
		}
		
		return me;
	}
	
	public void addSession(Session session, UserInfoData userInfoData) {
		SocketClientInfo clientInfo = new SocketClientInfo(session);
		clientInfo.setUserName(userInfoData.getName());
		clientInfo.setUserId(userInfoData.getLogin());
		socketClientSessions.put(clientInfo.getUserId(), clientInfo);
		socketClientMapping.put(session.getId(), clientInfo.getUserId());
	}
	
	public ConcurrentHashMap<String, SocketClientInfo> getSessions() {
		return socketClientSessions;
	}
	
	public void sendAll(Session srcSession, String message) throws SoftbankException {
		for (String key : socketClientSessions.keySet()) {
			try {
				if (socketClientSessions.get(key).getSession() != null && socketClientSessions.get(key).getSession().isOpen()) {
					socketClientSessions.get(key).getSession().getBasicRemote().sendText("srcSessionId = " + srcSession.getId() + ";sessionId = " + key + "; Message!");
				} else {
					socketClientSessions.remove(key);
				}
			} catch (IOException e) {
				e.printStackTrace();
				throw new SoftbankException(SoftbankExceptionType.IOException);
			}
		}
	}
	
	public JSONArray getAllUserInfo() {
		JSONArray jsonArray = new JSONArray();
		for (String key : socketClientSessions.keySet()) {
			if (!checkSessionActive(key)) {
				continue;
			}
			jsonArray.add(socketClientSessions.get(key).toJsonObj());
		}
		return jsonArray;
	}
	
	public void execute(ExecuteLisener lisener) {
		execute(null, lisener, true);
	}
	
	public void execute(SocketClientInfo srcClient, ExecuteLisener lisener) {
		execute(srcClient, lisener, false);
	}
	
	public void execute(SocketClientInfo srcClient, ExecuteLisener lisener, boolean inCludeMe) {
		for (String key : socketClientSessions.keySet()) {
			if (!checkSessionActive(key)) {
				continue;
			}
			if (!inCludeMe && srcClient.getUserId().equals(key)) {
				continue;
			}
			lisener.execute(socketClientSessions.get(key));
		}
	}
	
	public SocketClientInfo getSocketClient(String userId) {
		return socketClientSessions.get(userId);
	}
	
	public SocketClientInfo getSocketClientBySession(Session srcSession) {
		return socketClientSessions.get(socketClientMapping.get(srcSession.getId()));
	}
	
	public SocketClientInfo getSocketClientBySessionId(String sessionId) {
		return socketClientSessions.get(socketClientMapping.get(sessionId));
	}
	
	public void sendToUser(String userId, String message) throws SoftbankException {
		try {
			log.info("userId = {}", userId);
			if (!isUserActive(userId)) {
				return;
			}
			getSocketClient(userId).getSession().getBasicRemote().sendText(message);
		} catch (IOException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IOException);
		}
	}
	
	public void remove(Session srcSession) {
		if (socketClientMapping.get(srcSession.getId()) != null && socketClientSessions.containsKey(socketClientMapping.get(srcSession.getId()))) {
			socketClientSessions.remove(socketClientMapping.get(srcSession.getId()));
		}
	}
	
	public boolean isUserActive(String userId) {
		return socketClientSessions.containsKey(userId);
	}
	
	private boolean checkSessionActive(String key) {
		if (socketClientSessions.get(key).getSession() == null || !socketClientSessions.get(key).getSession().isOpen()) {
			socketClientSessions.remove(key);
			return false;
		}
		return true;
	}
	
}
