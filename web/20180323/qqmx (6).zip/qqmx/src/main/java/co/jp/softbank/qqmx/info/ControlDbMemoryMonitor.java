package co.jp.softbank.qqmx.info;

import java.util.Timer;
import java.util.TimerTask;

import co.jp.softbank.qqmx.dao.common.DbMemoryMonitorDaoService;
import co.jp.softbank.qqmx.dao.common.IDbExecute;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.message.IMessageAccessor;
import co.jp.softbank.qqmx.util.StringUtils;

public class ControlDbMemoryMonitor {
	
	private static ControlDbMemoryMonitor me;
	
	private static IDbExecute db;
	
	private static DbMemoryMonitorDaoService dbMemoryMonitorDaoService;
	
	private static IMessageAccessor messageAccessor;
	
	private Timer timer;
	
	private ControlDbMemoryMonitor() throws SoftbankException {
		super();
		timer = new Timer();
		TimerTask task = new DbMemoryMonitorTask(db);
		TimerTask taskWatchable = new DbMemoryWatchableMonitorTask(dbMemoryMonitorDaoService);
		TimerTask taskMit = new DbMemoryMitMonitorTask(dbMemoryMonitorDaoService);
		int time = StringUtils.toInt(messageAccessor.getMessage("MEMORY_DB_CHECK_TIMER"));
		timer.schedule(task, 0, time);
		timer.schedule(taskWatchable, 0, time);
		timer.schedule(taskMit, 0, time);
	}
	
	public static ControlDbMemoryMonitor getInstance() throws SoftbankException {
		synchronized (ControlRequestMap.class) {
			if (me == null) {
				me = new ControlDbMemoryMonitor();
			}
		}
		return me;
	}

	public static void setMessageAccessor(IMessageAccessor messageAccessor) {
		ControlDbMemoryMonitor.messageAccessor = messageAccessor;
	}

	public static void setDbMemoryMonitorDaoService(
			DbMemoryMonitorDaoService dbMemoryMonitorDaoService) {
		ControlDbMemoryMonitor.dbMemoryMonitorDaoService = dbMemoryMonitorDaoService;
	}
	
	public static void setDb(IDbExecute db) {
		ControlDbMemoryMonitor.db = db;
	}

}
