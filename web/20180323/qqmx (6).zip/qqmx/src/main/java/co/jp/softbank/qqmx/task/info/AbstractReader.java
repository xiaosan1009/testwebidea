package co.jp.softbank.qqmx.task.info;

import java.io.IOException;

import co.jp.softbank.qqmx.task.face.ICollector;
import co.jp.softbank.qqmx.task.face.IKey;
import co.jp.softbank.qqmx.task.face.IReader;
import co.jp.softbank.qqmx.task.face.ITaskContext;

public abstract class AbstractReader<V> implements IReader<V> {

	protected ICollector<V> collector;

	private boolean hasNext;
	
	private IKey currentKey;

	private V currentValue;
	
	public void setCollector(ICollector<V> collector) {
        this.collector = collector;
    }
	
	@Override
	public boolean hasNext() {
        hasNext = collector.hasNext();
        return hasNext;
    }

	@Override
	public void close() throws IOException {
		if (collector == null) {
            return;
        }
        collector.close();
	}

	@Override
	public void cleanup(ITaskContext context) {

	}

	@Override
	public IKey getKey() {
		return currentKey;
	}

	@Override
	public V getValue() {
		if (hasNext) {
            currentValue = collector.next();
            return currentValue;
        }
        return null;
	}
	
	@Override
	public int size() {
		return collector.size();
	}

}
