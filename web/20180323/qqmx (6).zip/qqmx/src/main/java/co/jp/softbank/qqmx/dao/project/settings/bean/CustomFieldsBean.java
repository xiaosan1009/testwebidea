package co.jp.softbank.qqmx.dao.project.settings.bean;

import net.sf.json.JSONObject;
import co.jp.softbank.qqmx.dao.common.bean.DaoBeanInterface;

public class CustomFieldsBean implements DaoBeanInterface {
	
	private int id;
	
	private String field_format;
	
	private String name;
	
	private String possible_values;
	
	private boolean is_required;
	
	private String default_value;
	
	private String value;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getField_format() {
		return field_format;
	}

	public void setField_format(String field_format) {
		this.field_format = field_format;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPossible_values() {
		return possible_values;
	}

	public void setPossible_values(String possible_values) {
		this.possible_values = possible_values;
	}

	public boolean isIs_required() {
		return is_required;
	}

	public void setIs_required(boolean is_required) {
		this.is_required = is_required;
	}

	public String getDefault_value() {
		return default_value;
	}

	public void setDefault_value(String default_value) {
		this.default_value = default_value;
	}
	
	public String getValue() {
		return value;
	}
	
	public void setValue(String value) {
		this.value = value;
	}

	@Override
	public void toJson(JSONObject dataObj) {
		dataObj.put("id", this.id);
		dataObj.put("field_format", this.field_format);
		dataObj.put("name", this.name);
		dataObj.put("value", this.value);
		dataObj.put("possible_values", this.possible_values);
		dataObj.put("is_required", this.is_required);
		dataObj.put("default_value", this.default_value);
	}

}
