package co.jp.softbank.qqmx.filter;

import java.io.IOException;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.util.List;
import java.util.Map;

import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.commons.fileupload.FileUploadException;
import org.apache.tomcat.util.http.fileupload.servlet.ServletFileUpload;
import org.ho.yaml.Yaml;
import org.springframework.context.ApplicationContext;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.application.CustomLoaderListener;
import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.info.ControlRequestMap;
import co.jp.softbank.qqmx.info.bean.FilterRequestData;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.SessionData;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.StringUtils;

public class RolesCheckFilter extends AbstractCommonFilter {
    
    public RolesCheckFilter() {
        super();
    }

    public void init(FilterConfig filterConfig) throws ServletException {
    }
    
	public void doFilter(ServletRequest request, ServletResponse response,
            FilterChain chain) throws IOException, ServletException {
    	
    	HttpContext httpContext = null;
    	try {
    		if (request instanceof HttpServletRequest) {
    			final HttpServletRequest req = (HttpServletRequest) request;
    			if (ServletFileUpload.isMultipartContent(req)) {
                	chain.doFilter(request, response);
                	return;
                }
    			httpContext = new HttpContext(request, response);
    			httpContext.createSession();
    			if (ControlRequestMap.getInstance().isIgnoreRole(httpContext.getParam())) {
    				chain.doFilter(request, response);
    				return;
    			}
    			
    			if (!doActionFilter(httpContext)) {
    				rolesException(httpContext);
    				return;
    			}
    			
    			SessionData sessionData = httpContext.getSessionData();
    			UserInfoData userInfoData = sessionData.getUserInfo();
    			if (userInfoData == null || userInfoData.isAdmin()) {
    				chain.doFilter(request, response);
                	return;
    			}
    			Map<String, Object> roleMap = Maps.newHashMap();
    			Map<String, Object> conditions = Maps.newHashMap();
    			conditions.put("user_id", userInfoData.getId());
    			List<Map<String, Object>> roles = db.querysC("roles.selectUserRolesForPublic", conditions);
    			createUserRoleMap(roleMap, roles, false);
    			
    			db.setContext(httpContext);
    			int projectId = httpContext.getParam().projectId;
    			if (projectId != 0) {
    				setMemberRoleByProjectId(request, response, chain, httpContext, sessionData, userInfoData, projectId, roleMap);
				}
    			if (sessionData != null) {
    				sessionData.setRoles(roleMap);
    			}
    			if (!ControlRequestMap.getInstance().checkPermissions(httpContext.getParam(), roleMap)) {
    				rolesException(httpContext);
    				return;
				}
    			chain.doFilter(request, response);
    		}
    	} catch (FileUploadException e) {
    		e.printStackTrace();
    	} catch (SoftbankException e) {
    		if (SoftbankExceptionType.RoleException.equals(e.getExceptionType())) {
    			rolesException(httpContext);
			} else {
				e.printStackTrace();
			}
    	} catch (NoSuchMethodException e) {
			e.printStackTrace();
		} catch (SecurityException e) {
			e.printStackTrace();
		} catch (IllegalAccessException e) {
			e.printStackTrace();
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
		} catch (InvocationTargetException e) {
			e.printStackTrace();
		}
    }

	private void setMemberRoleByProjectId(ServletRequest request, ServletResponse response, FilterChain chain,
			HttpContext httpContext, SessionData sessionData, UserInfoData userInfoData, int projectId, Map<String, Object> roleMap)
			throws SoftbankException, IOException, ServletException {
		Map<String, Object> condition = Maps.newHashMap();
		condition.put("project_id", projectId);
		condition.put("user_id", userInfoData.getId());
		Map<String, Object> projectInfo = db.queryC("projects.getProjectInfoAndCustom", condition);
		if (projectInfo == null) {
			return;
		}
		boolean isPublic = StringUtils.toBoolean(projectInfo.get("is_public"));
		List<Map<String, Object>> roles = db.querysC("roles.selectUserRolesForProject", condition);
		if (roles == null || roles.size() == 0) {
			if (isPublic) {
				if ("1".equals(projectInfo.get("only_member")) && !"3".equals(userInfoData.getEmployeeTypeCd())) {
					throw new SoftbankException(SoftbankExceptionType.RoleException);
				}
				Map<String, Object> nonRole = db.queryC("roles.selectNonmemberRoles");
				createUserRoleMap(roleMap, nonRole);
			} else {
				throw new SoftbankException(SoftbankExceptionType.RoleException);
			}
		} else {
			createUserRoleMap(roleMap, roles, true);
		}
	}

	private void createUserRoleMap(Map<String, Object> roleMap, List<Map<String, Object>> roles, boolean checkVisibility) {
		for (int i = 0; i < roles.size(); i++) {
			Map<String, Object> roleData = roles.get(i);
			if (checkVisibility) {
				String issues_visibility = StringUtils.toString(roleData.get("issues_visibility"));
				if (!roleMap.containsKey("issues_visibility")) {
					roleMap.put("issues_visibility", issues_visibility);
				} else {
					if (IssuesVisibility.get(issues_visibility).getVal() < IssuesVisibility.get(StringUtils.toString(roleMap.get("issues_visibility"))).getVal()) {
						roleMap.put("issues_visibility", issues_visibility);
					}
				}
			}
			createUserRoleMap(roleMap, roleData);
		}
	}

	@SuppressWarnings("unchecked")
	private void createUserRoleMap(Map<String, Object> roleMap, Map<String, Object> roleData) {
		List<String> nonRoles = (List<String>)Yaml.load(StringUtils.toString(roleData.get("permissions")));
		if (nonRoles!= null && nonRoles.size() > 0) {
			for (int j = 0; j < nonRoles.size(); j++) {
				String role = nonRoles.get(j);
				if (role.startsWith(ConstantsUtil.Str.COLON)) {
					role = role.substring(1);
				}
				roleMap.put(role, role);
			}
		}
	}

	private boolean doActionFilter(HttpContext httpContext) throws SoftbankException, NoSuchMethodException, SecurityException, IllegalAccessException, IllegalArgumentException, InvocationTargetException {
		List<FilterRequestData> filterList = ControlRequestMap.getInstance().getFilterList(httpContext.getParam());
		if (filterList == null || filterList.size() == 0) {
			return true;
		}
		final String logicName = ControlRequestMap.getInstance().getLogic(httpContext.getParam());
		final ApplicationContext wac = CustomLoaderListener.getApplicationContext();
		final Object logic = wac.getBean(logicName);
		if (logic instanceof AbstractBaseLogic) {
			final Class<? extends Object> clazz = logic.getClass();
			((AbstractBaseLogic)logic).applicationInit(httpContext);
			
			for (int i = 0; i < filterList.size(); i++) {
				FilterRequestData filterData = filterList.get(i);
				final String methodStr = filterData.getMethod();
				if (StringUtils.isNotEmpty(methodStr)) {
					Method method = clazz.getMethod(methodStr, new Class[]{});
					method.invoke(logic, new Object[]{});
					return httpContext.getResultBean().isFilter();
				}
			}
		}
		return true;
	}

    public void destroy() {
    }
    
    public enum IssuesVisibility {
    	all("all", 0), def("default", 1), own("own", 2);
    	
    	private String key;
    	
    	private int val;
    	
    	private IssuesVisibility(String key, int val) {
    		this.key = key;
    		this.val = val;
		}
    	
    	public static IssuesVisibility get(String key) {
    		if (key.equals(all.getKey())) {
				return all;
			} else if (key.equals(def.getKey())) {
				return def;
			} else if (key.equals(own.getKey())) {
				return own;
			}
    		return def;
    	}

		public String getKey() {
			return key;
		}

		public void setKey(String key) {
			this.key = key;
		}

		public int getVal() {
			return val;
		}

		public void setVal(int val) {
			this.val = val;
		}
    	
    	
    }
    
}
