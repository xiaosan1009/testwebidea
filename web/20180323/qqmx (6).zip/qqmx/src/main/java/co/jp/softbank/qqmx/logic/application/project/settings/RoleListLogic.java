package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.ho.yaml.Yaml;
import org.springframework.beans.factory.annotation.Autowired;

//import co.jp.softbank.qqmx.dao.project.settings.roleList;
import co.jp.softbank.qqmx.dao.project.settings.bean.NewRoleBean;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.PageListBean;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class RoleListLogic extends AbstractBaseLogic {

//	@Autowired
//	private roleList roleList;

	public void getRoleListInfo() throws SoftbankException {
/*		List<Map<String, Object>> RoleList = roleList.getRoleListInfo();
		context.getResultBean().setData(RoleList);*/
		if (StringUtils.isEmpty(context.getParam().get("role_flg"))){
			PageListBean pageListBean = pageList("roleList.getRoleListInfo");
			context.getResultBean().setData(pageListBean);
		} else {			
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("role_flg", context.getParam().get("role_flg"));
			List<Map<String, Object>> info = new ArrayList<Map<String, Object>>();
			info = db.querys("roleList.getRoleListInfo", conditions);
			if (info.size() > 0) {
				Map<String, Object> trackerInfo = info.get(0);
				if ( StringUtils.isEmpty((trackerInfo.get("position_start"))) 
						|| StringUtils.isEmpty(trackerInfo.get("position_end")) 
						|| StringUtils.isEmpty(trackerInfo.get("total_count")) 
						|| !"1".equals(StringUtils.toString(trackerInfo.get("position_start")))
						|| !(StringUtils.toString(trackerInfo.get("position_end")).equals(StringUtils.toString(trackerInfo.get("total_count"))))) {
					db.update("roleList.updatePosition");
				}
			}
		}
	}
	
	public void deleteRoleInfo() throws SoftbankException {
		int role_id = Integer.valueOf(context.getParam().get("role_id"));
		Map<String, Object> roleMap = Maps.newHashMap();
		
		roleMap.put("role_id", role_id);
		
		db.update("roleList.updateRoleInfo", roleMap);
		db.delete("roleList.deleteRoleInfo", roleMap);
		db.delete("roleList.deleteWorkflowsInfo", roleMap);
	}
	
	public void upRoleSort() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		List<Map<String, Object>> roleListEndIdList = db.querys("roleList.getRoleListInfo");
		String str_end_position = String.valueOf(roleListEndIdList.get(Integer.parseInt(context.getParam().get("end_pos"))).get("position"));
		
		conditions.put("role_id", Integer.parseInt(context.getParam().get("role_id")));
		List<Map<String, Object>> roleListIdList = db.querys("roleList.getRoleSortIdInfo", conditions);
		if (Integer.parseInt(str_end_position) > Integer.parseInt(String.valueOf(roleListIdList.get(0).get("position")))){
			conditions.put("end_pos", Integer.parseInt(str_end_position));
			conditions.put("start_pos", Integer.parseInt(String.valueOf(roleListIdList.get(0).get("position"))));
			db.update("roleList.upCommonMSort", conditions);
		}else{
			conditions.put("end_pos", Integer.parseInt(String.valueOf(roleListIdList.get(0).get("position"))));
			conditions.put("start_pos", Integer.parseInt(str_end_position));
			db.update("roleList.upCommonPSort", conditions);
		}
		Map<String, Object> conditionSort = Maps.newHashMap();
		conditionSort.put("role_id", Integer.parseInt(context.getParam().get("role_id")));
		conditionSort.put("end_pos", Integer.parseInt(str_end_position));
		db.update("roleList.upCommonSort", conditionSort);

	}
}
