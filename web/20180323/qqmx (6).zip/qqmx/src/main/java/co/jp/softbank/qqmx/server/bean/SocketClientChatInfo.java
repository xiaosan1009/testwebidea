package co.jp.softbank.qqmx.server.bean;

import net.sf.json.JSONObject;

public class SocketClientChatInfo {
	
	public SocketClientChatInfo(SocketClientInfo clientInfo) {
		this.sessionId = clientInfo.getSessionId();
		this.userId = clientInfo.getUserId();
		this.userName = clientInfo.getUserName();
	}
	
	private String userId;
	
	private String userName;
	
	private String sessionId;
	
	private String chatTime;
	
	private String chatMsg;
	
	private String to;

	public String getUserId() {
		return userId;
	}

	public void setUserId(String userId) {
		this.userId = userId;
	}

	public String getSessionId() {
		return sessionId;
	}

	public void setSessionId(String sessionId) {
		this.sessionId = sessionId;
	}
	

	public String toJsonStr() {
		return toJsonObj().toString();
	}

	public String getUserName() {
		return userName;
	}

	public void setUserName(String userName) {
		this.userName = userName;
	}

	public String getChatTime() {
		return chatTime;
	}

	public void setChatTime(String chatTime) {
		this.chatTime = chatTime;
	}

	public String getChatMsg() {
		return chatMsg;
	}

	public void setChatMsg(String chatMsg) {
		this.chatMsg = chatMsg;
	}

	public String getTo() {
		return to;
	}

	public void setTo(String to) {
		this.to = to;
	}

	public JSONObject toJsonObj() {
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("userId", this.userId);
		jsonObject.put("sessionId", this.sessionId);
		jsonObject.put("userName", this.userName);
		jsonObject.put("chatTime", this.chatTime);
		jsonObject.put("chatMsg", this.chatMsg);
		jsonObject.put("to", this.to);
		return jsonObject;
	}

}
