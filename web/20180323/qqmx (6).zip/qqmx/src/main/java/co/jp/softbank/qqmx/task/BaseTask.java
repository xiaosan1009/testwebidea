package co.jp.softbank.qqmx.task;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.ThreadFactory;
import java.util.concurrent.ThreadPoolExecutor;

import org.slf4j.Logger;

import com.google.common.collect.Lists;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.task.face.IWorker;
import co.jp.softbank.qqmx.util.LogUtil;

public abstract class BaseTask {
	
	protected Logger log = new LogUtil(this.getClass()).getLog();
	
	private long pollWorkerMillis = 100;
	
	private List<Future<IWorker>> futures;
	
	protected ThreadPoolExecutor executor;
	
	protected List<IWorker> workers = new LinkedList<IWorker>();
	
	protected int threads;
	
	public BaseTask() {
	}
	
	public BaseTask(int threads) throws SoftbankException {
		this.threads = threads;
		init(threads);
	}
	
	public void executeTask(IRunTask runTask) throws SoftbankException {
		IWorker worker = null;
		do {
			worker = pollWorker(futures);
		} while (worker == null);
		runTask.renderWorker(worker);
		Future<IWorker> future = executor.submit(worker);
		runTask.preWorker(future, worker);
		postWorker(runTask, future);
		futures.add(future);
	}
	
	public void init() throws SoftbankException {
		init(0);
	}
	
	public void init(int threads) throws SoftbankException {
		if (threads == 0) {
			return;
		}
		executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(threads, new ThreadFactory() {
			int count = 0;
			
			@Override
			public Thread newThread(Runnable r) {
				Thread t = new Thread(r);
				t.setName("line-worker-" + count++);
				return t;
			}
		});
		
		workers.clear();
		
		if (!createWorkers()) {
			return;
		}
		try {
			futures = new LinkedList<Future<IWorker>>(executor.invokeAll(workers));
		} catch (InterruptedException e) {
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.InterruptedException);
		}
	}
	
	protected IWorker pollWorker(List<Future<IWorker>> futures) throws SoftbankException {
		try {
			IWorker worker = null;
			int index = -1;
			for (int i = 0; i < futures.size(); i++) {
				Future<IWorker> temp = futures.get(i);
				if (temp.isDone()) {
					index = i;
					break;
				}
			}
			if (index < 0) {
				synchronized (futures) {
					futures.wait(pollWorkerMillis);
				}
			}
			if (index >= 0) {
				Future<IWorker> future = futures.remove(index);
				if (future.isCancelled()) {
					worker = createWorker();
				} else {
					worker = future.get();
				}
			}
			return worker;
		} catch (InterruptedException e) {
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.InterruptedException);
		} catch (ExecutionException e) {
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.InterruptedException);
		}
    }
	
	protected void clear() {
		try {
			for (IWorker worker : workers) {
				worker.cleanup();
			}
			executor.shutdown();
			workers.clear();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	public abstract boolean createWorkers() throws SoftbankException;
	
	public abstract IWorker createWorker() throws SoftbankException;
	
	public interface IRunTask {
		void renderWorker(IWorker worker);
		void preWorker(Future<IWorker> future, IWorker worker);
		void postWorker(IWorker worker) throws SoftbankException;
	}
	
	private void postWorker(final IRunTask runTask, final Future<IWorker> future) {
		Thread t = new Thread(new Runnable() {
			public void run() {
				try {
					while (!future.isDone() && !future.isCancelled()) {
					}
					if (!future.isCancelled()) {
						IWorker worker = future.get();
						runTask.postWorker(worker);
					}
				} catch (SoftbankException e) {
					e.printStackTrace();
					log.error(e.getErrorMsg(), e);
				} catch (InterruptedException e) {
					e.printStackTrace();
					log.error(e.getMessage(), e);
				} catch (ExecutionException e) {
					e.printStackTrace();
					log.error(e.getMessage(), e);
				}
			}
		});
		t.start();
	}
	
	public static void main(String[] args) {
		List<IWorker> workers = Lists.newArrayList();
		for (int i = 0; i < 10; i++) {
			workers.add(new TestWorker(i));
		}
		ThreadPoolExecutor executor = (ThreadPoolExecutor) Executors.newFixedThreadPool(10, new ThreadFactory() {
			int count = 0;
			
			@Override
			public Thread newThread(Runnable r) {
				Thread t = new Thread(r);
				t.setName("line-worker-" + count++);
				return t;
			}
		});
		try {
			List<Future<IWorker>> futures = new LinkedList<Future<IWorker>>(executor.invokeAll(workers));
			for (int i = 0; i < futures.size(); i++) {
				Future<IWorker> temp = futures.get(i);
				IWorker worker = (TestWorker)temp.get();
				System.out.println("futures("+((TestWorker)temp.get()).getId()+") = " + temp.isDone());
				executor.submit(worker);
			}
		} catch (InterruptedException e) {
			e.printStackTrace();
		} catch (ExecutionException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
	}
	
	/**
	 * @author dev6828503yu
	 *
	 */
	public static class TestWorker implements IWorker {
		
		private int id;
		
		public TestWorker(int id) {
			this.id = id;
		}

		public int getId() {
			return id;
		}

		@Override
		public IWorker call() throws Exception {
			System.out.println("Thread(" + id + ") started!!");
			Thread.sleep(5000);
			System.out.println("Thread(" + id + ") end!!");
			return this;
		}

		@Override
		public void cleanup() throws Exception {
			// TODO 自動生成されたメソッド・スタブ
			
		}
		
	}

}
