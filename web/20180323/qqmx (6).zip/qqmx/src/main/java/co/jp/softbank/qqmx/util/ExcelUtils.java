package co.jp.softbank.qqmx.util;

import java.io.InputStream;

import co.jp.softbank.qqmx.info.bean.ExcelInfoBean;

public class ExcelUtils {
	
	public static ExcelInfoBean readExcelInfo(InputStream is) {
		ExcelInfoBean infoBean = new ExcelInfoBean();
		return infoBean;
	}

}
