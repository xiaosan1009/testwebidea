package co.jp.softbank.qqmx.logic.application.batch;


import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;

import com.google.common.collect.Maps;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

/**
 * 版管理ツール(Git)からソースファイルを取得して、
 * ソース規模情報を収集する処理を行う。
 */
public class SourceDiffCountGitLogic extends SourceScaleCount {
    
    /** 一時ディレクトリ（変更前） */
    private static final String OLD_TMP_DIR = "ipf_git_old_";
    /** 一時ディレクトリ（変更後） */
    private static final String NEW_TMP_DIR = "ipf_git_new_";
    
    /**
     * ソース規模データ収集(Git用) 
     * 
     * @param args コマンドライン引数
     *  引数1 : プロジェクトID（必須）
     *  引数2 : バージョン（必須）
     *  引数3 : リポジトリパス（必須）
     *  引数4 : 収集開始リビジョン番号（任意、デフォルト1）
     * 
     */
	public void sourceDiff() {
		log.debug("☆☆☆ sourceDiffTime  ☆☆☆☆☆☆☆☆☆ Start ☆☆☆");
		try {
			String delFlg    = null;
			String projectId = context.getParam().get("projectId");
			String gitPath = context.getParam().get("gitPath");
			String repoPath = context.getParam().get("repoPath");
			String oldRevision    = context.getParam().get("oldRevision");
			String gitRequest   = context.getParam().get("gitRequest");
			String gitBranch   = context.getParam().get("branch");
			String version = "";
			String filePath = "";
//			gitRequest = "{\"object_kind\":\"push\",\"event_name\":\"push\",\"before\":\"1eb69e18d4fd410260e6253e736942c63bff9b3b\",\"after\":\"efc0fcc3c39c994d31cb320c4478f6f042b0fde7\",\"ref\":\"refs/heads/develop\",\"checkout_sha\":\"efc0fcc3c39c994d31cb320c4478f6f042b0fde7\",\"message\":null,\"user_id\":405,\"user_name\":\"- O Shin - 王 晨（情報システム本部）\",\"user_email\":\"shin.o01@g.softbank.co.jp\",\"user_avatar\":null,\"project_id\":4282,\"project\":{\"name\":\"monitoring-board-sample\",\"description\":\"\",\"web_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/monitoring-board-sample\",\"avatar_url\":null,\"git_ssh_url\":\"git@code-dev.ark.sbb-sys.info:qqmx/monitoring-board-sample.git\",\"git_http_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/monitoring-board-sample.git\",\"namespace\":\"qqmx\",\"visibility_level\":10,\"path_with_namespace\":\"qqmx/monitoring-board-sample\",\"default_branch\":\"master\",\"homepage\":\"http://code-dev.ark.sbb-sys.info/qqmx/monitoring-board-sample\",\"url\":\"git@code-dev.ark.sbb-sys.info:qqmx/monitoring-board-sample.git\",\"ssh_url\":\"git@code-dev.ark.sbb-sys.info:qqmx/monitoring-board-sample.git\",\"http_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/monitoring-board-sample.git\"},\"commits\":[{\"id\":\"efc0fcc3c39c994d31cb320c4478f6f042b0fde7\",\"message\":\"refs #807334\",\"timestamp\":\"2017-12-26T11:09:11+09:00\",\"url\":\"http://code-dev.ark.sbb-sys.info/qqmx/monitoring-board-sample/commit/efc0fcc3c39c994d31cb320c4478f6f042b0fde7\",\"author\":{\"name\":\"dev68443190e\",\"email\":\"dev68443190e@C73DEVPC1530097.dev.g.softbank.co.jp\"},\"added\":[\"sample/src/main/java/jp/co/softbank/qqmx/sample/A3.java\",\"sample/src/main/java/jp/co/softbank/qqmx/sample/A4.java\"],\"modified\":[\"sample/src/main/java/jp/co/softbank/qqmx/sample/A.java\",\"sample/src/main/java/jp/co/softbank/qqmx/sample/App.java\"],\"removed\":[\"sample/src/main/java/jp/co/softbank/qqmx/sample/A2.java\"]}],\"total_commits_count\":1,\"repository\":{\"name\":\"monitoring-board-sample\",\"url\":\"git@code-dev.ark.sbb-sys.info:qqmx/monitoring-board-sample.git\",\"description\":\"\",\"homepage\":\"http://code-dev.ark.sbb-sys.info/qqmx/monitoring-board-sample\",\"git_http_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/monitoring-board-sample.git\",\"git_ssh_url\":\"git@code-dev.ark.sbb-sys.info:qqmx/monitoring-board-sample.git\",\"visibility_level\":10}}";
//			gitRequest = "{\"object_kind\":\"push\",\"event_name\":\"push\",\"before\":\"1eb69e18d4fd410260e6253e736942c63bff9b3b\",\"after\":\"efc0fcc3c39c994d31cb320c4478f6f042b0fde7\",\"ref\":\"refs/heads/feature-qqmxtest2\",\"checkout_sha\":\"efc0fcc3c39c994d31cb320c4478f6f042b0fde7\",\"message\":null,\"user_id\":405,\"user_name\":\"- O Shin - 王 晨（情報システム本部）\",\"user_email\":\"shin.o01@g.softbank.co.jp\",\"user_avatar\":null,\"project_id\":4282,\"project\":{\"name\":\"monitoring-board-sample\",\"description\":\"\",\"web_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/monitoring-board-sample\",\"avatar_url\":null,\"git_ssh_url\":\"git@code-dev.ark.sbb-sys.info:qqmx/monitoring-board-sample.git\",\"git_http_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/monitoring-board-sample.git\",\"namespace\":\"qqmx\",\"visibility_level\":10,\"path_with_namespace\":\"qqmx/monitoring-board-sample\",\"default_branch\":\"master\",\"homepage\":\"http://code-dev.ark.sbb-sys.info/qqmx/monitoring-board-sample\",\"url\":\"git@code-dev.ark.sbb-sys.info:qqmx/monitoring-board-sample.git\",\"ssh_url\":\"git@code-dev.ark.sbb-sys.info:qqmx/monitoring-board-sample.git\",\"http_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/monitoring-board-sample.git\"},\"commits\":[{\"id\":\"efc0fcc3c39c994d31cb320c4478f6f042b0fde7\",\"message\":\"refs #807334\",\"timestamp\":\"2017-12-26T11:09:11+09:00\",\"url\":\"http://code-dev.ark.sbb-sys.info/qqmx/monitoring-board-sample/commit/efc0fcc3c39c994d31cb320c4478f6f042b0fde7\",\"author\":{\"name\":\"dev68443190e\",\"email\":\"dev68443190e@C73DEVPC1530097.dev.g.softbank.co.jp\"},\"added\":[\"sample/src/main/java/jp/co/softbank/qqmx/sample/A3.java\",\"sample/src/main/java/jp/co/softbank/qqmx/sample/A4.java\"],\"modified\":[\"sample/src/main/java/jp/co/softbank/qqmx/sample/A.java\",\"sample/src/main/java/jp/co/softbank/qqmx/sample/App.java\"],\"removed\":[\"sample/src/main/java/jp/co/softbank/qqmx/sample/A.java\",\"sample/src/main/java/jp/co/softbank/qqmx/sample/App.java\"]}],\"total_commits_count\":1,\"repository\":{\"name\":\"monitoring-board-sample\",\"url\":\"git@code-dev.ark.sbb-sys.info:qqmx/monitoring-board-sample.git\",\"description\":\"\",\"homepage\":\"http://code-dev.ark.sbb-sys.info/qqmx/monitoring-board-sample\",\"git_http_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/monitoring-board-sample.git\",\"git_ssh_url\":\"git@code-dev.ark.sbb-sys.info:qqmx/monitoring-board-sample.git\",\"visibility_level\":10}}";
			log.debug("☆☆☆ sourceDiffTime  ☆☆☆☆☆☆☆☆☆  gitRequest ☆☆☆" + gitRequest);
			if (StringUtils.isEmpty(oldRevision)){
				oldRevision = null;
			}
			if (StringUtils.isEmpty(gitRequest)){
				return;
			}
			
			JSONObject json = JSONObject.fromObject(gitRequest);
			
			String ref = "";
			if ( json.containsKey("ref") && json.get("ref") != null ) {
				ref = json.get("ref").toString();
			}
			
			// ブランチ
			String branch = getBranch(ref);
			log.debug("☆☆☆ sourceDiffTime  ☆☆☆☆☆☆☆☆☆  gitRequest ☆☆☆ branch ☆☆☆☆☆" + branch);
			log.debug("☆☆☆ sourceDiffTime  ☆☆☆☆☆☆☆☆☆  gitRequest ☆☆☆ gitBranch ☆☆☆☆☆" + gitBranch);
			if ( !StringUtils.isEmpty(gitBranch) ) {
				if (!gitBranch.equals(branch)){
					return;
				}
			}
			
			String oldRevStr = oldRevision;
			String newRevStr = "";
			if ( json.containsKey("after") && json.get("after") != null ) {
				newRevStr = json.get("after").toString();
				version = newRevStr;
			}
			String issueId = "";
			String changeResult = "";
			Date changeDate = new Date();
			log.debug("changeDate   :" + changeDate);
			if ( json.containsKey("commits") && json.get("commits") != null  ) {
				JSONArray commits = json.getJSONArray("commits");
				String message = commits.getJSONObject(0).getString("message");
				String timestamp = commits.getJSONObject(0).getString("timestamp");
				
				// test
				String added = commits.getJSONObject(0).getString("added");
				String modified = commits.getJSONObject(0).getString("modified");
				String removed = commits.getJSONObject(0).getString("removed");
				
				// ファイル名
				if( !"[]".equals(added) ){
					// 新規
					String addedFile = getFileName(added);
					changeResult = changeResult + addedFile;
				}
				if( !"[]".equals(modified) ){
					// 修正
					if( !"[]".equals(added) ){						
						changeResult = changeResult + ",";
					}
					modified = getFileName(modified);
					changeResult = changeResult + modified;
				}
				changeResult = changeResult.replace("\"", "");
				
				if( !"[]".equals(removed) ){
					// 新規
					String removedFile = getFileName(removed).replace("\"", "");
					String [] deleteFile = removedFile.split(",");

					for (int i = 0; i < deleteFile.length; i++) {
						log.debug("changeFile   :" + deleteFile[i]);
						String dFilePath = deleteFile[i].substring(0, deleteFile[i].lastIndexOf("/") + 1);
						String dFileName = deleteFile[i].substring(deleteFile[i].lastIndexOf("/") + 1);
						
					    Map<String, Object> conditions = Maps.newHashMap();
					    
					    conditions.put("project_id", Integer.parseInt(projectId));
					    conditions.put("filePath", dFilePath);
					    conditions.put("fileName", dFileName);

					    db.delete("sourceScale.deleteSourceDiff", conditions);
					}
				}
				
//				String [] changeFile = changeResult.split(",");
//				
//				for (int i = 0; i < changeFile.length; i++) {
//					log.debug("changeFile   :" + changeFile[i]);
//				}
				// test
				// チケットID
				issueId = getIssuesId(message);
				changeDate = getChangeData(timestamp);
				log.debug("timestamp   :" + changeDate);
			} 
			if ( StringUtils.isEmpty(changeResult) ) {
				log.debug("changeResult is Null");
				return;
			}
			String [] changeFile = changeResult.split(",");
			log.debug("issueId   :" + issueId);
			if ( StringUtils.isEmpty(issueId) ) {
				log.debug("issueId is Null");
				return;
			}
			int ticketId = Integer.parseInt(issueId);
			
			log.debug("projectId   :" + projectId);
			log.debug("version     :" + version);
			log.debug("repoPath    :" + repoPath);
			log.debug("gitPath    :" + gitPath);
			log.debug("filePath    :" + filePath);
			log.debug("delFlg      :" + delFlg);
			log.debug("oldRevStr   :" + oldRevStr);
			log.debug("newRevStr   :" + newRevStr);
			
			if (StringUtils.isEmpty(projectId) || StringUtils.isEmpty(gitPath) || StringUtils.isEmpty(repoPath) || StringUtils.isEmpty(branch) || StringUtils.isEmpty(newRevStr) ) {
				log.debug("isNull");
				return;
			}

            // テスト用　２３０不要 
            /*projectId = context.getParam().get("projectId");
            //String gitPath = context.getParam().get("gitPath");
            //gitPath = "C:\\Users\\dev68443190e\\Desktop\\gitRepository\\review-platform.git\\";
            repoPath = "C:\\Users\\dev68443190e\\Desktop\\gitRepository\\sample.git\\.git";
            version = "version_1.0";
            //filePath  = "C:\\Users\\dev68443190e\\Desktop\\difftest";
            oldRevStr = "43b2639bea82fc3f21dbd675d0db147cd9f2c4ce";
            newRevStr = "8d8a4f9165557ca73f9a55012e6df1a7a2321a77";
            */
            // ２３０要　テスト不要 
//			checkoutFile(gitPath, branch);
			log.debug("checkoutFile complete");

//            if ("/".equals(filePath.substring(0, 1))) {
//            	filePath = filePath.substring(1);
//            }

    		if (newRevStr == null) {
    			newRevStr = "HEAD";
    		}
//    		oldRevStr = "93f66fa360b4ea9489625388b123caf9a2647ff4";
//    		oldRevStr = null;
//    		
            // ソース規模収集
            sourceScaleCollect(projectId, ticketId, version, repoPath, filePath, delFlg, oldRevStr, newRevStr, changeDate, changeFile, branch);
            
        } catch (Throwable e) {
        	log.error("Throwable: " + e);
        } 
		finally {
        }
		log.debug("☆☆☆ sourceDiffTime  ☆☆☆☆☆☆☆☆☆ End ☆☆☆");
    }
    
    public void checkoutFile(String gitPath, String branch) {
		try {
			String cmd = "/opt/ipftools/review-platform.git/checkoutGitFile.sh " 
	    			 + gitPath + " " + branch;
			Process process = Runtime.getRuntime().exec(cmd);

			process.waitFor();
			process.destroy();
			
			log.debug("☆☆☆ cmd ☆☆☆" + cmd);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
    }

    /**
     * ソース規模データを集計してIPF・DBに登録する。
     * 
     * @param projectId プロジェクトID
     * @param version バージョン
     * @param repoPath リポジトリパス
     * @param oldRev 開始リビジョン
     * @param configInfo Pentaho 設定ファイル情報
     * @throws Exception 
     */
    public void sourceScaleCollect(
            String projectId, 
            int ticketId,
            String version, 
            String repoPath,
            String filePath, 
            String delFlg,
            String oldRev,
            String newRev,
            Date changeDate,
            String [] changeFile,
            String branch
        ) throws Exception {

        File oldTmpDir = null;
        File newTmpDir = null;
        
        try {
            
            // 一時ディレクトリ作成
            oldTmpDir = createTempDirectory(projectId + "_" + version + "_" + OLD_TMP_DIR, ".tmp");
            newTmpDir = createTempDirectory(projectId + "_" + version + "_" + NEW_TMP_DIR, ".tmp");
            log.debug("Temp Dir Create.");

            // Gitソースエクスポート
            IpfJGitUtils.export(repoPath, oldRev, newRev, oldTmpDir, newTmpDir);

            // 前回のデータ削除
            if ("1".equals(delFlg)) {
                deleteSourceDiff(projectId, version);
            }
            
            // 差分処理
            log.debug("diff start.");
            log.debug("diff old start.");
            diff(projectId, ticketId, version, repoPath, filePath, oldTmpDir.getName(), newTmpDir.getName(), oldTmpDir, true , changeDate, changeFile, branch);
            log.debug("diff new start.");
            diff(projectId, ticketId, version, repoPath, filePath, newTmpDir.getName(), oldTmpDir.getName(), newTmpDir, false, changeDate, changeFile, branch);
            log.debug("diff end.");
			
		} catch (Exception e) {
			try {
			} catch (Exception e2) {
			}
		} finally {
        }
    }

	public void diff(String projectId, int ticketId, String version, String repoPath, String filePath, String dirPathFrom,
			String dirPathTo, File dirForm, boolean diffFlg, Date changeDate, String [] changeFile, String branch) throws Exception {

		File[] files = dirForm.listFiles();

		if (files == null) {
			return;
		}
		
		for (File file : files) {
			if (!file.exists()) {
				continue;
			} else if (file.isDirectory()) {
				diff(projectId, ticketId, version, repoPath, filePath, dirPathFrom, dirPathTo, file, diffFlg, changeDate, changeFile, branch);
			} else if (file.isFile()) {
				// ソースファイル取得、ソース規模情報取得、DB登録
				sourceScaleCollectAndDbInsert(projectId, ticketId, version, repoPath, filePath, file,
						new File(file.getPath().replaceAll(dirPathFrom, dirPathTo)), diffFlg, changeDate, changeFile, branch);
			}
		}
	}
	
    /**
     * ソースファイルを取得して、ソース規模データを集計しDBに登録する。
     * 
     * @param conn DBコネクション
     * @param pstmt プレペアド・ステートメント
     * @param projectId プロジェクトID
     * @param version バージョン
     * @param repository リポジトリ
     * @param logEntry コミットログ
     * @param entryPath コミットファイル
     * @param oldTmpDir 一時ディレクトリ（変更前）
     * @param newTmpDir 一時ディレクトリ（変更後）
     * @throws Exception 
     */
    protected void sourceScaleCollectAndDbInsert (
            String projectId,
            int ticketId,
            String version,
            String repoPath,
            String filePathGit,
            File fromFile,
            File toFile,
            boolean diffFlg,
            Date changeDate,
            String [] changeFile,
    		String branch) throws Exception {

    	try {
	        long revision       = 0;  // リビジョン番号
	        
	        String filePath     = fromFile.getPath();                            // ファイルフルパス（ファイル名含む）
	        String filePathOnly = FilenameUtils.getPath(filePath);  				// ファイルパスのみ（ファイル名除く）
	        filePathOnly = filePathGit + FilenameUtils.separatorsToUnix(filePathOnly.substring(filePathOnly.indexOf(".tmp") + 5));
	        String fileName     = FilenameUtils.getName(filePath);                // ファイル名（拡張子含む）
	        String fileExt      = FilenameUtils.getExtension(filePath);           // 拡張子
	        
	        // ソース規模収集可否チェック
	        if (!isCountable(filePath)) {
	            // ログ出力（ファイル毎）（スキップ）
//	            String msgskip = String.format(resource.getString("log.file.collect.skip"), filePath);
//	            log.debug(msgskip);
	            return;
	        }
//	        Iterator<RevCommit> revIter = null;
//	        Repository repository = IpfJGitUtils.getGitRepository(repoPath);
//	        revIter = IpfJGitUtils.getRevList(repository);
//	        if (revIter.hasNext()) {
//                RevCommit commit = revIter.next();
//                String message      = commit.getFullMessage();              // コミットメッセージ
//                log.debug("message" + message);
//	        }
	        // ソース規模取得
	        SourceScaleResult result = null;
	        if (diffFlg) {
	        	result = count(fromFile, toFile);
	        } else {
	        	result = count(toFile, fromFile);
	        }
	        result.setRevision(Long.toString(revision));
	        result.setFilePath(filePathOnly);
	        result.setFileName(fileName);
	        result.setFileExt(fileExt);
	        
			String fileInfo = filePathOnly + fileName;
			log.debug("fileInfo   :" + fileInfo);
			for (int i = 0; i < changeFile.length; i++) {
				if (changeFile[i].equals(fileInfo)){
					log.debug("changeFile   :" + changeFile[i]);
					// ソース規模DB登録
					insertSourceDiff(projectId, ticketId, version, repoPath, result, changeDate, branch);
				}
			}

//	        // ソース規模DB登録
//	        insertSourceDiff(projectId, ticketId, version, repoPath, result, changeDate);

	        // ログ出力（ファイル毎）（処理成功）
//	        String msgok = String.format(resource.getString("log.file.collect.end"), filePath);
//	        log.debug(msgok);
        } finally {
            // 一時ファイル削除
            if (fromFile != null) FileUtils.deleteQuietly(fromFile);
            if (toFile != null) FileUtils.deleteQuietly(toFile);
            log.debug("File Remove.");
        }
            
    }
    
    protected String getBranch (String ref) throws Exception {
		String gBranch = ref.replace("refs/heads/", "");
		return gBranch;
	}

	protected String getIssuesId (String message) throws Exception {
		String issuesId = "";
		// コミットログからチケットIDを抽出するための正規表現
		String regexp = 
			"(?:close|closed|closes|fix|fixed|fixes|addresses|references|refs|re|see|[\\s,&]+|[\\s]*and)[\\s]*" + 
			"(?:ticket\\:|issue\\:|bug\\:|#)([0-9]+)";
		
		Pattern p = Pattern.compile(regexp, Pattern.MULTILINE);
		Matcher m = p.matcher(message.toLowerCase());
		while(m.find()){
			if (m.groupCount() > 0) {
				String ticketId = m.group(1);
				log.debug("[Trac] ticketId:" + ticketId);
				issuesId = ticketId;
				return issuesId;
			}
		}
		return issuesId;
	}
	
	protected Date getChangeData (String timestamp) throws Exception {
		SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss");	
		Date cData =  sdf.parse(timestamp);
		return cData;
	}
	
	protected String getFileName (String message) throws Exception {
		String fileName = "";
		if (StringUtils.isEmpty(message))
		{
			return fileName;
		}
		fileName = message.substring(message.indexOf("[\""), message.lastIndexOf("\"]")).replace("[\"", "");
		return fileName;
	}
}
