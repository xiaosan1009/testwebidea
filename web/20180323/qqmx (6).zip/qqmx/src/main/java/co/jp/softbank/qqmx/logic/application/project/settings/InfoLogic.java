package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.Param;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Maps;

public class InfoLogic extends AbstractBaseLogic {
	
	public LogicBean getProjectInfo() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		
		String projectIdString = context.getParam().get("proId");
		log.info("projectIdString = " + projectIdString);
		UserInfoData userInfoData = (UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY);
		Map<String, String> params = Maps.newHashMap();
		params.put("userLogin", userInfoData.getLogin());
		String result = externalHttpServer.getStr("projects/" + projectIdString + ".json", params);
		logicBean.setData(result);
		return logicBean;
	}
	
	public LogicBean submitProjectInfo() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		Integer parentId = null;
		if (StringUtils.isNotEmpty(context.getParam().get("project_parent_id"))) {
			parentId = Integer.parseInt(context.getParam().get("project_parent_id"));
		}
		String projectIdString = context.getParam().get("proId");
		conditions.put("project_id", Integer.parseInt(projectIdString));
		conditions.put("project_name", context.getParam().get("project_name"));
		conditions.put("project_parent_id", parentId);
		conditions.put("project_description", context.getParam().get("project_description"));
		conditions.put("project_identifier", context.getParam().get("project_identifier"));
		conditions.put("project_is_public", ("1".equals(context.getParam().get("project_is_public")) ? true : false));
		conditions.put("project_homepage", context.getParam().get("project_homepage"));
		conditions.put("project_landingpage", ConstantsUtil.Str.EMPTY);
		db.update("info.updateProjectInfo", conditions);
	
		context.getParam().each(new Param.EachFilter() {
			@Override
			public void filter(String key, String value) throws SoftbankException {
				if (key.startsWith("project_custom_field_values_")) {
					String pIdString = context.getParam().get("proId");
					Map<String, Object> customValueInfo = Maps.newHashMap();
					customValueInfo.put("customized_id", Integer.parseInt(pIdString));
					customValueInfo.put("custom_field_id", Integer.parseInt(key.substring("project_custom_field_values_".length())));
					customValueInfo.put("value", value);
					List<Map<String, Object>> projectInfos = null;
					try {
						projectInfos = db.querys("info.selectProjectsCustomValues", customValueInfo);
					} catch (SoftbankException e) {
						e.printStackTrace();
					}
					if (projectInfos.size() == 0){
						db.insert("info.insertProjectsCustomValues", customValueInfo);
					}else{
						db.update("info.updateProjectsCustomValues", customValueInfo);
					}
				}
			}
		});
		return logicBean;
	}

}
