package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

//import co.jp.softbank.qqmx.dao.project.settings.prjectSetting;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.util.StringUtils;

public class EditUserRoleLogic extends AbstractBaseLogic {

	public void editUserRoles() throws SoftbankException {
		String type = context.getParam().get("type");
		int user_id = context.getParam().getInt("user_id");
		String[] roles = context.getParam().getList("edit_user_role_role_selector");
		if ("user".equals(type)) {
			createRoleInfoForUser(user_id, roles);
		} else {
			createRoleInfoForMember(user_id, roles);
		}
	}

	private void createRoleInfoForMember(int user_id, String[] roles) throws SoftbankException {
		int projectId = context.getParam().getInt("projectId");
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("userId", user_id);
		conditions.put("user_id", user_id);
		conditions.put("project_id", projectId);
		Map<String, Object> memberInfo = db.query("users.selectUserMemberInfo", conditions);
		int membersId = StringUtils.toInt(memberInfo.get("id"));
		String userType = StringUtils.toString(memberInfo.get("type"));
		conditions.put("member_id", membersId);
		if ("Group".equals(userType)) {
			db.delete("member_roles.deleteMemberRoleByGroupId", conditions);
		} else {
			db.delete("member_roles.deleteMemberRoleByUserId", conditions);
		}
		if (roles != null && roles.length > 0) {
			for (int j = 0; j < roles.length; j++) {
				Map<String, Object> insertData = Maps.newHashMap();
				insertData.put("member_id", membersId);
				insertData.put("role_id", StringUtils.toInt(roles[j]));
				insertData.put("inherited_from", null);
				db.insert("member_roles.insertMemberRole", insertData);
				if ("Group".equals(userType)) {
					int groupRoleId = StringUtils.toInt(insertData.get("id"));
					conditions = Maps.newHashMap();
					conditions.put("group_id", user_id);
					conditions.put("project_id", projectId);
					List<Integer> selectGroupUserList = db.queryos("groups_users.selectMemberIdByGroupId", conditions);
					for (int k = 0; k < selectGroupUserList.size(); k++) {
						membersId = selectGroupUserList.get(k);
						for (int l = 0; l < roles.length; l++) {
							insertData = Maps.newHashMap();
							insertData.put("member_id", membersId);
							insertData.put("role_id", StringUtils.toInt(roles[l]));
							insertData.put("inherited_from", groupRoleId);
							db.insert("member_roles.insertMemberRole", insertData);
						}
					}
				}
			}
		} else {
			conditions.put("group_id", user_id);
			db.delete("members.deleteMemberInfo", conditions);
			if ("Group".equals(userType)) {
				db.delete("members.deleteMemberInfoByGroup", conditions);
			}
		}
	}

	private void createRoleInfoForUser(int user_id, String[] roles) throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("userId", user_id);
		conditions.put("user_id", user_id);
		String userType = db.queryo("users.selectTypeByUserId", conditions);
		if ("Group".equals(userType)) {
			db.delete("user_roles.deleteUserRoleByGroupId", conditions);
		} else {
			db.delete("user_roles.deleteUserRoleByUserId", conditions);
		}
		if (roles != null && roles.length > 0) {
			for (int j = 0; j < roles.length; j++) {
				Map<String, Object> insertData = Maps.newHashMap();
				insertData.put("user_id", user_id);
				insertData.put("role_id", StringUtils.toInt(roles[j]));
				insertData.put("inherited_from", null);
				db.insert("user_roles.insertUserPublicRole", insertData);
				if ("Group".equals(userType)) {
					int groupRoleId = StringUtils.toInt(insertData.get("id"));
					conditions = Maps.newHashMap();
					conditions.put("group_id", user_id);
					List<Map<String, Object>> selectGroupUserList = db.querys("groups_users.selectUserIdByGroupId", conditions);
					for (int k = 0; k < selectGroupUserList.size(); k++) {
						Map<String, Object> user = selectGroupUserList.get(k);
						for (int l = 0; l < roles.length; l++) {
							insertData = Maps.newHashMap();
							insertData.put("user_id", StringUtils.toInt(user.get("user_id")));
							insertData.put("role_id", StringUtils.toInt(roles[l]));
							insertData.put("inherited_from", groupRoleId);
							db.insert("user_roles.insertUserPublicRole", insertData);
						}
					}
				}
			}
		}
	}
	
	private int insertMember(int user_id, int project_id) throws SoftbankException{
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("user_id", user_id);
		conditions.put("project_id", project_id);
		Integer count = db.queryo("members.checkMemberExist", conditions);
		if (count != null) {
			return count.intValue();
		}
		db.insert("members.insertMemberInfo", conditions);
		return StringUtils.toInt(conditions.get("id"));
	}
}
