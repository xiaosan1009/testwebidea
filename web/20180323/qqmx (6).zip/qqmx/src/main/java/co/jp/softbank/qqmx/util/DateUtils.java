package co.jp.softbank.qqmx.util;

import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.GregorianCalendar;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.info.ControlDbMemory;
import co.jp.softbank.qqmx.util.bean.DaysBetweenInfo;

public class DateUtils {
	
	public static final String FORMAT_YEAR = "yyyy";
	
	public static final String FORMAT_MONTH = "MM";
	
	public static final String FORMAT_DAY = "dd";
	
	public static final String FORMAT_YYYYMM = "yyyyMM";
	
	public static final String FORMAT_MMDD_SLASH = "MM/dd";
	
	public static final String FORMAT_YYYYMMDD = "yyyyMMdd";
	
	public static final String FORMAT_YYYYMMDD_SLASH = "yyyy/MM/dd";
	
	public static final String FORMAT_YYYYMMDD_DASH = "yyyy-MM-dd";
	
	public static final String FORMAT_YYYYMMDDHHMMSS = "yyyyMMddHHmmss";
	
	public static final String FORMAT_YYYYMMDDHHMMSS_SLASH = "yyyy/MM/dd HH:mm:ss";
	
	public static final String FORMAT_YYYYMMDDHHMMSS_DASH = "yyyy-MM-dd HH:mm:ss";
	
	public static final String FORMAT_HHMMSS = "HH:mm:ss";
	
	public static final String FORMAT_DDMMMYYYY_DOT = "dd.MM.yyyy";
    
    /**
     * 格式为【yyyyMMdd】.
     */
    public static final String FORMAT_DD = "dd";
    /**
     * 格式为【yyyy/MM/dd】.
     */
    public static final String FORMAT_YMD = "yyyy/MM/dd";
    /**
     * 格式为【yyyy-MM-dd】.
     */
    public static final String FORMAT_YMD2 = "yyyy-MM-dd";
    /**
     * 格式为【yyyy年MM月dd日】.
     */
    public static final String FORMAT_YEAR_MONTH_DATE = "yyyy年MM月dd日";
    /**
     * 格式为【yyyy年MM月】.
     */
    public static final String FORMAT_YEAR_MONTH = "yyyy年MM月";
    /**
     * 格式为【yyyy年MM月dd日(E)】.
     */
    public static final String FORMAT_YEAR_MONTH_DATE_DAY = "yyyy年MM月dd日(E)";
    
    /**
     * 格式为【yyyy/MM/dd HH:mm:ss】.
     */
    public static final String FORMAT_YYYYMMDDHHSS = "yyyy/MM/dd HH:mm:ss";
    /**
     * 格式为【yyyy-MM-dd HH:mm:ss】.
     */
    public static final String FORMAT_YYYYMMDDHHSS2 = "yyyy-MM-dd HH:mm:ss";
    /**
     * 格式为【yyyyMMddHHmmss】.
     */
    public static final String FORMAT_YYYYMMDDHHSS3 = "yyyyMMddHHmmss";
    /**
     * 格式为【yyyy/MM/dd HH:mm】.
     */
    public static final String FORMAT_YYYYMMDDHHMM = "yyyy/MM/dd HH:mm";
    /**
     * 格式为【yyyy/MM/dd/HH/mm】.
     */
    public static final String FORMAT_YYYYMMDDHHMM2 = "yyyy/MM/dd/HH/mm";
    /**
     * 格式为【HH:mm:ss】.
     */
    public static final String FORMAT_HH_MM_SS = "HH:mm:ss";
    /**
     * 格式为【HH/mm】.
     */
    public static final String FORMAT_HHMM1 = "HH:mm";
    /**
     * 格式为【HH/mm】.
     */
    public static final String FORMAT_HHMM2 = "HH/mm";
    /**
     * 格式为【yyyy年MM月dd日HH:mm:ss】.
     */
    public static final String FORMAT_YEAR_MONTH_DATE_TIME = "yyyy年MM月dd日HH:mm:ss";
    /**
     * 格式为【yyyy年MM月dd日 HH:mm】.
     */
    public static final String FORMAT_YEAR_MONTH_DATE_TIME2 = "yyyy年MM月dd日 HH:mm";
	
	public static String getNow(String format) {
		return makeFormat(GregorianCalendar.getInstance(), format);
	}
	
	public static Date getNow() {
		return GregorianCalendar.getInstance().getTime();
	}
	
	public static long getNowTime() {
		return getNow().getTime();
	}
	
	public static String makeFormat(Calendar cal, String format) {
		DateFormat df = new SimpleDateFormat(format);
		return df.format(cal.getTime());
	}
	
	public static String makeFormat(Date date, String format) {
		if (date == null) {
			return null;
		}
		Calendar cal = GregorianCalendar.getInstance();
		cal.setTime(date);
		return makeFormat(cal, format);
	}
	
	public static Date formatToDate(String date, String format) throws SoftbankException {
		final DateFormat dt = new SimpleDateFormat(format);
		try {
			Date result = dt.parse(date);
			return result;
		} catch (ParseException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IllegalAccessException, e);
		}
	}
	
	public static int getWeek(Date date) {
		Calendar cal = GregorianCalendar.getInstance();
		cal.setTime(date);
		return cal.get(Calendar.DAY_OF_WEEK);
	}
	
	public static String calcDate(Date date, String format, int val) throws SoftbankException {
		Calendar calendar = GregorianCalendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.DAY_OF_MONTH, calendar.get(Calendar.DAY_OF_MONTH) + val);
		return makeFormat(calendar, format);
	}
	
	public static Date calcDateForDate(Date date, int val) throws SoftbankException {
		Calendar calendar = GregorianCalendar.getInstance();
		calendar.setTime(date);
		calendar.set(Calendar.DAY_OF_MONTH, calendar.get(Calendar.DAY_OF_MONTH) + val);
		return calendar.getTime();
	}
	
	public static Date calcDateForDate(String date, String format, int val) throws SoftbankException {
		Calendar calendar = GregorianCalendar.getInstance();
		calendar.setTime(formatToDate(date, format));
		calendar.set(Calendar.DAY_OF_MONTH, calendar.get(Calendar.DAY_OF_MONTH) + val);
		return calendar.getTime();
	}
	
	public static String calcDate(String date, String format, int val) throws SoftbankException {
		Calendar calendar = GregorianCalendar.getInstance();
		calendar.setTime(formatToDate(date, format));
		calendar.set(Calendar.DAY_OF_MONTH, calendar.get(Calendar.DAY_OF_MONTH) + val);
		return makeFormat(calendar, format);
	}
	
	public static int weekOfYear(String date, String format) throws SoftbankException {
		Calendar calendar = GregorianCalendar.getInstance();
		calendar.setTime(formatToDate(date, format));
		return calendar.get(Calendar.WEEK_OF_YEAR);
	}
	
	public static int daysBetween(Date date1, Date date2) throws SoftbankException {
		long interval = date2.getTime() - date1.getTime();
		return (int)(interval / 24 / 60 / 60 / 1000) + 1;
	}
	
	public static int daysBetweenUncludeHoliday(String date1, String date2) throws SoftbankException {
		return daysBetweenUncludeHoliday(formatToDate(date1, FORMAT_YYYYMMDD_DASH), formatToDate(date2, FORMAT_YYYYMMDD_DASH));
	}
	
	public static DaysBetweenInfo daysBetweenUncludeHolidayForBean(String date1, String date2) throws SoftbankException {
		return daysBetweenUncludeHolidayForBean(formatToDate(date1, FORMAT_YYYYMMDD_DASH), formatToDate(date2, FORMAT_YYYYMMDD_DASH));
	}
	
	public static int daysBetweenUncludeHoliday(Date date1, Date date2) throws SoftbankException {
		int count = 0;
		while (date2.compareTo(date1) >= 0) {
			if (DateUtils.getWeek(date1) != 1 && DateUtils.getWeek(date1) != 7 && !ControlDbMemory.getInstance().isHoliday(date1)) {
				count++;
			}
			date1 = DateUtils.calcDateForDate(date1, 1);
		}
		return count;
	}
	
	public static DaysBetweenInfo daysBetweenUncludeHolidayForBean(Date date1, Date date2) throws SoftbankException {
		DaysBetweenInfo bean = new DaysBetweenInfo();
		int count = 0;
		while (date2.compareTo(date1) >= 0) {
			if (DateUtils.getWeek(date1) != 1 && DateUtils.getWeek(date1) != 7 && !ControlDbMemory.getInstance().isHoliday(date1)) {
				if (bean.getStartDate() == null) {
					bean.setStartDate(date1);
				}
				bean.setEndDate(date1);
				count++;
			}
			date1 = DateUtils.calcDateForDate(date1, 1);
		}
		bean.setDays(count);
		return bean;
	}
	
	public static Date getNextNotHoliday(Date date) throws SoftbankException {
		do {
			date = DateUtils.calcDateForDate(date, 1);
		} while (DateUtils.getWeek(date) == 1 || DateUtils.getWeek(date) == 7 || ControlDbMemory.getInstance().isHoliday(date));
		return date;
	}
	
	public static Date getPrevNotHoliday(Date date) throws SoftbankException {
		do {
			date = DateUtils.calcDateForDate(date, -1);
		} while (DateUtils.getWeek(date) == 1 || DateUtils.getWeek(date) == 7 || ControlDbMemory.getInstance().isHoliday(date));
		return date;
	}
	
	public static int compare(String date1, String date2, String format) throws SoftbankException {
		return formatToDate(date1, format).compareTo(formatToDate(date2, format));
	}

	public static void main(String[] args) throws SoftbankException {
//		System.out.println(calcDateForDate("2016-07-11", FORMAT_YYYYMMDD_DASH, -31));
		System.out.println(daysBetween(formatToDate("2016-07-10", FORMAT_YYYYMMDD_DASH), formatToDate("2016-07-11", FORMAT_YYYYMMDD_DASH)));
//		System.out.println(getNow(FORMAT_YYYYMMDD_DASH));
//		System.out.println(String.format("%02d", 19d));
//		System.out.println(GregorianCalendar.getInstance().getTime().getTime());
//		System.out.println(weekOfYear("2017-03-15", FORMAT_YYYYMMDD_DASH));
	}
	
	public static String getNowTime(String format) {

		return makeFormat(GregorianCalendar.getInstance(), format);
	}
	
}
