package co.jp.softbank.qqmx.logic.application.mit;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.PageListBean;
import co.jp.softbank.qqmx.util.StringUtils;


public class MitListHTLogic extends AbstractBaseLogic {
	
	public void getMitProjectListInfo() throws SoftbankException, UnsupportedEncodingException {
		Map<String, Object> conditions = Maps.newHashMap();
		String divisionId = context.getParam().get("divisionId");
		String departmentId = context.getParam().get("departmentId");
		String regionId = context.getParam().get("regionId");
		String statusId = context.getParam().get("statusId");
		String type = context.getParam().get("mit_list_select");
		String searchName = "";
		try {
			searchName = URLDecoder.decode(context.getParam().get("searchName"), "utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		
		String organizationCd = divisionId;
		if (!"9898".equals(regionId)) {
			organizationCd = regionId;
		} else if (!"9898".equals(departmentId)) {
			organizationCd = departmentId;
		}
		conditions.put("organization_cd", organizationCd);
		conditions.put("status_Id", Integer.valueOf(statusId));
		conditions.put("search_name", searchName);
		
		PageListBean pageListBean = new PageListBean();
		// バージョン指定ません
		if(StringUtils.isEmpty(type) || "1".equals(type)){
			pageListBean = pageList("mitlistHT.getMitProjectNoversionListInfo",conditions);
		}
		else{
			// バージョン含む
			pageListBean = pageList("mitlistHT.getMitProjectListInfo",conditions);
		}
		context.getResultBean().setData(pageListBean);
	}

	public void getMitSumProjectListInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String divisionId = context.getParam().get("divisionId");
		String departmentId = context.getParam().get("departmentId");
		String regionId = context.getParam().get("regionId");
		String statusId = context.getParam().get("statusId");
		String searchName = "";
		try {
			searchName = URLDecoder.decode(context.getParam().get("searchName"), "utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		
		String organizationCd = divisionId;
		if (!"9898".equals(regionId)) {
			organizationCd = regionId;
		} else if (!"9898".equals(departmentId)) {
			organizationCd = departmentId;
		}
		conditions.put("organization_cd", organizationCd);
		conditions.put("status_Id", Integer.valueOf(statusId));
		conditions.put("search_name", searchName);
		
		PageListBean pageListBean = pageList("mitlistHT.getMitSumProjectListInfo",conditions);
		context.getResultBean().setData(pageListBean);
	}

	public void getIssuesInfo() throws SoftbankException {
		
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, Object> conditions = Maps.newHashMap();
		
		if(isSosiki()){
			
			String sosiki_cd = context.getParam().get("organizationCd");
			conditions.put("organization_cd", sosiki_cd);
			
			String searchName = "";
			try {
				searchName = URLDecoder.decode(context.getParam().get("searchName"), "utf-8");
			} catch (UnsupportedEncodingException e) {
				// TODO 自動生成された catch ブロック
				e.printStackTrace();
			}
			conditions.put("search_name", searchName);
			
			conditions.put("project_id", 1464);
			List<Map<String, Object>> project = db.querys("dashboard.getProject", conditions);
		
			
			resultMap.put("project", project);
			List<Map<String, Object>> lstInfo = db.querys("mitlistHT.getTotalCutHourInfo", conditions);
			
			resultMap.put("lstInfo", lstInfo);
			List<Map<String, Object>> bugsInfo = db.querys("mitlistHT.getTotalEntrustHourInfo", conditions) ;
			resultMap.put("bugsInfo", bugsInfo);
			List<Map<String, Object>> sum = db.querys("mitlistHT.getMitTotalProjectListInfo", conditions);
			
			resultMap.put("sum", sum);
			context.getResultBean().setData(resultMap);
		}else{
			String project_id = context.getParam().get("projectId");
			conditions.put("project_id", Integer.parseInt(project_id));
			String versionId = context.getParam().get("versionId") ;
			if(StringUtils.isNotEmpty(versionId)){
				conditions.put("versionId", Integer.parseInt(versionId));
			}
			List<Map<String, Object>> project = db.querys("dashboard.getProject", conditions);
		
			
			resultMap.put("project", project);
			List<Map<String, Object>> lstInfo = db.querys("mitlistHT.getCutHourInfo", conditions);
			
			resultMap.put("lstInfo", lstInfo);
			List<Map<String, Object>> bugsInfo = db.querys("mitlistHT.getEntrustHourInfo", conditions) ;
			resultMap.put("bugsInfo", bugsInfo);
			List<Map<String, Object>> sum = db.querys("mitlistHT.getHTProjectListInfo", conditions);
			
			resultMap.put("sum", sum);
			context.getResultBean().setData(resultMap);
		}
		
	}
	
	private boolean isSosiki(){
		String sosiki_cd = context.getParam().get("organizationCd");
		return StringUtils.isEmpty(sosiki_cd) ? false : true ;
	}
	
	public void doFilter() throws SoftbankException {
		UserInfoData userInfoData = context.getSessionData().getUserInfo();
		if (userInfoData != null) {
			if ( userInfoData.isAdmin() ) {
				context.getResultBean().setFilter(true);
				return;
			} else {
				int userId = userInfoData.getId();
				Map<String, Object> condition = Maps.newHashMap();
				condition.put("user_id",userId);
				List<Map<String, Object>> map =  db.querys("mitlistHT.getGroupUsers", condition);
				if ( map.size() > 0 ) {
					context.getResultBean().setFilter(true);
					return;
				}
			}
		}
		return;
	}
	
}
