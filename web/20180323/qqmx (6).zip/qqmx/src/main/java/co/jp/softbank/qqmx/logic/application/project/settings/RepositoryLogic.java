package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;

//import co.jp.softbank.qqmx.dao.project.settings.repository;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.PageListBean;

import com.google.common.collect.Maps;

public class RepositoryLogic extends AbstractBaseLogic {

//	@Autowired
//	private repository repository;

	public void getRepositoriesList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", context.getParam().projectId);
		PageListBean pageListBean = pageList("repository.getRepositoriesList", conditions);
		context.getResultBean().setData(pageListBean);
	}
	
	public void saveRepositorie() throws SoftbankException {
		String str_is_default = "";
		boolean is_default = false;
		String url = "";
		String login = "";
		String password = "";
		String root_url = "";
		String path_encoding = "";
		String log_encoding = "";
		String extra_info = "";
		String type = context.getParam().get("scm");
		String identifier = context.getParam().get("identifier");
		str_is_default = context.getParam().get("is_default");
		if ("true".equals(str_is_default)){is_default = true;}
		
		if ("Subversion".equals(type)){
			url = context.getParam().get("url_sub");
			login = context.getParam().get("login");
			password = context.getParam().get("password");
		}else if ("Git".equals(type)){
			url = context.getParam().get("url_git");
			path_encoding = context.getParam().get("path_encoding");
			extra_info = context.getParam().get("extra_report_last_commit");
		}

		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", context.getParam().projectId);
		conditions.put("url", url);
		conditions.put("login", login);
		conditions.put("password", password);
		conditions.put("root_url", root_url);
		conditions.put("type", type);
		conditions.put("path_encoding", path_encoding);
		conditions.put("log_encoding", log_encoding);
		conditions.put("extra_info", extra_info);
		conditions.put("identifier", identifier);
		conditions.put("is_default", is_default);
		
		String typeFlag = context.getParam().get("id");
		
		if ("undefined".equals(typeFlag)){
			db.insert("repository.saveRepositorie", conditions);
		}else{
			conditions.put("id", Integer.parseInt(typeFlag));
			db.update("repository.updateRepositorie", conditions);
		}
	}
	
	public void deleteRepositorie() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("repository_id", Integer.parseInt(context.getParam().get("repository_id")));
		db.delete("repository.deleteRepositorie", conditions);
	}
	
	public LogicBean editRepositorie() throws SoftbankException {
		LogicBean repositorieBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("repository_id", Integer.parseInt(context.getParam().get("repository_id")));
		repositorieBean.setData(db.querys("repository.editRepositorie", conditions));
		return repositorieBean;
	}
}
