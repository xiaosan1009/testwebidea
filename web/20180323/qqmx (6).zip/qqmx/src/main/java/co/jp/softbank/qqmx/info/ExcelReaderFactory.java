package co.jp.softbank.qqmx.info;

import java.io.File;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.face.IExcelReader;

public class ExcelReaderFactory {
	
	public static IExcelReader getReader(File file) throws SoftbankException {
		if (file.getName().endsWith(".xlsx")) {
			return new ExcelReaderCsv(file);
		} else {
			return new ExcelReader(file);
		}
		
	}

}
