package co.jp.softbank.qqmx.dao.common;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.UserInfoData;

import com.google.common.collect.Maps;

public class DbExecuteImpl implements IDbExecute {
	
	private IQueryDao queryDao;
	
	private IUpdateDao updateDao;
	
	private HttpContext context;

	@Override
	public Map<String, Object> query(String sqlID) throws SoftbankException {
		return queryDao.executeForMap(sqlID, makeConditions());
	}
	
	@Override
	public Map<String, Object> queryC(String sqlID) throws SoftbankException {
		return queryDao.executeForMapAndClosed(sqlID, makeConditions());
	}

	@Override
	public Map<String, Object> query(String sqlID, Object conditions) throws SoftbankException {
		return queryDao.executeForMap(sqlID, makeConditions(conditions));
	}
	
	@Override
	public Map<String, Object> queryC(String sqlID, Object conditions) throws SoftbankException {
		return queryDao.executeForMapAndClosed(sqlID, makeConditions(conditions));
	}

	@Override
	public <E> E query(String sqlID, Class<?> clazz) throws SoftbankException {
		return queryDao.executeForObject(sqlID, makeConditions(), clazz);
	}

	@Override
	public <E> E query(String sqlID, Object conditions, Class<?> clazz) throws SoftbankException {
		return queryDao.executeForObject(sqlID, makeConditions(conditions), clazz);
	}

	@Override
	public List<Map<String, Object>> querys(String sqlID) throws SoftbankException {
		return queryDao.executeForMapList(sqlID, makeConditions());
	}
	
	@Override
	public List<Map<String, Object>> querysC(String sqlID) throws SoftbankException {
		return queryDao.executeForMapListAndClosed(sqlID, makeConditions());
	}

	@Override
	public List<Map<String, Object>> querys(String sqlID, Object conditions) throws SoftbankException {
		return queryDao.executeForMapList(sqlID, makeConditions(conditions));
	}
	
	@Override
	public List<Map<String, Object>> querysC(String sqlID, Object conditions) throws SoftbankException {
		return queryDao.executeForMapListAndClosed(sqlID, makeConditions(conditions));
	}

	@Override
	public <E> List<E> queryos(String sqlID) throws SoftbankException {
		return queryDao.executeForObjectList(sqlID, makeConditions());
	}

	@Override
	public <E> List<E> queryos(String sqlID, Object conditions) throws SoftbankException {
		return queryDao.executeForObjectList(sqlID, makeConditions(conditions));
	}
	
	@Override
	public <E> List<E> queryosC(String sqlID) throws SoftbankException {
		return queryDao.executeForObjectListAndClosed(sqlID, makeConditions());
	}
	
	@Override
	public <E> List<E> queryosC(String sqlID, Object conditions) throws SoftbankException {
		return queryDao.executeForObjectListAndClosed(sqlID, makeConditions(conditions));
	}

	@Override
	public int insert(String sqlID) throws SoftbankException {
		return updateDao.insert(sqlID, makeConditions());
	}

	@Override
	public int insert(String sqlID, Object conditions) throws SoftbankException {
		Object conditionMap = makeConditions(conditions);
		int result = updateDao.insert(sqlID, conditionMap);
		if (conditionMap instanceof Map && ((Map)conditionMap).containsKey("id") && conditions instanceof Map) {
			((Map)conditions).put("id", ((Map)conditionMap).get("id"));
		}
		return result;
	}

	@Override
	public int update(String sqlID) throws SoftbankException {
		return updateDao.update(sqlID, makeConditions());
	}

	@Override
	public int update(String sqlID, Object conditions) throws SoftbankException {
		return updateDao.update(sqlID, makeConditions(conditions));
	}

	@Override
	public int delete(String sqlID) throws SoftbankException {
		return updateDao.update(sqlID, makeConditions());
	}

	@Override
	public int delete(String sqlID, Object conditions) throws SoftbankException {
		return updateDao.update(sqlID, makeConditions(conditions));
	}

	public void setQueryDao(IQueryDao queryDao) {
		this.queryDao = queryDao;
	}

	public void setUpdateDao(IUpdateDao updateDao) {
		this.updateDao = updateDao;
	}

	@Override
	public void setContext(HttpContext context) {
		this.context = context;
	}
	
	private Object makeConditions() {
		return makeConditions(null);
	}
	
	public Object makeConditions(Object conditions) {
		if (conditions != null && !(conditions instanceof Map)) {
			return conditions;
		}
		if (this.context == null) {
			return (Map)conditions;
		}
		Map<String, Object> resuMap = Maps.newHashMap();
		if (conditions != null && conditions instanceof Map) {
			resuMap.putAll((Map)conditions);
		}
		UserInfoData userInfo = this.context.getSessionData().getUserInfo();
		if (userInfo != null) {
			if (!resuMap.containsKey("user_id")) {
				resuMap.put("user_id", userInfo.getId());
			}
			if (!resuMap.containsKey("login")) {
				resuMap.put("login", userInfo.getLogin());
			}
		}
		if (!resuMap.containsKey("project_id")) {
			resuMap.put("project_id", context.getParam().projectId);
		}
		return resuMap;
	}

	@Override
	public SqlSession getQuerySession() {
		return queryDao.getQuerySession();
	}

	@Override
	public int insertC(String sqlID) throws SoftbankException {
		return updateDao.insertC(sqlID, makeConditions());
	}

	@Override
	public int insertC(String sqlID, Object conditions)
			throws SoftbankException {
		Object conditionMap = makeConditions(conditions);
		int result = updateDao.insertC(sqlID, makeConditions(conditions));
		if (conditionMap instanceof Map && ((Map)conditionMap).containsKey("id") && conditions instanceof Map) {
			((Map)conditions).put("id", ((Map)conditionMap).get("id"));
		}
		return result;
	}

	@Override
	public int updateC(String sqlID) throws SoftbankException {
		return updateDao.updateC(sqlID, makeConditions());
	}

	@Override
	public int updateC(String sqlID, Object conditions) throws SoftbankException {
		return updateDao.updateC(sqlID, makeConditions(conditions));
	}

	@Override
	public int deleteC(String sqlID) throws SoftbankException {
		return updateDao.deleteC(sqlID, makeConditions());
	}

	@Override
	public int deleteC(String sqlID, Object conditions)
			throws SoftbankException {
		return updateDao.deleteC(sqlID, makeConditions(conditions));
	}

	@Override
	public void inserts(String sqlID, List<Map<String, Object>> datas)
			throws SoftbankException {
		final DbExecuteImpl instance = this;
		updateDao.inserts(sqlID, datas, new MakeConditionsListener() {
			
			@Override
			public Object makeConditions(Object conditions) {
				return instance.makeConditions(conditions);
			}
		});
	}
	
	@Override
	public void ins(String sqlID, List<Map<String, Object>> datas)
			throws SoftbankException {
		updateDao.ins(sqlID, datas);
	}
	
	@Override
	public void updates(String sqlID, List<Map<String, Object>> datas) throws SoftbankException {
		final DbExecuteImpl instance = this;
		updateDao.updates(sqlID, datas, new MakeConditionsListener() {
			
			@Override
			public Object makeConditions(Object conditions) {
				return instance.makeConditions(conditions);
			}
		});
	}
	
	@Override
	public void deletes(String sqlID, List<Map<String, Object>> datas) throws SoftbankException {
		updateDao.deletes(sqlID, datas);
	}

	@Override
	public <E> E queryo(String sqlID) throws SoftbankException {
		return queryDao.executeForObject(sqlID, makeConditions());
	}

	@Override
	public <E> E queryo(String sqlID, Object conditions) throws SoftbankException {
		return queryDao.executeForObject(sqlID, makeConditions(conditions));
	}
	
	public interface MakeConditionsListener {
		Object makeConditions(Object conditions);
	}

	@Override
	public <E> E queryoC(String sqlID) throws SoftbankException {
		return queryDao.executeForObjectAndClosed(sqlID, makeConditions());
	}

	@Override
	public <E> E queryoC(String sqlID, Object conditions) throws SoftbankException {
		return queryDao.executeForObjectAndClosed(sqlID, makeConditions(conditions));
	}
}
