package co.jp.softbank.qqmx.logic.application.project;

import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Stack;

import org.aspectj.weaver.AjAttribute.PrivilegedAttribute;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.info.ControlSettingMap;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.application.face.IssueKey;
import co.jp.softbank.qqmx.logic.application.project.bean.TicketBean;
import co.jp.softbank.qqmx.logic.application.project.bean.UpdateTicketBean;
import co.jp.softbank.qqmx.logic.bean.Param;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.DateUtils;
import co.jp.softbank.qqmx.util.StringUtils;
import net.sf.json.JSONArray;

public class TicketBaseLogic extends AbstractBaseLogic {
	
	private List<String> issueUpdateHistoryKey = Lists.newArrayList(
			IssueKey.TRACKER_ID.KEY,
			IssueKey.PROJECT_ID.KEY,
			IssueKey.SUBJECT.KEY,
			IssueKey.DESCRIPTION.KEY,
			IssueKey.DUE_DATE.KEY,
			IssueKey.CATEGORY_ID.KEY,
			IssueKey.STATUS_ID.KEY,
			IssueKey.ASSIGNED_TO_ID.KEY,
			IssueKey.PRIORITY_ID.KEY,
			IssueKey.FIXED_VERSION_ID.KEY,
			IssueKey.START_DATE.KEY,
			IssueKey.DONE_RATIO.KEY,
			IssueKey.ESTIMATED_HOURS.KEY,
			IssueKey.PARENT_ID.KEY,
			IssueKey.REMAINING_HOURS.KEY,
			IssueKey.ORGANIZATION_CD.KEY,
			IssueKey.STORY_POINTS.KEY,
			IssueKey.RELEASE_ID.KEY);
	
	protected Map<String, Object> getTicketById(int issueId, int projectId) throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		conditions.put("issue_id", issueId);
		List<Map<String, Object>> customFields = db.querys("issues.getCustomFieldsForOldByIssueId", conditions);
		conditions.put("customFields", customFields);
		return db.query("issues.getTicketAllInfoById", conditions);
	}
	
	protected void updateTicket(final int issueId) throws SoftbankException {
		
		TicketBean ticketBean = createIssueData(issueId);
		
		//　データ変更後のPARENTID。
		int newParentIssueId = 0;
		if (StringUtils.isNotEmpty(ticketBean.getIssuesData().get("parent_id"))) {
			newParentIssueId = StringUtils.toInt(ticketBean.getIssuesData().get("parent_id"));
		}
		
		updateIssueAndParentInfo(ticketBean, issueId, newParentIssueId);
		
		List<String> watcherUserIds = Lists.newArrayList();
		if (context.getParam().getList("watcher_user_ids") != null) {
			watcherUserIds = Lists.newArrayList(context.getParam().getList("watcher_user_ids"));
		}
		updateWatcherInfo(issueId, watcherUserIds);
	}
	
	@SuppressWarnings("unchecked")
	protected void updateTicket(final Map<String, Object> issuesData) throws SoftbankException {
		TicketBean ticketBean = new TicketBean();
		ticketBean.setIssuesData(issuesData);
		if (issuesData.containsKey("customMap")) {
			ticketBean.setCustomValues((Map<Integer, Object>)issuesData.get("customMap"));
		}
		int issueId = 0;
		if (StringUtils.isNotEmpty(issuesData.get("id"))) {
			issueId = StringUtils.toInt(issuesData.get("id"));
			issuesData.put(IssueKey.ISSUE_ID.KEY, issueId);
		} else {
			issueId = StringUtils.toInt(issuesData.get(IssueKey.ISSUE_ID.KEY));
		}
		//　データ変更後のPARENTID。
		int newParentIssueId = 0;
		if (StringUtils.isNotEmpty(issuesData.get("parent_id"))) {
			newParentIssueId = StringUtils.toInt(issuesData.get("parent_id"));
		}
		updateIssueAndParentInfo(ticketBean, issueId, newParentIssueId);
	}
	
	protected void afterInsertTicket(final Map<String, Object> issuesData) throws SoftbankException {
		List<Integer> changeIssueIdList = Lists.newArrayList();
		Map<String, Object> conditions = Maps.newHashMap();
		int issueId = 0;
		if (StringUtils.isNotEmpty(issuesData.get("id"))) {
			issueId = StringUtils.toInt(issuesData.get("id"));
			issuesData.put(IssueKey.ISSUE_ID.KEY, issueId);
		} else {
			issueId = StringUtils.toInt(issuesData.get(IssueKey.ISSUE_ID.KEY));
		}
		
		//　データ変更後のPARENTID。
		int newParentIssueId = 0;
		if (StringUtils.isNotEmpty(issuesData.get("parent_id"))) {
			newParentIssueId = StringUtils.toInt(issuesData.get("parent_id"));
		}
		updateIssuePosition(issueId, newParentIssueId, 0, ConstantsUtil.OperatorType.insert);
		
		if (newParentIssueId != 0) {
			getChangedParent(issueId, changeIssueIdList);
			for (Integer tid : changeIssueIdList) {
				conditions.put("issue_id", tid);
				db.update("issues.updateIssueParentInfo", conditions);
			}
		}
		
		changeIssueIdList.add(issueId);
		
		updateBacklogHistory(changeIssueIdList);
	}
	
	protected void updateIssuePosition(int issueId, int newParentIssueId, int oldParentIssueId, ConstantsUtil.OperatorType operatorType) throws SoftbankException {
		List<Map<String, Object>> oldDataTreeList = null;
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("issue_id", issueId);
		switch (operatorType) {
		case insert:
			if (newParentIssueId == 0) {
				int maxRootSeq = db.queryo("issues.selectMaxRootSeqByIssueId", conditions);
				Map<String, Object> position = Maps.newHashMap();
				position.put("issue_id", issueId);
				position.put("root_id", issueId);
				position.put("parent_id", null);
				position.put("lft", 1);
				position.put("rgt", 2);
				position.put("root_seq", ++maxRootSeq);
				db.update("issues.updateIssuesOrderById", position);
			} else {
				conditions.put("issue_id", newParentIssueId);
				oldDataTreeList = db.querys("issues.selectDataTreeByIssueId", conditions);
				int moveIndex = 0;
				for (int i = 0; i < oldDataTreeList.size(); i++) {
					Map<String, Object> data = oldDataTreeList.get(i);
					int tid = StringUtils.toInt(data.get("id"));
					if (tid == newParentIssueId) {
						moveIndex = i + 1;
						break;
					}
				}
				Map<String, Object> data = Maps.newHashMap();
				data.put("id", issueId);
				data.put("parent_id", newParentIssueId);
				oldDataTreeList.add(moveIndex, data);
				refreshIssuePosition(oldDataTreeList);
			}
			break;
		case update:
			oldDataTreeList = db.querys("issues.selectDataTreeByIssueId", conditions);
			int old_root_id = StringUtils.toInt(oldDataTreeList.get(0).get("root_id"));
			List<Map<String, Object>> moveList = null;
			if (newParentIssueId == 0) {
				moveList = refreshKeepList(issueId, oldParentIssueId, oldDataTreeList);
				int maxRootSeq = db.queryo("issues.selectMaxRootSeqByIssueId", conditions);
				moveList.get(0).put("root_id", issueId);
				moveList.get(0).put("root_seq", ++maxRootSeq);
				moveList.get(0).put("parent_id", null);
				refreshIssuePosition(moveList);
			} else {
				conditions.put("issue_id", newParentIssueId);
				List<Map<String, Object>> newDataTreeList = db.querys("issues.selectDataTreeByIssueId", conditions);
				int root_id = StringUtils.toInt(newDataTreeList.get(0).get("root_id"));
				int root_seq = StringUtils.toInt(newDataTreeList.get(0).get("root_seq"));
				if (root_id == old_root_id) {
					moveList = refreshKeepList(issueId, newParentIssueId, oldParentIssueId, oldDataTreeList);
					refreshIssuePosition(moveList);
				} else {
					moveList = refreshKeepList(issueId, oldParentIssueId, oldDataTreeList);
					moveList.get(0).put("root_id", root_id);
					moveList.get(0).put("root_seq", root_seq);
					moveList.get(0).put("parent_id", newParentIssueId);
					int moveIndex = 0;
					for (int i = 0; i < newDataTreeList.size(); i++) {
						Map<String, Object> data = newDataTreeList.get(i);
						int tid = StringUtils.toInt(data.get("id"));
						if (newParentIssueId == tid) {
							moveIndex = i + 1;
							break;
						}
					}
					newDataTreeList.addAll(moveIndex, moveList);
					refreshIssuePosition(newDataTreeList);
				}
			}
			break;
		case delete:
			conditions.put("issue_id", oldParentIssueId);
			oldDataTreeList = db.querys("issues.selectDataTreeByIssueId", conditions);
			refreshIssuePosition(oldDataTreeList);
			break;

		default:
			break;
		}
	}
	
	protected boolean updateTicket(final Map<String, Object> issuesData, Map<Integer, Object> customValues) throws SoftbankException {
		return updateTicket(issuesData, customValues, null);
	}
	
	protected boolean updateTicket(final Map<String, Object> issuesData, Map<Integer, Object> customValues, UpdateTicketBean updateTicketBean) throws SoftbankException {
		TicketBean ticketBean = new TicketBean();
		ticketBean.setIssuesData(issuesData);
		ticketBean.setCustomValues(customValues);
		ticketBean.setUpdateTicketBean(updateTicketBean);
		ticketBean.setNotes(StringUtils.toString(issuesData.get(IssueKey.PROCESS.NOTES)));
		boolean result = updateTicket(ticketBean);
		if (result) {
			if (StringUtils.isNotEmpty(issuesData.get(IssueKey.PROCESS.WATCHER_USER_IDS))) {
				int issueId = ticketBean.getIssueId();
				String watcherUserIdstr = StringUtils.toString(issuesData.get(IssueKey.PROCESS.WATCHER_USER_IDS));
				List<String> watcherUserIds = Lists.newArrayList();
				if (!"empty".equals(watcherUserIdstr)) {
					JSONArray watcherArray = JSONArray.fromObject(watcherUserIdstr);
					if (watcherArray.size() > 0) {
						for (int i = 0; i < watcherArray.size(); i++) {
							watcherUserIds.add(watcherArray.getString(i));
						}
					}
				}
				updateWatcherInfo(issueId, watcherUserIds);
			}
		}
		return result;
	}
	
	protected boolean updatePortalTicket(final Map<String, Object> issuesData) throws SoftbankException {
		TicketBean ticketBean = new TicketBean();
		ticketBean.setPortal(true);
		ticketBean.setIssuesData(issuesData);
		return updateTicket(ticketBean);
	}
	
	/**
	 * チケット更新処理
	 * @param ticketBean
	 * @return
	 * @throws SoftbankException
	 */
	protected boolean updateTicket(TicketBean ticketBean) throws SoftbankException {
		Map<String, Object> issueValues = ticketBean.getIssuesData();
		int issueId = ticketBean.getIssueId();
		if (issueValues.containsKey(IssueKey.PROCESS.ONLY_ORDER_CHANGED)) {
			if (ticketBean.getUpdateTicketBean() != null) {
				ticketBean.getUpdateTicketBean().addUpdateIssueOrderValue(issueValues);
			} else {
				db.update("issues.updateIssuesOrderById", issueValues);
			}
			return true;
		}
		// チケット古いデータを取得する
		Map<String, Object> oldIssueValues = getOldIssueValues(ticketBean, issueId);
		ticketBean.setOldIssueValues(oldIssueValues);
		// チケット排他処理
		if (oldIssueValues == null 
				|| StringUtils.toInt(oldIssueValues.get(IssueKey.LOCK_VERSION.KEY)) != StringUtils.toInt(issueValues.get(IssueKey.LOCK_VERSION.KEY))) {
			return false;
		}
		renderHistoryData(ticketBean, issueValues, oldIssueValues);
		renderCustomData(ticketBean, issueId, oldIssueValues);
		updateIssueData(ticketBean, issueValues);
		updateCustomData(ticketBean);
		updateHistoryData(ticketBean, issueId);
		
		return true;
	}
	
	@SuppressWarnings("unchecked")
	protected List<Map<String, Object>> updateIssueWithParent(Map<String, Object> issueData) throws SoftbankException {
		return updateIssueWithParent(Lists.newArrayList(issueData));
	}
	
	protected List<Map<String, Object>> updateIssueWithParent(List<Map<String, Object>> issueDatas) throws SoftbankException {
		return updateIssueWithParent(issueDatas, false);
	}
	
	@SuppressWarnings("unchecked")
	protected List<Map<String, Object>> updateIssueWithParent(List<Map<String, Object>> issueDatas, boolean isPortal) throws SoftbankException {
		List<Map<String, Object>> conflicts = Lists.newArrayList();
		List<Integer> set = Lists.newArrayList();
		for (int i = 0; i < issueDatas.size(); i++) {
			Map<String, Object> data = issueDatas.get(i);
			String tid = StringUtils.toString(data.get(IssueKey.ISSUE_ID.KEY));
			if (!tid.equals(StringUtils.toString(data.get(IssueKey.ROOT_ID.KEY)))) {
				Map<String, Object> conditions = Maps.newHashMap();
				conditions.put("issue_id", tid);
				List<Map<String, Object>> parentList = db.querys("issues.getTicketParentInfo", conditions);
				for (int j = 0; j < parentList.size(); j++) {
					int parentId = StringUtils.toInt(parentList.get(j).get("id"));
					if (!set.contains(parentId)) {
						set.add(parentId);
					}
				}
			}
			boolean isConfilict = false;
			if (isPortal) {
				int progress = StringUtils.toInt(data.get(IssueKey.DONE_RATIO.KEY));
				int status_id = 2;
				switch (progress) {
				case 0:
					status_id = 1;
					break;
				case 100:
					status_id = 3;
					break;

				default:
					break;
				}
				data.put(IssueKey.STATUS_ID.KEY, status_id);
				isConfilict = !updatePortalTicket(data);
			} else {
				isConfilict = !updateTicket(data, (Map<Integer, Object>)data.get(IssueKey.CUSTOMVALUES.KEY));
			}
			if (isConfilict) {
				conflicts.add(data);
			}
		}
		for (Integer tid : set) {
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("issue_id", tid);
			db.update("issues.updateIssueParentInfo", conditions);
		}
		return conflicts;
	}
	
	protected void insertIssue(Map<String, Object> data, List<Map<String, Object>> customFieldList, int issueId) throws SoftbankException {
		insertCustomValues(data, issueId, customFieldList);
	}
	
	protected void deleteTicketById(final int issue_id) throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("issue_id", issue_id);
		int oldParentIssueId = db.queryo("issues.selectParentByIssueId", conditions);
		
		List<Integer> changeIssueIdList = Lists.newArrayList();
		if (oldParentIssueId != 0) {
			getChangedParent(issue_id, changeIssueIdList);
		}
		
		db.delete("issues.deleteIssueRelationsByIssueId", conditions);
		db.delete("issues.deleteWatchersByIssueId", conditions);
		db.delete("issues.deleteJournalDetailsByIssueId", conditions);
		db.delete("issues.deleteJournalsByIssueId", conditions);
		db.delete("issues.deleteCustomValuesByIssueId", conditions);
		db.delete("backlog_history.deleteBacklogHistoryByIssueId", conditions);
		db.delete("issues.deleteIssuesById", conditions);
		
		if (oldParentIssueId != 0) {
			updateIssuePosition(issue_id, 0, oldParentIssueId, ConstantsUtil.OperatorType.delete);
		}
		
		for (Integer tid : changeIssueIdList) {
			conditions = Maps.newHashMap();
			conditions.put("issue_id", tid);
			db.update("issues.updateIssueParentInfo", conditions);
		}
		
	}
	
	protected void deleteTicketOnlyById(final int issue_id) throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("issue_id", issue_id);
		db.delete("issues.deleteIssueRelationsOnlyByIssueId", conditions);
		db.delete("issues.deleteWatchersOnlyByIssueId", conditions);
		db.delete("issues.deleteJournalDetailsOnlyByIssueId", conditions);
		db.delete("issues.deleteJournalsOnlyByIssueId", conditions);
		db.delete("issues.deleteCustomValuesOnlyByIssueId", conditions);
		db.delete("issues.deleteIssuesOnlyById", conditions);
	}
	
	protected void sendMailSync(final String id, final String event) {
		Thread t = new Thread(new Runnable() {
			public void run() {
				try {
					sendMail(id, event);
				} catch (SoftbankException e) {
					e.printStackTrace();
					log.error(e.getErrorMsg(), e);
				}
			}
		});
		t.start();
	}

	private void updateIssueAndParentInfo(TicketBean ticketBean, int issueId, int newParentIssueId) throws SoftbankException {
		//　データ変更前のPARENTID。
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("issue_id", issueId);
		int oldParentIssueId = db.queryo("issues.selectParentByIssueId", conditions);
		List<Integer> changeIssueIdList = Lists.newArrayList();
		if (oldParentIssueId != 0) {
			getChangedParent(issueId, changeIssueIdList);
		}
		
		boolean result = updateTicket(ticketBean);
		if (!result) {
			throw new SoftbankException(SoftbankExceptionType.ExclusiveException);
		}
		if (newParentIssueId != oldParentIssueId) {
			updateIssuePosition(issueId, newParentIssueId, oldParentIssueId, ConstantsUtil.OperatorType.update);
			getChangedParent(issueId, changeIssueIdList);
		}
		
		for (Integer tid : changeIssueIdList) {
			conditions = Maps.newHashMap();
			conditions.put("issue_id", tid);
			db.update("issues.updateIssueParentInfo", conditions);
		}
		
		changeIssueIdList.add(issueId);
		
		updateFinishedDateByIds(changeIssueIdList);
		
		updateBacklogHistory(changeIssueIdList);
	}
	
	private void updateFinishedDateByIds(List<Integer> changeIssueIdList) throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("issue_ids", changeIssueIdList);
		List<Map<String, Object>> datas = db.querys("issues.selectProgressFinishedDateByIds", conditions);
		
		if (datas != null && datas.size() > 0) {
			List<Map<String, Object>> customValuesInsertList = Lists.newArrayList();
			for (int i = 0; i < datas.size(); i++) {
				Map<String, Object> data = datas.get(i);
				int done_ratio = StringUtils.toInt(data.get("done_ratio"));
				int issueId = StringUtils.toInt(data.get("id"));
				if (done_ratio == 100) {
					if (StringUtils.isEmpty(data.get("value"))) {
						Map<String, Object> customValueInfo = Maps.newHashMap();
						customValueInfo.put("customized_id", issueId);
						customValueInfo.put("custom_field_id", 64);
						customValueInfo.put("value", DateUtils.getNow(DateUtils.FORMAT_YMD2));
						customValuesInsertList.add(customValueInfo);
					}
				} else {
					if (StringUtils.isNotEmpty(data.get("value"))) {
						int custom_value_id = StringUtils.toInt(data.get("custom_value_id"));
						conditions = Maps.newHashMap();
						conditions.put("custom_values_id", custom_value_id);
						db.delete("issues.deleteCustomValuesById", conditions);
					}
				}
			}
			if (customValuesInsertList.size() > 0) {
				Map<String, Object> map = Maps.newHashMap();
				map.put("customValues", customValuesInsertList);
				db.insert("issues.insertIssueCustomValues", map);
			}
		}
		
	}

	private void updateBacklogHistory(List<Integer> changeIssueIdList) throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("issue_ids", changeIssueIdList);
		db.delete("backlog_history.deleteBacklogHistory", conditions);
		db.insert("backlog_history.addBacklogHistory", conditions);
	}

	private void getChangedParent(int issueId, List<Integer> set) throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("issue_id", issueId);
		List<Map<String, Object>> parentList = db.querys("issues.getTicketParentInfo", conditions);
		if (parentList != null && parentList.size() > 0) {
			for (int j = 0; j < parentList.size(); j++) {
				int parentId = StringUtils.toInt(parentList.get(j).get("id"));
				if (!set.contains(parentId)) {
					set.add(parentId);
				}
			}
		}
	}
	
	private TicketBean createIssueData(final int issueId) throws SoftbankException {
		TicketBean ticketBean = new TicketBean();
		final Map<String, Object> issueValues = Maps.newHashMap();
		final Map<Integer, Object> customValues = Maps.newHashMap();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("tracker_id", Integer.parseInt(context.getParam().get("issue_tracker_id")));
		List<Map<String, Object>> boolList = db.querys("issues.getBoolDate", conditions);
		for (int i = 0; i < boolList.size(); i++) {
			customValues.put(StringUtils.toInt(boolList.get(i).get("id")), "0");
		}
		context.getParam().each(new Param.EachFilter() {
			@Override
			public void filter(String key, String value) {
				if (key.startsWith("issue_custom_field_values_")) {
					customValues.put(StringUtils.toInt(key.substring("issue_custom_field_values_".length())), value);
				} else if (key.startsWith("issue_")) {
					if (!"".equals(value)){
						issueValues.put(key.substring("issue_".length()), value);
					}
				}
			}
		});
		issueValues.put("issue_id", issueId);
		issueValues.put("lock_version", context.getParam().get("lock_version"));
		ticketBean.setIssuesData(issueValues);
		ticketBean.setCustomValues(customValues);
		ticketBean.setNotes(context.getParam().get("notes"));
		return ticketBean;
	}
	
	private List<Map<String, Object>> refreshKeepList(int issueId, int newParentIssueId, int oldParentIssueId, List<Map<String, Object>> oldDataTreeList) throws SoftbankException {
		List<Map<String, Object>> moveList = Lists.newArrayList();
		List<Map<String, Object>> keepList = Lists.newArrayList();
		Map<Integer, String> indexMap = Maps.newHashMap();
		int root_id = StringUtils.toInt(oldDataTreeList.get(0).get("root_id"));
		int root_seq = StringUtils.toInt(oldDataTreeList.get(0).get("root_seq"));
		for (int i = 0; i < oldDataTreeList.size(); i++) {
			Map<String, Object> data = oldDataTreeList.get(i);
			int tid = StringUtils.toInt(data.get("id"));
			String index = StringUtils.toString(tid);
			if (StringUtils.isEmpty(data.get("parent_id"))) {
				indexMap.put(tid, index);
			} else {
				int pid = StringUtils.toInt(data.get("parent_id"));
				if (issueId == tid) {
					pid = oldParentIssueId;
				}
				index = indexMap.get(pid);
				index += ConstantsUtil.Str.SPACE + tid;
				indexMap.put(tid, index);
			}
			if (index.indexOf(StringUtils.toString(issueId)) != -1) {
				moveList.add(data);
			} else {
				keepList.add(data);
			}
		}
		moveList.get(0).put("root_id", root_id);
		moveList.get(0).put("root_seq", root_seq);
		moveList.get(0).put("parent_id", newParentIssueId);
		int moveIndex = 0;
		for (int i = 0; i < keepList.size(); i++) {
			Map<String, Object> data = keepList.get(i);
			int tid = StringUtils.toInt(data.get("id"));
			if (newParentIssueId == tid) {
				moveIndex = i + 1;
				break;
			}
		}
		keepList.addAll(moveIndex, moveList);
		return keepList;
	}
	
	private List<Map<String, Object>> refreshKeepList(int issueId, int oldParentIssueId, List<Map<String, Object>> oldDataTreeList) throws SoftbankException {
		List<Map<String, Object>> moveList = Lists.newArrayList();
		List<Map<String, Object>> keepList = Lists.newArrayList();
		Map<Integer, String> indexMap = Maps.newHashMap();
		for (int i = 0; i < oldDataTreeList.size(); i++) {
			Map<String, Object> data = oldDataTreeList.get(i);
			int tid = StringUtils.toInt(data.get("id"));
			String index = StringUtils.toString(tid);
			if (StringUtils.isEmpty(data.get("parent_id"))) {
				indexMap.put(tid, index);
			} else {
				int pid = StringUtils.toInt(data.get("parent_id"));
				if (issueId == tid) {
					pid = oldParentIssueId;
				}
				index = indexMap.get(pid);
				index += ConstantsUtil.Str.SPACE + tid;
				indexMap.put(tid, index);
			}
			if (index.indexOf(StringUtils.toString(issueId)) != -1) {
				moveList.add(data);
			} else {
				keepList.add(data);
			}
		}
		refreshIssuePosition(keepList);
		return moveList;
	}
	
	private void refreshIssuePosition(List<Map<String, Object>> datas) throws SoftbankException {
		if (datas == null || datas.size() == 0) {
			return;
		}
		Stack<Map<String, Object>> rightNode = new Stack<Map<String, Object>>();
		Map<Integer, Integer> floorMap = Maps.newHashMap();
		List<Map<String, Object>> updateList = Lists.newArrayList();
		int root_id = StringUtils.toInt(datas.get(0).get("root_id"));
		int root_seq = StringUtils.toInt(datas.get(0).get("root_seq"));
		int left = 1;
		int right = 1;
		int prevFloor = 0;
		for (int i = 0; i < datas.size(); i++) {
			Map<String, Object> data = datas.get(i);
			Map<String, Object> position = Maps.newHashMap();
			int tid = StringUtils.toInt(data.get("id"));
			position.put("issue_id", tid);
			position.put("root_id", root_id);
			position.put("root_seq", root_seq);
			int floor = 1;
			if (StringUtils.isEmpty(data.get("parent_id"))) {
				floorMap.put(tid, floor);
				position.put("parent_id", null);
			} else {
				int pid = StringUtils.toInt(data.get("parent_id"));
				floor = floorMap.get(pid) + 1;
				floorMap.put(tid, floor);
				position.put("parent_id", pid);
			}
			if (prevFloor != 0 && prevFloor >= floor) {
				if (rightNode.size() > 0) {
					for (int j = 0; j <= (prevFloor - floor); j++) {
						Map<String, Object> rightMap = rightNode.pop();
						right = left++;
						rightMap.put("rgt", right);
					}
				}
			}
			prevFloor = floor;
			position.put("lft", left++);
			rightNode.push(position);
			updateList.add(position);
		}
		while (rightNode.size() > 0) {
			Map<String, Object> rightMap = rightNode.pop();
			rightMap.put("rgt", left++);
		}
		db.updates("issues.updateIssuesOrderById", updateList);
		log.info("updateList.size = {}", updateList.size());
	}
	
	private void updateWatcherInfo(final int issueId, List<String> watcherUserIds) throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("issue_id", issueId);
		List<Map<String, Object>> oldWatchers = db.querys("issues.getIssueWatchers", conditions);

		List<String> watcherDeleteList = Lists.newArrayList();
		for (Map<String, Object> watcher_old : oldWatchers) {
			if (watcherUserIds.contains(watcher_old.get("user_id").toString())) {
				watcherUserIds.remove(watcher_old.get("user_id").toString());
			} else {
				watcherDeleteList.add(watcher_old.get("user_id").toString());
			}
		}
		
		if (watcherDeleteList != null && watcherDeleteList.size() > 0) {
			for (String watcherDelete : watcherDeleteList) {
				conditions.put("watchable_id", issueId);
				conditions.put("user_id", Integer.parseInt(watcherDelete));
				db.delete("issues.deleteWatchers", conditions);
			}
		}

		if (watcherUserIds != null && watcherUserIds.size() > 0) {
			for (String issue_watcher_user_id : watcherUserIds) {
				conditions.put("watchable_id", issueId);
				conditions.put("user_id", Integer.parseInt(issue_watcher_user_id));
				db.insert("issues.insertWatchers", conditions);
			}
		}
	}

	private void renderHistoryData(TicketBean ticketBean, Map<String, Object> issueValues, Map<String, Object> oldIssueValues) {
		for (int i = 0; i < issueUpdateHistoryKey.size(); i++) {
			String key = issueUpdateHistoryKey.get(i);
			if (issueValues.containsKey(key)) {
				Object old_value = oldIssueValues.get(key);
				String value = StringUtils.toString(issueValues.get(key));
				if (IssueKey.PROCESS.NOT_CHANGED.equals(value)) {
					continue;
				}
				if (isChanged(old_value, value)) {
					Map<String, Object> changes = Maps.newHashMap();
					changes.put("property", "attr");
					changes.put("prop_key", key);
					if (IssueKey.ASSIGNED_TO_ID.KEY.equals(key) || IssueKey.FIXED_VERSION_ID.KEY.equals(key)) {
						if (StringUtils.isEmpty(old_value)) {
							old_value = null;
						}
						if (StringUtils.isEmpty(value)) {
							value = null;
						}
					}
					changes.put("old_value", old_value);
					changes.put("value", value);
					ticketBean.getChangeList().add(changes);
				}
			}
		}
		
//		for (Map.Entry<String, Object> issueValue : issueValues.entrySet()) {
//		String key = issueValue.getKey();
//		Object old_value = oldIssueValues.get(key);
//		String value = StringUtils.toString(issueValue.getValue());
//		if (IssueKey.PROCESS.NOT_CHANGED.equals(value)) {
//			continue;
//		}
//		if (!IssueKey.LFT.KEY.equals(key)
//				&& !IssueKey.ISSUE_ID.KEY.equals(key)
//				&& !IssueKey.ROOT_ID.KEY.equals(key)
//				&& !IssueKey.ROOT_SEQ.KEY.equals(key)
//				&& !IssueKey.PROCESS.FLOOR_ID.equals(key)
//				&& !IssueKey.PROCESS.ADDFLG.equals(key)
//				&& !IssueKey.PROCESS.ISDELETE.equals(key)
//				&& !IssueKey.PROCESS.ISUPDATE.equals(key)
//				&& !IssueKey.PROCESS.ISPARENT.equals(key)
//				&& !IssueKey.PROCESS.WATCHER_USER_IDS.equals(key)
//				&& !IssueKey.PROCESS.NOTES.equals(key)
//				&& !IssueKey.CUSTOMVALUES.KEY.equals(key)
//				&& !IssueKey.LOCK_VERSION.KEY.equals(key)
//				&& !"added".equals(key)
//				&& !IssueKey.RGT.KEY.equals(key) 
//				&& isChanged(old_value, value)) {
//			Map<String, Object> changes = Maps.newHashMap();
//			changes.put("property", "attr");
//			changes.put("prop_key", key);
//			if (IssueKey.ASSIGNED_TO_ID.KEY.equals(key) || IssueKey.FIXED_VERSION_ID.KEY.equals(key)) {
//				if (StringUtils.isEmpty(old_value)) {
//					old_value = null;
//				}
//				if (StringUtils.isEmpty(value)) {
//					value = null;
//				}
//			}
//			changes.put("old_value", old_value);
//			changes.put("value", value);
//			ticketBean.getChangeList().add(changes);
//		}
//	}
	}

	private void renderCustomData(TicketBean ticketBean, int issueId, Map<String, Object> oldIssueValues) throws SoftbankException {
		Map<Integer, Object> customValues = ticketBean.getCustomValues();
		if (customValues != null && customValues.size() > 0) {
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("issue_id", issueId);
			conditions.put("project_id", oldIssueValues.get("project_id"));
			conditions.put("tracker_id", oldIssueValues.get("tracker_id"));
			List<Map<String, Object>> oldCustomValues = null;
			if (ticketBean.getUpdateTicketBean() != null) {
				oldCustomValues = ticketBean.getUpdateTicketBean().getIssuesCustomValues(issueId);
			} else {
				oldCustomValues = db.querys("issues.selectIssueCustomFieldsAndValues", conditions);
			}
			if (oldCustomValues != null) {
				ticketBean.setOldCustomValues(oldCustomValues);
				for (Map<String, Object> customValue_old : oldCustomValues) {
					if (StringUtils.isEmpty(customValue_old.get("custom_values_id"))) {
						continue;
					}
					if (customValues.containsKey(customValue_old.get("id"))) {
						Object old_value = customValue_old.get("value");
						String value = StringUtils.toString(customValues.get(customValue_old.get("id")));
						if (isChanged(old_value, value)) {
							Map<String, Object> customUpdate = Maps.newHashMap();
							customUpdate.put("custom_values_id", customValue_old.get("custom_values_id"));
							customUpdate.put("property", "cf");
							customUpdate.put("prop_key", customValue_old.get("id").toString());
							customUpdate.put("old_value", old_value);
							customUpdate.put("value", value);
							ticketBean.getCustomUpdateList().add(customUpdate);
							ticketBean.getChangeList().add(customUpdate);
						}
						customValues.remove(customValue_old.get("id"));
					} else {
						Map<String, Object> customUpdate = Maps.newHashMap();
						customUpdate.put("custom_values_id", customValue_old.get("custom_values_id"));
						if (ticketBean.getUpdateTicketBean() != null) {
							ticketBean.getUpdateTicketBean().addDeleteCustomValueId(customUpdate);
						} else {
							ticketBean.getCustomDeleteList().add(customUpdate);
						}
					}
				}
			}
			
			for (Map.Entry<Integer, Object> customValue : customValues.entrySet()) {
				Map<String, Object> customValueInfo = Maps.newHashMap();
				customValueInfo.put("customized_id", issueId);
				customValueInfo.put("custom_field_id", customValue.getKey());
				customValueInfo.put("value", customValue.getValue());
				if (StringUtils.isNotEmpty(customValue.getValue())) {
					customValueInfo.put("property", "cf");
					customValueInfo.put("prop_key", customValue.getKey());
					customValueInfo.put("old_value", "");
					ticketBean.getChangeList().add(customValueInfo);
				}
				ticketBean.getCustomInsertList().add(customValueInfo);
			}
		}
	}

	private void updateIssueData(TicketBean ticketBean, Map<String, Object> issueValues) throws SoftbankException {
		if (issueValues.containsKey(IssueKey.IS_PRIVATE.KEY)) {
			issueValues.put(IssueKey.IS_PRIVATE.KEY, StringUtils.toBoolean(issueValues.get(IssueKey.IS_PRIVATE.KEY)));
		}
		if (ticketBean.isPortal()) {
			db.update("issues.updateIssuesInfoForPortal", issueValues);
		} else {
			if (ticketBean.getUpdateTicketBean() != null) {
				ticketBean.getUpdateTicketBean().addUpdateIssueValue(issueValues);
			} else {
				db.update("issues.updateIssuesById", issueValues);
			}
		}
	}

	private void updateHistoryData(TicketBean ticketBean, int issueId) throws SoftbankException {
		Map<String, Object> conditions;
		if (ticketBean.getChangeList().size() > 0 || StringUtils.isNotEmpty(ticketBean.getNotes()) ) {
			conditions = Maps.newHashMap();
			conditions.put("journalized_id", issueId);
			conditions.put("user_id", ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId());
			conditions.put("notes", ticketBean.getNotes());
			if (ticketBean.getUpdateTicketBean() != null) {
				ticketBean.getUpdateTicketBean().addJournalizedList(conditions, ticketBean.getChangeList());
			} else {
				db.insert("issues.insertJournals", conditions);
				if (!ControlSettingMap.getInstance().getBoolean(ControlSettingMap.SettingKey.DEBUG_MODEL)) {
					sendMailSync(StringUtils.toString(conditions.get("id")), "edit");
				}
				for (Map<String, Object> changeItem : ticketBean.getChangeList()) {
					changeItem.put("journal_id", conditions.get("id"));
					db.insert("issues.insertJournalDetails", changeItem);
				}
			}
		}
	}

	private void updateCustomData(TicketBean ticketBean) throws SoftbankException {
		if (ticketBean.getCustomUpdateList().size() > 0) {
			for (Map<String, Object> customUpdate : ticketBean.getCustomUpdateList()) {
				if (customUpdate.get("custom_values_id") != null){
					db.update("issues.updateCustomValuesById", customUpdate);
				}
			}
		}
		
		if (ticketBean.getCustomInsertList().size() > 0) {
			Map<String, Object> map = Maps.newHashMap();
			map.put("customValues", ticketBean.getCustomInsertList());
			db.insert("issues.insertIssueCustomValues", map);
		}
		
		if (ticketBean.getCustomDeleteList().size() > 0) {
			for (Map<String, Object> customDelete : ticketBean.getCustomDeleteList()) {
				db.delete("issues.deleteCustomValuesById", customDelete);
			}
		}
	}

	/**
	 * チケット古いデータを取得する
	 * @param ticketBean
	 * @param issueId
	 * @return
	 * @throws SoftbankException
	 */
	private Map<String, Object> getOldIssueValues(TicketBean ticketBean, int issueId) throws SoftbankException {
		if (ticketBean.getUpdateTicketBean() != null) {
			//　ガントチャートの場合は、それぞれチケットのデータ全部一緒に取得する
			return ticketBean.getUpdateTicketBean().getOldIssueData(issueId);
		}
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("issue_id", issueId);
		Map<String, Object> oldIssueValues = db.query("issues.selectIssueById", conditions);
		return oldIssueValues;
	}

	@SuppressWarnings("unchecked")
	private void insertCustomValues(Map<String, Object> data, final int issueId, List<Map<String, Object>> customFieldList)
			throws SoftbankException {
		Map<Integer, Object> customValues = (Map<Integer, Object>)data.get(IssueKey.CUSTOMVALUES.KEY);
		final List<Map<String, Object>> customValuesList = Lists.newArrayList();
		for (Map.Entry<Integer, Object> customValue : customValues.entrySet()) {
			if (StringUtils.isEmpty(customValue.getValue())) {
				continue;
			}
			Map<String, Object> customValueInfo = Maps.newHashMap();
			customValueInfo.put("customized_id", issueId);
			customValueInfo.put("custom_field_id", customValue.getKey());
			customValueInfo.put("value", customValue.getValue());
			customValuesList.add(customValueInfo);
		}
		if (customValuesList != null && customValuesList.size() > 0) {
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("customValues", customValuesList);
			customFieldList.add(conditions);
		}
	}
	
	private void sendMail(String id, String event) throws SoftbankException {
		log.info("sendMail start! id = {}, event = {}", id, event);
		Map<String, String> params = Maps.newHashMap();
		params.put("id", id);
		params.put("type", "issue");
		params.put("event", event);
		externalHttpServer.post("send_mail_by_api", params, true);
		log.info("sendMail end!");
	}
	
	private static boolean isChanged(Object oldValue, String value) {
		boolean isChanged = false;
		if (StringUtils.isEmpty(oldValue)) {
			if (StringUtils.isNotEmpty(value)) {
				isChanged = true;
			}
		} else {
			if (StringUtils.isEmpty(value)) {
				isChanged = true;
			} else {
				try {
					if (Double.parseDouble(value) != Double.parseDouble(StringUtils.toString(oldValue))) {
						isChanged = true;
					}
				} catch (NumberFormatException e) {
					if (!org.apache.commons.lang.StringUtils.equals(value, oldValue.toString())) {
						isChanged = true;
					}
				}
			}
		}
		return isChanged;
	}
	
}
