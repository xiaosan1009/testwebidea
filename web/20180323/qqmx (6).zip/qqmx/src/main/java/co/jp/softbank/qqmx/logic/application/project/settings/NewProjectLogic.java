
package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.yaml.snakeyaml.Yaml;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.dao.IDaoInterface;
//import co.jp.softbank.qqmx.dao.project.settings.NewProjectDao;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.ControlDbMemory;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.Param;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.StringUtils;

public class NewProjectLogic extends AbstractBaseLogic {
	
//	@Autowired
//	private NewProjectDao newProjectDao;
	
	@SuppressWarnings("unchecked")
	public LogicBean getProjectInfos() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, String> settingsMap = Maps.newHashMap();
		String project_id = context.getParam().get("projectId");
		List<Map<String,Object>> customFields =  db.querys("newProject.getCustomFieldsBeans");
		resultMap.put("customFields", customFields);
		
		if (StringUtils.isEmpty(project_id)){
			
			List<Map<String, Object>> settingsList =  db.querys("newProject.getSettings");
			Map<String, Object> settingsData = settingsList.get(0);
			String settingsValue = StringUtils.toString(settingsData.get("value"));
			Yaml yaml = new Yaml();
			List<String> settingsList2 = (List<String>)yaml.load(settingsValue);
			for (int i = 0; i < settingsList2.size(); i++) {
				settingsMap.put(settingsList2.get(i), settingsList2.get(i));
			}
			resultMap.put("trackers",  db.querys("newProject.getTrackers"));
			resultMap.put("issuesCustomFields",  db.querys("newProject.getIssuesCustomFields"));
			
		} else {
			Map<String, Object> conditions = Maps.newHashMap();
			Map<String, Object> enabledModulesMap = Maps.newHashMap();
			conditions.put("project_id", Integer.parseInt(project_id));
			conditions.put("projectId", Integer.parseInt(project_id));
			List<Map<String, Object>> enabledModulesList =  db.querys("newProject.getEnabledModules", conditions);
			
			for (int e = 0; e < enabledModulesList.size(); e++) {
				enabledModulesMap = enabledModulesList.get(e);
				settingsMap.put(StringUtils.toString(enabledModulesMap.get("name")), StringUtils.toString(enabledModulesMap.get("name")));
			}
			
			resultMap.put("customFieldValuesP", db.querys("newProject.getCustomFieldsBeanValues", conditions));
			resultMap.put("projectInfo", db.query("settingInfo.getProjectInfo" , conditions));
			resultMap.put("trackers", db.querys("newProject.getProjectTrackers", conditions));
			resultMap.put("issuesCustomFields", db.querys("newProject.getProjectIssuesCustomFields"));
		}
		
		resultMap.put("section_msts", db.querys("section_msts.selectSectionMstsInfo"));
		resultMap.put("settings", settingsMap);
		resultMap.put("plugins", ControlDbMemory.getInstance().getPluginInfoBeans());
		logicBean.setData(resultMap);
		return logicBean;
	}
	
	public LogicBean saveProjectInfos() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		Integer parentId = null;
		if (StringUtils.isNotEmpty(context.getParam().get("project_parent_id"))) {
			parentId = Integer.parseInt(context.getParam().get("project_parent_id"));
			Map<String, Object> projectMapInfo = Maps.newHashMap();
			Map<String, Object> projectMapLftRtInfo = Maps.newHashMap();
			projectMapInfo.put("project_id", parentId);
			List<Map<String, Object>> projectInfo = db.querys("newProject.getProjectInfo", projectMapInfo);
			if (projectInfo.size() == 1) {
				int rgt = StringUtils.toInt(projectInfo.get(0).get("rgt"));
				
				projectMapLftRtInfo.put("project_rgt", rgt);
				db.update("newProject.upLftProjectInfos", projectMapLftRtInfo);
				
				projectMapInfo.put("project_rgt", rgt);
				db.update("newProject.upProjectInfos", projectMapInfo);
				
				conditions.put("project_lft", rgt);
				conditions.put("project_rgt", rgt + 1);
			} else {
				return null;
			}
		} else {
			List<Map<String, Object>> projectInfo = db.querys("newProject.getMaxProjectInfo");
			if (projectInfo.size() == 1) {
				conditions.put("project_lft", StringUtils.toInt(projectInfo.get(0).get("rgt")) + 1 );
				conditions.put("project_rgt", StringUtils.toInt(projectInfo.get(0).get("rgt")) + 2 );
			} else {
				return null;
			}
		}
		conditions.put("project_name", context.getParam().get("project_name"));
		conditions.put("project_parent_id", parentId);
		conditions.put("project_description", context.getParam().get("project_description"));
		conditions.put("project_identifier", context.getParam().get("project_identifier"));
		conditions.put("project_is_public", ("1".equals(context.getParam().get("project_is_public")) ? true : false));
		conditions.put("project_homepage", context.getParam().get("project_homepage"));
		conditions.put("project_landingpage", ConstantsUtil.Str.EMPTY);
		conditions.put("project_status", 1);
		
		db.insert("newProject.insertProjectInfo", conditions);
		
		
		final int projectId = Integer.parseInt(StringUtils.toString(conditions.get("id")));
		log.info("projectId = " + projectId);
		
		// project_relation
		conditions.put("project_id", projectId);
		
		Integer projectOrganizationId = null;
		if (StringUtils.isNotEmpty(context.getParam().get("project_organization_id"))) {
			projectOrganizationId = StringUtils.toInt(context.getParam().get("project_organization_id"));
		}
		conditions.put("project_organization_id", projectOrganizationId);
		
		conditions.put("project_type", "P");
		
		if (StringUtils.isEmpty(parentId)) {
			conditions.put("project_relation_parent_id", projectId);
		} else {
			conditions.put("project_relation_parent_id", parentId);
		}
		
		db.insert("newProject.insertProjectRelation", conditions);
		
		// module
		String[] enabledModulesInfos = sessionToString("module_selected_name");
		if (enabledModulesInfos != null) {
			List<Map<String, Object>> enabledModulesInfoList = Lists.newArrayList();
			for (int i = 0; i < enabledModulesInfos.length; i++) {
				Map<String, Object> enabledModulesInfo = Maps.newHashMap();
				enabledModulesInfo.put("name", enabledModulesInfos[i]);
				enabledModulesInfo.put("project_id", projectId);
				enabledModulesInfoList.add(enabledModulesInfo);
			}
			conditions = Maps.newHashMap();
			conditions.put("enabledModulesInfos", enabledModulesInfoList);
			db.insert("newProject.insertEnabledModulesInfos", conditions);
		}
		
		conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		conditions.put("start_page", "Wiki");
		db.insert("newProject.insertWikisInfos", conditions);
		final int wiki_id = Integer.parseInt(StringUtils.toString(conditions.get("id")));
		
		// tracker
		String[] projectsTrackers = sessionToString("tracker_selected_name");
		if (projectsTrackers != null) {
			List<Map<String, Object>> projectsTrackerList = Lists.newArrayList();
			for (int i = 0; i < projectsTrackers.length; i++) {
				Map<String, Object> projectsTrackerInfo = Maps.newHashMap();
				projectsTrackerInfo.put("project_id", projectId);
				projectsTrackerInfo.put("tracker_id", Integer.parseInt(projectsTrackers[i]));
				projectsTrackerList.add(projectsTrackerInfo);
			}
			conditions = Maps.newHashMap();
			conditions.put("projectsTrackers", projectsTrackerList);
			db.insert("newProject.insertProjectsTrackersInfos", conditions);
		}
		
		// custom
		String[] customFields = sessionToString("custom_selected_name");
		if (customFields != null && !"".equals(customFields[0])) {
			List<Map<String, Object>> customFieldList = Lists.newArrayList();
			for (int i = 0; i < customFields.length; i++) {
				Map<String, Object> customFieldInfo = Maps.newHashMap();
				customFieldInfo.put("project_id", projectId);
				customFieldInfo.put("custom_field_id", Integer.parseInt(customFields[i]));
				customFieldList.add(customFieldInfo);
			}
			conditions = Maps.newHashMap();
			conditions.put("customFields", customFieldList);
			db.insert("newProject.insertProjectsCustomFields", conditions);
		}
		
		final List<Map<String, Object>> customValuesList = Lists.newArrayList();
		context.getParam().each(new Param.EachFilter() {
			
			@Override
			public void filter(String key, String value) {
				if (key.startsWith("project_custom_field_values_")) {
					Map<String, Object> customValueInfo = Maps.newHashMap();
					customValueInfo.put("customized_id", projectId);
					customValueInfo.put("custom_field_id", Integer.parseInt(key.substring("project_custom_field_values_".length())));
					customValueInfo.put("value", value);
					customValuesList.add(customValueInfo);
				}
			}
		});
		
		if (customValuesList != null && customValuesList.size() > 0) {
			conditions = Maps.newHashMap();
			conditions.put("customValues", customValuesList);
//			newProjectDao.insertProjectsCustomValues(conditions);
			db.insert("newProject.insertProjectsCustomValues", conditions);
		}
		
		String copy_project_id = context.getParam().get("projectId");
		String copy_flg = context.getParam().get("copy_flg");
		if ("1".equals(copy_flg)) {
			conditions.put("project_id", projectId);
			conditions.put("copy_project_id", Integer.parseInt(copy_project_id));
			if ("1".equals(context.getParam().get("project_copy_member"))) {// メンバーcopy
				db.insert("newProject.insertProjectCopyMember", conditions);
			}
			if ("1".equals(context.getParam().get("project_copy_version"))) {// バージョンcopy
				db.insert("newProject.insertProjectCopyVersion", conditions);
			}
			if ("1".equals(context.getParam().get("project_copy_category"))) {// チケットのカテゴリcopy
				db.insert("newProject.insertProjectCopyCategory", conditions);
			}
			if ("1".equals(context.getParam().get("project_copy_ticket"))) {// チケットcopy
				db.insert("newProject.insertProjectCopyTicket", conditions);
			}
			if ("1".equals(context.getParam().get("project_copy_customquery"))) {// カスタムクエリcopy
				db.insert("newProject.insertProjectCopyCustomquery", conditions);
			}
			if ("1".equals(context.getParam().get("project_copy_forum"))) {// フォーラムcopy
				db.insert("newProject.insertProjectCopyForum", conditions);
			}
			if ("1".equals(context.getParam().get("project_copy_wikipage"))) {// Wikiページcopy
				List<Map<String, Object>> wikiInfo =  db.querys("newProject.getProjectCopyWikiId", conditions);
				if ( wikiInfo.size() != 0 ){					
					conditions.put("wiki_id", wiki_id);
					conditions.put("copy_wiki_id", wikiInfo.get(0).get("id"));
					db.insert("newProject.insertProjectCopyWikiPage", conditions);
				}
			}
		}
		return logicBean;
	}
	
	
	public LogicBean getProjectCopyInfos() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		String project_id = context.getParam().get("projectId");
		String copy_flg = context.getParam().get("copy_flg");
		if (!StringUtils.isEmpty(copy_flg) && !StringUtils.isEmpty(project_id)) {
			Map<String, Object> copyConditions = Maps.newHashMap();
			copyConditions.put("project_id", Integer.parseInt(project_id));
			resultMap.put("copy_info", db.querys("newProject.getCopyInfo", copyConditions));
		}
		logicBean.setData(resultMap);
		return logicBean;
	}
	
	private String[] sessionToString(String key) {
//		String[] result = new String[]{} ;
		String[] temp = context.getParam().getList(key); 
		return StringUtils.isEmpty(temp) ? null : temp ;  
	}

}
