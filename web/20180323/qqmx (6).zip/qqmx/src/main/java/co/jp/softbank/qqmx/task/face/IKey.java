package co.jp.softbank.qqmx.task.face;

public interface IKey {

}
