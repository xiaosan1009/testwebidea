package co.jp.softbank.qqmx.info.bean;

public class DbRequestData {
	
	private DbRequestDataType type;
	
	private String sql;
	
	private String key;

	public DbRequestDataType getType() {
		return type;
	}

	public void setType(DbRequestDataType type) {
		this.type = type;
	}

	public String getSql() {
		return sql;
	}

	public void setSql(String sql) {
		this.sql = sql;
	}
	
	public enum DbRequestDataType {
		item("item"), list("list"), page("page"), insert("insert"), update("update"), delete("delete");
		private String key;
		private DbRequestDataType(String key) {
			this.key = key;
		}
		
		public String getKey() {
			return key;
		}
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}

}
