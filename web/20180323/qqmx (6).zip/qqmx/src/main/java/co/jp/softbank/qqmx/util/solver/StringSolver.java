package co.jp.softbank.qqmx.util.solver;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.DateUtils;
import co.jp.softbank.qqmx.util.StringUtils;

public class StringSolver {
	
	private static long sSequenceNo = 1;
	
	public static final long MAX_SIZE = 10000;
	
	public static final Object LOCK = new Object();
	
	private List<SolverBean>  solverBeans;
	
	private Map<String, SolverBean> solverMap;
	
	private Map<String, List<String>> relationMap;
	
	private SolverBean currentBean;
	
	public StringSolver() {
		solverBeans = Lists.newArrayList();
		solverMap = Maps.newHashMap();
		relationMap = Maps.newHashMap();
	}
	
	public void execute() {
		for (String key : relationMap.keySet()) {
			SolverBean bean = solverMap.get(key);
		}
	}
	
	public StringSolver d(String key) {
		currentBean = getBean(key);
		return this;
	}
	
	public StringSolver add(String key) {
		if (currentBean == null) {
			return this;
		}
		String beforeKey = currentBean.getKey();
		final StringBuffer sb = new StringBuffer();
		createObject(beforeKey, sb);
		currentBean = getBean(key);
		createObject(key, sb);
		String tempKey = createTempKey();
		currentBean = new SolverBean(tempKey);
		currentBean.setValue(sb.toString());
		addRelation(beforeKey, key);
		return this;
	}
	
	public StringSolver contains(String str) {
		if (currentBean == null) {
			return this;
		}
		String value = currentBean.getValue();
		final StringBuffer sb = new StringBuffer();
		if (StringUtils.isEmpty(value)) {
			sb.append("*");
			sb.append(str);
			sb.append("*");
		}
		currentBean.setValue(sb.toString());
		return this;
	}

	private void createObject(String key, final StringBuffer sb) {
		sb.append("(");
		sb.append(key);
		sb.append(")");
	}
	
	public StringSolver substring(int start, int end) {
		if (currentBean == null) {
			return this;
		}
		String beforeKey = currentBean.getKey();
		final StringBuffer sb = new StringBuffer();
		createObject(beforeKey, sb);
		createRange(start, end, sb);
		String key = createTempKey();
		currentBean = new SolverBean(key);
		currentBean.setValue(sb.toString());
		addRelation(beforeKey, key);
		return this;
	}

	private void createRange(int start, int end, final StringBuffer sb) {
		sb.append("[");
		sb.append(start);
		sb.append(",");
		sb.append(end);
		sb.append("]");
	}
	
	public StringSolver indexOf(String str, int index) {
		if (currentBean == null) {
			return this;
		}
		String value = currentBean.getValue();
		final StringBuffer sb = new StringBuffer("TEMP");
		if (StringUtils.isEmpty(value)) {
			if (index != 0) {
				sb.append("*");
				sb.append("{");
				sb.append(index);
				sb.append("}");
			}
			sb.append(str);
			sb.append("*");
		}
		currentBean.setValue(sb.toString());
		return this;
	}
	
	public StringSolver assignment(String key) {
		if (currentBean == null) {
			return this;
		}
		String beforeKey = currentBean.getKey();
		currentBean = null;
		getBean(key);
		addRelation(beforeKey, key);
		return this;
	}
	
	public SolverBean getBean(String key) {
		SolverBean bean = null;
		if (solverMap.containsKey(key)) {
			bean = solverMap.get(key);
		} else {
			bean = new SolverBean(key);
			solverMap.put(key, bean);
			solverBeans.add(bean);
		}
		return bean;
	}
	
	public void addRelation(String leftKey, String rightKey) {
		if (!relationMap.containsKey(leftKey)) {
			List<String> relationList = Lists.newArrayList();
			relationMap.put(leftKey, relationList);
		}
		relationMap.get(leftKey).add(rightKey);
	}
	
	public String createTempKey() {
		final String tranDate = DateUtils.getNowTime(DateUtils.FORMAT_YYYYMMDDHHSS3);
		
		int current = 10;
        synchronized (LOCK) {
            if (sSequenceNo > MAX_SIZE) {
                sSequenceNo = 10;
            }
            current += sSequenceNo++;
        }
        final StringBuffer sb = new StringBuffer("TEMP");
        sb.append(ConstantsUtil.Str.UNDERLINE);
        sb.append(tranDate);
        sb.append(ConstantsUtil.Str.UNDERLINE);
        sb.append(current);
        return sb.toString();
	}
	
	public class SolverBean {
		
		private String key;
		
		private String value;
		
		public SolverBean(String key) {
			this.key = key;
		}

		public String getKey() {
			return key;
		}

		public void setKey(String key) {
			this.key = key;
		}

		public String getValue() {
			return value;
		}

		public void setValue(String value) {
			this.value = value;
		}
		
	}
	
	public class OperatorBean {
		private String operator;
		private String leftKey;
		private String rightKey;
		public String getOperator() {
			return operator;
		}
		public void setOperator(String operator) {
			this.operator = operator;
		}
		public String getLeftKey() {
			return leftKey;
		}
		public void setLeftKey(String leftKey) {
			this.leftKey = leftKey;
		}
		public String getRightKey() {
			return rightKey;
		}
		public void setRightKey(String rightKey) {
			this.rightKey = rightKey;
		}
		
	}

}
