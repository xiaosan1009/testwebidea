package co.jp.softbank.qqmx.task.info;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.task.face.ITaskContext;

public class FileReader<V> extends AbstractReader<V> {

	@Override
	public void prepare(ITaskContext context) throws SoftbankException {
		collector.prepare(context);
	}

}
