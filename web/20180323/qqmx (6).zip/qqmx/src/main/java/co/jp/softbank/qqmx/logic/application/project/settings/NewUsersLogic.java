package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.util.StringUtils;

public class NewUsersLogic extends AbstractBaseLogic {

	public LogicBean selectUserList() throws SoftbankException {
		LogicBean groupBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		
		String groupId = context.getParam().get("groupId");
		conditions.put("group_id", Integer.parseInt(groupId));
		conditions.put("input_date", context.getParam().get("input_date"));
		groupBean.setData(db.querys("newUsers.selectUserList", conditions));
		return groupBean;
	}
	
	public void saveGroupNewUser() throws SoftbankException {
		String[] projectSettingUser = sessionToString("user_fields_selected_name");
		String groupId = context.getParam().get("groupId");
		for (int i = 0; i < projectSettingUser.length; i++) {
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("user_id", Integer.parseInt(projectSettingUser[i]));
			conditions.put("group_id", Integer.parseInt(groupId));
			db.insert("newUsers.saveGroupNewUser", conditions);
			
//			List<Map<String, Object>> selectMemberList = db.querys("newUsers.selectMember" ,conditions);
//			if (selectMemberList.size()>0){
//				for (int b = 0; b < selectMemberList.size(); b++) {
//					conditions.put("project_id", Integer.parseInt(String.valueOf(selectMemberList.get(b).get("project_id"))));
//					db.insert("newUsers.insertProjectSettingUser", conditions);
//					int memberId = Integer.parseInt(StringUtils.toString(conditions.get("id")));
//					
//					List<Map<String, Object>> selectProjectMemberList = db.querys("newUsers.selectProjectMember" ,conditions);
//					if (selectProjectMemberList.size()>0){
//						for (int m = 0; m < selectProjectMemberList.size(); m++) {
//							Map<String, Object> conditionsMembers = Maps.newHashMap();
//							conditionsMembers.put("member_id", memberId);
//							conditionsMembers.put("role_id", Integer.parseInt(String.valueOf(selectProjectMemberList.get(m).get("role_id"))));
//							conditionsMembers.put("inherited_from", Integer.parseInt(String.valueOf(selectProjectMemberList.get(m).get("member_roles_id"))));
//							db.insert("newUsers.insertProjectSettingMembers", conditionsMembers);
//						}
//					}
//				}
//			}
			
		}
	}
	
	public int insertRole(String[] projectSettingRole, int project_id ,int members_id, int inherited_from) throws SoftbankException{
		int mUserRoleId = 0;
		for (int m = 0; m < projectSettingRole.length; m++) {
			Map<String, Object> conditionRoles = Maps.newHashMap();
			conditionRoles.put("member_id", members_id);
			conditionRoles.put("role_id", Integer.parseInt(projectSettingRole[m]));
			List<Map<String, Object>> selectMemberRoles = db.querys("newUsers.selectProjectMemberRoles" ,conditionRoles);
			
			if (selectMemberRoles.size() == 0) {
				if (inherited_from == 0) {
					conditionRoles.put("inherited_from", null);
				} else {
					conditionRoles.put("inherited_from", inherited_from);
				}
				db.insert("newUsers.insertProjectSettingMembers" ,conditionRoles);
				mUserRoleId = Integer.parseInt(StringUtils.toString(conditionRoles.get("id")));
			}
		}
		return mUserRoleId;
	}	
	
	private String[] sessionToString(String key) {
		String[] result = new String[]{} ;
		String[] temp = context.getParam().getList(key); 
		return StringUtils.isEmpty(temp) ? result : temp ;  
	}
}
