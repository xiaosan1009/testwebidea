package co.jp.softbank.qqmx.logic.application.watchable;

import java.util.Map;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;

import com.google.common.collect.Maps;

public class ProjectListLogic extends AbstractBaseLogic {
	
	public void getProjectListInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String headquartersId = context.getParam().get("headquartersId").equals("")? "9898": context.getParam().get("headquartersId");
		String divisionId = context.getParam().get("divisionId").equals("")? "9898": context.getParam().get("divisionId");
		String department_id = context.getParam().get("departmentId").equals("")? "9898": context.getParam().get("departmentId");
		String category_id = context.getParam().get("categoryId").equals("")? "9898": context.getParam().get("categoryId");
		String status_Id = context.getParam().get("statusId").equals("")? "90000001": context.getParam().get("statusId");
		
		String searchName = context.getParam().get("demos_principal_search");
		String initMyPageFlg = context.getParam().get("initMyPageFlg");
		int loginUserId = ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId();
		conditions.put("user_id", loginUserId);
		
		String search1 = context.getParam().get("search1");
		String sort1 = context.getParam().get("sort1");
		String search2 = context.getParam().get("search2");
		String sort2 = context.getParam().get("sort2");
		if ("".equals(search1) && "".equals(search2)){
			search1 = "project_name";
			sort1 = "asc";
			search2 = "project_name";
			sort2 = "asc";
		}
		if (!"".equals(search1) && "".equals(search2)){
			search2 = search1;
			sort2 = sort1;
		}
		if ("".equals(search1) && !"".equals(search2)){
			search1 = search2;
			sort1 = sort2;
		}
		conditions.put("search1", search1);
		conditions.put("sort1", sort1);
		conditions.put("search2", search2);
		conditions.put("sort2", sort2);
		
		if ("1".equals(initMyPageFlg)){
			conditions.put("init_my_page", "1");
			conditions.put("search_name", "");
			conditions.put("headquarters_Id", 9898);
			conditions.put("division_id", 9898);
			conditions.put("department_id", 9898);
			conditions.put("category_id", 9898);
			conditions.put("status_Id", 9898);
		}else if ("2".equals(initMyPageFlg)){
			conditions.put("init_my_page", "0");
			conditions.put("search_name", searchName);
			conditions.put("headquarters_Id", 9898);
			conditions.put("division_id", 9898);
			conditions.put("department_id", 9898);
			conditions.put("category_id", 9898);
			conditions.put("status_Id", 9898);
		}else{
			conditions.put("init_my_page", "0");
			conditions.put("search_name", searchName);
			conditions.put("headquarters_Id", headquartersId);
			if ("9898".equals(divisionId)){
				conditions.put("division_id", headquartersId);
			}else{
				conditions.put("division_id", divisionId);
			}
	        if ("9898".equals(department_id)){
	            if ("9898".equals(divisionId)){
	                conditions.put("department_id", Integer.parseInt(headquartersId));
	            }else{
	            	conditions.put("department_id", Integer.parseInt(divisionId));
	            }
	        }else{
	        	conditions.put("department_id", Integer.parseInt(department_id));
	        }
			conditions.put("category_id", Integer.parseInt(category_id));
			conditions.put("status_Id", Integer.parseInt(status_Id));
		}

		context.getResultBean().setData(db.querys("projectList.getProjectList", conditions));
	}
	public void getMyPageProjectListInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();

//		conditions.put("search1", search1);
//		conditions.put("sort1", sort1);
//		conditions.put("search2", search2);
//		conditions.put("sort2", sort2);
//		conditions.put("headquarters_Id", headquartersId);
//		conditions.put("division_id", headquartersId);
//		conditions.put("department_id", Integer.parseInt(headquartersId));
//		conditions.put("category_id", Integer.parseInt(category_id));
		int loginUserId = ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId();
		conditions.put("user_id", loginUserId);
		
		context.getResultBean().setData(db.querys("projectList.getMyPageProjectListInfo", conditions));
	}
	public void getSelectList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String selectId = context.getParam().get("selectFlg");
		String headquartersId = context.getParam().get("headquartersId").equals("")? "9898": context.getParam().get("headquartersId");
		String divisionId = context.getParam().get("divisionId").equals("")? "9898": context.getParam().get("divisionId");
		String department_id = context.getParam().get("departmentId").equals("")? "9898": context.getParam().get("departmentId");
		String project_id = context.getParam().get("proId").equals("")? "9898": context.getParam().get("proId");
		String category_id = context.getParam().get("categoryId").equals("")? "9898": context.getParam().get("categoryId");
		String status_Id = context.getParam().get("statusId").equals("")? "90000001": context.getParam().get("statusId");
		int loginUserId = ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId();
		
		if ("headquarters".equals(selectId)){
			context.getResultBean().setData(db.querys("projectList.getHeadquartersList"));
		}else if ("division".equals(selectId)){
			conditions.put("headquarters_Id", headquartersId);
			context.getResultBean().setData(db.querys("projectList.getDivisionList", conditions));
		}else if ("department".equals(selectId)){
			if ("9898".equals(divisionId)){
				conditions.put("division_id", headquartersId);
			}else{
				conditions.put("division_id", divisionId);
			}
			context.getResultBean().setData(db.querys("projectList.getDepartmentList", conditions));
		}else if ("prj".equals(selectId)){
			
			if ("9898".equals(department_id)){
				if ("9898".equals(divisionId)){
					conditions.put("department_id", Integer.parseInt(headquartersId));
				}else{
					conditions.put("department_id", Integer.parseInt(divisionId));
				}
			}else{
				conditions.put("department_id", Integer.parseInt(department_id));
			}
			
			conditions.put("category_id", Integer.parseInt(category_id));
			conditions.put("status_Id", Integer.parseInt(status_Id));
			conditions.put("user_id", loginUserId);
			
			String searchName = context.getParam().get("demos_principal_search");
			conditions.put("search_name", searchName);
			context.getResultBean().setData(db.querys("projectList.getPrjList", conditions));
		}else if ("subPrj".equals(selectId)){
			
			if (!"".equals(project_id)){
				conditions.put("project_id", Integer.parseInt(project_id));
				conditions.put("user_id", loginUserId);
				context.getResultBean().setData(db.querys("projectList.getSubPrjList", conditions));
			}
		}
	}
	public void getUrlList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String clickId = context.getParam().get("projectClick");
		conditions.put("click_project_id", Integer.parseInt(clickId));
		context.getResultBean().setData(db.querys("projectList.getUrlList", conditions));
	}
	public void getInitMyPageListInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		
		int loginUserId = ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId();
		conditions.put("user_id", loginUserId);
		context.getResultBean().setData(db.querys("projectList.getInitMyPageListInfo", conditions));
	}
	public void getGitListInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String clickId = context.getParam().get("projectClick");
		conditions.put("click_project_id", Integer.parseInt(clickId));
		context.getResultBean().setData(db.querys("projectList.getGitListInfo", conditions));
	}
//	public void getMyPageCheckboxInfo() throws SoftbankException {
//		Map<String, Object> conditions = Maps.newHashMap();
//		String myPageCheckboxFlg = context.getParam().get("myPageCheckboxFlg");
//		int loginUserId = ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId();
//		conditions.put("user_id", loginUserId);
//		if("true".equals(myPageCheckboxFlg)){
//			
//		}else{
//			
//		}
//
//		context.getResultBean().setData(db.querys("projectList.getInitMyPageListInfo", conditions));
//	}
	public void insertMyPageInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		
		int loginUserId = ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId();
		conditions.put("user_id", loginUserId);
		String[] projectMyPage = context.getParam().getList("my_page_ids");
		context.getResultBean().setData(db.delete("projectList.deleteMyPageInfo", conditions));
		if (projectMyPage != null) {
			for (int i = 0; i < projectMyPage.length; i++) {
				conditions.put("project_id", Integer.parseInt(projectMyPage[i]));
				context.getResultBean().setData(db.insert("projectList.insertMyPageInfo", conditions));
			}
		}
	}
}
