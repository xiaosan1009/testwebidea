package co.jp.softbank.qqmx.dao.common;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.dao.IDaoInterface;

public interface DbMemoryMonitorDao extends IDaoInterface {

	Map<String, Object> getIssueUpdateTimestamp(Map<String, Object> conditions);
	
	List<Map<String, Object>> getIssueUpdateTimestampForGantt(Map<String, Object> conditions);
	
	Integer getProjectParentId(Map<String, Object> conditions);
}
