package co.jp.softbank.qqmx.dao.common;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

import co.jp.softbank.qqmx.exception.SoftbankException;

public interface IQueryDao {
	
	<E> E executeForObject(String sqlID) throws SoftbankException;
	
	<E> E executeForObject(String sqlID, Class<?> clazz) throws SoftbankException;
	
	<E> E executeForObject(String sqlID, Object conditions, Class<?> clazz) throws SoftbankException;
	
	<E> E executeForObject(String sqlID, Object conditions) throws SoftbankException;
	
	<E> List<E> executeForObjectList(String sqlID) throws SoftbankException;
	
	<E> List<E> executeForObjectList(String sqlID, Object conditions) throws SoftbankException;
	
	<E> List<E> executeForObjectListAndClosed(String sqlID) throws SoftbankException;
	
	<E> List<E> executeForObjectListAndClosed(String sqlID, Object conditions) throws SoftbankException;
	
	Map<String, Object> executeForMap(String sqlID) throws SoftbankException;
	
	Map<String, Object> executeForMapAndClosed(String sqlID) throws SoftbankException;
	
	Map<String, Object> executeForMap(String sqlID, Object conditions) throws SoftbankException;
	
	Map<String, Object> executeForMapAndClosed(String sqlID, Object conditions) throws SoftbankException;
	
	<E> E executeForObjectAndClosed(String sqlID) throws SoftbankException;
	
	<E> E executeForObjectAndClosed(String sqlID, Object conditions) throws SoftbankException;
	
	List<Map<String, Object>> executeForMapList(String sqlID) throws SoftbankException;
	
	List<Map<String, Object>> executeForMapListAndClosed(String sqlID) throws SoftbankException;
	
	List<Map<String, Object>> executeForMapList(String sqlID, Object conditions) throws SoftbankException;
	
	List<Map<String, Object>> executeForMapListAndClosed(String sqlID, Object conditions) throws SoftbankException;

	SqlSession getQuerySession();
}
