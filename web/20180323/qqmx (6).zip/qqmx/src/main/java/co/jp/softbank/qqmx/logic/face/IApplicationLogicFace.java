package co.jp.softbank.qqmx.logic.face;

import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.Param;
import co.jp.softbank.qqmx.logic.bean.SessionData;

public interface IApplicationLogicFace {
	
	void applicationInit(HttpContext context);

}
