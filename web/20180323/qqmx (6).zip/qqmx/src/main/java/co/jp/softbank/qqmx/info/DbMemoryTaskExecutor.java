package co.jp.softbank.qqmx.info;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.info.bean.DbMemoryWorker;
import co.jp.softbank.qqmx.info.bean.ProjectWorkerBean;
import co.jp.softbank.qqmx.task.BaseTask;
import co.jp.softbank.qqmx.task.face.IWorker;

public class DbMemoryTaskExecutor extends BaseTask {
	
	public DbMemoryTaskExecutor(int threads) throws SoftbankException {
		super(threads);
	}

	@Override
	public boolean createWorkers() throws SoftbankException {
		try {
			for (int i = 0; i < threads; i++) {
				workers.add(createWorker());
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SystemException);
		}
		return true;
	}

	@Override
	public IWorker createWorker() throws SoftbankException {
		try {
			return new DbMemoryWorker(new ProjectWorkerBean());
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SystemException);
		}
	}

}
