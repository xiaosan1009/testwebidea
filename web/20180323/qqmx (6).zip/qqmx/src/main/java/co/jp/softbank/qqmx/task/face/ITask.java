package co.jp.softbank.qqmx.task.face;

import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

public interface ITask<IN> {

	void prepare(ITaskContext context) throws Exception;
	
	void reprocess(ITaskContext context) throws Exception;
	
	void execute(ITaskContext context, IKey key, IN value) throws Exception;

	void cleanup(ITaskContext context) throws Exception;

	boolean isMultiline() throws Exception;

	boolean isPrepared() throws Exception;

	int numOfThreads() throws Exception;

	long considersHangupMills() throws Exception;

	Map<String, List<Object>> keyOrder() throws Exception;

	void handleException(ITaskContext context, IN value, Exception cause) throws Exception;
	
	void setLines(AtomicInteger lines) throws Exception;
	
	IReader<? extends Object> getReader() throws Exception;
}
