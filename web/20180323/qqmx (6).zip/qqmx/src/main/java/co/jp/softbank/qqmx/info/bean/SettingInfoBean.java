package co.jp.softbank.qqmx.info.bean;

import java.util.Map;

import com.google.common.collect.Maps;

public class SettingInfoBean {
	
	private Map<String, String> settingMap = Maps.newHashMap();

	public Map<String, String> getSettingMap() {
		return settingMap;
	}
	
	public void putSetting(String key, String value) {
		settingMap.put(key, value);
	}
	
	public String get(String key) {
		return settingMap.get(key);
	}

}
