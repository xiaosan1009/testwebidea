package co.jp.softbank.qqmx.logic.application.project;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.validator.Field;
import org.apache.commons.validator.GenericTypeValidator;
import org.apache.commons.validator.GenericValidator;
import org.apache.commons.validator.ValidatorAction;
import org.apache.commons.validator.ValidatorException;
import org.ho.yaml.Yaml;
import org.slf4j.Logger;
import org.springframework.context.support.DefaultMessageSourceResolvable;

import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.dao.common.IDbExecute;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.ControlDbMemory;
import co.jp.softbank.qqmx.info.ControlSettingMap;
import co.jp.softbank.qqmx.logic.application.face.CustomFieldType;
import co.jp.softbank.qqmx.logic.application.face.IssueKey;
import co.jp.softbank.qqmx.util.LogUtil;
import co.jp.softbank.qqmx.util.StringUtils;
import co.jp.softbank.qqmx.validator.IValidationErrors;
import co.jp.softbank.qqmx.validator.ValidatorChecks;

public class IssueValidatorChecks extends ValidatorChecks {
	
	private Logger log = new LogUtil(this.getClass()).getLog();

	@SuppressWarnings("unchecked")
	public boolean checkIssueCustom(Object bean, Map<String, Object> param, ValidatorAction va, Field field, IValidationErrors errors, IDbExecute dao) throws ValidatorException {
		boolean result = true;
		try {
			int projectId = ((HttpContext) bean).getParam().projectId;
			// カスタムフィールドチェックかどうか
			if (!ControlSettingMap.getInstance().isCheckCustom(projectId)) {
				return result;
			}
			// 親チェックしない
			if (param.containsKey(IssueKey.PROCESS.ISPARENT)) {
				return result;
			}
			// カスタムフィールドを取得する
			List<Map<String, Object>> customList = ControlDbMemory.getInstance().getCustomListMap(projectId);
			String fieldkey = "CustomField";
			for (int i = 0; i < customList.size(); i++) {
				Map<String, Object> custom = customList.get(i);
				Map<Integer, Object> customValues = (Map<Integer, Object>)param.get(IssueKey.CUSTOMVALUES.KEY);
				String value = StringUtils.toString(customValues.get(StringUtils.toInt(custom.get("id"))));
				int custom_field_id = StringUtils.toInt(custom.get("id"));
				// 必要入力チェック
				if ("true".equals(StringUtils.toString(custom.get("is_required"))) 
						|| StringUtils.isNotEmpty(custom.get("required_issue_status_ids"))) {
					int tracker_id = StringUtils.toInt(param.get(IssueKey.TRACKER_ID.KEY));
					if (!ControlSettingMap.getInstance().isCheckCustomLevel(projectId, getLevel(param), custom_field_id)) {
						continue;
					}
					Map<Integer, Integer> mapping = ControlDbMemory.getInstance().getCustomFieldTrackerMap(tracker_id);
					if (mapping == null || !mapping.containsKey(custom_field_id)) {
						continue;
					}
					if (StringUtils.isNotEmpty(custom.get("required_issue_status_ids"))) {
						int status_id = StringUtils.toInt(param.get(IssueKey.STATUS_ID.KEY));
						List<String> statusYaml = (List<String>)Yaml.load(StringUtils.toString(custom.get("required_issue_status_ids")));
						if (statusYaml != null && statusYaml.size() > 0) {
							boolean checkYaml = false;
							for (int j = 0; j < statusYaml.size(); j++) {
								int statusId = StringUtils.toInt(statusYaml.get(j));
								if (status_id == statusId) {
									checkYaml = true;
									break;
								}
							}
							if (!checkYaml) {
								continue;
							}
						}
					}
					if (GenericValidator.isBlankOrNull(value) || !checkActualCount(custom_field_id, value) || !checkFinishedCount(custom_field_id, value, param)) {
						DefaultMessageSourceResolvable[] args = new DefaultMessageSourceResolvable[1];
						field.setKey(fieldkey + custom_field_id);
						args[0] = new DefaultMessageSourceResolvable(new String[] {}, StringUtils.toString(custom.get("name")));
						rejectValue(errors, field, va, bean, args);
						result = false;
					}
				}
				
				if (!customTypeCheck(custom, value, custom_field_id, bean, va, field, errors)) {
					result = false;
				}
			}
		} catch (SoftbankException e) {
			log.error("SoftbankException : " + e.getMessage(), e);
			throw new ValidatorException("SoftbankException : " + e.getMessage());
		}
		return result;
	}
	
	private boolean checkActualCount(int custom_field_id, String value) {
		if (custom_field_id == 2124 && "0".equals(value)) {
			return false;
		}
		return true;
	}
	
	@SuppressWarnings("unchecked")
	private boolean checkFinishedCount(int custom_field_id, String value, Map<String, Object> param) {
		if (custom_field_id == 2120) {
			Map<Integer, Object> customValues = (Map<Integer, Object>)param.get(IssueKey.CUSTOMVALUES.KEY);
			String val = StringUtils.toString(customValues.get(2118));
			if (!"なし".equals(val) && "0".equals(value)) {
				return false;
			}
		}
		return true;
	}
	
	private boolean customTypeCheck(
			Map<String, Object> custom, 
			String value, 
			int custom_field_id, 
			Object bean, 
			ValidatorAction va, 
			Field field, 
			IValidationErrors errors) {
		if (StringUtils.isEmpty(value)) {
			return true;
		}
		String fieldkey = "CustomField";
		String type = StringUtils.toString(custom.get("field_format"));
		if (CustomFieldType.INT.equals(type)) {
			if (GenericTypeValidator.formatInt(value) == null) {
				DefaultMessageSourceResolvable[] args = new DefaultMessageSourceResolvable[1];
				field.setKey(fieldkey + custom_field_id);
				args[0] = new DefaultMessageSourceResolvable(new String[] {}, StringUtils.toString(custom.get("name")));
				rejectValue(errors, field, va, bean, args, "errors.integer");
				return false;
			}
		} else if (CustomFieldType.FLOAT.equals(type)) {
			if (GenericTypeValidator.formatFloat(value) == null) {
				DefaultMessageSourceResolvable[] args = new DefaultMessageSourceResolvable[1];
				field.setKey(fieldkey + custom_field_id);
				args[0] = new DefaultMessageSourceResolvable(new String[] {}, StringUtils.toString(custom.get("name")));
				rejectValue(errors, field, va, bean, args, "errors.float");
				return false;
			}
		}
		return true;
	}
	
	private int getLevel(Map<String, Object> param) {
		int level = 0;
		String levelInfo = StringUtils.toString(param.get(IssueKey.PROCESS.FLOOR_ID));
		String[] levels = levelInfo.split(" ");
		for (int i = 0; i < levels.length; i++) {
			if (levels[i].startsWith("p") || levels[i].startsWith("v")) {
				continue;
			}
			level++;
		}
		return level;
	}

}
