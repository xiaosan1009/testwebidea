package co.jp.softbank.qqmx.dao.project.settings;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.dao.IDaoInterface;

public interface PrjectSettingDao extends IDaoInterface {
	
	List<Map<String, Object>> getProjectSettingList(Map<String, Object> conditions);
	List<Map<String, Object>> getProjectSettingGroupList(Map<String, Object> conditions);
	List<Map<String, Object>> getProjectSettingRoleList(Map<String, Object> conditions);
	List<Map<String, Object>> getProjectSettingSelectList(Map<String, Object> conditions);
	
	List<Map<String, Object>> selectProjectSettingMembers(Map<String, Object> conditions);
	List<Map<String, Object>> selectProjectSettingUsers(Map<String, Object> conditions);
	List<Map<String, Object>> selectProjectSettingMemberUsers(Map<String, Object> conditions);
	void deleteProjectSettingMemberUsers(Map<String, Object> conditions);
	void deleteProjectSettingMemberGroupUsers(Map<String, Object> conditions);
	List<Map<String, Integer>> selectProjectSettingGroupUsers(Map<String, Integer> conditions);
	List<Map<String, Integer>> selectProjectSettingNewGroupUsers(Map<String, Integer> conditions);
	List<Map<String, Object>> selectProjectSettingMemberInfo(Map<String, Object> conditions);
	
	void insertProjectSettingMembers(Map<String, Object> conditions);
	List<Map<String, Object>> saveProjectSettingRole(Map<String, Object> conditions);
	
	List<Map<String, Object>> saveProjectSettingNewUser(Map<String, Object> conditions);
	List<Map<String, Object>> selectProjectSettingMembersUser(Map<String, Object> conditions);
	
	
	void insertProjectSettingUser(Map<String, Object> conditions);
	void deleteProjectSettingUser(Map<String, Object> conditions);
	void deleteProjectSettingMemberUsersAll(Map<String, Object> conditions);
	void deleteProjectSettingMemberUsersflg(Map<String, Object> conditions);
	void deleteProjectSettingMemberGroupUsers1(Map<String, Object> conditions);
	void deleteProjectSettingMemberGroup1(Map<String, Object> conditions);
	
	
}
