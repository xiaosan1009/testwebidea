package co.jp.softbank.qqmx.logic.application.mail;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.Date;
import java.util.Properties;

import javax.mail.Address;
import javax.mail.Message;
import javax.mail.MessagingException;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.AddressException;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

import org.apache.commons.lang.StringUtils;

public class MailRelease {

	 private static final String SMTP_HOST = "internal-smtp.bb.local";
	 private static final String SMTP_PORT = "25";
	 private static final String MAIL_FROM = "sbbgrp-qqmx@g.softbank.co.jp";
	 private static final String MAIL_TO = "gyougi.o@g.softbank.co.jp";
	 private static final String MAIL_CC = "";
	 private static final String MAIL_SUBJECT = "【復旧】サーバーダウンに伴うQQM-X利用不可のお知らせ（2017-11-08 12:00～2017-11-08 14:10）";
//	 private static final String MAIL_TEXT = "本文\n\r";
	 
	/**
	 * メール送信
	 * 
	 * @param args
	 * @throws IOException 
	 * @throws MessagingException 
	 * @throws AddressException 
	 */
	public static void main(String[] args) throws IOException {

		File dir = new File("/tmp/mail/mail.csv");
		byte[] b = new byte[(int) dir.length()];
		FileInputStream fi = new FileInputStream(dir);
		fi.read(b);
		String s = new String(b);
		s = s.replaceAll("\r", "");
		String[] strrec = s.split("\n");
		
		for (int i = 0; i<strrec.length; i++){
			mailPost(strrec[i]);
			try {
				Thread.currentThread().sleep(200);
				System.out.println("実行時間=" + new Date());
			} catch (InterruptedException e) {
				System.out.println(e.getMessage());
				e.printStackTrace();
			}
		}
		fi.close();
	}
	
	public static void mailPost(String bcc) {
		
		Properties props = new Properties();
		props.setProperty("mail.debug", "true");  
		props.setProperty("mail.host", SMTP_HOST);
		props.setProperty("mail.transport.protocol", SMTP_PORT);
		
		Session session = Session.getInstance(props);
		Message msg = new MimeMessage(session);

		try {
			msg.setSubject(MAIL_SUBJECT);  
			String mail_text = 
				"QQM-X利用者各位\n" +
				"\n" +
				"以下システムのDBサーバ障害ですが、現在復旧し利用可能です。\n" +
				"\n" +
				" ・QQM-X全環境\n" +
				" ・関連Dashboard\n" +
				"　PJ見える化関連\n" +
				"　TU 50%Shift関連\n" +
				"\n" +
				"よろしくお願いします。";
			msg.setText(mail_text);
			// FROM設定
			if (!StringUtils.isEmpty(MAIL_FROM)) {
				msg.setFrom(new InternetAddress(MAIL_FROM));
			}
			
			Transport transport = session.getTransport("smtp");
			transport.connect(SMTP_HOST, MAIL_FROM);
			transport.sendMessage(msg, new Address[] {new InternetAddress(bcc)});  
			transport.close();  
		} catch (MessagingException e) {
			// TODO 自動生成された catch ブロック
			System.out.println(e.getMessage());
			System.out.println("#####################################" + bcc);
			e.printStackTrace();
		}  
	}
	
}
