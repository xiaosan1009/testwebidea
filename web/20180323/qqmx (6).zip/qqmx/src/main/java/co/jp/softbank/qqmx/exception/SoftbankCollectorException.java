package co.jp.softbank.qqmx.exception;

public class SoftbankCollectorException extends RuntimeException {

	private static final long serialVersionUID = 1L;
	
	public SoftbankCollectorException() {
        super();
    }

    public SoftbankCollectorException(String message) {
        super(message);
    }

    public SoftbankCollectorException(Throwable cause) {
        super(cause);
    }

    public SoftbankCollectorException(String message, Throwable cause) {
        super(message, cause);
    }

}
