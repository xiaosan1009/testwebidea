package co.jp.softbank.qqmx.logic.application.test;

import java.util.List;
import java.util.Map;

import org.yaml.snakeyaml.Yaml;


import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.util.FileUtils;

public class CustomTestLogic extends AbstractBaseLogic {
	
	public LogicBean getTestData() {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> param = Maps.newHashMap();
		param.put("test", "aaa");
		logicBean.setData(param);
		return logicBean;
	}
	
//	public static void main(String[] args) throws SoftbankException {
//		String b = "C:\\Users\\dev6828503yu\\Documents\\workspace\\temp\\a.txt";
//		List<String> a = Lists.newArrayList("Java数");
//		System.out.println((new Yaml()).load(FileUtils.getFileDataString(b)));
//	}

}
