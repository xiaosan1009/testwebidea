package co.jp.softbank.qqmx.application;

import javax.servlet.ServletContextEvent;
import javax.servlet.ServletContextListener;

import org.slf4j.Logger;
import org.springframework.context.ApplicationContext;
import org.springframework.web.context.support.WebApplicationContextUtils;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.ControlDbMemory;
import co.jp.softbank.qqmx.util.LogUtil;

public class CustomLoaderListener implements ServletContextListener {
	
	private Logger log = new LogUtil(this.getClass()).getLog();
	
	private static ApplicationContext springContext;

	@Override
	public void contextDestroyed(ServletContextEvent arg0) {
	}

	@Override
	public void contextInitialized(ServletContextEvent arg0) {
//		LogFactory.useSlf4jLogging();
//		LogFactory.useLog4JLogging();
//		LogFactory.useJdkLogging();
//		LogFactory.useCommonsLogging();
//		LogFactory.useStdOutLogging();
		springContext = WebApplicationContextUtils.getWebApplicationContext(arg0.getServletContext());
		log.info("contextInitialized");
	}

	public static ApplicationContext getApplicationContext() {
		return springContext;
	}
}
