package co.jp.softbank.qqmx.dao.project.settings;

import co.jp.softbank.qqmx.dao.IDaoInterface;

public interface AllInsertDao extends IDaoInterface {
	
}
