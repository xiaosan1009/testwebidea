package co.jp.softbank.qqmx.info;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.math.BigDecimal;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

import javax.xml.parsers.ParserConfigurationException;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.apache.poi.hssf.usermodel.HSSFDateUtil;
import org.apache.poi.openxml4j.exceptions.InvalidFormatException;
import org.apache.poi.openxml4j.exceptions.InvalidOperationException;
import org.apache.poi.openxml4j.exceptions.OpenXML4JException;
import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.openxml4j.opc.PackageAccess;
import org.apache.poi.ss.usermodel.BuiltinFormats;
import org.apache.poi.ss.usermodel.DataFormatter;
import org.apache.poi.xssf.eventusermodel.ReadOnlySharedStringsTable;
import org.apache.poi.xssf.eventusermodel.XSSFReader;
import org.apache.poi.xssf.model.StylesTable;
import org.apache.poi.xssf.usermodel.XSSFCellStyle;
import org.apache.poi.xssf.usermodel.XSSFRichTextString;
import org.slf4j.Logger;
import org.xml.sax.Attributes;
import org.xml.sax.InputSource;
import org.xml.sax.SAXException;
import org.xml.sax.XMLReader;
import org.xml.sax.helpers.DefaultHandler;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.info.bean.ExcelInfoBean;
import co.jp.softbank.qqmx.info.bean.ExcelInfoBean.CellInfoBean;
import co.jp.softbank.qqmx.info.bean.ExcelInfoBean.DiffAnalizy;
import co.jp.softbank.qqmx.info.bean.ExcelInfoBean.RowInfoBean;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.DateUtils;
import co.jp.softbank.qqmx.util.LogUtil;
import co.jp.softbank.qqmx.util.StringUtils;

public class XLSXCovertCSVReader {

	protected Logger log = new LogUtil(this.getClass()).getLog();

	enum xssfDataType {
		BOOL, ERROR, FORMULA, INLINESTR, SSTINDEX, NUMBER,
	}

	private ReadOnlySharedStringsTable strings;

	private OPCPackage xlsxPackage;

	public XLSXCovertCSVReader(String path) throws SoftbankException {
		try {
			this.xlsxPackage = OPCPackage.open(path, PackageAccess.READ);
			this.strings = new QqmxStringsTable(this.xlsxPackage);
		} catch (InvalidOperationException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.InvalidOperationException, e);
		} catch (InvalidFormatException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.InvalidFormatException, e);
		} catch (IOException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IOException, e);
		} catch (SAXException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.SAXException, e);
		}
	}

	public XLSXCovertCSVReader(File file) throws SoftbankException {
		try {
			this.xlsxPackage = OPCPackage.open(file, PackageAccess.READ);
			this.strings = new QqmxStringsTable(this.xlsxPackage);
		} catch (InvalidOperationException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.InvalidOperationException, e);
		} catch (InvalidFormatException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.InvalidFormatException, e);
		} catch (IOException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IOException, e);
		} catch (SAXException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.SAXException, e);
		}
	}

	public XLSXCovertCSVReader(InputStream is) throws SoftbankException {
		try {
			this.xlsxPackage = OPCPackage.open(is);
			this.strings = new QqmxStringsTable(this.xlsxPackage);
		} catch (InvalidOperationException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.InvalidOperationException, e);
		} catch (InvalidFormatException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.InvalidFormatException, e);
		} catch (IOException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IOException, e);
		} catch (SAXException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.SAXException, e);
		}
	}

	public List<String[]> processSheet(StylesTable styles, InputStream sheetInputStream, boolean referFirst, int startRow)
			throws SoftbankException {
		try {
			List<String[]> ret = Lists.newArrayList();
			InputSource sheetSource = new InputSource(sheetInputStream);
			SAXParserFactory saxFactory = SAXParserFactory.newInstance();
			SAXParser saxParser = saxFactory.newSAXParser();
			XMLReader sheetParser = saxParser.getXMLReader();
			MyXSSFSheetHandler handler = new MyXSSFSheetHandler(styles, referFirst, startRow);
			if (strings != null) {
				handler.setSharedStringsTable(strings);
			}
			sheetParser.setContentHandler(handler);
			sheetParser.parse(sheetSource);
			
			HashMap<String, String> workMap = handler.getWorkMap();
			int firstRowLength = handler.getFirstRowColumnLength();
			for (String colRow : workMap.keySet()) {
				int sepIdx = 0;
				int colRowLen = colRow.length();

				for (int i = 0; i < colRowLen; i++) {
					if (colRow.charAt(i) < 'A') {
						sepIdx = i;
						break;
					}
				}

				String colStr = colRow.substring(0, sepIdx);
				String rowStr = colRow.substring(sepIdx);
				int x = 0;
				int y = Integer.parseInt(rowStr);
				int colStrLen = colStr.length();
				for (int i = 0; i < colStrLen; i++) {
					int colIdx = colStr.charAt(i) - 'A' + 1;
					for (int j = 1; j < colStrLen - i; j++) {
						colIdx = colIdx * 26;
					}
					x += colIdx;
				}
				x--;
				y--;

				String[] data = null;
				int retSize = ret.size();
				if (y < retSize) {
					data = ret.get(y);
				} else {
					int addCnt = y - retSize + 1;
					for (int i = 0; i < addCnt; i++) {
						data = new String[firstRowLength];
						ret.add(data);
					}
				}
				data[x] = workMap.get(colRow);
			}
			return ret;
		} catch (IOException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IOException, e);
		} catch (SAXException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.SAXException, e);
		} catch (ParserConfigurationException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.ParserConfigurationException, e);
		}
	}

	public ReadOnlySharedStringsTable getStrings() {
		return strings;
	}

	public List<String[]> process(String sheetName) throws SoftbankException {
		return process(sheetName, false, 0);
	}
	
	public List<String[]> process(String sheetName, int startRow) throws SoftbankException {
		return process(sheetName, false, startRow);
	}
	
	public List<String[]> process(int sheetIndex, int startRow) throws SoftbankException {
		return process(sheetIndex, false, startRow);
	}

	public List<String[]> process(String sheetName, boolean referFirst, int startRow) throws SoftbankException {

		try {
			XSSFReader xssfReader = new XSSFReader(this.xlsxPackage);
			StylesTable styles = null;
			try {
				styles = xssfReader.getStylesTable();
			} catch (Exception e) {
				log.warn(e.getMessage());
			}
			XSSFReader.SheetIterator iter = (XSSFReader.SheetIterator) xssfReader.getSheetsData();
			while (iter.hasNext()) {
				InputStream stream = iter.next();
				try {
					String sheetNameTemp = iter.getSheetName();
					if (sheetName.equals(sheetNameTemp)) {
						return processSheet(styles, stream, referFirst, startRow);
					}
				} finally {
					stream.close();
				}
			}
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IOException, e);
		} catch (InvalidFormatException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.InvalidFormatException, e);
		} catch (OpenXML4JException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.OpenXML4JException, e);
		}
	}
	
	public List<String[]> process(int sheetIndex, boolean referFirst, int startRow) throws SoftbankException {
		
		try {
			XSSFReader xssfReader = new XSSFReader(this.xlsxPackage);
			StylesTable styles = null;
			try {
				styles = xssfReader.getStylesTable();
			} catch (Exception e) {
				log.warn(e.getMessage());
			}
			XSSFReader.SheetIterator iter = (XSSFReader.SheetIterator) xssfReader.getSheetsData();
			int index = 0;
			while (iter.hasNext()) {
				InputStream stream = iter.next();
				try {
					if (sheetIndex == index) {
						return processSheet(styles, stream, referFirst, startRow);
					}
					index++;
				} finally {
					stream.close();
				}
			}
			return null;
		} catch (IOException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IOException, e);
		} catch (InvalidFormatException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.InvalidFormatException, e);
		} catch (OpenXML4JException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.OpenXML4JException, e);
		}
	}

	public ExcelInfoBean getSheetInfos() throws SoftbankException {
		try {
			ExcelInfoBean infoBean = new ExcelInfoBean();
			XSSFReader xssfReader;
			xssfReader = new XSSFReader(this.xlsxPackage);
			XSSFReader.SheetIterator iter = (XSSFReader.SheetIterator) xssfReader.getSheetsData();
			int index = 0;
			while (iter.hasNext()) {
				InputStream stream = iter.next();
				try {
					String sheetNameTemp = iter.getSheetName();
					infoBean.addSheetName((index++) + ConstantsUtil.Str.COLON + sheetNameTemp);
				} finally {
					stream.close();
				}
			}
			return infoBean;
		} catch (IOException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IOException, e);
		} catch (OpenXML4JException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.OpenXML4JException, e);
		} finally {
			close();
		}
	}

	public ExcelInfoBean getSheetFirstRowInfos(String sheetName, DiffAnalizy diff, int headerRow) throws SoftbankException {
		try {
			List<String[]> datas = process(sheetName, headerRow);
			return getSheetFirstRowInfos(datas, diff, headerRow);
		} finally {
			close();
		}
	}
	
	public ExcelInfoBean getSheetFirstRowInfos(int sheetIndex, DiffAnalizy diff, int headerRow) throws SoftbankException {
		try {
			List<String[]> datas = process(sheetIndex, headerRow);
			return getSheetFirstRowInfos(datas, diff, headerRow);
		} finally {
			close();
		}
	}
	
	private ExcelInfoBean getSheetFirstRowInfos(List<String[]> datas, DiffAnalizy diff, int headerRow) throws SoftbankException {
		ExcelInfoBean infoBean = new ExcelInfoBean();
		if (datas == null || datas.size() == 0) {
			return infoBean;
		}
		if (headerRow != 0) {
//			headerRow = headerRow - 1;
		}
		String[] row = datas.get(headerRow);
		if (row == null) {
			return infoBean;
		}
		for (int i = 0; i < row.length; i++) {
			String cell = row[i];
			if (StringUtils.isNotEmpty(cell)) {
				infoBean.addFirstRowCellName(cell, i, diff);
			}
		}
		return infoBean;
	}

	public ExcelInfoBean getAllCellInfos(String sheetName, boolean referFirst, int startRow) throws SoftbankException {
		List<String[]> datas = process(sheetName, referFirst, startRow);
		return getAllCellInfos(datas, referFirst, startRow);
	}
	public ExcelInfoBean getAllCellInfos(int sheetIndex, boolean referFirst, int startRow) throws SoftbankException {
		List<String[]> datas = process(sheetIndex, referFirst, startRow);
		return getAllCellInfos(datas, referFirst, startRow);
	}
	public ExcelInfoBean getAllCellInfos(List<String[]> datas, boolean referFirst, int startRow) throws SoftbankException {
		ExcelInfoBean infoBean = new ExcelInfoBean();
		if (datas == null) {
			return infoBean;
		}
		int cellNumber = 0;
		for (int i = 0; i < datas.size(); i++) {
			String[] row = datas.get(i);
			if (row != null) {
				RowInfoBean rowInfo = new RowInfoBean(i);
				infoBean.addRow(rowInfo);
				if (referFirst) {
					if (i == 0) {
						cellNumber = row.length;
					}
				} else {
					cellNumber = row.length;
				}
				for (int j = 0; j < cellNumber; j++) {
					CellInfoBean cellInfo = new CellInfoBean(j);
					String cell = row[j];
					rowInfo.addCell(cellInfo);
					if (StringUtils.isNotEmpty(cell)) {
						cellInfo.setContent(cell);
					}
				}
			}
		}
		return infoBean;
	}

	public void close() throws SoftbankException {
		try {
			xlsxPackage.close();
		} catch (IOException e) {
			e.printStackTrace();
			throw new SoftbankException(SoftbankExceptionType.IOException, e);
		}
	}

	class MyXSSFSheetHandler extends DefaultHandler {

		private ReadOnlySharedStringsTable sharedStringsTable;

		private boolean referFirst;
		private int startRow;
		
		private StylesTable stylesTable;

		// Gathers characters as they are seen.
		private StringBuffer value;
		private boolean isFinished = false;
		private boolean isFirstRow = true;
		private boolean isDummy;
		private HashMap<String, String> workMap;
		public HashMap<String, String> getWorkMap() {
			return workMap;
		}

		private String workKey = "";
		private boolean nextIsString;
		private boolean inlineStr;
		private int firstRowColumnLength;
		private xssfDataType nextDataType;
		private short formatIndex;
		private String formatString;
		private final DataFormatter formatter;

		public MyXSSFSheetHandler(StylesTable styles) {
			this(styles, false, 1);
		}

		public MyXSSFSheetHandler(StylesTable styles, boolean referFirst, int startRow) {
			this.referFirst = referFirst;
			this.startRow = startRow;
			this.value = new StringBuffer();
			this.stylesTable = styles;
			this.formatter = new DataFormatter();
			workMap = Maps.newHashMap();
		}

		public ReadOnlySharedStringsTable getSharedStringsTable() {
			return sharedStringsTable;
		}

		public void setSharedStringsTable(ReadOnlySharedStringsTable sharedStringsTable) {
			this.sharedStringsTable = sharedStringsTable;
		}

		public void startElement(String uri, String localName, String name, Attributes attributes) throws SAXException {
			if (isFinished) {
				return;
			}
			if (name.equals("c")) {
				this.nextDataType = xssfDataType.NUMBER;
				workKey = attributes.getValue("r");
				
				if (isFirstRow) {
					int firstDigit = -1;
					for (int c = 0; c < workKey.length(); ++c) {
						if (Character.isDigit(workKey.charAt(c))) {
							firstDigit = c;
							break;
						}
					}
					int rowNumber = StringUtils.toInt(workKey.substring(firstDigit));
					if (rowNumber > this.startRow) {
						firstRowColumnLength = nameToColumn(workKey.substring(0, firstDigit)) + 1;
					}
				}
				String cellType = attributes.getValue("t");
				String cellStyleStr = attributes.getValue("s");
				if ("b".equals(cellType)) {
					nextDataType = xssfDataType.BOOL;
				} else if ("e".equals(cellType)) {
					nextDataType = xssfDataType.ERROR;
				} else if ("inlineStr".equals(cellType)) {
					nextDataType = xssfDataType.INLINESTR;
					inlineStr = true;
				} else if ("s".equals(cellType)) {
					nextDataType = xssfDataType.SSTINDEX;
					nextIsString = true;
				} else if ("str".equals(cellType)) {
					nextDataType = xssfDataType.FORMULA;
				} else if (cellStyleStr != null && stylesTable != null) {
					int styleIndex = Integer.parseInt(cellStyleStr);
					XSSFCellStyle style = stylesTable.getStyleAt(styleIndex);
					this.formatIndex = style.getDataFormat();
					this.formatString = style.getDataFormatString();
					if (this.formatString == null) {
						this.formatString = BuiltinFormats.getBuiltinFormat(this.formatIndex);
					}
				}
			}
			if ("rPh".equals(name)) {
				isDummy = true;
			}
			// Clear contents cache
			value.setLength(0);

		}

		public int getFirstRowColumnLength() {
			return firstRowColumnLength;
		}

		public void endElement(String uri, String localName, String name) throws SAXException {

			if (isFinished) {
				return;
			}
			String data = value.toString();
			if (nextIsString) {
				int idx = StringUtils.toInt(data);
				data = new XSSFRichTextString(sharedStringsTable.getEntryAt(idx)).toString();
				nextIsString = false;
			}
			
			// v => contents of a cell
			// Output after we've seen the string contents
			if ("v".equals(name) || (inlineStr && "c".equals(name))) {
				// System.out.println(lastContents);
				if ("v".equals(name)) {
					switch (nextDataType) {

					case BOOL:
						char first = value.charAt(0);
						data = first == '0' ? "FALSE" : "TRUE";
						break;

					case ERROR:
						data = "\"ERROR:" + value.toString() + '"';
						break;

					case FORMULA:
						data = value.toString();
						break;

					case INLINESTR:
						XSSFRichTextString rtsi = new XSSFRichTextString(value.toString());
						data = rtsi.toString();
						break;

					case SSTINDEX:
						String sstIndex = value.toString();
						try {
							int idx = Integer.parseInt(sstIndex);
							XSSFRichTextString rtss = new XSSFRichTextString(sharedStringsTable.getEntryAt(idx));
							data = rtss.toString();
						} catch (NumberFormatException ex) {
							log.error(ex.getMessage(), ex);
						}
						break;

					case NUMBER:
						String n = value.toString();
						if (HSSFDateUtil.isADateFormat(this.formatIndex, n)) {
							Double d = Double.parseDouble(n);
							Date date = HSSFDateUtil.getJavaDate(d);
							if (date == null) {
								data = StringUtils.toString((new BigDecimal(n)).doubleValue());
							} else {
								data = formateDateToString(date);
							}
						} else if (this.formatString != null) {
							data = formatter.formatRawCellContents(Double.parseDouble(n), this.formatIndex,
									this.formatString);
							if ("dd\\.mm\\.yyyy".equals(this.formatString)) {
								try {
									data = formateDateToString(DateUtils.formatToDate(data, DateUtils.FORMAT_DDMMMYYYY_DOT));
								} catch (SoftbankException e) {
									e.printStackTrace();
									log.error(e.getErrorMsg(), e);
								}
							}
						} else {
							data = StringUtils.toString((new BigDecimal(n)).doubleValue());
						}
						break;

					default:
						data = "(TODO: Unexpected type: " + nextDataType + ")";
						break;
					}
				}
				workMap.put(workKey, data);
				this.formatString = null;
			} else if ("row".equals(name)) {
				if (firstRowColumnLength > 0) {
					if (!referFirst) {
						isFinished = true;
					}
					isFirstRow = false;
				}
			}

		}

		public void characters(char[] ch, int start, int length) throws SAXException {
			value.append(ch, start, length);
		}
		
		private int nameToColumn(String name) {
			int column = -1;
			for (int i = 0; i < name.length(); ++i) {
				int c = name.charAt(i);
				column = (column + 1) * 26 + c - 'A';
			}
			return column;
		}
		
		private String formateDateToString(Date date) {
			SimpleDateFormat sdf = new SimpleDateFormat(DateUtils.FORMAT_YYYYMMDD_DASH);
			return sdf.format(date);

		}

	}
	
	public static class QqmxStringsTable extends ReadOnlySharedStringsTable {
		
		private boolean isDummy;
		
		public QqmxStringsTable(OPCPackage pkg) throws IOException, SAXException {
			super(pkg);
		}

		@Override
		public void startElement(String uri, String localName, String name, Attributes attributes) throws SAXException {
			super.startElement(uri, localName, name, attributes);
			if ("rPh".equals(name)) {
				isDummy = true;
			}
		}
		
		@Override
		public void endElement(String uri, String localName, String name) throws SAXException {
			super.endElement(uri, localName, name);
			
			if ("rPh".equals(name)) {
				isDummy = false;
			}
		}
		
		@Override
		public void characters(char[] ch, int start, int length) throws SAXException {
			if (!isDummy) {
				super.characters(ch, start, length);
			}
		}
		
	}

	public static void main(String[] args) throws Exception {
//		String path = "C:\\Users\\dev6828503yu\\Documents\\workspace\\temp\\upload\\ipf_xls_importer_jedi-ffph1-shop_kihatar94.xlsx";
//		 String path = "C:\\Users\\dev6828503yu\\Documents\\workspace\\temp\\upload\\0621\\export00002017062117325811.xlsx";
		 String path = "C:\\Users\\dev6828503yu\\Documents\\workspace\\temp\\upload\\0621\\Jedi品質管理_issues_export.xlsx";
//		String sheetName = "Sheet1";
		 String sheetName = "チケット";
//		XLSXCovertCSVReader xlsx2csv = new XLSXCovertCSVReader(path);
//		ExcelInfoBean bean = xlsx2csv.getSheetFirstRowInfos(sheetName, null);
//		List<String[]> rowInfoBeans = bean.getFirstRowCellNames();
//		for (int i = 0; i < rowInfoBeans.size(); i++) {
//			System.out.print(rowInfoBeans.get(i)[0] + ":" + rowInfoBeans.get(i)[1]);
//		}
		XLSXCovertCSVReader xlsx2csv = new XLSXCovertCSVReader(path);
		ExcelInfoBean bean = xlsx2csv.getAllCellInfos(sheetName, true, 0);
		List<RowInfoBean> rowInfoBeans = bean.getRows();
		for (int i = 0; i < rowInfoBeans.size(); i++) {
			RowInfoBean rowInfoBean = rowInfoBeans.get(i);
			List<CellInfoBean> cells = rowInfoBean.getCells();
			for (int j = 0; j < cells.size(); j++) {
				CellInfoBean cell = cells.get(j);
				System.out.print(cell.getContent() + ",");
			}
			System.out.println();
		}
	}

}