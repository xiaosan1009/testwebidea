package co.jp.softbank.qqmx.info;

import java.io.File;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;

public class ControlFileMemory {
	
	private static ControlFileMemory me;
	
	private static final String DEFAULT_PATH = "WEB-INF" + File.separator + "work" + File.separator;
	
	private static final String USER_PROJECT_PATH = "user" + File.separator + "project" + File.separator;
	
	private static String path;
	
	private Map<String, List<String>> userProjectInfo;
	
	private ControlFileMemory() throws SoftbankException {
		super();
		userProjectInfo = Maps.newHashMap();
	}
	
	public static ControlFileMemory getInstance() throws SoftbankException {
		synchronized (ControlRequestMap.class) {
			if (me == null) {
				me = new ControlFileMemory();
			}
		}
		return me;
	}
	
	public static void setPath(String path) {
		ControlFileMemory.path = path + DEFAULT_PATH;
	}
	
	private void readUserProject() {
		
	}

}
