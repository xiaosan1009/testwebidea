package co.jp.softbank.qqmx.info;

import java.util.Date;
import java.util.Map;

import co.jp.softbank.qqmx.dao.common.DbMemoryMonitorDaoService;

import com.google.common.collect.Maps;

/**
 * 見えるか機能のタスク
 * @author King
 *
 */
public class DbMemoryWatchableMonitorTask extends DbMemoryTaskBase {
	
	/**
	 * メモリのデータベースサービス
	 */
	private DbMemoryMonitorDaoService dbMemoryMonitorDaoService;
	
	/**
	 * メモリのデータベースサービスを設定する
	 * @param dbMemoryMonitorDaoService
	 */
	public DbMemoryWatchableMonitorTask(DbMemoryMonitorDaoService dbMemoryMonitorDaoService) {
		this.dbMemoryMonitorDaoService = dbMemoryMonitorDaoService;
	}
	
	@Override
	public void run() {
		try {
			// メモリすべてデータの最後更新日付を取得
			Map<Integer, Date> timestampMap = ControlDbMemory.getInstance().getTimestampWatchableMap();
			//　日付データをループ
			for (Map.Entry<Integer, Date> projectTimestamp : timestampMap.entrySet()) {
				//　プロジェクトのIDを取得
				int projectId = projectTimestamp.getKey();
				//　日付を取得
				Date memoryTimestamp = projectTimestamp.getValue();
				//　日付と現時点を比較
				if ((new Date()).compareTo(memoryTimestamp) < 0) {
					//　現時点より日付遅くの場合
					//　データをリフレッシュする
					ControlDbMemory.getInstance().refreshTicketsForWatchableSync(projectId);
					continue;
				}

				Map<String, Object> conditions = Maps.newHashMap();
				conditions.put("project_id", projectId);
				// プロジェクトの最後更新日付を取得
				Map<String, Object> issueUpdateTimestampMap = dbMemoryMonitorDaoService.getIssueUpdateTimestamp(conditions);
				//　最後の更新日付存在の場合
				if (issueUpdateTimestampMap != null) {
					//　日付を取得
					Date issueUpdateTimestamp = (Date)issueUpdateTimestampMap.get("updated_on");
					log.debug("project_id = {}, issueUpdateTimestamp = {}, memoryTimestamp = {}", projectId, issueUpdateTimestamp, memoryTimestamp);
					//　最後の更新日付とメモリの日付う比較
					if (issueUpdateTimestamp.compareTo(memoryTimestamp) > 0) {
						//　メモリの日付より最後更新日付遅くの場合
						//　データをリフレッシュする
						log.debug("projectId = {}", projectId);
						ControlDbMemory.getInstance().refreshTicketsForWatchableSync(projectId);
						//　親プロジェクトIDを取得
						Integer parentId = dbMemoryMonitorDaoService.getProjectParentId(conditions);
						if (parentId != null) {
							//　親プロジェクト存在の場合
							//　親プロジェクトをリフレッシュする
							log.debug("parentId = {}", parentId);
							ControlDbMemory.getInstance().refreshTicketsForWatchableSync(parentId);
						}
					}
				}
			}
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
	}
}
