package co.jp.softbank.qqmx.dao.issues.bean;

import net.sf.json.JSONObject;
import co.jp.softbank.qqmx.dao.common.bean.DaoBeanInterface;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.util.DateUtils;
import co.jp.softbank.qqmx.util.StringUtils;

public class IssuesPersonBean implements DaoBeanInterface {
	
	private int id;
	
	private int issues_id;
	
	private int project_id;
	
	private int time_entries_id;
	
	private String due_date;
	
	private String start_time;
	
	private String end_time;
	
	private String subject;
	
	private String description;
	
	private String status;
	
	private int activity_id;
	
	private double during;
	
	private int author_id;
	
	private int done_ratio;
	
	private int issues_ratio;
	
	private int year;
	
	private int month;
	
	private int week;
	
	private boolean isUpdate;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public int getIssues_id() {
		return issues_id;
	}

	public void setIssues_id(int issues_id) {
		this.issues_id = issues_id;
	}

	public int getProject_id() {
		return project_id;
	}

	public void setProject_id(int project_id) {
		this.project_id = project_id;
	}

	public int getTime_entries_id() {
		return time_entries_id;
	}

	public void setTime_entries_id(int time_entries_id) {
		this.time_entries_id = time_entries_id;
	}

	public String getDue_date() {
		return due_date;
	}

	public void setDue_date(String due_date) throws SoftbankException {
		this.due_date = due_date;
		String[] dates = due_date.split("-");
		this.year = StringUtils.toInt(dates[0]);
		this.month = StringUtils.toInt(dates[1]);
		this.week = DateUtils.weekOfYear(due_date, DateUtils.FORMAT_YYYYMMDD_DASH);
	}

	public String getStart_time() {
		return start_time;
	}

	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}

	public String getEnd_time() {
		return end_time;
	}

	public void setEnd_time(String end_time) {
		this.end_time = end_time;
	}

	public double getDuring() {
		return during;
	}

	public void setDuring(double during) {
		this.during = during;
	}

	public int getAuthor_id() {
		return author_id;
	}

	public void setAuthor_id(int author_id) {
		this.author_id = author_id;
	}

	public int getDone_ratio() {
		return done_ratio;
	}

	public void setDone_ratio(int done_ratio) {
		this.done_ratio = done_ratio;
	}

	public String getSubject() {
		return subject;
	}

	public void setSubject(String subject) {
		this.subject = subject;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getStatus() {
		return status;
	}

	public void setStatus(String status) {
		this.status = status;
	}

	public int getActivity_id() {
		return activity_id;
	}

	public void setActivity_id(int activity_id) {
		this.activity_id = activity_id;
	}

	public int getIssues_ratio() {
		return issues_ratio;
	}

	public void setIssues_ratio(int issues_ratio) {
		this.issues_ratio = issues_ratio;
	}

	public int getYear() {
		return year;
	}

	public void setYear(int year) {
		this.year = year;
	}

	public int getMonth() {
		return month;
	}

	public void setMonth(int month) {
		this.month = month;
	}

	public int getWeek() {
		return week;
	}

	public void setWeek(int week) {
		this.week = week;
	}

	public boolean isUpdate() {
		return isUpdate;
	}

	public void setUpdate(boolean isUpdate) {
		this.isUpdate = isUpdate;
	}

	@Override
	public void toJson(JSONObject dataObj) {
		dataObj.put("id", this.id);
		dataObj.put("issues_id", this.issues_id);
		dataObj.put("due_date", this.due_date);
		dataObj.put("start_time", this.start_time);
		dataObj.put("end_time", this.end_time);
		dataObj.put("during", this.during);
		dataObj.put("author_id", this.author_id);
		dataObj.put("done_ratio", this.done_ratio);
		dataObj.put("subject", this.subject);
		dataObj.put("description", this.description);
		dataObj.put("status", this.status);
		dataObj.put("issues_ratio", this.issues_ratio);
	}

}
