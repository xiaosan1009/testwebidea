package co.jp.softbank.qqmx.info;

import java.util.Map;

import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.face.IExcelWriter;
import co.jp.softbank.qqmx.info.face.IExcelWriter.CreateFileName;

public class ExcelWriterFactory {
	
	public static IExcelWriter getWriter(HttpContext context) throws SoftbankException {
		return new ExcelWriter(context);
		
	}
	
	public static IExcelWriter getWriterX(HttpContext context) throws SoftbankException {
		return new ExcelWriterX(context);
	}
	
	public static IExcelWriter getWriterX(HttpContext context, CreateFileName createFileName) throws SoftbankException {
		return new ExcelWriterX(context, createFileName);
	}
	
	public static IExcelWriter getWriterX(HttpContext context, Map<String, Object> templateMap, CreateFileName createFileName) throws SoftbankException {
		return new ExcelWriterX(context, templateMap, createFileName);
	}
	
}
