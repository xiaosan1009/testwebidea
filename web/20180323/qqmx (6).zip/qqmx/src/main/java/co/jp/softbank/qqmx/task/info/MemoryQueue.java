package co.jp.softbank.qqmx.task.info;

import java.io.IOException;

import com.google.common.io.Closer;

public class MemoryQueue<E> extends BaseQueue<E> {
	
	private transient Closer closer;
	
	public MemoryQueue() {
		this.closer = Closer.create();
	}

	@Override
	protected void doClose() throws IOException {
		closer.close();
	}

}
