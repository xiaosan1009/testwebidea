package co.jp.softbank.qqmx.dao.project.settings;

import java.util.List;
import java.util.Map;

public interface ProjectAccountSingleInsertDao {
	
}
