package co.jp.softbank.qqmx.logic.application.mit;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.util.StringUtils;

public class MitDashboardLogic extends AbstractBaseLogic {
	
	public void getDashboardInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String statusId = context.getParam().get("statusId");
		conditions.put("status_Id", Integer.valueOf(statusId));
		if(isSosiki()){
			conditions.put("project_id", 1464);
			String organization_cd = "";
			organization_cd = context.getParam().get("organizationCd");
			conditions.put("organization_cd", organization_cd);
			context.getResultBean().setData(db.querys("mitDashboard.getMitTotalProjectListInfo", conditions));
		} else {
		
			String project_id = context.getParam().get("projectId");
			conditions.put("project_id", Integer.parseInt(project_id));
			String versionId = context.getParam().get("versionId") ;
			if(StringUtils.isNotEmpty(versionId)){
				conditions.put("versionId", Integer.parseInt(versionId));
			}
			context.getResultBean().setData(db.querys("mitDashboard.getMitProjectListInfo", conditions));
		}
	}
	
	public void getIssuesInfo() throws SoftbankException {
	
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, Object> conditions = Maps.newHashMap();
		String statusId = context.getParam().get("statusId");
		conditions.put("status_Id", Integer.valueOf(statusId));
		if(isSosiki()){
			
			String sosiki_cd = context.getParam().get("organizationCd");
			conditions.put("organization_cd", sosiki_cd);
			
			conditions.put("project_id", 1464);
			List<Map<String, Object>> project = db.querys("dashboard.getProject", conditions);
		
			
			resultMap.put("project", project);
			List<Map<String, Object>> lstInfo = db.querys("mitDashboard.getTicketInfor", conditions);
			
			resultMap.put("lstInfo", lstInfo);
			List<Map<String, Object>> bugsInfo = db.querys("mitDashboard.getBugsInfor", conditions) ;
			resultMap.put("bugsInfo", bugsInfo);
			List<Map<String, Object>> sum = db.querys("mitDashboard.getMitTotalProjectListInfo", conditions);
			
			resultMap.put("sum", sum);
			context.getResultBean().setData(resultMap);
		}else{
			String project_id = context.getParam().get("projectId");
			conditions.put("project_id", Integer.parseInt(project_id));
			String versionId = context.getParam().get("versionId") ;
			if(StringUtils.isNotEmpty(versionId)){
				conditions.put("versionId", Integer.parseInt(versionId));
			}
			List<Map<String, Object>> project = db.querys("dashboard.getProject", conditions);
		
			
			resultMap.put("project", project);
			List<Map<String, Object>> lstInfo = db.querys("mitDashboard.getEachTicketInfor", conditions);
			
			resultMap.put("lstInfo", lstInfo);
			List<Map<String, Object>> bugsInfo = db.querys("mitDashboard.getEachBugsInfor", conditions) ;
			resultMap.put("bugsInfo", bugsInfo);
			List<Map<String, Object>> sum = db.querys("mitDashboard.getMitProjectListInfo", conditions);
			
			resultMap.put("sum", sum);
			context.getResultBean().setData(resultMap);
		}
		
	}
	public void getTopicCommentRole() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		Integer projectId = context.getParam().projectId;
		int loginUserId = ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId();
		conditions.put("project_id", projectId);
		conditions.put("user_id", loginUserId);
		
//		conditions.put("project_id", 60);
//		conditions.put("user_id", 10606);
		
		context.getResultBean().setData(db.querys("mitDashboard.getTopicCommentRole", conditions));
	}
	public void getTopicCommentInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String versionId = context.getParam().get("versionId") ;
		if(StringUtils.isNotEmpty(versionId)){
			conditions.put("versionId", (versionId));
		} else{
			conditions.put("versionId", "");
		}
		String sosiki_cd = context.getParam().get("organizationCd");
		if(StringUtils.isNotEmpty(sosiki_cd)){
			conditions.put("organizationCd", sosiki_cd);
		} else {
			conditions.put("organizationCd", "0");
		}
		String project_id = context.getParam().get("projectId");
		if(StringUtils.isNotEmpty(project_id)){
			conditions.put("project_id", Integer.parseInt(project_id));
		} else {
			conditions.put("project_id", 0);
		}
		context.getResultBean().setData(db.querys("mitDashboard.getTopicCommentInfo", conditions));
	}
	public void getTopicCommentValueInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String versionId = context.getParam().get("versionId") ;
		if(StringUtils.isNotEmpty(versionId)){
			conditions.put("versionId", versionId);
		} else{
			conditions.put("versionId", "");
		}
		
		String sosiki_cd = context.getParam().get("organizationCd");
		if(StringUtils.isNotEmpty(sosiki_cd)){
			conditions.put("organizationCd", sosiki_cd);
		} else {
			conditions.put("organizationCd", "0");
		}
	
		String project_id = context.getParam().get("projectId");
		if(StringUtils.isNotEmpty(project_id)){
			conditions.put("project_id", Integer.parseInt(project_id));
		} else {
			conditions.put("project_id", 0);
		}
		
		String shoriTime = context.getParam().get("shoriTime");
		conditions.put("shori_time", shoriTime.replaceAll("/", "-"));
		context.getResultBean().setData(db.querys("mitDashboard.getTopicCommentValueInfo", conditions));
	}
	public void insertTopicComment() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String shoriTime = context.getParam().get("shoriTime");
		String versionId = context.getParam().get("versionId") ;
		
		if(StringUtils.isNotEmpty(versionId)){
			conditions.put("versionId", versionId);
		} else{
			conditions.put("versionId", "");
		}
		String comment = context.getParam().get("commentData");
		
		String sosiki_cd = context.getParam().get("organizationCd");
		if(StringUtils.isNotEmpty(sosiki_cd)){
			conditions.put("organizationCd", sosiki_cd);
		} else {
			conditions.put("organizationCd", "0");
		}
	
		String project_id = context.getParam().get("projectId");
		if(StringUtils.isNotEmpty(project_id)){
			conditions.put("project_id", Integer.parseInt(project_id));
		} else {
			conditions.put("project_id", 0);
		}

		conditions.put("shori_time", shoriTime.replaceAll("/", "-"));
		conditions.put("comment", comment);
		context.getResultBean().setData(db.insert("mitDashboard.insertTopicComment", conditions));
	}
	private boolean isSosiki(){
		String sosiki_cd = context.getParam().get("organizationCd");
		return StringUtils.isEmpty(sosiki_cd) ? false : true ;
	}
	
}
