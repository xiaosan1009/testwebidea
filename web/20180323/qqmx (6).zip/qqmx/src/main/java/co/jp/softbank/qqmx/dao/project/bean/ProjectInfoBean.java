package co.jp.softbank.qqmx.dao.project.bean;

import java.util.Date;

import net.sf.json.JSONObject;

import co.jp.softbank.qqmx.dao.common.bean.DaoBeanInterface;

public class ProjectInfoBean implements DaoBeanInterface {
	
	public static final String PROJECT_INFO_KEY = "PROJECT_INFO_KEY";

	private int id;
	
	private String name;
	
	private String description;
	
	private String homepage;
	
	private boolean is_public;
	
	private int parent_id;
	
	private Date created_on;
	
	private Date updated_on;
	
	private String identifier;
	
	private int status;
	
	private int lft;
	
	private int rgt;
	
	private String landing_page;

	public int getId() {
		return id;
	}

	public void setId(int id) {
		this.id = id;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getHomepage() {
		return homepage;
	}

	public void setHomepage(String homepage) {
		this.homepage = homepage;
	}

	public boolean isIs_public() {
		return is_public;
	}

	public void setIs_public(boolean is_public) {
		this.is_public = is_public;
	}

	public int getParent_id() {
		return parent_id;
	}

	public void setParent_id(int parent_id) {
		this.parent_id = parent_id;
	}

	public Date getCreated_on() {
		return created_on;
	}

	public void setCreated_on(Date created_on) {
		this.created_on = created_on;
	}

	public Date getUpdated_on() {
		return updated_on;
	}

	public void setUpdated_on(Date updated_on) {
		this.updated_on = updated_on;
	}

	public String getIdentifier() {
		return identifier;
	}

	public void setIdentifier(String identifier) {
		this.identifier = identifier;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public int getLft() {
		return lft;
	}

	public void setLft(int lft) {
		this.lft = lft;
	}

	public int getRgt() {
		return rgt;
	}

	public void setRgt(int rgt) {
		this.rgt = rgt;
	}

	public String getLanding_page() {
		return landing_page;
	}

	public void setLanding_page(String landing_page) {
		this.landing_page = landing_page;
	}

	@Override
	public void toJson(JSONObject dataObj) {
		dataObj.put("id", this.id);
		dataObj.put("name", this.name);
		dataObj.put("description", this.description);
		dataObj.put("homepage", this.homepage);
		dataObj.put("is_public", this.is_public);
		dataObj.put("parent_id", this.parent_id);
		dataObj.put("created_on", this.created_on);
		dataObj.put("updated_on", this.updated_on);
		dataObj.put("identifier", this.identifier);
		dataObj.put("status", this.status);
		dataObj.put("lft", this.lft);
		dataObj.put("rgt", this.rgt);
		dataObj.put("landing_page", this.landing_page);
	}
	
}
