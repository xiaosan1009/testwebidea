
package co.jp.softbank.qqmx.sockect.bean;

import net.sf.json.JSONObject;

import org.apache.commons.collections4.MapUtils;
import org.springframework.web.socket.WebSocketSession;

import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.util.DateUtils;

public class WebSocketClientInfo {
    
    private static final String KEY_USER_ID = "userId";

    private WebSocketSession session;
    
    private int userId;
    
    private String company;
    
    private String sessionId;
    
    private String dateTime;
    
    private String time;
    
    private UserInfoData userInfoData;
    
    public WebSocketClientInfo(WebSocketSession session) {
        this.session = session;
        this.sessionId = session.getId();
        this.userInfoData = (UserInfoData)MapUtils.getObject(session.getHandshakeAttributes(), UserInfoData.USER_INFO_KEY);
        this.userId = this.userInfoData.getId();
        this.dateTime = DateUtils.getNowTime(DateUtils.FORMAT_YYYYMMDDHHSS2);
        this.time = DateUtils.getNowTime(DateUtils.FORMAT_HH_MM_SS);
    }

    public WebSocketSession getSession() {
        return session;
    }

    public void setSession(WebSocketSession session) {
        this.session = session;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public String getSessionId() {
        return sessionId;
    }

    public void setSessionId(String sessionId) {
        this.sessionId = sessionId;
    }

    public String getDateTime() {
        return dateTime;
    }

    public void setDateTime(String dateTime) {
        this.dateTime = dateTime;
    }

    public String toJsonStr() {
        return toJsonObj().toString();
    }

    public String getTime() {
        return time;
    }

    public void setTime(String time) {
        this.time = time;
    }

    public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public UserInfoData getUserInfoData() {
		return userInfoData;
	}

	public void setUserInfoData(UserInfoData userInfoData) {
		this.userInfoData = userInfoData;
	}

	public JSONObject toJsonObj() {
        JSONObject jsonObject = new JSONObject();
        jsonObject.put("userId", this.userId);
        jsonObject.put("sessionId", this.sessionId);
        jsonObject.put("dateTime", this.dateTime);
        jsonObject.put("time", this.time);
        return jsonObject;
    }

}
