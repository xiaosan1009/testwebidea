package co.jp.softbank.qqmx.util.tag;

import java.io.IOException;

import javax.servlet.jsp.JspException;

import net.sf.json.JSONObject;
import co.jp.softbank.qqmx.logic.bean.LogicBean;


public class JsonHeaderTag extends BodyTagSupportBase {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	
	private StringBuilder outerPrint;
	
	@Override
	public int doStartTag() throws JspException {
		log.info("--------------- start -----------------");
		outerPrint = new StringBuilder();
		final LogicBean logicBean = (LogicBean)pageContext.getRequest().getAttribute(LogicBean.RESPONSE_DATA);
		if (logicBean != null) {
			outerPrint.append(analysisLogicBean(logicBean).toString());
		}
		log.info("--------------- end -----------------");
		return SKIP_BODY;
	}
	
	@Override
	public int doEndTag() throws JspException {
		try {
			pageContext.getOut().print(outerPrint.toString());
		} catch (IOException e) {
			e.printStackTrace();
		}
		return EVAL_PAGE;
	}
	
	private JSONObject analysisLogicBean(LogicBean logicBean) {
		JSONObject result = new JSONObject();
		result.put("flg", logicBean.isResultFlg());
		result.put("ignore", logicBean.isIgnore());
		result.put("resultCode", logicBean.getResultCode());
		result.put("resultMsg", logicBean.getResultMsg());
		result.put("showPanel", logicBean.isShowPanel());
		return result;
	}

}
