package co.jp.softbank.qqmx.logic.application.test;

import javax.annotation.Resource;

import org.springframework.context.annotation.Scope;
import org.springframework.stereotype.Service;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;

public class CommonTestLogic extends AbstractBaseLogic {
	
	public void getAttachmentFiles() throws SoftbankException {
		context.getResultBean().setData(db.querys("attachments.selectAllAttachments"));
	}

}
