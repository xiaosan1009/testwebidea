package co.jp.softbank.qqmx.logic.application.tables;

import java.util.Date;
import java.util.Map;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Maps;

public class TVersionManagementsLogic extends AbstractBaseLogic {
	
	public void selectVersionManagements() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		context.getResultBean().setData(db.querys("version_managements.selectVersionManagements", conditions));
	}
	
	public void addVersionManagementInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("name", context.getParam().get("version_name"));
		conditions.put("ver_inser_date", new Date());
		if ("1".equals(context.getParam().get("mast_schdule"))) {
			conditions.put("confirmer_flag", true);
		} else {
			conditions.put("confirmer_flag", false);
		}
		db.insert("version_managements.addVersionManagementInfo", conditions);
	}
	
	public void updateVersionManagementInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("version_id", StringUtils.toInt(context.getParam().get("version_id")));
		conditions.put("name", context.getParam().get("version_name"));
		if ("1".equals(context.getParam().get("mast_schdule"))) {
			conditions.put("confirmer_flag", true);
		} else {
			conditions.put("confirmer_flag", false);
		}
		db.update("version_managements.updateVersionManagementInfo", conditions);
	}
	
	public void deleteVersionManagementInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("version_id", StringUtils.toInt(context.getParam().get("version_id")));
		db.insert("version_managements.deleteVersionManagementInfo", conditions);
	}
}
