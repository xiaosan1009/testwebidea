package co.jp.softbank.qqmx.dao.project.settings;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.dao.IDaoInterface;

public interface NewRoleDao extends IDaoInterface {
	List<Map<String, Object>> getRolesBaseList();
	List<Map<String, Object>> getRolesBaseSubList(Map<String, Object> conditions);
	List<Map<String, Object>> getRolesCheckFlg(Map<String, Object> conditions);
	List<Map<String, Object>> getRoleIdInfo(Map<String, Object> conditions);
	List<Map<String, Object>> selectRolePermissionList(Map<String, Object> conditions);
	List<Map<String, Object>> getRoleList();
	List<Map<String, Object>> selectTrackers();
	void saveRole(Map<String, Object> conditions);
	void updateRole(Map<String, Object> conditions);
	void deleteWorkflows(Map<String, Object> conditions);
	void inserWorkflows(Map<String, Object> conditions);
}
