package co.jp.softbank.qqmx.logic.application.project;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.HttpURLConnection;
import java.net.URL;
import java.security.DigestInputStream;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import org.apache.commons.fileupload.FileItem;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.UploadFileInfo;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.StringUtils;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.google.common.collect.Maps;

public class FileLogic extends AbstractBaseLogic {

	public void getFileListInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("container_id", context.getParam().projectId);
		conditions.put("container_type", "Project");
		List<Map<String, Object>> attachments = db.querys("attachments.selectAttachments", conditions);
		
		String requestUrl = context.getRequest().getRequestURL().toString();
		requestUrl = requestUrl.substring(0, requestUrl.lastIndexOf("/") + 1);
		
		for (int i = 0; i < attachments.size(); i++) {
			Map<String, Object> attachment = attachments.get(i);
			String disk_filename = StringUtils.toString(attachment.get("disk_filename"));
			disk_filename = requestUrl + "upload/" + disk_filename;
			attachment.put("disk_filename", disk_filename);
		}
		context.getResultBean().setData(attachments);
	}
	
	public void getFileVersionListInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", context.getParam().projectId);
		List<Map<String, Object>> attachments = db.querys("attachments.getFileVersionListInfo", conditions);
		context.getResultBean().setData(attachments);
	}
	
	public void deleteFileInfo() throws SoftbankException {
		int file_id = Integer.parseInt(context.getParam().get("file_id"));
		
		// realファイルを削除
		deleteAttachmentFile(file_id, context.getParam().get("disk_filename"));		
		
	}
	
	public void downloadFileInfo() throws SoftbankException {
		
		Map<String, Object> conditions = Maps.newHashMap();
		String file_id = context.getParam().get("file_id");
		conditions.put("id", Integer.parseInt(file_id));
		context.getResultBean().setData(db.delete("attachments.updateFileInfo" , conditions));
	}
	
	public void saveFileListInfo() throws SoftbankException, FileNotFoundException, IOException, NoSuchAlgorithmException {
		String version_id = context.getParam().get("version_id");
		int upload_id;
		String container_type;
		
		if ("".equals(version_id) || version_id == null){
			upload_id = StringUtils.toInt(context.getParam().projectId);
			container_type = "Project";
		}else{
			upload_id = Integer.parseInt(version_id);
			container_type = "Version";
		}
		
		// 添付ファイル
		String upload_datas = context.getParam().get("upload_datas");
		
		if (StringUtils.isNotEmpty(upload_datas)) {
			JSONArray importFile = JSONArray.fromObject(upload_datas);

			for (int i = 0; i < importFile.size(); i++) {
				JSONObject fileData = importFile.getJSONObject(i);
				
				String description = ConstantsUtil.Str.EMPTY;
				if (fileData.containsKey("description")) {
					description = fileData.getString("description");
				}
				
				Map<String, Object> dataMap = Maps.newHashMap();
				
				dataMap.put("id", upload_id);
				dataMap.put("attachments_id", fileData.getInt("id"));
				dataMap.put("description", description);
				dataMap.put("container_type", container_type);

				// 既存ファイルを削除場合
				if (fileData.containsKey("delete")) {
					dataMap.put("id", fileData.getInt("id"));
					db.update("attachments.deleteFileInfo", dataMap);
				} else {
					db.update("attachments.updateAttachmentsByIdAfterInsert", dataMap);
				}
			}
		}		
		
	}
}
