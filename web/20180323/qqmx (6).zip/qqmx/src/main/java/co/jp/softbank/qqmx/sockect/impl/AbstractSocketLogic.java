
package co.jp.softbank.qqmx.sockect.impl;

import net.sf.json.JSONObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import co.jp.softbank.qqmx.dao.common.IDbExecute;
import co.jp.softbank.qqmx.message.IMessageAccessor;
import co.jp.softbank.qqmx.validator.IBeanValidator;

public class AbstractSocketLogic {
	
	protected final Logger log = LoggerFactory.getLogger(getClass());
	
	protected IBeanValidator validator;
	
	protected IMessageAccessor messageAccessor;
	
	protected IDbExecute db;
	
	public interface SocketMessageType {
		String ARTSON_S = "string";
		String USER_MESSAGE = "userMessage";
		String GANTT_SHOW = "GANTT_SHOW";
		String GANTT_OPERATOR = "GANTT_OPERATOR";
		String ISSUES_DATA_REFRESH = "ISSUES_DATA_REFRESH";
		String USER_CLOSED = "USER_CLOSED";
		String USER_CONNECT = "USER_CONNECT";
	}

	public String getResultData(String type, Object data) {
        JSONObject result = new JSONObject();
        result.put("type", type);
        result.put("data", data);
        return result.toString();
    }
    
    public void setValidator(IBeanValidator validator) {
		this.validator = validator;
	}

	public void setMessageAccessor(IMessageAccessor messageAccessor) {
		this.messageAccessor = messageAccessor;
	}
	
	public void setDb(IDbExecute db) {
		this.db = db;
	}

}
