package co.jp.softbank.qqmx.logic.application.project;

import java.math.BigDecimal;
import java.util.Arrays;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.BacklogRefreshMemory;
import co.jp.softbank.qqmx.info.ControlDbMemory;
import co.jp.softbank.qqmx.info.bean.BacklogRefreshDataBean;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.info.bean.BacklogRefreshDataBean.BacklogRefreshDataType;
import co.jp.softbank.qqmx.logic.application.face.IssueKey;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.DateUtils;
import co.jp.softbank.qqmx.util.StringUtils;
import co.jp.softbank.qqmx.util.bean.DaysBetweenInfo;
import net.sf.json.JSONArray;
import net.sf.json.JSONNull;
import net.sf.json.JSONObject;

public class BacklogLogic extends TicketBaseLogic {
	
	@SuppressWarnings("unchecked")
	public void getStoryInfos() throws SoftbankException {
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, Object> backlogSett = db.query("backlog_settings.selectSettingInfosForProject");
		String settValue = StringUtils.toString(backlogSett.get("story_trackers"));
		String points = StringUtils.toString(backlogSett.get("story_points"));
		String[] story_trackers = settValue.split(ConstantsUtil.Str.COMMA);
		String[] story_points = points.split(ConstantsUtil.Str.COMMA);
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("story_trackers", story_trackers);
		List<Map<String, Object>> backlogs = db.querys("backlogs.selectBacklogInfosForProject", conditions);
		
		List<Map<String, Object>> sprints = db.querys("versions.selectVersionInfosForProject");
		
		List<Map<String, Object>> releases = db.querys("releases.selectReleasesInfosForProject");
		
		resultMap.put("backlogs", backlogs);
		resultMap.put("sprints", sprints);
		resultMap.put("releases", releases);
		
		Map<String, Object> backlogSettings = Maps.newHashMap();
		List<Map<String, Object>> storyTrackers = db.querys("trackers.selectTrackersInfoForCmb", conditions);
		backlogSettings.put("story_trackers", storyTrackers);
		backlogSettings.put("story_points", story_points);
		backlogSettings.put("members", db.querys("users.getBacklogMembersForCmb"));
		backlogSettings.put("backlogSett", backlogSett);
		backlogSettings.put("issue_statuses", getIssueStatuses(conditions));
		backlogSettings.put("phases", db.querys("phases.getPhasesForCmb"));
		backlogSettings.put("testphase", db.querys("test_phases.getTestPhasesForCmb"));
		backlogSettings.put("target_systems", db.querys("target_systems.getTargetSystemsForCmb"));
		String displayTrackers = StringUtils.toString(backlogSett.get("display_trackers"));
		if (StringUtils.isNotEmpty(displayTrackers)) {
			String[] display_trackers = displayTrackers.split(ConstantsUtil.Str.COMMA);
			List<String> trackerList = Lists.newArrayList(story_trackers);
			trackerList.addAll(Arrays.asList(display_trackers));
			conditions.put("story_trackers", trackerList);
		}
		backlogSettings.put("customFields", db.querys("issues.getCustomFieldsForBacklog", conditions));
		backlogSettings.put("token", BacklogRefreshMemory.getInstance().getLastKey(context.getParam().projectId));
		
		createRoleMap(backlogSettings);
		
		resultMap.put("backlogSettings", backlogSettings);
		
		context.getResultBean().setData(resultMap);
	}

	public void loadSprintInfos() throws SoftbankException {
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, Object> backlogSett = db.query("backlog_settings.selectSettingInfosForProject");
		String settValue = StringUtils.toString(backlogSett.get("story_trackers"));
		String[] story_trackers = settValue.split(ConstantsUtil.Str.COMMA);
		int task_tracker = StringUtils.toInt(backlogSett.get("task_tracker"));
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("sprint_id", context.getParam().get("sprint_id"));
		conditions.put("story_trackers", story_trackers);
		List<Map<String, Object>> storys = db.querys("backlogs.selectStoryInfosForSprint", conditions);
		conditions.put("storys", storys);
		conditions.put("tracker_id", task_tracker);
		
		List<Map<String, Object>> tasks = Lists.newArrayList();
		Map<Integer, List<Map<String, Object>>> issueStatusMap = Maps.newHashMap();
		
		String displayTrackers = StringUtils.toString(backlogSett.get("display_trackers"));
		if (StringUtils.isNotEmpty(displayTrackers)) {
			String[] display_trackers = displayTrackers.split(ConstantsUtil.Str.COMMA);
			for (int i = 0; i < display_trackers.length; i++) {
				int tid = StringUtils.toInt(display_trackers[i]);
				if (issueStatusMap.containsKey(tid)) {
					continue;
				}
				conditions.put("tracker_id", tid);
				List<Map<String, Object>> issueStatuses = db.querys("issue_statuses.getIssueStatusesInfosByTracker", conditions);
				issueStatusMap.put(tid, issueStatuses);
			}
			conditions.put("story_trackers", display_trackers);
			List<Map<String, Object>> displayTrackerInfos = db.querys("trackers.selectTrackersInfoForCmb", conditions);
			resultMap.put("displayTrackerInfos", displayTrackerInfos);
			
			if (storys != null && storys.size() > 0) {
				tasks = db.querys("backlogs.selectTaskInfosForSprint", conditions);
//				if (tasks != null && tasks.size() > 0) {
//					conditions.put("tasks", tasks);
//					List<Map<String, Object>> blocks = db.querys("backlogs.selectBlockTaskInfosForSprint", conditions);
//					if (tasks != null && tasks.size() > 0) {
//						tasks.addAll(blocks);
//					}
//				}
			}
//			List<Map<String, Object>> trackerTasks = db.querys("backlogs.selectTaskInfosForTrackers", conditions);
//			tasks.addAll(trackerTasks);
			resultMap.put("customFields", db.querys("issues.getCustomFieldsForBacklog", conditions));
		}
		resultMap.put("kanban_statuses", issueStatusMap);
		resultMap.put("backlogSett", backlogSett);
		resultMap.put("storys", storys);
		resultMap.put("tasks", tasks);
		
		context.getResultBean().setData(resultMap);
	}
	
	public void stroyUpdate() throws SoftbankException {
		String changeData = context.getParam().get("update");
		if (StringUtils.isEmpty(changeData)) {
			return;
		}
		JSONObject dataJson = JSONObject.fromObject(changeData);
		JSONObject properties = dataJson.getJSONObject("p");
		if (dataJson.containsKey("pd")) {
			JSONArray positions = dataJson.getJSONArray("pd");
			updatePositionData(positions);
		}
		if (!properties.isEmpty()) {
			Map<String, Object> storyData = createIssueMap(properties);
			storyData.put(IssueKey.ESTIMATED_HOURS.KEY, ConstantsUtil.Sql.NUMBER_NOT_CHANGED);
			storyData.put(IssueKey.REMAINING_HOURS.KEY, ConstantsUtil.Sql.NUMBER_NOT_CHANGED);
			updateTicket(storyData);
			db.update("backlogs.updateTaskSprintSameByStory", storyData);
		}
	}
	
	public void taskUpdate() throws SoftbankException {
		String changeData = context.getParam().get("update");
		if (StringUtils.isEmpty(changeData)) {
			return;
		}
		Map<String, Object> resultMap = Maps.newHashMap();
		JSONObject dataJson = JSONObject.fromObject(changeData);
		JSONObject properties = dataJson.getJSONObject("p");
		if (dataJson.containsKey("pd")) {
			JSONArray positions = dataJson.getJSONArray("pd");
			updatePositionData(positions);
		}
		if (!properties.isEmpty()) {
			Map<String, Object> data = createIssueMap(properties);
			updateTicket(data);
			String block_id = StringUtils.toString(data.get("block_id"));
			String relation_id = StringUtils.toString(data.get("relation_id"));
			if (StringUtils.isNotEmpty(relation_id)) {
				Map<String, Object> conditions = Maps.newHashMap();
				conditions.put("relation_id", StringUtils.toInt(relation_id));
				db.delete("issue_relations.deleteRelationData", conditions);
			}
			if (StringUtils.isNotEmpty(block_id)) {
				Map<String, Object> conditions = Maps.newHashMap();
				conditions.put("issue_from_id", StringUtils.toInt(data.get("id")));
				conditions.put("issue_to_id", StringUtils.toInt(block_id));
				conditions.put("relation_type", "1");
				conditions.put("check", false);
				db.insert("issue_relations.insertLinkData", conditions);
				relation_id = StringUtils.toString(conditions.get("id"));
				resultMap.put("relation_id", relation_id);
			}
			BacklogRefreshDataBean bean = new BacklogRefreshDataBean(BacklogRefreshDataType.taskChange);
			bean.setTaskInfo(data);
			BacklogRefreshMemory.getInstance().addData(context.getParam().projectId, bean);
		}
		context.getResultBean().setData(resultMap);
	}

	public void addSprintInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("sprint_name", context.getParam().get("sprint_name"));
		conditions.put("effective_date", context.getParam().get("effective_date"));
		conditions.put("sprint_start_date", context.getParam().get("sprint_start_date"));
		db.insert("versions.addVersionInfo", conditions);
		context.getResultBean().setData(conditions.get("id"));
	}
	
	public void addReleaseInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("name", context.getParam().get("release_name"));
		conditions.put("release_start_date", context.getParam().get("release_start_date"));
		conditions.put("release_end_date", context.getParam().get("release_end_date"));
		conditions.put("status", context.getParam().get("release_status"));
		conditions.put("planned_velocity", context.getParam().get("release_planned_velocity"));
		conditions.put("sharing", context.getParam().get("release_sharing"));
		conditions.put("description", context.getParam().get("description"));
		db.insert("releases.addReleaseInfo", conditions);
		context.getResultBean().setData(conditions.get("id"));
	}
	
	public void updateReleaseInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("id", context.getParam().get("id"));
		conditions.put("name", context.getParam().get("release_name"));
		conditions.put("release_start_date", context.getParam().get("release_start_date"));
		conditions.put("release_end_date", context.getParam().get("release_end_date"));
		conditions.put("status", context.getParam().get("release_status"));
		conditions.put("planned_velocity", context.getParam().get("release_planned_velocity"));
		conditions.put("sharing", context.getParam().get("release_sharing"));
		conditions.put("description", context.getParam().get("description"));
		db.update("releases.updateReleaseInfo", conditions);
	}
	
	public void addStoryInfo() throws SoftbankException {
		String insertData = context.getParam().get("insert");
		if (StringUtils.isEmpty(insertData)) {
			return;
		}
		JSONObject dataJson = JSONObject.fromObject(insertData);
		int maxPosition = dataJson.getInt("pd");
		JSONObject properties = dataJson.getJSONObject("p");
		int maxRootSeq = db.queryo("issues.selectMaxRootSeqByProjectId");
		int priority_id = db.queryo("enumerations.selectDefaultIssuePriority");
		Map<String, Object> conditions = createIssueMap(properties);
		conditions.put(IssueKey.PRIORITY_ID.KEY, priority_id);
		conditions.put(IssueKey.ROOT_SEQ.KEY, (maxRootSeq + 1));
		db.insert("backlogs.addStoryInfo", conditions);
		addCustomFieldValues(conditions);
		Map<String, Object> resultMap = Maps.newHashMap();
		resultMap.put("issue_id", conditions.get("id"));
		resultMap.put("position", (maxPosition + 1));
		
		afterInsertTicket(conditions);
		
		db.insert("backlog_position.insertBacklogPositionInfo", resultMap);
		context.getResultBean().setData(resultMap);
	}
	
	public void addTaskInfo() throws SoftbankException {
		String insertData = context.getParam().get("insert");
		if (StringUtils.isEmpty(insertData)) {
			return;
		}
		Map<String, Object> resultMap = Maps.newHashMap();
		JSONObject dataJson = JSONObject.fromObject(insertData);
		int maxPosition = dataJson.getInt("pd");
		JSONObject properties = dataJson.getJSONObject("p");
		Map<String, Object> data = createIssueMap(properties);
		int priority_id = db.queryo("enumerations.selectDefaultIssuePriority");
		data.put(IssueKey.PRIORITY_ID.KEY, priority_id);
		db.insert("backlogs.addTaskInfo", data);
		addCustomFieldValues(data);
		afterInsertTicket(data);
		String block_id = StringUtils.toString(data.get("block_id"));
		if (StringUtils.isNotEmpty(block_id)) {
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("issue_from_id", StringUtils.toInt(data.get("id")));
			conditions.put("issue_to_id", StringUtils.toInt(block_id));
			conditions.put("relation_type", "1");
			conditions.put("check", false);
			db.insert("issue_relations.insertLinkData", conditions);
			resultMap.put("relation_id", conditions.get("id"));
		}
		resultMap.put("issue_id", data.get("id"));
		resultMap.put("position", (maxPosition + 1));
		
		db.insert("backlog_position.insertBacklogPositionInfo", resultMap);
		context.getResultBean().setData(resultMap);
	}
	
	public void makeReleaseToSprint() throws SoftbankException {
		int release_id = context.getParam().getInt("release_id");
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("release_id", release_id);
		db.delete("releases.deleteReleaseInfoById", conditions);
		
		conditions.put("sprint_name", context.getParam().get("sprint_name"));
		conditions.put("effective_date", context.getParam().get("effective_date"));
		conditions.put("sprint_start_date", context.getParam().get("sprint_start_date"));
		db.insert("versions.addVersionInfo", conditions);
		context.getResultBean().setData(conditions.get("id"));
		
		db.update("releases.changeReleaseToSprint", conditions);
	}
	
	public void getCustomValuesForStory() throws SoftbankException {
		int storyId = context.getParam().getInt("story_id");
		String customs = context.getParam().get("customs");
		if (StringUtils.isEmpty(customs)) {
			return;
		}
		JSONArray customsJson = JSONArray.fromObject(customs);
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("story_id", storyId);
		conditions.put("customFieldIds", customsJson);
		
		context.getResultBean().setData(db.querys("backlogs.getCustomValuesForStory", conditions));
	}
	
	public LogicBean checkBlockIdAtAdd() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		String insertData = context.getParam().get("insert");
		if (StringUtils.isEmpty(insertData)) {
			return logicBean;
		}
		JSONObject dataJson = JSONObject.fromObject(insertData);
		return checkBlock(logicBean, dataJson);
	}
	
	public LogicBean checkBlockIdAtUpdate() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		String updateData = context.getParam().get("update");
		if (StringUtils.isEmpty(updateData)) {
			return logicBean;
		}
		JSONObject dataJson = JSONObject.fromObject(updateData);
		return checkBlock(logicBean, dataJson);
	}
	
	public LogicBean checkStatusAtUpdate() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		String updateData = context.getParam().get("update");
		if (StringUtils.isEmpty(updateData)) {
			return logicBean;
		}
		JSONObject dataJson = JSONObject.fromObject(updateData);
		JSONObject properties = dataJson.getJSONObject("p");
		Map<String, Object> data = createIssueMap(properties);
		
		int oldStatusId = db.queryo("issues.selectStatusByIssueId", data);
		int newStatusId = StringUtils.toInt(data.get("status_id"));
		if (oldStatusId != newStatusId) {
			Map<String, Object> backlogSett = db.query("backlog_settings.selectSettingInfosForProject");
			int task_tracker = StringUtils.toInt(backlogSett.get("task_tracker"));
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("tracker_id", task_tracker);
			conditions.put("id", StringUtils.toInt(data.get("id")));
			int taskNumber = db.queryo("getTasksByStoryId", conditions);
			if (taskNumber > 0) {
				logicBean.setResultFlg(false);
				logicBean.setResultCode("errors.change_status_has_task_story");
			}
		}
		return logicBean;
	}
	
	public LogicBean checkEstimatedHoursAtInsert() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		String updateData = context.getParam().get("insert");
		if (StringUtils.isEmpty(updateData)) {
			return logicBean;
		}
		JSONObject dataJson = JSONObject.fromObject(updateData);
		JSONObject properties = dataJson.getJSONObject("p");
		Map<String, Object> data = createIssueMap(properties);
		
		double estimated_hours = StringUtils.toDouble(data.get("estimated_hours"));
		if (estimated_hours <= 0) {
			logicBean.setResultFlg(false);
			logicBean.setResultCode("errors.estimated_hours_range");
		}
		return logicBean;
	}
	
	public LogicBean checkEstimatedHoursAtUpdate() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		String updateData = context.getParam().get("update");
		if (StringUtils.isEmpty(updateData)) {
			return logicBean;
		}
		JSONObject dataJson = JSONObject.fromObject(updateData);
		JSONObject properties = dataJson.getJSONObject("p");
		Map<String, Object> data = createIssueMap(properties);
		
		double estimated_hours = StringUtils.toDouble(data.get("estimated_hours"));
		if (estimated_hours <= 0) {
			logicBean.setResultFlg(false);
			logicBean.setResultCode("errors.estimated_hours_range");
		}
		return logicBean;
	}
	
	/**
	 * タスクの名前を保存されたの場合、チェックする
	 * @return
	 * @throws SoftbankException
	 */
	public LogicBean checkTaskNameAtInsert() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		String insertData = context.getParam().get("insert");
		if (StringUtils.isEmpty(insertData)) {
			return logicBean;
		}
		JSONObject dataJson = JSONObject.fromObject(insertData);
		JSONObject properties = dataJson.getJSONObject("p");
		Map<String, Object> data = createIssueMap(properties);
		
		if (StringUtils.isEmpty(data.get(IssueKey.SUBJECT.KEY))) {
			logicBean.setResultFlg(false);
			logicBean.setResultCode("errors.required");
		}
		
		return logicBean;
	}
	
	/**
	 * デフォルトストーリーのトラッカー設定の場合、チェックする
	 * @return
	 * @throws SoftbankException
	 */
	public LogicBean checkDefaultStoryTracker() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		String[] storyTrackerSelected = context.getParam().getList("story_tracker_selected");
		String default_story_tracker = context.getParam().get("default_story_tracker");
		if (storyTrackerSelected == null || storyTrackerSelected.length == 0 || StringUtils.isEmpty(default_story_tracker)) {
			return logicBean;
		}
		boolean flg = false;
		for (int i = 0; i < storyTrackerSelected.length; i++) {
			if (default_story_tracker.equals(storyTrackerSelected[i])) {
				flg = true;
				break;
			}
		}
		if (!flg) {
			logicBean.setResultFlg(false);
			logicBean.setResultCode("errors.default_story_tracker");
		}
		return logicBean;
	}
	
	/**
	 * デフォルトタスクのトラッカー設定の場合、チェックする
	 * @return
	 * @throws SoftbankException
	 */
	public LogicBean checkDefaultTaskTracker() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		String[] displayTrackerSelected = context.getParam().getList("display_tracker_selected");
		String task_tracker = context.getParam().get("task_tracker");
		if (displayTrackerSelected == null || displayTrackerSelected.length == 0 || StringUtils.isEmpty(task_tracker)) {
			return logicBean;
		}
		boolean flg = false;
		for (int i = 0; i < displayTrackerSelected.length; i++) {
			if (task_tracker.equals(displayTrackerSelected[i])) {
				flg = true;
				break;
			}
		}
		if (!flg) {
			logicBean.setResultFlg(false);
			logicBean.setResultCode("errors.default_task_tracker");
		}
		return logicBean;
	}

	/**
	 * スプリントを更新する
	 * @throws SoftbankException
	 */
	public void updateSprintInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("id", context.getParam().get("id"));
		conditions.put("sprint_name", context.getParam().get("sprint_name"));
		conditions.put("effective_date", context.getParam().get("effective_date"));
		conditions.put("sprint_start_date", context.getParam().get("sprint_start_date"));
		db.update("versions.updateVersionInfo", conditions);
	}
	
	/**
	 * スプリントを削除する
	 * @throws SoftbankException
	 */
	public void removeSprintInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("version_id", context.getParam().get("sprint_id"));
		List<Map<String, Object>> issues = db.querys("versions.hasIssuesInVersion", conditions);
		if (issues != null && issues.size() > 0) {
			throw new SoftbankException("removeSprintInfoError");
		}
		db.delete("versions.deleteVersionInfoById", conditions);
	}
	
	/**
	 * リリースを削除する
	 * @throws SoftbankException
	 */
	public void removeReleaseInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("release_id", context.getParam().get("release_id"));
		List<Map<String, Object>> issues = db.querys("releases.hasIssuesInRelease", conditions);
		if (issues != null && issues.size() > 0) {
			throw new SoftbankException("removeReleaseInfoError");
		}
		db.delete("releases.deleteReleaseInfoById", conditions);
	}
	
	/**
	 * ストーリーを削除する
	 * @throws SoftbankException
	 */
	public void removeStoryInfo() throws SoftbankException {
		deleteTicketById(context.getParam().getInt("story_id"));
	}
	
	/**
	 * スプリントをクローズする
	 * @throws SoftbankException
	 */
	public void closeSprint() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("version_id", context.getParam().get("sprint_id"));
		
		Map<String, Object> backlogSett = db.query("backlog_settings.selectSettingInfosForProject");
		String settValue = StringUtils.toString(backlogSett.get("story_trackers"));
		String[] story_trackers = settValue.split(ConstantsUtil.Str.COMMA);
		conditions.put("story_trackers", story_trackers);
		
		List<Map<String, Object>> issues = db.querys("versions.hasNotFinishedIssuesInVersion", conditions);
		if (issues != null && issues.size() > 0) {
			throw new SoftbankException("closeSprintInfoError");
		}
		db.delete("versions.closeVersion", conditions);
	}
	
	/**
	 * スプリントをオープンする
	 * @throws SoftbankException
	 */
	public void openSprint() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("version_id", context.getParam().get("sprint_id"));
		db.delete("versions.openVersion", conditions);
	}
	
	/**
	 * バックログの設定データを保存する
	 * @throws SoftbankException
	 */
	public void saveBacklogSetting() throws SoftbankException {
		String task_color = context.getParam().get("task_color");
		String[] storyTrackerSelected = context.getParam().getList("story_tracker_selected");
		String[] displayTrackerSelected = context.getParam().getList("display_tracker_selected");
		String default_story_tracker = context.getParam().get("default_story_tracker");
		String task_tracker = context.getParam().get("task_tracker");
		String story_point = context.getParam().get("story_point");
		String autorefresh_wait = context.getParam().get("autorefresh_wait");
		
		Map<String, Object> userInfo = db.query("user_preferences.getUserPreferencesInfo");
		if (StringUtils.isNotEmpty(task_color)) {
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("backlogs_task_color", task_color);
			if (userInfo == null) {
				db.insert("user_preferences.addUserPreferencesInfo", conditions);
			} else {
				db.update("user_preferences.updateUserPreferencesInfo", conditions);
			}
			BacklogRefreshDataBean bean = new BacklogRefreshDataBean(BacklogRefreshDataType.userColor);
			bean.setBackgroundColor(task_color);
			bean.setUserId(getUserInfos().getId());
			BacklogRefreshMemory.getInstance().addData(context.getParam().projectId, bean);
		}
		UserInfoData userInfoData = getUserInfos();
		if (userInfoData.isAdmin() || userInfoData.getRoleMap().containsKey("configure_backlogs")) {
			String story_trackers = ConstantsUtil.Str.EMPTY;
			for (int i = 0; i < storyTrackerSelected.length; i++) {
				story_trackers += storyTrackerSelected[i];
				if (i != storyTrackerSelected.length - 1) {
					story_trackers += ConstantsUtil.Str.COMMA;
				}
			}
			String display_trackers = ConstantsUtil.Str.EMPTY;
			if (StringUtils.isNotEmpty(displayTrackerSelected)) {
				for (int i = 0; i < displayTrackerSelected.length; i++) {
					display_trackers += displayTrackerSelected[i];
					if (i != displayTrackerSelected.length - 1) {
						display_trackers += ConstantsUtil.Str.COMMA;
					}
				}
			}
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("story_trackers", story_trackers);
			conditions.put("display_trackers", display_trackers);
			conditions.put("task_tracker", task_tracker);
			conditions.put("story_points", story_point);
			conditions.put("autorefresh_wait", autorefresh_wait);
			conditions.put("default_story_tracker", default_story_tracker);
			db.update("backlog_settings.updateSettingInfosForProject", conditions);
		}
	}
	
	/**
	 * チャートのデータを取得する
	 * @throws SoftbankException
	 */
	public void getChartDatas() throws SoftbankException {
		//　スプリントの開始日を取得する
		String startDate = context.getParam().get("start_date");
		//　スプリントの完了日を取得する
		String endDate = context.getParam().get("end_date");
		//　開始日と完了日の間隔を取得する
		DaysBetweenInfo daysBean = DateUtils.daysBetweenUncludeHolidayForBean(startDate, endDate);
		
		if (daysBean.getDays() == 0) {
			//　間隔ゼロの場合、データ取得なし
			return;
		}
		Map<String, Object> resultMap = Maps.newHashMap();
		//　チャートのデータ保存リスト
		List<Map<String, Object>> chartDataList = Lists.newArrayList();
		//　プロジェクトのバックログ設定を取得する
		Map<String, Object> backlogSett = db.query("backlog_settings.selectSettingInfosForProject");
		//　ストーリーのトラッカー
		String settValue = StringUtils.toString(backlogSett.get("story_trackers"));
		//　ストーリーのトラッカーリスト
		String[] story_trackers = settValue.split(ConstantsUtil.Str.COMMA);
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("sprint_id", context.getParam().getInt("sprint_id"));
		conditions.put("story_trackers", story_trackers);
		//　スプリントのストーリーを取得する
//		List<Map<String, Object>> storys = db.querys("backlogs.selectStoryInfosForSprint", conditions);
		//　全部の予定時間
//		double estimated_hours = 0;
		
//		for (int i = 0; i < storys.size(); i++) {
//			Map<String, Object> story = storys.get(i);
//			estimated_hours += StringUtils.toDouble(story.get("estimated_hours"));
//		}
		
		Map<String, Object> idealMap = Maps.newHashMap();
		idealMap.put("key", "理想時間");
		Map<String, Object> remainingMap = Maps.newHashMap();
		remainingMap.put("key", "残り時間");
		Map<String, Object> storyPointsMap = Maps.newHashMap();
		storyPointsMap.put("key", "承認されたポイント");
		storyPointsMap.put("p", true);
		Map<String, Object> masterStoryPointsMap = Maps.newHashMap();
		masterStoryPointsMap.put("key", "必要なバーンレート(ポイント)");
		masterStoryPointsMap.put("p", true);
		Map<String, Object> masterRemainingMap = Maps.newHashMap();
		masterRemainingMap.put("key", "必要なバーンレート(時間)");
		Map<String, Object> costMap = Maps.newHashMap();
		costMap.put("key", "消化線");
		
		//　理想時間用
		List<Map<String, Object>> ideals = Lists.newArrayList();
		//　残り時間用
		List<Map<String, Object>> remainings = Lists.newArrayList();
		//　承認されたポイント用
		List<Map<String, Object>> storyPoints = Lists.newArrayList();
		//　必要なバーンレート(ポイント)用
		List<Map<String, Object>> masterStoryPoints = Lists.newArrayList();
		//　必要なバーンレート(時間)用
		List<Map<String, Object>> masterRemaining = Lists.newArrayList();
		//　消化線用
		List<Map<String, Object>> costList = Lists.newArrayList();
		//　開始日を取得する
		Date startDateD = daysBean.getStartDate();
		//　完了日を取得する
		Date endDateD = daysBean.getEndDate();
		
		conditions.put("startDate", DateUtils.makeFormat(startDateD, DateUtils.FORMAT_YYYYMMDD_DASH));
		conditions.put("endDate", DateUtils.makeFormat(endDateD, DateUtils.FORMAT_YYYYMMDD_DASH));
		
		double estimated_hours = db.queryo("backlog_history.selectBacklogBeforeHistoryBySprintIdForIdeals", conditions);
		//　毎日の予定時間
		double interval = estimated_hours / daysBean.getDays();
		Date now = DateUtils.formatToDate(DateUtils.getNow(DateUtils.FORMAT_YYYYMMDD_DASH), DateUtils.FORMAT_YYYYMMDD_DASH);
		int endCount = DateUtils.daysBetweenUncludeHoliday(now, endDateD);
		// 残り時間用
		Map<Integer, Double> lastRemainingMap = Maps.newHashMap();
		// 予定時間用
		Map<Integer, Double> estimatedMap = Maps.newHashMap();
		// 承認されたポイント用
		Map<Integer, Double> lastStoryPointsMap = Maps.newHashMap();
		// 残りポイント用
		Map<Integer, Double> lastRemainingStoryPointsMap = Maps.newHashMap();
		// スプリント開始日前のストーリー情報を取得する
		List<Map<String, Object>> remainingBeforeList = db.querys("backlog_history.selectBacklogBeforeHistoryBySprintId", conditions);
		for (int i = 0; i < remainingBeforeList.size(); i++) {
			Map<String, Object> beforeremaining = remainingBeforeList.get(i);
			int tid = StringUtils.toInt(beforeremaining.get("issue_id"));
			lastRemainingMap.put(tid, StringUtils.toDouble(beforeremaining.get("remaining_hours")));
			estimatedMap.put(tid, StringUtils.toDouble(beforeremaining.get("estimated_hours")));
			lastStoryPointsMap.put(tid, StringUtils.toDouble(beforeremaining.get("story_points")));
			lastRemainingStoryPointsMap.put(tid, StringUtils.toDouble(beforeremaining.get("remaining_points")));
		}
		// スプリント開始日と完了日間のストーリー情報を取得する
		List<Map<String, Object>> remainingList = db.querys("backlog_history.selectBacklogHistoryBySprintId", conditions);
		Map<String, Map<Integer, Map<String, Object>>> remainingDateMap = Maps.newHashMap();
		Map<Integer, Map<String, Object>> remainingIssueMap = null;
		for (int i = 0; i < remainingList.size(); i++) {
			Map<String, Object> remaining = remainingList.get(i);
			int tid = StringUtils.toInt(remaining.get("issue_id"));
			String updated_on = StringUtils.toString(remaining.get("updated_on"));
			if (!remainingDateMap.containsKey(updated_on)) {
				remainingIssueMap = Maps.newHashMap();
				remainingDateMap.put(updated_on, remainingIssueMap);
			} else {
				remainingIssueMap = remainingDateMap.get(updated_on);
			}
			remainingIssueMap.put(tid, remaining);
		}
		
		int i = 0;
		
		Map<String, Object> data = Maps.newHashMap();
//		data.put("x", i);
//		data.put("l", DateUtils.makeFormat(DateUtils.getPrevNotHoliday(startDateD), DateUtils.FORMAT_MMDD_SLASH));
//		data.put("y", (estimated_hours - interval * i));
//		ideals.add(data);
//		
//		i++;
		//　開始されたのフラグ
		boolean isStart = false;
		double prev_remaining_hours_sum = 0;
		double prev_estimated_hours_sum = 0;
		while (endDateD.compareTo(startDateD) >= 0) {
			//　休日判断する
			if (DateUtils.getWeek(startDateD) != 1 && DateUtils.getWeek(startDateD) != 7 && !ControlDbMemory.getInstance().isHoliday(startDateD)) {
				//　平日の場合
				data = Maps.newHashMap();
				data.put("x", i);
				data.put("l", DateUtils.makeFormat(startDateD, DateUtils.FORMAT_MMDD_SLASH));
				data.put("y", (estimated_hours - interval * (i + 1)));
				ideals.add(data);
				String currentDate = DateUtils.makeFormat(startDateD, DateUtils.FORMAT_YYYYMMDD_DASH);
				if ((isStart || lastRemainingMap.size() > 0 || remainingDateMap.containsKey(currentDate)) && now.compareTo(startDateD) >= 0) {
					isStart = true;
					Map<Integer, Map<String, Object>> rim = remainingDateMap.get(currentDate);
					double remaining_hours_sum = 0;
					double estimated_hours_sum = 0;
					double story_points_sum = 0;
					double remaining_story_points_sum = 0;
					if (lastRemainingMap.size() > 0) {
						for (Integer tid : lastRemainingMap.keySet()) {
							if (rim != null && rim.containsKey(tid)) {
								// 残り時間
								double remaining_hours = StringUtils.toDouble(rim.get(tid).get("remaining_hours"));
								// 予定時間
								double estimated_h = StringUtils.toDouble(rim.get(tid).get("estimated_hours"));
								// ストーリーポイント
								double story_points = StringUtils.toDouble(rim.get(tid).get("story_points"));
								// 残りポイント
								double remaining_points = StringUtils.toDouble(rim.get(tid).get("remaining_points"));
								lastRemainingMap.put(tid, remaining_hours);
								estimatedMap.put(tid, estimated_h);
								lastStoryPointsMap.put(tid, story_points);
								lastRemainingStoryPointsMap.put(tid, remaining_points);
								remaining_hours_sum += remaining_hours;
								estimated_hours_sum += estimated_h;
								story_points_sum += story_points;
								remaining_story_points_sum += remaining_points;
								rim.remove(tid);
							} else {
								remaining_hours_sum += lastRemainingMap.get(tid);
								estimated_hours_sum += estimatedMap.get(tid);
								story_points_sum += lastStoryPointsMap.get(tid);
								remaining_story_points_sum += lastRemainingStoryPointsMap.get(tid);
							}
						}
					}
					if (rim != null && rim.size() > 0) {
						for (Integer tid : rim.keySet()) {
							double remaining_hours = StringUtils.toDouble(rim.get(tid).get("remaining_hours"));
							double estimated_h = StringUtils.toDouble(rim.get(tid).get("estimated_hours"));
							double story_points = StringUtils.toDouble(rim.get(tid).get("story_points"));
							double remaining_points = StringUtils.toDouble(rim.get(tid).get("remaining_points"));
							lastRemainingMap.put(tid, remaining_hours);
							estimatedMap.put(tid, estimated_h);
							lastStoryPointsMap.put(tid, story_points);
							lastRemainingStoryPointsMap.put(tid, remaining_points);
							remaining_hours_sum += remaining_hours;
							estimated_hours_sum += estimated_h;
							story_points_sum += story_points;
							remaining_story_points_sum += remaining_points;
						}
					}
					
//					if (i == 1) {
//						data = Maps.newHashMap();
//						data.put("x", 0);
//						data.put("y", remaining_hours_sum);
//						remainings.add(data);
//						
//						data = Maps.newHashMap();
//						data.put("x", 0);
//						data.put("y", story_points_sum);
//						data.put("p", true);
//						storyPoints.add(data);
//					}
					double remaining_hours_sum_p = prev_remaining_hours_sum;
					if (prev_remaining_hours_sum != 0) {
						remaining_hours_sum_p += estimated_hours_sum - prev_estimated_hours_sum;
					}
					prev_remaining_hours_sum = remaining_hours_sum;
					prev_estimated_hours_sum = estimated_hours_sum;
					data = Maps.newHashMap();
					data.put("x", i);
					data.put("y", remaining_hours_sum);
					data.put("px", remaining_hours_sum_p);
					remainings.add(data);
					
					data = Maps.newHashMap();
					data.put("x", i);
					data.put("y", story_points_sum);
					data.put("p", true);
					storyPoints.add(data);
					
					int dayCount = DateUtils.daysBetweenUncludeHoliday(startDateD, endDateD);
					
					BigDecimal storyPointsBD = new BigDecimal(remaining_story_points_sum);
					BigDecimal dayBD = new BigDecimal(dayCount);
					
					BigDecimal result = storyPointsBD.divide(dayBD, 1, BigDecimal.ROUND_HALF_UP);
//					if (i == 1) {
//						data = Maps.newHashMap();
//						data.put("x", 0);
//						data.put("y", result);
//						data.put("p", true);
//						masterStoryPoints.add(data);
//					}
					data = Maps.newHashMap();
					data.put("x", i);
					data.put("y", result);
					data.put("p", true);
					masterStoryPoints.add(data);
					
					BigDecimal remainingBD = new BigDecimal(remaining_hours_sum);
					result = remainingBD.divide(dayBD, 1, BigDecimal.ROUND_HALF_UP);
//					if (i == 1) {
//						data = Maps.newHashMap();
//						data.put("x", 0);
//						data.put("y", result);
//						masterRemaining.add(data);
//					}
					data = Maps.newHashMap();
					data.put("x", i);
					data.put("y", result);
					masterRemaining.add(data);
				} else {
//					if (i == 1) {
//						data = Maps.newHashMap();
//						data.put("x", 0);
//						data.put("y", null);
//						remainings.add(data);
//						
//						data = Maps.newHashMap();
//						data.put("x", 0);
//						data.put("y", null);
//						data.put("p", true);
//						storyPoints.add(data);
//						
//						data = Maps.newHashMap();
//						data.put("x", 0);
//						data.put("y", null);
//						data.put("p", true);
//						masterStoryPoints.add(data);
//						
//						data = Maps.newHashMap();
//						data.put("x", 0);
//						data.put("y", null);
//						data.put("p", true);
//						masterRemaining.add(data);
//					}
					data = Maps.newHashMap();
					data.put("x", i);
					data.put("y", null);
					remainings.add(data);
					
					data = Maps.newHashMap();
					data.put("x", i);
					data.put("y", null);
					data.put("p", true);
					storyPoints.add(data);
					
					data = Maps.newHashMap();
					data.put("x", i);
					data.put("y", null);
					data.put("p", true);
					masterStoryPoints.add(data);
					
					data = Maps.newHashMap();
					data.put("x", i);
					data.put("y", null);
					data.put("p", true);
					masterRemaining.add(data);
					
					if (costList.size() == 0) {
						data = Maps.newHashMap();
						data.put("x", (i - 1));
						data.put("y", prev_remaining_hours_sum);
						costList.add(data);
					}
					
					BigDecimal remainingBD = new BigDecimal(prev_remaining_hours_sum);
					BigDecimal dayBD = new BigDecimal(endCount - 1);
					BigDecimal intervalBig = remainingBD.divide(dayBD, 1, BigDecimal.ROUND_HALF_UP);
					BigDecimal result = intervalBig.multiply(new BigDecimal(DateUtils.daysBetweenUncludeHoliday(startDateD, endDateD) - 1));
					data = Maps.newHashMap();
					data.put("x", i);
					data.put("y", result);
					costList.add(data);
				}
				i++;
			}
			startDateD = DateUtils.calcDateForDate(startDateD, 1);
		}
		
		ideals.get(ideals.size() - 1).put("y", 0);
		// 理想時間[0]
		idealMap.put("values", ideals);
		chartDataList.add(idealMap);
		// 残り時間[1]
		remainingMap.put("values", remainings);
		chartDataList.add(remainingMap);
		// 承認されたポイント[2]
		storyPointsMap.put("values", storyPoints);
		chartDataList.add(storyPointsMap);
		// 必要なバーンレート(ポイント)[3]
		masterStoryPointsMap.put("values", masterStoryPoints);
		chartDataList.add(masterStoryPointsMap);
		// 必要なバーンレート(時間)[4]
		masterRemainingMap.put("values", masterRemaining);
		chartDataList.add(masterRemainingMap);
		// 消化線[5]
		costMap.put("values", costList);
		chartDataList.add(costMap);
		
		resultMap.put("chartDataList", chartDataList);
		
		context.getResultBean().setData(resultMap);
	}
	
	public void autoRefresh() throws SoftbankException {
		Map<String, Object> result = Maps.newHashMap();
		String token = context.getParam().get("token");
		List<BacklogRefreshDataBean> datas = BacklogRefreshMemory.getInstance().getDatas(context.getParam().projectId, token);
		if (datas != null && datas.size() > 0) {
			result.put("datas", datas);
		}
		context.getResultBean().setData(result);
	}
	
	private Map<String, Object> createIssueMap(JSONObject properties) {
		Map<String, Object> issueMap = Maps.newHashMap();
		for (Object key : properties.keySet()) {
			String ks = StringUtils.toString(key);
			Object val = properties.get(key);
			if (val instanceof JSONNull) {
				val = null;
			} else {
				if ("customMap".equals(ks)) {
					Map<Integer, Object> customMap = Maps.newHashMap();
					JSONObject customJson = properties.getJSONObject(ks);
					for (Object k : customJson.keySet()) {
						customMap.put(StringUtils.toInt(k), customJson.get(k));
					}
					val = customMap;
				}
			}
			issueMap.put(ks, val);
		}
		return issueMap;
	}
	
	private void createRoleMap(Map<String, Object> backlogSettings) {
		Map<String, Object> roleMap = Maps.newHashMap();
		roleMap.put("configure_backlogs", checkConfigureBacklogs());
		backlogSettings.put("roleMap", roleMap);
	}
	
	private void updatePositionData(JSONArray positions) throws SoftbankException {
		if (!positions.isEmpty()) {
			List<Integer> delids = Lists.newArrayList();
			List<Map<String, Object>> positionList = Lists.newArrayList();
			for (int i = 0; i < positions.size(); i++) {
				Map<String, Object> posMap = Maps.newHashMap();
				JSONObject pos = positions.getJSONObject(i);
				delids.add(pos.getInt("id"));
				posMap.put("issue_id", pos.getInt("id"));
				posMap.put("position", pos.getInt("position"));
				positionList.add(posMap);
			}
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("delids", delids);
			conditions.put("positions", positionList);
			db.delete("backlog_position.deleteBacklogPositionByIssueId", conditions);
			db.insert("backlog_position.insertBacklogPositionInfos", conditions);
		}
	}
	
	@SuppressWarnings("unchecked")
	private void addCustomFieldValues(Map<String, Object> data) throws SoftbankException {
		if (!data.containsKey("customMap")) {
			return;
		}
		int issueId = StringUtils.toInt(data.get("id"));
		Map<Integer, Object> customMap = (Map<Integer, Object>)data.get("customMap");
		final List<Map<String, Object>> customValuesList = Lists.newArrayList();
		for (int filedId : customMap.keySet()) {
			String value = StringUtils.toString(customMap.get(filedId));
			Map<String, Object> customValueInfo = Maps.newHashMap();
			customValueInfo.put("customized_id", issueId);
			customValueInfo.put("custom_field_id", filedId);
			customValueInfo.put("value", value);
			customValuesList.add(customValueInfo);
		}
		if (customValuesList != null && customValuesList.size() > 0) {
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("customValues", customValuesList);
			db.insert("custom_values.insertIssueCustomValues", conditions);
		}
	}
	
	private Map<String, Map<String, List<Map<String, Object>>>> getIssueStatuses(Map<String, Object> conditions) throws SoftbankException {
		List<Map<String, Object>> issueStatuses = db.querys("issue_statuses.getIssueStatuses", conditions);

		Map<String, Map<String, List<Map<String, Object>>>> issueStatusMap = Maps.newHashMap();

		for (int i = 0; i < issueStatuses.size(); i++) {
			Map<String, Object> data = issueStatuses.get(i);
			String trackerId = String.valueOf(data.get("tracker_id"));
			String trackerName = String.valueOf(data.get("tracker_name"));
			String oldStatusId = String.valueOf(data.get("old_status_id"));
			String oldStatusName = String.valueOf(data.get("old_status_name"));
			String oldStatusPosition = String.valueOf(data.get("old_status_position"));
			if (!issueStatusMap.containsKey(trackerId)) {
				Map<String, List<Map<String, Object>>> oldStatusMap = Maps.newHashMap();
				issueStatusMap.put(trackerId, oldStatusMap);
			}
			if (!issueStatusMap.get(trackerId).containsKey(oldStatusId)) {
				List<Map<String, Object>> newStatusList = Lists.newArrayList();
				Map<String, Object> newStatusMap = Maps.newHashMap();
				newStatusMap.put("value", oldStatusId);
				newStatusMap.put("label", oldStatusName);
				newStatusMap.put("position", oldStatusPosition);
				newStatusMap.put("is_closed", StringUtils.toBoolean(data.get("old_is_closed")));
				newStatusMap.put("default_done_ratio", StringUtils.toString(data.get("old_default_done_ratio")));
				newStatusMap.put("default_selected", StringUtils.toString(data.get("old_default_selected")));
				newStatusList.add(newStatusMap);
				issueStatusMap.get(trackerId).put(oldStatusId, newStatusList);
			}
			issueStatusMap.get(trackerId).get(oldStatusId).add(makeStatusOptionMap(data));
		}
		return issueStatusMap;
	}
	
	private LogicBean checkBlock(LogicBean logicBean, JSONObject dataJson) {
		JSONObject properties = dataJson.getJSONObject("p");
		Map<String, Object> data = createIssueMap(properties);
		if (StringUtils.toBoolean(data.get("is_block"))) {
			if (StringUtils.isEmpty(data.get("block_id"))) {
				logicBean.setResultFlg(false);
				logicBean.setResultCode("errors.required");
			}
		}
		return logicBean;
	}
	
	private Map<String, Object> makeStatusOptionMap(Map<String, Object> data) {
		Map<String, Object> newStatusMap = Maps.newHashMap();
		String newStatusId = StringUtils.toString(data.get("new_status_id"));
		String newStatusName = StringUtils.toString(data.get("new_status_name"));
		String newStatusPosition = StringUtils.toString(data.get("new_status_position"));
		boolean newIsClosed = StringUtils.toBoolean(data.get("new_is_closed"));
		String newDefaultDoneRatio = StringUtils.toString(data.get("new_default_done_ratio"));
		String newDefaultSelected = StringUtils.toString(data.get("new_default_selected"));
		newStatusMap.put("value", newStatusId);
		newStatusMap.put("label", newStatusName);
		newStatusMap.put("position", newStatusPosition);
		newStatusMap.put("is_closed", newIsClosed);
		newStatusMap.put("default_done_ratio", newDefaultDoneRatio);
		newStatusMap.put("default_selected", newDefaultSelected);
		return newStatusMap;
	}
	
	private boolean checkConfigureBacklogs() {
		UserInfoData userInfo = getUserInfos();
		if (userInfo.isAdmin()) {
			return true;
		}
		if (userInfo.getRoleMap().containsKey("configure_backlogs")) {
			return true;
		}
		return false;
	}

}
