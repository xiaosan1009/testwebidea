package co.jp.softbank.qqmx.info.bean;

import java.util.List;

public class ProjectWorkerBean {
	
	private int projectId;

	private ProjectWorkerType type;
	
	private List<Integer> userList;
	
	public ProjectWorkerBean() {
	}
	
	public ProjectWorkerBean(int projectId, ProjectWorkerType type) {
		this.projectId = projectId;
		this.type = type;
	}

	public int getProjectId() {
		return projectId;
	}

	public void setProjectId(int projectId) {
		this.projectId = projectId;
	}

	public ProjectWorkerType getType() {
		return type;
	}

	public void setType(ProjectWorkerType type) {
		this.type = type;
	}
	
	
	public List<Integer> getUserList() {
		return userList;
	}

	public void setUserList(List<Integer> userList) {
		this.userList = userList;
	}

	public enum ProjectWorkerType {
		normal, watchable, mit;
	}
	
}
