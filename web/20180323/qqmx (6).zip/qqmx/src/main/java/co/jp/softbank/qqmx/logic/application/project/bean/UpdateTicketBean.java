package co.jp.softbank.qqmx.logic.application.project.bean;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.util.StringUtils;

public class UpdateTicketBean {
	
	private List<JournalizedBean> journalizedList = Lists.newArrayList();
	
	private List<Map<String, Object>> deleteCustomValueIds = Lists.newArrayList();
	
	private List<Map<String, Object>> updateIssueValues = Lists.newArrayList();
	
	private List<Map<String, Object>> updateIssueOrderValues = Lists.newArrayList();
	
	private Map<Integer, Map<String, Object>> oldIssuesDataMap = Maps.newHashMap();
	
	private Map<Integer, Map<String, Object>> issuesMap;
	
	private Map<Integer, List<Map<String, Object>>> issuesCustomValuesMap = Maps.newHashMap();

	public List<JournalizedBean> getJournalizedList() {
		return journalizedList;
	}

	public void addJournalizedList(Map<String, Object> data, List<Map<String, Object>> changeList) {
		JournalizedBean bean = new JournalizedBean(data, changeList);
		journalizedList.add(bean);
	}
	
	public void createOldIssueDataMap(List<Map<String, Object>> datas) {
		for (int i = 0; i < datas.size(); i++) {
			Map<String, Object> data = datas.get(i);
			oldIssuesDataMap.put(StringUtils.toInt(data.get("id")), data);
		}
	}
	
	public Map<String, Object> getOldIssueData(int tid) {
		return oldIssuesDataMap.get(tid);
	}
	
	public Map<Integer, Map<String, Object>> getIssuesMap() {
		return issuesMap;
	}

	public void setIssuesMap(Map<Integer, Map<String, Object>> issuesMap) {
		this.issuesMap = issuesMap;
	}
	
	public void addDeleteCustomValueId(Map<String, Object> customUpdate) {
		deleteCustomValueIds.add(customUpdate);
	}
	
	public void addUpdateIssueValue(Map<String, Object> updateData) {
		updateIssueValues.add(updateData);
	}
	
	public void addUpdateIssueOrderValue(Map<String, Object> updateData) {
		updateIssueOrderValues.add(updateData);
	}
	
	public List<Map<String, Object>> getDeleteCustomValueIds() {
		return deleteCustomValueIds;
	}

	public List<Map<String, Object>> getUpdateIssueValues() {
		return updateIssueValues;
	}
	
	public List<Map<String, Object>> getUpdateIssueOrderValues() {
		return updateIssueOrderValues;
	}

	public void createIssuesCustomValuesMap(List<Map<String, Object>> datas) {
		for (int i = 0; i < datas.size(); i++) {
			Map<String, Object> data = datas.get(i);
			int tid = StringUtils.toInt(data.get("customized_id"));
			if (!issuesCustomValuesMap.containsKey(tid)) {
				List<Map<String, Object>> valueList = Lists.newArrayList();
				issuesCustomValuesMap.put(tid, valueList);
			}
			issuesCustomValuesMap.get(tid).add(data);
		}
	}
	
	public List<Map<String, Object>> getIssuesCustomValues(int tid) {
		return issuesCustomValuesMap.get(tid);
	}

	public static class JournalizedBean {
		private Map<String, Object> data;
		
		private List<Map<String, Object>> changeList;
		
		public JournalizedBean(Map<String, Object> data, List<Map<String, Object>> changeList) {
			this.data = data;
			this.changeList = changeList;
		}

		public Map<String, Object> getData() {
			return data;
		}

		public void setData(Map<String, Object> data) {
			this.data = data;
		}

		public List<Map<String, Object>> getChangeList() {
			return changeList;
		}

		public void setChangeList(List<Map<String, Object>> changeList) {
			this.changeList = changeList;
		}
		
	}
}
