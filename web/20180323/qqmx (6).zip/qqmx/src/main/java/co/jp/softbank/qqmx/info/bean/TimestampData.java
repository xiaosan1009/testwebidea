package co.jp.softbank.qqmx.info.bean;

import java.util.Date;
import java.util.List;

public class TimestampData {
	
	private Date timestamp;
	
	private List<Integer> userList;
	
	private boolean skip;

	public Date getTimestamp() {
		return timestamp;
	}

	public void setTimestamp(Date timestamp) {
		this.timestamp = timestamp;
	}

	public List<Integer> getUserList() {
		return userList;
	}

	public void setUserList(List<Integer> userList) {
		this.userList = userList;
	}

	public boolean isSkip() {
		return skip;
	}

	public void setSkip(boolean skip) {
		this.skip = skip;
	}

}
