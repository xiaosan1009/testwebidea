package co.jp.softbank.qqmx.dao.project.settings;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.dao.IDaoInterface;

public interface CategoryListDao extends IDaoInterface {
//	List<Map<String, Object>> getRoleListInfo();
//	void deleteRoleInfo(Map<String, Object> conditions);
//	void deleteWorkflowsInfo(Map<String, Object> conditions);
//	void updateRoleInfo(Map<String, Object> conditions);
//	void updateRoleListInfo(Map<String, Object> conditions);
//	
//	
//	List<Map<String, Object>> getRolesBaseList();
//	List<Map<String, Object>> getRolesBaseSubList();
	List<Map<String, Object>> getProjectCategoryUserList(Map<String, Object> conditions);
	List<Map<String, Object>> getCategoryListInfo(Map<String, Object> conditions);
	List<Map<String, Object>> getProjectCategoryId(Map<String, Object> conditions);
	void saveProjectCategory(Map<String, Object> conditions);
	void delProjectCategory(Map<String, Object> conditions);
	void updateProjectCategory(Map<String, Object> conditions);
}
