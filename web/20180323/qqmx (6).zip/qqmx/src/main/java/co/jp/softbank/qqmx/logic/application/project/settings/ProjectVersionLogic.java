package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.util.DateUtils;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Maps;

public class ProjectVersionLogic extends AbstractBaseLogic {
	
	public void getProjectVersionList() throws SoftbankException {
		
		Map<String, Object> conditions = Maps.newHashMap();
		String projectIdString = context.getParam().get("projectId");
		conditions.put("project_id", Integer.parseInt(projectIdString));
		List<Map<String, Object>> lftRgtList = db.querys("projectVersion.getLftRgtInfoList", conditions);
		conditions.put("project_lft", Integer.parseInt(String.valueOf(lftRgtList.get(0).get("project_lft"))));
		conditions.put("project_rgt", Integer.parseInt(String.valueOf(lftRgtList.get(0).get("project_rgt"))));
		if (null == lftRgtList.get(0).get("parent_lft")){
			conditions.put("parent_lft", Integer.parseInt(String.valueOf(lftRgtList.get(0).get("project_lft"))));
		}else{
			conditions.put("parent_lft", Integer.parseInt(String.valueOf(lftRgtList.get(0).get("parent_lft"))));
		}
		
		if (null == lftRgtList.get(0).get("parent_rgt")){
			conditions.put("parent_rgt", Integer.parseInt(String.valueOf(lftRgtList.get(0).get("project_rgt"))));
		}else{
			conditions.put("parent_rgt", Integer.parseInt(String.valueOf(lftRgtList.get(0).get("parent_rgt"))));
		}
//		context.getResultBean().setData(db.querys("projectVersion.getVersionList", conditions));
		context.getResultBean().setData(pageList("projectVersion.getVersionList", conditions));
		
	}
	
	public LogicBean checkNameExists() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("name", context.getParam().get("settings_version_name"));

		if (StringUtils.isNotEmpty(context.getParam().get("version_id"))) {
			conditions.put("id", StringUtils.toInt(context.getParam().get("version_id")));
		}
		Integer getGroupCount = db.queryo("projectVersion.getVersionsName", conditions);
		
		if (getGroupCount > 0) {
			logicBean.setResultFlg(false);
			logicBean.setResultCode("301503.status_name_error_result");
		}
		return logicBean;
	}
	
	public void setProjectVersionList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String version_name = context.getParam().get("settings_version_name");
		String version_description = context.getParam().get("settings_version_description");
		String version_status = context.getParam().get("settings_version_status");
		String version_wiki_page_title = context.getParam().get("settings_version_wiki_page_title");
		String version_effective_date = context.getParam().get("settings_version_effective_date");
		String version_sharing = context.getParam().get("settings_version_sharing");
		String version_custom_field_values_658 = context.getParam().get("settings_version_custom_field_values_658");
		String version_custom_field_values_659 = context.getParam().get("settings_version_custom_field_values_659");
		String version_custom_field_values_660 = context.getParam().get("settings_version_custom_field_values_660");
		
		conditions.put("name", version_name);
		conditions.put("description", version_description);
		conditions.put("status", version_status);
		conditions.put("wiki_page_title", version_wiki_page_title);
		if ("".equals(version_effective_date)){
			conditions.put("effective_date", null);
		}else{
			conditions.put("effective_date", DateUtils.formatToDate(version_effective_date, DateUtils.FORMAT_YYYYMMDD_DASH));
		}
		conditions.put("sharing", version_sharing);
		conditions.put("sprint_start_date", null);
		String projectIdString = context.getParam().get("projectId");
		conditions.put("project_id", Integer.parseInt(projectIdString));
		context.getResultBean().setData(db.insert("projectVersion.insertVersions", conditions));
		final int newVersionId = Integer.parseInt(StringUtils.toString(conditions.get("id")));
		
		Map<String, Object> customizedConditions = Maps.newHashMap();
		customizedConditions.put("customized_id", newVersionId);
		customizedConditions.put("value", version_custom_field_values_658);
		customizedConditions.put("custom_field_id", 658);
		context.getResultBean().setData(db.insert("projectVersion.insertCustomValues", customizedConditions));

		customizedConditions.put("custom_field_id", 659);
		customizedConditions.put("value", version_custom_field_values_659);
		context.getResultBean().setData(db.insert("projectVersion.insertCustomValues", customizedConditions));
		
		customizedConditions.put("custom_field_id", 660);
		customizedConditions.put("value", version_custom_field_values_660);
		context.getResultBean().setData(db.insert("projectVersion.insertCustomValues", customizedConditions));
		
	}
	
	public void editProjectVersionList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String version_name = context.getParam().get("settings_version_name");
		String version_description = context.getParam().get("settings_version_description");
		String version_status = context.getParam().get("settings_version_status");
		String version_wiki_page_title = context.getParam().get("settings_version_wiki_page_title");
		String version_effective_date = context.getParam().get("settings_version_effective_date");
		String version_sharing = context.getParam().get("settings_version_sharing");
		String version_custom_field_values_658 = context.getParam().get("settings_version_custom_field_values_658");
		String version_custom_field_values_659 = context.getParam().get("settings_version_custom_field_values_659");
		String version_custom_field_values_660 = context.getParam().get("settings_version_custom_field_values_660");
		String version_id = context.getParam().get("version_id");
		
		conditions.put("id", Integer.parseInt(version_id));
		conditions.put("name", version_name);
		conditions.put("description", version_description);
		conditions.put("status", version_status);
		conditions.put("wiki_page_title", version_wiki_page_title);
		conditions.put("wiki_page_title", version_wiki_page_title);
		if ("".equals(version_effective_date)){
			conditions.put("effective_date", null);
		}else{
			conditions.put("effective_date", DateUtils.formatToDate(version_effective_date, DateUtils.FORMAT_YYYYMMDD_DASH));
		}
		conditions.put("sharing", version_sharing);
		conditions.put("sprint_start_date", null);
		context.getResultBean().setData(db.update("projectVersion.updateVersions", conditions));
		
		conditions.put("customized_id", Integer.parseInt(version_id));
		conditions.put("value", version_custom_field_values_658);
		conditions.put("custom_field_id", 658);
		context.getResultBean().setData(db.update("projectVersion.updateCustomValues", conditions));
		
		conditions.put("custom_field_id", 659);
		conditions.put("value", version_custom_field_values_659);
		context.getResultBean().setData(db.update("projectVersion.updateCustomValues", conditions));
		
		conditions.put("custom_field_id", 660);
		conditions.put("value", version_custom_field_values_660);
		context.getResultBean().setData(db.update("projectVersion.updateCustomValues", conditions));
		
	}
	
	public void delProjectVersionList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();

		String version_id = context.getParam().get("version_id");
		conditions.put("id", Integer.parseInt(version_id));
		
		int issuesCount = db.queryo("projectVersion.getIssuesByVersionId", conditions);
		if (0 != issuesCount) {
			throw new SoftbankException("removeVersionInfoError");
		}
		
		context.getResultBean().setData(db.delete("projectVersion.deleteVersions", conditions));
		
		String projectIdString = context.getParam().get("projectId");
		conditions.put("customized_id", Integer.parseInt(projectIdString));
		conditions.put("custom_field_id", 658);
		context.getResultBean().setData(db.delete("projectVersion.deleteCustomValues", conditions));
		
		conditions.put("custom_field_id", 659);
		context.getResultBean().setData(db.delete("projectVersion.deleteCustomValues", conditions));
		
		conditions.put("custom_field_id", 660);
		context.getResultBean().setData(db.delete("projectVersion.deleteCustomValues", conditions));
		
	}
	
	public void getProjectEditVersionList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		
		String version_id = context.getParam().get("version_id");
		conditions.put("id", Integer.parseInt(version_id));
		context.getResultBean().setData(db.querys("projectVersion.getProjectEditVersionList", conditions));
		
	}

}
