package co.jp.softbank.qqmx.sockect;

import java.util.Enumeration;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.server.ServerHttpRequest;
import org.springframework.http.server.ServerHttpResponse;
import org.springframework.http.server.ServletServerHttpRequest;
import org.springframework.web.socket.WebSocketHandler;
import org.springframework.web.socket.server.support.HttpSessionHandshakeInterceptor;

import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.bean.SessionData;

public class HandshakeInterceptor extends HttpSessionHandshakeInterceptor{  
	
	protected final Logger log = LoggerFactory.getLogger(getClass());
    
    @Override  
    public boolean beforeHandshake(ServerHttpRequest request,  
            ServerHttpResponse response, WebSocketHandler wsHandler,  
            Map<String, Object> attributes) throws Exception {  
        log.info("Before Handshake start!!");
        HttpServletRequest req = ((ServletServerHttpRequest)request).getServletRequest();
        HttpSession session = req.getSession(false);
        final SessionData sessionData = (SessionData)session.getAttribute(SessionData.APPLICATION_SESSION_KEY);
        UserInfoData userInfoData = sessionData.getUserInfo();
        Enumeration<String> keys = req.getParameterNames();
        while (keys.hasMoreElements()) {
        	String key = keys.nextElement();
        	attributes.put(key, req.getParameter(key));
		}
        attributes.put(UserInfoData.USER_INFO_KEY, userInfoData);
        log.info("Before Handshake end!!");
        return super.beforeHandshake(request, response, wsHandler, attributes);  
    }  
  
    @Override  
    public void afterHandshake(ServerHttpRequest request,  
            ServerHttpResponse response, WebSocketHandler wsHandler,  
            Exception ex) {  
        log.info("After Handshake start!!");
        super.afterHandshake(request, response, wsHandler, ex);  
        log.info("After Handshake end!!");
    }  
  
}  
