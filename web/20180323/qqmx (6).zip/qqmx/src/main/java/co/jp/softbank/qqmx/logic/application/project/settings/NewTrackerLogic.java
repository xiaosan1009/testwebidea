package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

//import co.jp.softbank.qqmx.dao.project.settings.TrackerListDao;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.util.StringUtils;

public class NewTrackerLogic extends AbstractBaseLogic {

	// 保存
	public void saveTracker() throws SoftbankException {
		
		String[] customFieldsIds = sessionToString("custom_fields_selected_name");
		
		String[] projectIds = sessionToString("project_selected_name");
		
		Map<String, Object> conditions = Maps.newHashMap();
		String name = context.getParam().get("name");
		conditions.put("name", name);
		conditions.put("is_in_roadmap", "true".equals(context.getParam().get("tracker_is_in_roadmap")) ? true : false);
		conditions.put("is_in_chlog", false);
		
		int trackerId = 0;
		// 新しいトラック場合
		if ( "0".equals(context.getParam().get("trackersId"))){
			db.insert("newTracker.insertTrackers", conditions);
			
			trackerId = Integer.parseInt(StringUtils.toString(conditions.get("id")));
			
			// ワークフローをここからコピー
			if (StringUtils.isNotEmpty(context.getParam().get("copy_tracker_workflow_from"))) {
				conditions.put("new_tracker_id", trackerId);
				conditions.put("bak_tracker_id", StringUtils.toInt(context.getParam().get("copy_tracker_workflow_from")));
				db.insert("newTracker.inserWorkflowsAllroles", conditions);
			}
			
		}else{
			trackerId = Integer.parseInt(context.getParam().get("trackersId"));
			conditions.put("tracker_id", trackerId);
			
			String trackerName = context.getParam().get("name");
			conditions.put("name", trackerName);
			
			conditions.put("is_in_roadmap", false);
			
			db.update("newTracker.updateTrackers", conditions);
		}
		
		Map<String, Object> conditionProjectsTracker = Maps.newHashMap();
		conditionProjectsTracker.put("tracker_id", trackerId);
		db.delete("newTracker.delProjectsTrackers", conditionProjectsTracker);
		for (int i=0; i < projectIds.length; i++ ){
			conditionProjectsTracker.put("project_id", Integer.parseInt(projectIds[i]));	
			db.insert("newTracker.insertProjectsTrackers", conditionProjectsTracker);
		}
		
		Map<String, Object> conditionCustomFieldsTrackers = Maps.newHashMap();
		conditionCustomFieldsTrackers.put("tracker_id", trackerId);
		db.delete("newTracker.delCustomFieldsTrackers", conditionCustomFieldsTrackers);
		
		for (int i=0; i < customFieldsIds.length; i++ ){
			conditionCustomFieldsTrackers.put("custom_field_id", Integer.parseInt(customFieldsIds[i]));
			db.insert("newTracker.insertCustomFieldsTrackers", conditionCustomFieldsTrackers);
		}

	}
	
	/*
	 * 名前の唯一性チェック
	 */
	public LogicBean checkTracker() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("name", context.getParam().get("name"));
		
		if (StringUtils.isNotEmpty(context.getParam().get("trackersId"))) {
			conditions.put("tracker_id", StringUtils.toInt(context.getParam().get("trackersId")));
		}
		
		Integer count = db.queryo("newTracker.getTrackersName", conditions);
		
		if (count > 0) {
			logicBean.setResultFlg(false);
			logicBean.setResultCode("301430.tracker_name_error_result");
		}
		return logicBean;
	}
	
	public LogicBean getTrackerListCustomFields() throws SoftbankException {
		LogicBean trackerBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		List<Map<String, Object>> info = new ArrayList<Map<String, Object>>();
		conditions.put("name", context.getParam().get("input_date"));
		info = db.querys("newTracker.getTrackerListCustomFields", conditions);
		trackerBean.setData(info);
		return trackerBean;
	}
	
	public LogicBean getTrackerListProjects() throws SoftbankException {
		LogicBean trackerBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		List<Map<String, Object>> info = new ArrayList<Map<String, Object>>();
		conditions.put("name", context.getParam().get("input_date"));
		info = db.querys("newTracker.getTrackerListProjects", conditions);
		trackerBean.setData(info);
		return trackerBean;
	}
	private String[] sessionToString(String key) {
		String[] result = new String[]{} ;
		String[] temp = context.getParam().getList(key); 
		return StringUtils.isEmpty(temp) ? result : temp ;  
	}
}
