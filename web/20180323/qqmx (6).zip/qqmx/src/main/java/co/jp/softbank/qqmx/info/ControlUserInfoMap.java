package co.jp.softbank.qqmx.info;

import java.io.File;
import java.util.Map;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.DispRequestData;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.bean.Param;

public class ControlUserInfoMap {
	
	private static ControlUserInfoMap me;
	
	private static final String DEFAULT_PATH = "WEB-INF" + File.separator + "xml" + File.separator + "settings" + File.separator + "user-info.xml";
	
	private static String path;
	
	private Map<String, UserInfoData> userInfoMap;
	
	private UserInfoReader reader;
	
	private ControlUserInfoMap() throws SoftbankException {
		super();
		reader = new UserInfoReader(path);
		userInfoMap = reader.read();
	}
	
	public static ControlUserInfoMap getInstance() throws SoftbankException {
		synchronized (ControlUserInfoMap.class) {
			if (me == null) {
				me = new ControlUserInfoMap();
			}
		}
		return me;
	}
	
	public UserInfoData checkUserActivity(Param param) {
		if (!userInfoMap.containsKey(reader.createMapKey(param.get("userLogin"), param.get("userPwd")))) {
			return null;
		}
		return userInfoMap.get(reader.createMapKey(param.get("userLogin"), param.get("userPwd")));
	}
	
	public static void setPath(String path) {
		ControlUserInfoMap.path = path + DEFAULT_PATH;
	}

}
