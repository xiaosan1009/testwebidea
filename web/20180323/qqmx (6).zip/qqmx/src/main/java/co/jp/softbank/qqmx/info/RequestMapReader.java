package co.jp.softbank.qqmx.info;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.slf4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.DispRequestData;
import co.jp.softbank.qqmx.info.bean.FilterRequestData;
import co.jp.softbank.qqmx.info.bean.CmdRequestData;
import co.jp.softbank.qqmx.info.bean.DbRequestData;
import co.jp.softbank.qqmx.info.bean.DbRequestData.DbRequestDataType;
import co.jp.softbank.qqmx.info.bean.MessageRequestData;
import co.jp.softbank.qqmx.util.LogUtil;
import co.jp.softbank.qqmx.util.StringUtils;

public class RequestMapReader extends ReadXml {
	
	private Logger log = new LogUtil(this.getClass()).getLog();
	
	private static final String DISPS = "disps";
	
	private static final String DISP = "disp";
	
	private static final String CMDS = "cmds";
	
	private static final String CMD = "cmd";
	
	private static final String MESSAGES = "messages";
	
	private static final String MESSAGE = "message";
	
	private static final String DB = "db";
	
	private static final String FILTER = "filter";
	
	private static final String CODE = "code";
	
	private static final String JSP = "jsp";
	
	private static final String LOGIC = "logic";
	
	private static final String METHOD = "method";
	
	private static final String LOGOUT = "logout";
	
	private static final String CHECK = "check";
	
	private static final String IGNORE_ROLE = "ignore_role";
	
	private static final String IGNORE_ACCESS_LOG = "ignore_access_log";
	
	private static final String SUCCESS = "success";
	
	private static final String EACTION = "eaction";
	
	private static final String VALUE = "value";
	
	private static final String TYPE = "type";
	
	private static final String SQL = "sql";
	
	private static final String KEY = "key";
	
	private static final String PERMISSIONS = "permissions";

	public RequestMapReader(String path) throws SoftbankException {
		super(path);
	}
	
	public Map<String, DispRequestData> read() {
		if (docs == null || docs.size() == 0) {
			return null;
		}
		Map<String, DispRequestData> result = new HashMap<String, DispRequestData>();
		
		for (int i = 0; i < docs.size(); i++) {
			analyze(docs.get(i), result);
		}
		
		return result;
	}
	
	private void analyze(Document doc, Map<String, DispRequestData> result) {
		setDisps(doc, result);
	}
	
	private void setDisps(Document doc, Map<String, DispRequestData> result) {
		final NodeList dispsList = doc.getElementsByTagName(DISPS);
		if (dispsList == null || dispsList.getLength() == 0) {
			return;
		}
		
		final Element dispsElement = (Element)dispsList.item(0);
		if (dispsElement == null) {
			return;
		}
		
		final NodeList dispList = dispsElement.getElementsByTagName(DISP);
		
		for (int i = 0; i < dispList.getLength(); i++) {
			final Element dispElement = (Element)dispList.item(i);
			setDisp(dispElement, result);
		}
	}

	private void setDisp(Element dispElement, Map<String, DispRequestData> result) {
		final String dispCode = dispElement.getAttribute(CODE);
		DispRequestData dispData = new DispRequestData();
		dispData.setCode(dispCode);
		dispData.setJsp(dispElement.getAttribute(JSP));
		dispData.setLogic(dispElement.getAttribute(LOGIC));
		dispData.setPermissions(dispElement.getAttribute(PERMISSIONS));
		log.debug("EACTION = {}, dispcode = {}", Lists.newArrayList(StringUtils.toString(dispElement.getAttribute(EACTION)), dispCode).toArray());
		if (StringUtils.isNotEmpty(dispElement.getAttribute(EACTION)) && "true".equals(dispElement.getAttribute(EACTION))) {
			dispData.setEaction(true);
		}
		if (StringUtils.isEmpty(dispElement.getAttribute(LOGOUT))) {
			dispData.setLogout("0");
		} else {
			dispData.setLogout(dispElement.getAttribute(LOGOUT));
		}
		setCmds(dispElement, dispData);
		setFilter(dispElement, dispData);
		result.put(dispCode, dispData);
	}
	
	private void setCmds(Element dispElement, DispRequestData dispData) {
		final Map<String, CmdRequestData> cmdMap = new HashMap<String, CmdRequestData>();
		dispData.setCmdMap(cmdMap);
		final NodeList cmdsList = dispElement.getElementsByTagName(CMDS);
		if (cmdsList == null || cmdsList.getLength() == 0) {
			return;
		}
		final Element cmdsElement = (Element)cmdsList.item(0);
		final NodeList cmdList = cmdsElement.getElementsByTagName(CMD);
		if (cmdList == null || cmdList.getLength() == 0) {
			return;
		}
		
		for (int i = 0; i < cmdList.getLength(); i++) {
			final Element cmdElement = (Element)cmdList.item(i);
			setCmd(cmdElement, cmdMap);
		}
	}
	
	private void setMessages(Element cmdElement, CmdRequestData cmdData) {
		final Map<String, MessageRequestData> messagesMap = Maps.newHashMap();
		cmdData.setMessageMap(messagesMap);
		final NodeList messagesList = cmdElement.getElementsByTagName(MESSAGES);
		if (messagesList == null || messagesList.getLength() == 0) {
			return;
		}
		final Element messagesElement = (Element)messagesList.item(0);
		final NodeList messageList = messagesElement.getElementsByTagName(MESSAGE);
		if (messageList == null || messageList.getLength() == 0) {
			return;
		}
		
		for (int i = 0; i < messageList.getLength(); i++) {
			final Element messageElement = (Element)messageList.item(i);
			setMessage(messageElement, messagesMap);
		}
	}
	
	private void setCmd(Element cmdElement, Map<String, CmdRequestData> cmdMap) {
		CmdRequestData cmdData = new CmdRequestData();
		final String cmd = cmdElement.getAttribute(CODE);
		cmdData.setCode(cmd);
		cmdData.setJsp(cmdElement.getAttribute(JSP));
		cmdData.setMethod(cmdElement.getAttribute(METHOD));
		cmdData.setSuccess(cmdElement.getAttribute(SUCCESS));
		cmdData.setCheck(cmdElement.getAttribute(CHECK));
		cmdData.setPermissions(cmdElement.getAttribute(PERMISSIONS));
		cmdData.setIgnoreRole(StringUtils.toBoolean(cmdElement.getAttribute(IGNORE_ROLE)));
		cmdData.setIgnoreAccessLog(StringUtils.toBoolean(cmdElement.getAttribute(IGNORE_ACCESS_LOG)));
		if (StringUtils.isEmpty(cmdElement.getAttribute(LOGOUT))) {
			cmdData.setLogout("0");
		} else {
			cmdData.setLogout(cmdElement.getAttribute(LOGOUT));
		}
		setMessages(cmdElement, cmdData);
		setDbExecute(cmdElement, cmdData);
		cmdMap.put(cmd, cmdData);
	}
	
	private void setDbExecute(Element cmdElement, CmdRequestData cmdData) {
		final NodeList dbList = cmdElement.getElementsByTagName(DB);
		if (dbList == null || dbList.getLength() == 0) {
			return;
		}
		List<DbRequestData> dbRequestDatas = Lists.newArrayList();
		for (int i = 0; i < dbList.getLength(); i++) {
			final Element dbElement = (Element)dbList.item(i);
			dbRequestDatas.add(createDbExecute(dbElement));
		}
		cmdData.setDbList(dbRequestDatas);
	}
	
	private void setFilter(Element dispElement, DispRequestData dispData) {
		final NodeList filterList = dispElement.getElementsByTagName(FILTER);
		if (filterList == null || filterList.getLength() == 0) {
			return;
		}
		List<FilterRequestData> dbRequestDatas = Lists.newArrayList();
		for (int i = 0; i < filterList.getLength(); i++) {
			final Element dbElement = (Element)filterList.item(i);
			dbRequestDatas.add(createFilter(dbElement));
		}
		dispData.setFilterList(dbRequestDatas);
	}
	
	private void setMessage(Element messageElement, Map<String, MessageRequestData> messagesMap) {
		MessageRequestData messageData = new MessageRequestData();
		final String code = messageElement.getAttribute(CODE);
		messageData.setCode(code);
		messageData.setValue(messageElement.getAttribute(VALUE));
		messagesMap.put(code, messageData);
	}
	
	private DbRequestData createDbExecute(Element dbElement) {
		DbRequestData dbData = new DbRequestData();
		final String type = dbElement.getAttribute(TYPE);
		if (DbRequestDataType.item.getKey().equals(type)) {
			dbData.setType(DbRequestDataType.item);
		} else if (DbRequestDataType.insert.getKey().equals(type)) {
			dbData.setType(DbRequestDataType.insert);
		} else if (DbRequestDataType.update.getKey().equals(type)) {
			dbData.setType(DbRequestDataType.update);
		} else if (DbRequestDataType.delete.getKey().equals(type)) {
			dbData.setType(DbRequestDataType.delete);
		} else if (DbRequestDataType.page.getKey().equals(type)) {
			dbData.setType(DbRequestDataType.page);
		} else {
			dbData.setType(DbRequestDataType.list);
		}
		final String sql = dbElement.getAttribute(SQL);
		dbData.setSql(sql);
		final String key = dbElement.getAttribute(KEY);
		dbData.setKey(key);
		return dbData;
	}
	
	private FilterRequestData createFilter(Element filterElement) {
		FilterRequestData filterData = new FilterRequestData();
		final String method = filterElement.getAttribute(METHOD);
		filterData.setMethod(method);
		return filterData;
	}

}
