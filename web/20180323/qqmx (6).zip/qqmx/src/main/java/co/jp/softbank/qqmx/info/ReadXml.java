package co.jp.softbank.qqmx.info;

import java.io.File;
import java.io.FileFilter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.parsers.DocumentBuilder;
import javax.xml.parsers.DocumentBuilderFactory;

import org.w3c.dom.Document;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.util.StringUtils;

public class ReadXml {
	
	private static final String SUFFIX_XML = ".xml";
	
	protected List<Document> docs = new ArrayList<Document>();
	
	private DocumentBuilderFactory factory;
	
	public ReadXml(String path) throws SoftbankException {
		if (StringUtils.isNotEmpty(path)) {
			factory = DocumentBuilderFactory.newInstance();
			final File dir = new File(path);
			parse(dir);
		}
	}
	
	private void parse(File file) throws SoftbankException {
		try {
			if (file.isDirectory()) {
				final File[] files = file.listFiles(new FileFilter() {

					@Override
					public boolean accept(File pathname) {
						return pathname.getName().toLowerCase().contains(SUFFIX_XML) || pathname.isDirectory();
					}
				});
				for (int i = 0; i < files.length; i++) {
					parse(files[i]);
				}
			} else {
				final DocumentBuilder builder = factory.newDocumentBuilder();
				docs.add(builder.parse(file));
			}
		} catch (Exception e) {
			throw new SoftbankException(SoftbankExceptionType.SystemException, e);
		}
	}

}
