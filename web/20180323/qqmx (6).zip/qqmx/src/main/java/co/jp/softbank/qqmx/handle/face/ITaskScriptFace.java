package co.jp.softbank.qqmx.handle.face;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.task.face.ITaskContext;

public interface ITaskScriptFace {
    
    /**
     * @Description: 
     * @author king
     * @version V1.0
     * @param method method
     * @return value
     * @throws SoftbankException SoftbankException
     */
    Object execute(String project, String action, String model, String method) throws SoftbankException;
    
    /**
     * @Description: 
     * @author king
     * @since May 10, 2013 11:22:08 AM 
     * @version V1.0
     * @param value value
     * @param method method
     * @param params params
     * @return value
     * @throws SoftbankException SoftbankException
     */
    Object execute(String project, String action, String model, String method, Object... args) throws SoftbankException;
    
    void setHandlerMethod(ITaskContext context);
    
}
