package co.jp.softbank.qqmx.server.face;

import javax.websocket.Session;

import co.jp.softbank.qqmx.exception.SoftbankException;

import net.sf.json.JSONObject;

public interface ISocketLogicInterface {
	
	void recieve(Session sendSession, JSONObject message) throws SoftbankException;
	
	void connect(Session connSession) throws SoftbankException;
	
	void closed(Session connSession);

}
