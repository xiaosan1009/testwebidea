package co.jp.softbank.qqmx.info;

import java.io.File;

import org.slf4j.Logger;

import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.face.IExcelWriter;
import co.jp.softbank.qqmx.info.face.IExcelWriter.CellAnalysis;
import co.jp.softbank.qqmx.info.face.IExcelWriter.CellErrorStyle;
import co.jp.softbank.qqmx.info.face.IExcelWriter.CellFormat;
import co.jp.softbank.qqmx.info.face.IExcelWriter.CreateFileName;
import co.jp.softbank.qqmx.logic.bean.ExportFileInfo;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.CreateSequencesUtil;
import co.jp.softbank.qqmx.util.DateUtils;
import co.jp.softbank.qqmx.util.FileUtils;
import co.jp.softbank.qqmx.util.LogUtil;

public class ExcelWriterBase {
	
	protected Logger log = new LogUtil(this.getClass()).getLog();

	protected HttpContext context;
	
	protected ExportFileInfo fileInfo = new ExportFileInfo();
	
	protected CellAnalysis cellAnalysis;
	
	protected CellFormat cellFormat;
	
	protected CellErrorStyle cellErrorStyle;
	
	protected CreateFileName createFileName;
	
	public ExcelWriterBase(HttpContext context) throws SoftbankException {
		this(context, null);
	}
	
	public ExcelWriterBase(HttpContext context, CreateFileName createFileName) throws SoftbankException {
		this.createFileName = createFileName;
		String path = context.getContext().getRealPath(File.separator) + ConstantsUtil.Frame.EXPORT_PATH + DateUtils.getNow(DateUtils.FORMAT_YYYYMMDD_DASH);
		String fileName = null;
		if (createFileName == null) {
			fileName = CreateSequencesUtil.createID("export") + ".xlsx";
		} else {
			fileName = createFileName.create();
		}
		FileUtils.createFolder(path);
		File file = FileUtils.createFile(path + File.separator + fileName);
		this.context = context;
		
		String requestUrl = context.getRequest().getRequestURL().toString();
		requestUrl = requestUrl.substring(0, requestUrl.lastIndexOf("/") + 1);
		String urlPath = requestUrl + ConstantsUtil.Frame.EXPORT_PATH + DateUtils.getNow(DateUtils.FORMAT_YYYYMMDD_DASH) + File.separator + fileName;
		fileInfo.setUrlPath(urlPath);
		fileInfo.setRealPath(path);
		fileInfo.setFileName(fileName);
		fileInfo.setFile(file);
	}

	public void setContext(HttpContext context) {
		this.context = context;
	}
	
	public IExcelWriter setCellAnalysis(CellAnalysis cellAnalysis) {
		this.cellAnalysis = cellAnalysis;
		return (IExcelWriter)this;
	}
	
	public IExcelWriter setCellFormat(CellFormat format) {
		this.cellFormat = format;
		return (IExcelWriter)this;
	}
	
	public IExcelWriter setCellErrorStyle(CellErrorStyle cellErrorStyle) {
		this.cellErrorStyle = cellErrorStyle;
		return (IExcelWriter)this;
	}
	
	public IExcelWriter setCreateFileName(CreateFileName create) {
		this.createFileName = create;
		return (IExcelWriter)this;
	}
}
