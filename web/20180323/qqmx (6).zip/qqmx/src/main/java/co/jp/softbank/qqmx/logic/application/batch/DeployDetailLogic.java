package co.jp.softbank.qqmx.logic.application.batch;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.apache.commons.codec.binary.Base64;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.dao.common.IDbExecute;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.server.ExternalHttpServer;
import co.jp.softbank.qqmx.util.StringUtils;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class DeployDetailLogic {
	
	private IDbExecute db;
	
	public DeployDetailLogic(IDbExecute db) {
		this.db = db;
	}
	private static final int ZERO = 0 ;
	public void getDetaiInfo(String url,String sonarUrl,Integer deploy_id, Map<String, Object> map)  throws SoftbankException{
		boolean isJenkinsData = true ;
		// checkStyle
		ExternalHttpServer externalHttpServer = new ExternalHttpServer(null);
		String checkStyle = externalHttpServer.getStrUrl(url +"/checkstyleResult/api/json?depth=2");
		List<List<String>> filenameList =  Lists.newArrayList();
		List<Map<String, Map<String, Object>>> resultList =  Lists.newArrayList();
		if(!checkStyle.contains("<html>")){
			JSONObject csjson = JSONObject.fromObject(checkStyle);
			String warnings = csjson.get("warnings").toString();
			if(!warnings.equals("[]")){
				JSONArray array = JSONArray.fromObject(warnings); 
				for(int i = 0; i < array.size(); i++){
					String fileStr = array.get(i).toString();
					JSONObject filejson = JSONObject.fromObject(fileStr);
					String fileName = filejson.get("fileName").toString();
					int index = fileName.lastIndexOf("/");
					fileName = fileName.substring(index+1, fileName.length());
					String packageName = filejson.get("packageName").toString();
					if(filenameList.size() == 0){
						List<String> list = Lists.newArrayList();
						list.add(fileName);
						list.add(packageName);
						filenameList.add(list);
					}else{
						for(int j = 0;j<filenameList.size();j++){
							if(filenameList.get(j).get(0).equals(fileName) && filenameList.get(j).get(1).equals(packageName)){
								break;
							}else{
								if(j+1 == filenameList.size()){
									List<String> list = Lists.newArrayList();
									list.add(fileName);
									list.add(packageName);
									filenameList.add(list);
								}
							}
						}
					}
				}
				for(int j = 0;j<filenameList.size();j++){
					Map<String, Object> data = Maps.newHashMap();
					Map<String,Map<String, Object>> keyData =  Maps.newHashMap();
					int style_high_number = 0;
					int style_normal_number = 0; 
					int style_low_number = 0;
					String name =  filenameList.get(j).get(0);
					String packname =  filenameList.get(j).get(1);
					for(int i = 0; i < array.size(); i++){
						String fileStr = array.get(i).toString();
						JSONObject filejson = JSONObject.fromObject(fileStr);
						String fileName = filejson.get("fileName").toString();
						int index = fileName.lastIndexOf("/");
						fileName = fileName.substring(index+1, fileName.length());
						String packageName = filejson.get("packageName").toString();
						if(name.equals(fileName) && packname.equals(packageName)){
							String priority = filejson.get("priority").toString();
							if(priority.equals("NORMAL")){
								style_normal_number++;
							}else if(priority.equals("HIGH")){
								style_high_number++;
							}else{
								style_low_number++;
							}
							data.put("packageName", packageName);
						}
					}
					data.put("style_high_number", style_high_number);
					data.put("style_normal_number", style_normal_number);
					data.put("style_low_number", style_low_number);
					keyData.put(name, data);
					resultList.add(keyData);
				}
				System.out.println(resultList);
			}
		} else {
			isJenkinsData = false ;
		}
		
		//　findbugs
		String findbugs = externalHttpServer.getStrUrl(url +"/findbugsResult/api/json?depth=2");
		if(!findbugs.contains("<html>")){
			JSONObject fbjson = JSONObject.fromObject(findbugs);
			String warnings = fbjson.get("warnings").toString();
			if(!warnings.equals("[]")){
				JSONArray array = JSONArray.fromObject(warnings); 
				for(int i = 0; i < array.size(); i++){
					String fileStr = array.get(i).toString();
					JSONObject filejson = JSONObject.fromObject(fileStr);
					String fileName = filejson.get("fileName").toString();
					int index = fileName.lastIndexOf("/");
					fileName = fileName.substring(index+1, fileName.length());
					String packageName = filejson.get("packageName").toString();
					if(filenameList.size() == 0){
						List<String> list = Lists.newArrayList();
						list.add(fileName);
						list.add(packageName);
						filenameList.add(list);
					}else{
						for(int j = 0;j<filenameList.size();j++){
							if(filenameList.get(j).get(0).equals(fileName) && filenameList.get(j).get(1).equals(packageName)){
								break;
							}else{
								if(j+1 == filenameList.size()){
									List<String> list = Lists.newArrayList();
									list.add(fileName);
									list.add(packageName);
									filenameList.add(list);
								}
							}
						}
					}
				}
				for(int j = 0;j<filenameList.size();j++){
					Map<String, Object> data = Maps.newHashMap();
					Map<String,Map<String, Object>> keyData =  Maps.newHashMap();
					int bugs_high_number = 0;
					int bugs_normal_number = 0; 
					int bugs_low_number = 0;
					String name =  filenameList.get(j).get(0);
					String packname =  filenameList.get(j).get(1);
					for(int i = 0; i < array.size(); i++){
						String fileStr = array.get(i).toString();
						JSONObject filejson = JSONObject.fromObject(fileStr);
						String fileName = filejson.get("fileName").toString();
						int index = fileName.lastIndexOf("/");
						fileName = fileName.substring(index+1, fileName.length());
						String packageName = filejson.get("packageName").toString();
						if(name.equals(fileName) && packname.equals(packageName)){
							String priority = filejson.get("priority").toString();
							if(priority.equals("NORMAL")){
								bugs_normal_number++;
							}else if(priority.equals("HIGH")){
								bugs_high_number++;
							}else{
								bugs_low_number++;
							}
							data.put("packageName", packageName);
						}
					}
					boolean flag = true;
					for(int n = 0; n < resultList.size();n++){
						if(resultList.get(n).get(name) != null){
							data = resultList.get(n).get(name);
							flag = false;
						}
					}
					data.put("bugs_high_number", bugs_high_number);
					data.put("bugs_normal_number", bugs_normal_number);
					data.put("bugs_low_number", bugs_low_number);
					keyData.put(name, data);
					if(flag){
						resultList.add(keyData);
					}
				}
				System.out.println(resultList);
			}
		} else {
			isJenkinsData = false ;
		}
		
		// junit
		String junit = externalHttpServer.getStrUrl(url + "/testReport/api/json");
		if(!junit.contains("<html>")){
			JSONObject junitJson = JSONObject.fromObject(junit);
			String suites = "";
			if(junitJson.has("childReports")){
				String childReport  = junitJson.get("childReports").toString();
				JSONObject childReportJson = JSONObject.fromObject(childReport.substring(1, childReport.length()-1));
				JSONObject resultJson = JSONObject.fromObject(childReportJson.get("child").toString());
				String detailUrl = resultJson.get("url").toString();
				String junitDetail = externalHttpServer.getStrUrl(detailUrl + "testReport/api/json?depth=2");
				JSONObject detailJson = JSONObject.fromObject(junitDetail);
				suites = detailJson.get("suites").toString();
			}else{
				suites = junitJson.get("suites").toString();
			}
			if(!suites.equals("[]")){
				JSONArray array = JSONArray.fromObject(suites); 
				for(int i = 0; i < array.size(); i++){
					String fileStr = array.get(i).toString();
					JSONObject filejson = JSONObject.fromObject(fileStr);
					String cases = filejson.get("cases").toString();
					JSONArray caseArr = JSONArray.fromObject(cases); 
					for(int n = 0; n < caseArr.size(); n++){
						String caseStr = caseArr.get(n).toString();
						JSONObject casejson = JSONObject.fromObject(caseStr);
						String fileName = casejson.get("className").toString();
						int index = fileName.lastIndexOf(".");
						String packageName = fileName.substring(0, index);
						fileName = fileName.substring(index+1, fileName.length()) +".java";
						if(filenameList.size() == 0){
							List<String> list = Lists.newArrayList();
							list.add(fileName);
							list.add(packageName);
							filenameList.add(list);
						}else{
							for(int j = 0;j<filenameList.size();j++){
								if(filenameList.get(j).get(0).equals(fileName) && filenameList.get(j).get(1).equals(packageName)){
									break;
								}else{
									if(j+1 == filenameList.size()){
										List<String> list = Lists.newArrayList();
										list.add(fileName);
										list.add(packageName);
										filenameList.add(list);
									}
								}
							}
						}
					}
				}
				for(int j = 0;j<filenameList.size();j++){
					Map<String, Object> data = Maps.newHashMap();
					Map<String,Map<String, Object>> keyData =  Maps.newHashMap();
					String name =  filenameList.get(j).get(0);
					String packname =  filenameList.get(j).get(1);
					int skipCount =0;
					int passCount =0;
					int failCount = 0;
					for(int i = 0; i < array.size(); i++){
						String fileStr = array.get(i).toString();
						JSONObject filejson = JSONObject.fromObject(fileStr);
						String cases = filejson.get("cases").toString();
						JSONArray caseArr = JSONArray.fromObject(cases); 
						for(int n = 0; n < caseArr.size(); n++){
							String caseStr = caseArr.get(n).toString();
							JSONObject casejson = JSONObject.fromObject(caseStr);
							String fileName = casejson.get("className").toString();
							int index = fileName.lastIndexOf(".");
							fileName = fileName.substring(index+1, fileName.length()) +".java";
							String packageName = casejson.get("className").toString().substring(0, index);
							if(name.equals(fileName) && packname.equals(packageName)){
								String status = casejson.get("status").toString();
								if(status.equals("PASSED")){
									passCount++;
								}else if(status.equals("SKIPPED")){
									skipCount++;
								}else if(status.equals("FAILED")){
									failCount++;
								}
								data.put("packageName", packageName);
							}
						}
						boolean flag = true;
						for(int n = 0; n < resultList.size();n++){
							if(resultList.get(n).get(name) != null){
								data = resultList.get(n).get(name);
								flag = false;
							}
						}
						
						data.put("passCount", passCount);
						data.put("doCount", skipCount+passCount+failCount);
						keyData.put(name, data);
						if(flag){
							resultList.add(keyData);
						}
					}
				}
				System.out.println(resultList);
			}
		} else {
			isJenkinsData = false ;
		}
		
		// jacoco
		for(int j = 0;j<filenameList.size();j++){
			String name =  filenameList.get(j).get(0);
			String packname =  filenameList.get(j).get(1);
			if(name.contains(".java")){
				String filename = name.substring(0,name.indexOf("."));
				String jacocoUrl = url + "/jacoco/"+packname+"/"+filename+"/api/json";
				String jacoco = externalHttpServer.getStrUrl(jacocoUrl);
				if(!jacoco.contains("<html>")){
					Map<String, Object> data = Maps.newHashMap();
					Map<String,Map<String, Object>> keyData =  Maps.newHashMap();
					data.put("packageName", packname);
					JSONObject jacocoJson = JSONObject.fromObject(jacoco);
					String branchCoverage  = jacocoJson.get("branchCoverage").toString();
					String instructionCoverage  = jacocoJson.get("instructionCoverage").toString();
					JSONObject branchJson = JSONObject.fromObject(branchCoverage);
					Integer branchCovered  = Integer.valueOf(branchJson.get("covered").toString());
					Integer branchTotal = Integer.valueOf(branchJson.get("total").toString());
					
					JSONObject instructionJson = JSONObject.fromObject(instructionCoverage);
					Integer instructionCovered  = Integer.valueOf(instructionJson.get("covered").toString());
					Integer instructionTotal  = Integer.valueOf(instructionJson.get("total").toString());
					boolean flag = true;
					for(int n = 0; n < resultList.size();n++){
						if(resultList.get(n).get(name) != null){
							data = resultList.get(n).get(name);
							flag = false;
						}
					}
					data.put("branchCovered", branchCovered);
					data.put("branchTotal", branchTotal);
					data.put("instructionCovered", instructionCovered);
					data.put("instructionTotal", instructionTotal);
					keyData.put(name, data);
					if(flag){
						resultList.add(keyData);
					}
				} else {
					isJenkinsData = false ;
				}
				
			}
		} 
		
		System.out.println(resultList);
		// sonarQube
		String sonarqube_url = StringUtils.toString(map.get("sonarqube_url"));
		String sonarUrl1 = sonarqube_url + "/api/measures/component_tree?baseComponentKey="+ sonarUrl +"&metricKeys=duplicated_lines_density,duplicated_lines,lines,complexity,ncloc,sqale_index"
				+ ",lines_to_cover,line_coverage,uncovered_conditions,branch_coverage,"
				+ "tests,test_failures,test_errors,skipped_tests";
		if(sonarUrl.length()!=0){
			
			Map<String, String> deployUrlInfo = new HashMap<String, String>();
			if ( map.get("sonarqube_user") == null ) {
				deployUrlInfo.put("Authorization", "Basic Y2hhcmdpbmc6cGFzc3dvcmQ=");
			} else {
				String userInfo = StringUtils.toString(map.get("sonarqube_user")) + ":" + StringUtils.toString("sonarqube_password");
				String user = "Basic " + Base64.encodeBase64String(userInfo.getBytes());
				deployUrlInfo.put("Authorization", user);
			}
			String sonarStr = externalHttpServer.getStrUrl(sonarUrl1, deployUrlInfo);
			if(!sonarStr.contains("<html>")){
				JSONObject js1 = new JSONObject();
				String strjs1 = "";
				js1 = JSONObject.fromObject(sonarStr);
				strjs1 = StringUtils.toString(js1.get("components"));
				
				JSONArray sonarArr = JSONArray.fromObject(strjs1); 
				for(int i = 0; i < sonarArr.size(); i++){
					String obj = sonarArr.get(i).toString();
					JSONObject objjson = JSONObject.fromObject(obj);
					String fileName = objjson.get("name").toString();
					if(objjson.get("qualifier") == null  || objjson.get("qualifier").toString().equals("DIR") || objjson.get("qualifier").toString().equals("BRC") ){
						continue;
					}
					String keyurl = objjson.get("key").toString();
					int index = keyurl.lastIndexOf(":");
					int lastindex = keyurl.lastIndexOf("/");
					String packageName = keyurl.substring(index+1,lastindex);
					packageName = packageName.replace("/", ".");
					if(filenameList.size() == 0){
						List<String> list = Lists.newArrayList();
						list.add(fileName);
						list.add(packageName);
						filenameList.add(list);
					}else{
						for(int j = 0;j<filenameList.size();j++){
							if(filenameList.get(j).get(0).equals(fileName)){
								break;
							}else{
								if(j+1 == filenameList.size()){
									List<String> list = Lists.newArrayList();
									list.add(fileName);
									list.add(packageName);
									filenameList.add(list);
								}
							}
						}
					}
				}
				for(int j = 0;j<filenameList.size();j++){
					Map<String, Object> data = Maps.newHashMap();
					Map<String,Map<String, Object>> keyData =  Maps.newHashMap();
					int ncloc = 0;
					int complexity = 0; 
					int duplicated_lines = 0;
					int lines = 0;
					Integer s = 0;
					Float duplications = null;
					
					int skippedTest = ZERO;
					int failureTest = ZERO;
					int totalTest = ZERO;
					int errorTest = ZERO;
					

					float line_coverage = 0f;
					int lines_to_cover = ZERO ;

					float branch_coverage = 0f;
					int branch_to_cover = ZERO ;
					int branch_uncovered = ZERO;
					int branch_covered = ZERO;
					
					String name =  filenameList.get(j).get(0);
					String packname =  filenameList.get(j).get(1);
					for(int i = 0; i < sonarArr.size(); i++){
						String obj = sonarArr.get(i).toString();
						JSONObject objjson = JSONObject.fromObject(obj);
						String fileName = objjson.get("name").toString();
						if(name.equals(fileName)){
							if(objjson.get("qualifier") == null  || objjson.get("qualifier").toString().equals("DIR") || objjson.get("qualifier").toString().equals("BRC") ){
								continue;
							}
							String msr = objjson.get("measures").toString();
							JSONArray msrArr = JSONArray.fromObject(msr); 
							for(int n = 0; n < msrArr.size(); n++){
								JSONObject msrjson = JSONObject.fromObject(msrArr.get(n).toString());
								String key = msrjson.get("metric").toString();
								if(key.equals("sqale_index")){
									s = StringUtils.toInt(msrjson.get("value")) * 60;
								}else if(key.equals("duplicated_lines_density")){
									duplications = Float.valueOf(msrjson.get("value").toString());
								}else if(key.equals("ncloc")){
									String number = msrjson.get("value").toString();
									ncloc = Integer.valueOf(number);
								}else if(key.equals("complexity")){
									String number = msrjson.get("value").toString();
									complexity = Integer.valueOf(number);
								}else if(key.equals("duplicated_lines")){
									String duplicatedLines = msrjson.get("value").toString();
									duplicated_lines = Integer.valueOf(duplicatedLines);
								}else if(key.equals("lines")){
									String l = msrjson.get("value").toString();
									lines = Integer.valueOf(l);
								}
								// 「Jenkins」から取得できない場合
								else if("line_coverage".equals(key) && !isJenkinsData){
									line_coverage =  Float.valueOf(msrjson.get("value").toString());
								}
								else if("branch_coverage".equals(key) && !isJenkinsData){
									branch_coverage = Float.valueOf(msrjson.get("value").toString());
								}
								else if("lines_to_cover".equals(key) && !isJenkinsData){
									lines_to_cover = StringUtils.toInt(msrjson.get("value"));
								}
								else if("uncovered_conditions".equals(key) && !isJenkinsData){
									branch_uncovered = StringUtils.toInt(msrjson.get("value"));
								}
								else if("tests".equals(key) && !isJenkinsData){
									totalTest = StringUtils.toInt(msrjson.get("value"));
								}
								else if("test_failures".equals(key) && !isJenkinsData){
									failureTest = StringUtils.toInt(msrjson.get("value"));
								}
								else if("test_errors".equals(key) && !isJenkinsData){
									errorTest = StringUtils.toInt(msrjson.get("value"));
								}
								else if("skipped_tests".equals(key) && !isJenkinsData){
									skippedTest = StringUtils.toInt(msrjson.get("value"));
								}
								
								data.put("packageName", packname);
							}
							data.put("ncloc", ncloc);
							data.put("complexity", complexity);
							data.put("technical_debt", s);
							data.put("duplications", duplications);
							data.put("duplicated_lines", duplicated_lines);
							data.put("lines", lines);
							
							if(!isJenkinsData){
								data.put("instructionCovered", Math.round(lines_to_cover * line_coverage / 100));
								data.put("instructionTotal", lines_to_cover);
								
								if(branch_coverage == 100 || branch_uncovered == 0){
									branch_covered = 0 ;
								} else {
									branch_to_cover = Math.round(branch_uncovered / ((100f - branch_coverage) / 100) ) ;
									branch_covered = Math.round(branch_to_cover * branch_coverage / 100);
								}
							
								data.put("branchCovered", branch_covered);
								data.put("branchTotal", branch_to_cover);
								
								data.put("doCount", totalTest);
								data.put("passCount", totalTest - errorTest - skippedTest - failureTest);
							}
							break ;
						}
						boolean flag = true;
						for(int n = 0; n < resultList.size();n++){
							if(resultList.get(n).get(name) != null){
								data = resultList.get(n).get(name);
								flag = false;
							}
						}
						
						keyData.put(name, data);
						if(flag){
							resultList.add(keyData);
						}
					}
				}
			}
		}
		
		System.out.println(resultList);
		for(int j = 0; j<resultList.size();j++){
			Map<String, Object> conditions = Maps.newHashMap();
			Map<String,Map<String, Object>> keyData = resultList.get(j);
			for(Map.Entry<String,Map<String, Object>> entry : keyData.entrySet()){
				String filename = entry.getKey().toString();
				conditions.put("file_name", filename);
				conditions.put("deploy_id", deploy_id);
				Map<String, Object> data = entry.getValue();
				conditions.put("package_name", data.get("packageName"));
				conditions.put("style_high_number", data.get("style_high_number"));
				conditions.put("style_normal_number", data.get("style_normal_number"));
				conditions.put("style_low_number", data.get("style_low_number"));
				conditions.put("bugs_high_number", data.get("bugs_high_number"));
				conditions.put("bugs_normal_number", data.get("bugs_normal_number"));
				conditions.put("bugs_low_number", data.get("bugs_low_number"));
				conditions.put("doCount", data.get("doCount"));
				conditions.put("successCount", data.get("passCount"));
				conditions.put("steps", data.get("ncloc"));
				conditions.put("complexity", data.get("complexity"));
				conditions.put("duplications", data.get("duplications"));
				conditions.put("duplicated_lines", data.get("duplicated_lines"));
				conditions.put("lines", data.get("lines"));
				conditions.put("technical_debt", data.get("technical_debt"));
				conditions.put("branch_covered", data.get("branchCovered"));
				conditions.put("branch_total", data.get("branchTotal"));
				conditions.put("instruction_covered", data.get("instructionCovered"));
				conditions.put("instruction_total", data.get("instructionTotal"));
				db.insert("deploy.insertDeployDetailInfo",conditions);
			}
		}
		System.out.println(resultList);
	}
}
