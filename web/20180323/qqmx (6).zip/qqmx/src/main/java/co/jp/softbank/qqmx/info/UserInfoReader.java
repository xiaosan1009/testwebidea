package co.jp.softbank.qqmx.info;

import java.util.HashMap;
import java.util.Map;

import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.UserInfoData;

public class UserInfoReader extends ReadXml {

	public UserInfoReader(String path) throws SoftbankException {
		super(path);
	}
	
	public Map<String, UserInfoData> read() {
		if (docs == null || docs.size() == 0) {
			return null;
		}
		Map<String, UserInfoData> result = new HashMap<String, UserInfoData>();
		
		for (int i = 0; i < docs.size(); i++) {
			analyze(docs.get(i), result);
		}
		
		return result;
	}
	
	private void analyze(Document doc, Map<String, UserInfoData> result) {
		final NodeList usersList = doc.getElementsByTagName("users");
		if (usersList == null || usersList.getLength() == 0) {
			return;
		}
		
		final Element usersElement = (Element)usersList.item(0);
		if (usersElement == null) {
			return;
		}
		
		final NodeList userList = usersElement.getElementsByTagName("user");
		
		for (int i = 0; i < userList.getLength(); i++) {
			UserInfoData data = new UserInfoData();
			final Element userElement = (Element)userList.item(i);
			final String login = userElement.getAttribute("login");
			final String pwd = userElement.getAttribute("pwd");
			final String name = userElement.getAttribute("name");
			data.setLogin(login);
			data.setPwd(pwd);
			data.setName(name);
			result.put(createMapKey(login, pwd), data);
		}
	}
	
	public String createMapKey(String login, String pwd) {
		return "l=" + login + "p=" + pwd;
	}

}
