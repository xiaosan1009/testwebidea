package co.jp.softbank.qqmx.logic.application.reform;


import java.math.BigDecimal;
import java.net.URLDecoder;
import java.text.DateFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.ControlDbMemory;
import co.jp.softbank.qqmx.util.StringUtils;

public class TuChartBarListLogic extends TuLogicBase {
	private static final String SISAKUSUU = "施策数" ;
	private static final String KINGAKU = "金額" ;
	private static final String JINKOU = "人工数" ;
	private static final String LEVEL1 = "level1" ;
	private static final String LEVEL2 = "level2" ;
	private static final String LEVEL3 = "level3" ;

	public void getOkureSuuiInfor() throws SoftbankException, Exception {
		// パラメータ
		Map<String, Object> conditions = Maps.newHashMap();
		String datepickerStart = context.getParam().get("datepickerStart");
		String datepickerEnd = context.getParam().get("datepickerEnd");
		
//		String budget_artificial_flag = context.getParam().get("budget_artificial_flag");
		// 統括
		String headquartersId = null;
		if (StringUtils.isEmpty(context.getParam().get("headquartersId"))) {
			headquartersId = "9898";
		} else {
			headquartersId = context.getParam().get("headquartersId");
		}
		// 本部
		String divisionId = null;
		if (StringUtils.isEmpty(context.getParam().get("divisionId"))) {
			divisionId = "9898";
		} else {
			divisionId = context.getParam().get("divisionId");
		}
		// 統括部
		String departmentId = null;
		if (StringUtils.isEmpty(context.getParam().get("departmentId"))) {
			departmentId = "9898";
		} else {
			departmentId = context.getParam().get("departmentId");
		}
		// 部
		String regionId = null;
		if (StringUtils.isEmpty(context.getParam().get("regionId"))) {
			regionId = "9898";
		} else {
			regionId = context.getParam().get("regionId");
		}
		// 全従業員/社員/業託
		String dispartch = null;
		if (!StringUtils.isEmpty(context.getParam().get("dispartchId"))) {
			dispartch = URLDecoder.decode(context.getParam().get("dispartchId"),"utf-8");
		}
		// 新規/既存
		String category = null;
		if (!StringUtils.isEmpty(context.getParam().get("categoryId"))) {
			category = URLDecoder.decode(context.getParam().get("categoryId"),"utf-8");
		}
		
		// 人工数/金額/施策数
		String statusId = null;
		if (!StringUtils.isEmpty(context.getParam().get("statusId"))) {
			statusId = URLDecoder.decode(context.getParam().get("statusId"),"utf-8");
		} 
		String study = null;
		boolean isHistory = false ;
		if (!StringUtils.isEmpty(context.getParam().get("tuStudy"))) {
			if ("9898".equals(context.getParam().get("tuStudy"))) {
				study = ControlDbMemory.getInstance().getTuNewDate();
			} else {
				isHistory = true ;
				study = context.getParam().get("tuStudy");
			}
		}
		conditions.put("study", study);
		conditions.put("headquarters_Id", Integer.parseInt(headquartersId));
		conditions.put("division_id", Integer.parseInt(divisionId));
		conditions.put("department_id", Integer.parseInt(departmentId));
		conditions.put("region_id", Integer.parseInt(regionId));
		conditions.put("dispartch", dispartch);
		conditions.put("category", category);
		if("".equals(statusId) || statusId == null || "人工数".equals(statusId)){
			conditions.put("artificial_unit", "人工");
		}
		
		conditions.put("statusId", statusId);
		// 開始日
		List<Map<String, Object>> minDay = db.querys("tuChartBar.getShisakuMinDay", conditions);

		SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
		if(minDay.isEmpty()|| StringUtils.isEmpty((Date) minDay.get(0).get("start_date"))){
			return ;
		}
		Date startDay = (Date) minDay.get(0).get("start_date");
		Double budget =  ((BigDecimal) minDay.get(0).get("plan_budget")).doubleValue() ;
		Double artificial = ((BigDecimal) minDay.get(0).get("plan_artificial")).doubleValue() ;
		
		// 今日
		Date today = isNowOrHistory(isHistory, study);
		// DB 開始日と画面の開始日を比較する
		if(!StringUtils.isEmpty(datepickerStart)){
			Date datepickerStartDt = fmt.parse(datepickerStart.replace("/", "-")) ;
			if(datepickerStartDt.compareTo(startDay) > 0){
				startDay = datepickerStartDt ;
			}
		}
		//今日と画面の終了日を比較する
		if(!StringUtils.isEmpty(datepickerEnd)){
			Date datepickerEndDt = fmt.parse(datepickerEnd.replace("/", "-")) ;
			if(today.compareTo(datepickerEndDt) > 0){
				today = datepickerEndDt ;
			}
		}
		int kikan = daysBetween(today, startDay);
		// 週
		// 日
		List<String> kikanList = Lists.newArrayList();
		// 件数
		String startDayStr = fmt.format(startDay) ;
		kikanList.add( startDayStr);
		

		Calendar calTemp = Calendar.getInstance();
		calTemp.setTime(startDay);
		

		for (int i = 1; i <= kikan; i++) {
			calTemp.add(Calendar.DAY_OF_MONTH, 1);
			Date dateTemp = calTemp.getTime();
			String date = fmt.format(dateTemp) ;
			kikanList.add(date);
		}
		Map<String, Object> listMap = Maps.newHashMap() ;
		dataProcess(kikanList, kikanList, "day", listMap,budget,artificial);
		listMap.put("dateData", kikanList);
		
		context.getResultBean().setData(listMap);

	}
	
	public void getWeekInfo() throws SoftbankException, Exception {

		// パラメータ
		Map<String, Object> conditions = Maps.newHashMap();
		String datepickerStart = context.getParam().get("datepickerStart");
		String datepickerEnd = context.getParam().get("datepickerEnd");
		// 統括
		String headquartersId = null;
		if (StringUtils.isEmpty(context.getParam().get("headquartersId"))) {
			headquartersId = "9898";
		} else {
			headquartersId = context.getParam().get("headquartersId");
		}
		// 本部
		String divisionId = null;
		if (StringUtils.isEmpty(context.getParam().get("divisionId"))) {
			divisionId = "9898";
		} else {
			divisionId = context.getParam().get("divisionId");
		}
		// 統括部
		String departmentId = null;
		if (StringUtils.isEmpty(context.getParam().get("departmentId"))) {
			departmentId = "9898";
		} else {
			departmentId = context.getParam().get("departmentId");
		}
		// 部
		String regionId = null;
		if (StringUtils.isEmpty(context.getParam().get("regionId"))) {
			regionId = "9898";
		} else {
			regionId = context.getParam().get("regionId");
		}
		// 全従業員/社員/業託
		String dispartch = null;
		if (!StringUtils.isEmpty(context.getParam().get("dispartchId"))) {
			dispartch = URLDecoder.decode(context.getParam().get("dispartchId"),"utf-8");
		}
		// 新規/既存
		String category = null;
		if (!StringUtils.isEmpty(context.getParam().get("categoryId"))) {
			category = URLDecoder.decode(context.getParam().get("categoryId"),"utf-8");
		}
		// 人工数/金額/施策数
		String statusId = null;
		if (!StringUtils.isEmpty(context.getParam().get("statusId"))) {
			statusId = URLDecoder.decode(context.getParam().get("statusId"),"utf-8");
		} 
		String study = null;
		boolean isHistory = false ;
		if (!StringUtils.isEmpty(context.getParam().get("tuStudy"))) {
			if ("9898".equals(context.getParam().get("tuStudy"))) {
				study = ControlDbMemory.getInstance().getTuNewDate();
			} else {
				isHistory = true ;
				study = context.getParam().get("tuStudy");
			}
		}
		conditions.put("study", study);
		conditions.put("headquarters_Id", Integer.parseInt(headquartersId));
		conditions.put("division_id", Integer.parseInt(divisionId));
		conditions.put("department_id", Integer.parseInt(departmentId));
		conditions.put("region_id", Integer.parseInt(regionId));
		conditions.put("dispartch", dispartch);
		conditions.put("category", category);
		if("".equals(statusId) || statusId == null || "人工数".equals(statusId)){
			conditions.put("artificial_unit", "人工");
		}
		// 開始日
		List<Map<String, Object>> minDay = db.querys("tuChartBar.getShisakuMinDay", conditions);
		SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");

		// 今日
		Date today = isNowOrHistory(isHistory, study);

		if(minDay.isEmpty()|| StringUtils.isEmpty((Date) minDay.get(0).get("start_date"))){
			return ;
		}
		Date startDay = (Date) minDay.get(0).get("start_date");
		Double budget =  ((BigDecimal) minDay.get(0).get("plan_budget")).doubleValue() ;
		Double artificial = ((BigDecimal) minDay.get(0).get("plan_artificial")).doubleValue() ;
		// DB 開始日と画面の開始日を比較する
		if(!StringUtils.isEmpty(datepickerStart)){
			Date datepickerStartDt = fmt.parse(datepickerStart.replace("/", "-")) ;
			if(datepickerStartDt.compareTo(startDay) > 0){
				startDay = datepickerStartDt ;
			}
		}
		//今日と画面の終了日を比較する
		if(!StringUtils.isEmpty(datepickerEnd)){
			Date datepickerEndDt = fmt.parse(datepickerEnd.replace("/", "-")) ;
			if(today.compareTo(datepickerEndDt) > 0){
				today = datepickerEndDt ;
			}
		}

		int kikan = daysBetween(today, startDay);
		int weeks = weeksBetween(today, startDay) ;
		// 週
		List<String> kikanWeeksList = Lists.newArrayList() ;
		// 日
		List<String> kikanList = Lists.newArrayList();
		// 件数
		String startDayStr = fmt.format(startDay) ;
		kikanList.add( startDayStr);
		
		kikanWeeksList.add( startDayStr);

		Calendar calTemp = Calendar.getInstance();
		calTemp.setTime(startDay);
		

		Calendar calTempWeek = Calendar.getInstance();
		calTempWeek.setTime(startDay);
		for (int i = 1; i <= kikan; i++) {
			calTemp.add(Calendar.DAY_OF_MONTH, 1);
			Date dateTemp = calTemp.getTime();
			String date = fmt.format(dateTemp) ;
			kikanList.add(date);
		}
		calTempWeek.setFirstDayOfWeek(Calendar.MONDAY);
		for (int i = 0; i <  weeks; i++) {
			calTempWeek.add(Calendar.WEEK_OF_YEAR, 1);
			calTempWeek.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
//			kikanList.add(String.valueOf(cal.get(Calendar.YEAR)).substring(2,4)+"-"+(cal.get(Calendar.MONTH)+1)+"-"+(cal.get(Calendar.DAY_OF_MONTH)+1)) ;
			
			Date dateTemp = calTempWeek.getTime();
			String date = fmt.format(dateTemp) ;
			if(	today.compareTo(dateTemp)>= 0){
				kikanWeeksList.add(date);
			}
			
		}
		Map<String, Object> listMap = Maps.newHashMap() ;
		dataProcess(kikanList, kikanWeeksList, "week", listMap,budget,artificial);
		listMap.put("dateData", kikanWeeksList);
		
		context.getResultBean().setData(listMap);

	
	}
	
	public void getMonthInfo() throws SoftbankException, Exception {

		// パラメータ
		Map<String, Object> conditions = Maps.newHashMap();
		String datepickerStart = context.getParam().get("datepickerStart");
		String datepickerEnd = context.getParam().get("datepickerEnd");

		

		SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
		// 統括
		String headquartersId = null;
		if (StringUtils.isEmpty(context.getParam().get("headquartersId"))) {
			headquartersId = "9898";
		} else {
			headquartersId = context.getParam().get("headquartersId");
		}
		// 本部
		String divisionId = null;
		if (StringUtils.isEmpty(context.getParam().get("divisionId"))) {
			divisionId = "9898";
		} else {
			divisionId = context.getParam().get("divisionId");
		}
		// 統括部
		String departmentId = null;
		if (StringUtils.isEmpty(context.getParam().get("departmentId"))) {
			departmentId = "9898";
		} else {
			departmentId = context.getParam().get("departmentId");
		}
		// 部
		String regionId = null;
		if (StringUtils.isEmpty(context.getParam().get("regionId"))) {
			regionId = "9898";
		} else {
			regionId = context.getParam().get("regionId");
		}
		// 全従業員/社員/業託
		String dispartch = null;
		if (!StringUtils.isEmpty(context.getParam().get("dispartchId"))) {
			dispartch = URLDecoder.decode(context.getParam().get("dispartchId"),"utf-8");
		}
		// 新規/既存
		String category = null;
		if (!StringUtils.isEmpty(context.getParam().get("categoryId"))) {
			category = URLDecoder.decode(context.getParam().get("categoryId"),"utf-8");
		}
		// 人工数/金額/施策数
		String statusId = null;
		if (!StringUtils.isEmpty(context.getParam().get("statusId"))) {
			statusId = URLDecoder.decode(context.getParam().get("statusId"),"utf-8");
		} 
		boolean isHistory = false ;
		String study = null;
		if (!StringUtils.isEmpty(context.getParam().get("tuStudy"))) {
			if ("9898".equals(context.getParam().get("tuStudy"))) {
				study = ControlDbMemory.getInstance().getTuNewDate();
			} else {
				isHistory = true ;
				study = context.getParam().get("tuStudy");
			}
		}
		conditions.put("study", study);
		conditions.put("headquarters_Id", Integer.parseInt(headquartersId));
		conditions.put("division_id", Integer.parseInt(divisionId));
		conditions.put("department_id", Integer.parseInt(departmentId));
		conditions.put("region_id", Integer.parseInt(regionId));
		conditions.put("dispartch", dispartch);
		conditions.put("category", category);
		if("".equals(statusId) || statusId == null || "人工数".equals(statusId)){
			conditions.put("artificial_unit", "人工");
		}
		// 今日
		Date today = isNowOrHistory(isHistory, study);
		// 開始日
		List<Map<String, Object>> minDay = db.querys("tuChartBar.getShisakuMinDay", conditions);
		if(minDay.isEmpty()|| StringUtils.isEmpty((Date) minDay.get(0).get("start_date"))){
			return ;
		}
		Double budget =  ((BigDecimal) minDay.get(0).get("plan_budget")).doubleValue() ;
		Double artificial = ((BigDecimal) minDay.get(0).get("plan_artificial")).doubleValue() ;
		Date startDay = (Date) minDay.get(0).get("start_date");
		// DB 開始日と画面の開始日を比較する
		if(!StringUtils.isEmpty(datepickerStart)){
			Date datepickerStartDt = fmt.parse(datepickerStart.replace("/", "-")) ;
			if(datepickerStartDt.compareTo(startDay) > 0){
				startDay = datepickerStartDt ;
			}
		}
		//今日と画面の終了日を比較する
		if(!StringUtils.isEmpty(datepickerEnd)){
			Date datepickerEndDt = fmt.parse(datepickerEnd.replace("/", "-")) ;
			if(today.compareTo(datepickerEndDt) > 0){
				today = datepickerEndDt ;
			}
		}


		int kikan = monthsBetween(today, startDay);
		// 日
		List<String> kikanList = Lists.newArrayList();
		
		// 日(画面表示用)
		List<String> xKikanList = Lists.newArrayList();
		// 件数
		String startDayStr = fmt.format(startDay) ;
		
		kikanList.add( startDayStr);
		
//		xKikanList.add( startDayStr.substring(0, 7));
		Calendar calTemp = Calendar.getInstance();
		calTemp.setTime(startDay);
		
		int kikanDays = daysBetween(today, startDay) ;
		Calendar xCalTemp = Calendar.getInstance();
		xCalTemp.setTime(startDay);
//		xCalTemp.set(Calendar.DAY_OF_MONTH, xCalTemp.getActualMaximum(Calendar.DATE));
		
		xKikanList.add( fmt.format(xCalTemp.getTime()));
		
		for (int i = 1; i <= kikan; i++) {
			xCalTemp.add(Calendar.MONTH, 1);
			xCalTemp.set(Calendar.DAY_OF_MONTH, xCalTemp.getActualMaximum(Calendar.DATE));
			Date xDateTemp = xCalTemp.getTime();
			String xDate = fmt.format(xDateTemp) ;
//			xKikanList.add(xDate.substring(0, 7));
			xKikanList.add(xDate);
		}
		for (int i = 1; i <= kikanDays; i++) {
			calTemp.add(Calendar.DAY_OF_MONTH, 1);
			Date dateTemp = calTemp.getTime();
			String date = fmt.format(dateTemp) ;
			kikanList.add(date);
		}
		
	
		Map<String, Object> listMap = Maps.newHashMap() ;
		dataProcess(kikanList, xKikanList, "month", listMap,budget,artificial);
		listMap.put("dateData", xKikanList);
		listMap.put("model", "month");
		
		context.getResultBean().setData(listMap);

	
	}
	
	public void getYearInfo() throws SoftbankException, Exception {


		// パラメータ
		Map<String, Object> conditions = Maps.newHashMap();
		String datepickerStart = context.getParam().get("datepickerStart");
		String datepickerEnd = context.getParam().get("datepickerEnd");

		SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd");
		// 統括
		String headquartersId = null;
		if (StringUtils.isEmpty(context.getParam().get("headquartersId"))) {
			headquartersId = "9898";
		} else {
			headquartersId = context.getParam().get("headquartersId");
		}
		// 本部
		String divisionId = null;
		if (StringUtils.isEmpty(context.getParam().get("divisionId"))) {
			divisionId = "9898";
		} else {
			divisionId = context.getParam().get("divisionId");
		}
		// 統括部
		String departmentId = null;
		if (StringUtils.isEmpty(context.getParam().get("departmentId"))) {
			departmentId = "9898";
		} else {
			departmentId = context.getParam().get("departmentId");
		}
		// 部
		String regionId = null;
		if (StringUtils.isEmpty(context.getParam().get("regionId"))) {
			regionId = "9898";
		} else {
			regionId = context.getParam().get("regionId");
		}
		// 全従業員/社員/業託
		String dispartch = null;
		if (!StringUtils.isEmpty(context.getParam().get("dispartchId"))) {
			dispartch = URLDecoder.decode(context.getParam().get("dispartchId"),"utf-8");
		}
		// 新規/既存
		String category = null;
		if (!StringUtils.isEmpty(context.getParam().get("categoryId"))) {
			category = URLDecoder.decode(context.getParam().get("categoryId"),"utf-8");
		}
		// 人工数/金額/施策数
		String statusId = null;
		if (!StringUtils.isEmpty(context.getParam().get("statusId"))) {
			statusId = URLDecoder.decode(context.getParam().get("statusId"),"utf-8");
		} 
		boolean isHistory = false ;
		String study = null;
		if (!StringUtils.isEmpty(context.getParam().get("tuStudy"))) {
			if ("9898".equals(context.getParam().get("tuStudy"))) {
				study = ControlDbMemory.getInstance().getTuNewDate();
			} else {
				isHistory = true ;
				study = context.getParam().get("tuStudy");
			}
		}
		conditions.put("study", study);
		conditions.put("headquarters_Id", Integer.parseInt(headquartersId));
		conditions.put("division_id", Integer.parseInt(divisionId));
		conditions.put("department_id", Integer.parseInt(departmentId));
		conditions.put("region_id", Integer.parseInt(regionId));
		conditions.put("dispartch", dispartch);
		conditions.put("category", category);
		if("".equals(statusId) || statusId == null || "人工数".equals(statusId)){
			conditions.put("artificial_unit", "人工");
		}
		// 今日
		Date today = isNowOrHistory(isHistory, study);

		// 開始日
		List<Map<String, Object>> minDay = db.querys("tuChartBar.getShisakuMinDay", conditions);

		if(minDay.isEmpty()|| StringUtils.isEmpty((Date) minDay.get(0).get("start_date"))){
			return ;
		}
		Date startDay = (Date) minDay.get(0).get("start_date");
		Double budget =  ((BigDecimal) minDay.get(0).get("plan_budget")).doubleValue() ;
		Double artificial = ((BigDecimal) minDay.get(0).get("plan_artificial")).doubleValue() ;
		// DB 開始日と画面の開始日を比較する
		if(!StringUtils.isEmpty(datepickerStart)){
			Date datepickerStartDt = fmt.parse(datepickerStart.replace("/", "-")) ;
			if(datepickerStartDt.compareTo(startDay) > 0){
				startDay = datepickerStartDt ;
			}
		}
		//今日と画面の終了日を比較する
		if(!StringUtils.isEmpty(datepickerEnd)){
			Date datepickerEndDt = fmt.parse(datepickerEnd.replace("/", "-")) ;
			if(today.compareTo(datepickerEndDt) > 0){
				today = datepickerEndDt ;
			}
		}
		int kikan = yearsBetween(today, startDay);
		// 日
		List<String> kikanList = Lists.newArrayList();
		
		// 年(画面表示用)
		List<String> xKikanList = Lists.newArrayList();
		// 件数
		String startDayStr = fmt.format(startDay) ;
		
		kikanList.add( startDayStr);
		
//		xKikanList.add( startDayStr.substring(0, 4));
	
		
		
		Calendar calTemp = Calendar.getInstance();
		calTemp.setTime(startDay);
	
		int kikanDays = daysBetween(today, startDay) ;
		Calendar xCalTemp = Calendar.getInstance();
		xCalTemp.setTime(startDay);

		startDayStr =  fmt.format(xCalTemp.getTime());
		
		xKikanList.add( startDayStr);
		for (int i = 1; i <= kikan; i++) {
			xCalTemp.add(Calendar.YEAR, 1);
			xCalTemp.set(Calendar.MONTH, Calendar.DECEMBER);
			xCalTemp.set(Calendar.DAY_OF_MONTH, xCalTemp.getActualMaximum(Calendar.DATE));
			Date xDateTemp = xCalTemp.getTime();
			String xDate = fmt.format(xDateTemp) ;
			xKikanList.add(xDate);
		}
		for (int i = 1; i <= kikanDays; i++) {
			calTemp.add(Calendar.DAY_OF_MONTH, 1);
			Date dateTemp = calTemp.getTime();
			String date = fmt.format(dateTemp) ;
			kikanList.add(date);
		}
		Map<String, Object> listMap = Maps.newHashMap() ;
		dataProcess(kikanList, xKikanList, "year", listMap,budget,artificial);
		listMap.put("dateData", xKikanList);
		listMap.put("model", "year");
//		context.getSessionData().set("level1" + "TuChartBar", level1);
//		
//		context.getSessionData().set("level2" + "TuChartBar", level2);
//		
//		context.getSessionData().set("level3" + "TuChartBar", level3); 
//		
//		context.getSessionData().set("dateData" + "TuChartBar", dateData); 
		
		context.getResultBean().setData(listMap);
	}
	/**
	 * 二つ日付の間隔を取得
	 * @param dateEnd
	 * @param dateStart
	 * @return
	 * @throws ParseException
	 */
	private int daysBetween(Date dateEnd,Date dateStart) throws ParseException{
		
		SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd") ; 
		
		dateEnd = fmt.parse(fmt.format(dateEnd) );
		
		dateStart = fmt.parse(fmt.format(dateStart) );
		
		Calendar cal = Calendar.getInstance() ;
		cal.setTime(dateEnd);
		long endTimes = cal.getTimeInMillis() ;
		cal.setTime(dateStart);
		long startTimes = cal.getTimeInMillis() ;
		
		return Integer.parseInt(String.valueOf((endTimes-startTimes)/(1000*3600*24))) ;
	}
	/**
	 * 二つ日付の週間隔を取得
	 * @param dateEnd
	 * @param dateStart
	 * @return
	 * @throws ParseException
	 */
	private int weeksBetween(Date dateEnd,Date dateStart) throws ParseException{
		
		SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd") ; 
		
		dateEnd = fmt.parse(fmt.format(dateEnd) );
		
		dateStart = fmt.parse(fmt.format(dateStart) );
		
		Calendar cal = Calendar.getInstance() ;
		cal.setTime(dateEnd);
		long endTimes = cal.getTimeInMillis() ;
		cal.setTime(dateStart);
		long startTimes = cal.getTimeInMillis() ;
		
		return Integer.parseInt(String.valueOf((endTimes-startTimes)/(1000*3600*24*7))) + 1;
	
		
		
//		Calendar cal = Calendar.getInstance() ;
//		cal.setFirstDayOfWeek(Calendar.MONDAY);
//		cal.setTime(dateEnd);
////		long endTimes = cal.getTimeInMillis() ;
//		int weekOfYearEnd = cal.get(Calendar.WEEK_OF_YEAR) ;
//		
//		cal.setTime(dateStart);
//		int weekOfYearStart = cal.get(Calendar.WEEK_OF_YEAR) ;
////		long startTimes = cal.getTimeInMillis() ;
//		
//		return  weekOfYearEnd - weekOfYearStart ;
	}
	
	/**
	 * 二つ日付の月間隔を取得
	 * @param dateEnd
	 * @param dateStart
	 * @return
	 * @throws ParseException
	 */
	private int monthsBetween(Date dateEnd,Date dateStart) throws ParseException{
		
		SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd") ; 
		
		dateEnd = fmt.parse(fmt.format(dateEnd) );
		
		dateStart = fmt.parse(fmt.format(dateStart) );
		
		Calendar cal = Calendar.getInstance() ;
		cal.setTime(dateEnd);
		
		int yearEnd = cal.get(Calendar.YEAR) ;
		int monthEnd = cal.get(Calendar.MONTH) + 1 ;
		
		cal.setTime(dateStart);
		
		int yearStart = cal.get(Calendar.YEAR) ;
		int monthStart = cal.get(Calendar.MONTH) + 1 ;
		return 12 * (yearEnd - yearStart) + monthEnd - monthStart ;
	}
	
	
	
	/**
	 * 二つ日付の年間隔を取得
	 * @param dateEnd
	 * @param dateStart
	 * @return
	 * @throws ParseException
	 */
	private int yearsBetween(Date dateEnd,Date dateStart) throws ParseException{
		
		SimpleDateFormat fmt = new SimpleDateFormat("yyyy-MM-dd") ; 
		
		dateEnd = fmt.parse(fmt.format(dateEnd) );
		
		dateStart = fmt.parse(fmt.format(dateStart) );
		
		Calendar cal = Calendar.getInstance() ;
		cal.setTime(dateEnd);
		
		int yearEnd = cal.get(Calendar.YEAR) ;
		
		cal.setTime(dateStart);
		
		int yearStart = cal.get(Calendar.YEAR) ;
		return (yearEnd - yearStart) ;
	}
	private boolean isNotNullAndSpace (Object obj){
		return  !(obj == null ||"".equals(obj)) ;
		
	}
	
	
	private void dataProcess(
		List<String> kikanList, 
		List<String> xKikanList,
		String modelFlg,
		Map<String, Object> listMap,
		double plan_budget,
		double plan_artificial) throws SoftbankException, Exception{
		// パラメータ
		// 統括
		String headquartersId = null;
		if (StringUtils.isEmpty(context.getParam().get("headquartersId"))) {
			headquartersId = "9898";
		} else {
			headquartersId = context.getParam().get("headquartersId");
		}
		// 本部
		String divisionId = null;
		if (StringUtils.isEmpty(context.getParam().get("divisionId"))) {
			divisionId = "9898";
		} else {
			divisionId = context.getParam().get("divisionId");
		}
		// 統括部
		String departmentId = null;
		if (StringUtils.isEmpty(context.getParam().get("departmentId"))) {
			departmentId = "9898";
		} else {
			departmentId = context.getParam().get("departmentId");
		}
		// 部
		String regionId = null;
		if (StringUtils.isEmpty(context.getParam().get("regionId"))) {
			regionId = "9898";
		} else {
			regionId = context.getParam().get("regionId");
		}
		// 全従業員/社員/業託
		String dispartch = null;
		if (!StringUtils.isEmpty(context.getParam().get("dispartchId"))) {
			dispartch = URLDecoder.decode(context.getParam().get("dispartchId"),"utf-8");
		}
		// 新規/既存
		String category = null;
		if (!StringUtils.isEmpty(context.getParam().get("categoryId"))) {
			category = URLDecoder.decode(context.getParam().get("categoryId"),"utf-8");
		}
		// 人工数/金額/施策数
		String statusId = null;
		if (!StringUtils.isEmpty(context.getParam().get("statusId"))) {
			statusId = URLDecoder.decode(context.getParam().get("statusId"),"utf-8");
		} 
		
		Map<String, Object> conditions = Maps.newHashMap();
		String study = null;
		boolean isHistory = false ;
		if (!StringUtils.isEmpty(context.getParam().get("tuStudy"))) {
			if ("9898".equals(context.getParam().get("tuStudy"))) {
				study = ControlDbMemory.getInstance().getTuNewDate();
			} else {
				isHistory = true ;
				study = context.getParam().get("tuStudy");
			}
		}
		conditions.put("study", study);
		conditions.put("headquarters_Id", Integer.parseInt(headquartersId));
		conditions.put("division_id", Integer.parseInt(divisionId));
		conditions.put("department_id", Integer.parseInt(departmentId));
		conditions.put("region_id", Integer.parseInt(regionId));
		conditions.put("dispartch", dispartch);
		conditions.put("category", category);
		if("".equals(statusId) || statusId == null || "人工数".equals(statusId)){
			conditions.put("artificial_unit", "人工");
		}
		
		
		int[] normal = new int[xKikanList.size()];
		int[] warn = new int[xKikanList.size()];
		int[] danger = new int[xKikanList.size()];

		double[] normal_artificial = new double[xKikanList.size()];
		double[] warn_artificial = new double[xKikanList.size()];
		double[] danger_artificial = new double[xKikanList.size()];

		double[] normal_budget = new double[xKikanList.size()];
		double[] warn_budget = new double[xKikanList.size()];
		double[] danger_budget = new double[xKikanList.size()];
		
		

		
		
		// 進捗情報
		List<Map<String, Object>> listFact = db.querys("tuChartBar.getUnderwayInfo", conditions);
		Map<Integer ,double[]> kouka = getKouka(listFact) ;
		int count = 0 ;
		if(!listFact.isEmpty()){
			count = listFact.size() ;
		}
		int dataCount = 0 ;
		int dayDataCount = -1;
		int monthOfYear = -1 ;
		int weekOfYear = -1 ;
		int year = -1 ;
		
		
		Calendar xCalTemp = Calendar.getInstance() ;
		SimpleDateFormat fmt =  new SimpleDateFormat("yyyy-MM-dd");
		
		if("month".equals(modelFlg)){
			if(kikanList.size() > 0){
				String xDateTemp = kikanList.get(0);
				Date xDate = fmt.parse(xDateTemp) ;
				xCalTemp.setTime(xDate); 
				monthOfYear = xCalTemp.get(Calendar.MONTH) ;
			}
		} else if("year".equals(modelFlg)){
			if(kikanList.size() > 0){
				String xDateTemp = kikanList.get(0);
				Date xDate = fmt.parse(xDateTemp) ;
				xCalTemp.setTime(xDate); 
				year = xCalTemp.get(Calendar.YEAR) ;
			}
		} else if("week".equals(modelFlg)){
				if(kikanList.size() > 0){
					String xDateTemp = kikanList.get(0);
					Date xDate = fmt.parse(xDateTemp) ;
					xCalTemp.setFirstDayOfWeek(Calendar.MONDAY);
					xCalTemp.setTime(xDate); 
					weekOfYear = xCalTemp.get(Calendar.WEEK_OF_YEAR) ;
				}
			}
		for (int i = 0; i < xKikanList.size(); i++) {
			List<Integer> testResult = Lists.newArrayList();
			String xDateTemp = xKikanList.get(i);
//			System.out.println(xDateTemp);
			Date xDate = fmt.parse(xDateTemp) ;
			xCalTemp.setTime(xDate); 
			if("month".equals(modelFlg)){
				if((getMonthOfYear(xDate) < getMonthOfYear(isNowOrHistory(isHistory, study)) && xDate.compareTo(isNowOrHistory(isHistory, study))< 0 && getYear(xDate) == getYear(isNowOrHistory(isHistory, study)))
						|| (xDate.compareTo(isNowOrHistory(isHistory, study))< 0 && getYear(xDate) <= getYear(isNowOrHistory(isHistory, study)))){
					xCalTemp.set(Calendar.DAY_OF_MONTH, xCalTemp.getActualMaximum(Calendar.DATE));
					xDate = xCalTemp.getTime();
				}else{
					xDate = isNowOrHistory(isHistory, study);
				}
				// months
				if( xCalTemp.get(Calendar.MONTH) != monthOfYear){
					monthOfYear = xCalTemp.get(Calendar.MONTH) ;
					if((getMonthOfYear(xDate) < getMonthOfYear(isNowOrHistory(isHistory, study)) && xDate.compareTo(isNowOrHistory(isHistory, study))< 0 && getYear(xDate) == getYear(isNowOrHistory(isHistory, study)))
							|| (xDate.compareTo(isNowOrHistory(isHistory, study))< 0 && getYear(xDate) <= getYear(isNowOrHistory(isHistory, study)))){
						xCalTemp.set(Calendar.DAY_OF_MONTH, xCalTemp.getActualMaximum(Calendar.DATE));
						xDate = xCalTemp.getTime() ;
					}else{
						xDate = isNowOrHistory(isHistory, study);
					}
					
					dataCount++;
				}
			}
			else if("year".equals(modelFlg)){
				
				if(xDate.compareTo(isNowOrHistory(isHistory, study)) < 0 && getYear(xDate) < getYear(isNowOrHistory(isHistory, study)) ){
					xCalTemp.set(Calendar.MONTH, Calendar.DECEMBER);
					xCalTemp.set(Calendar.DAY_OF_MONTH, xCalTemp.getActualMaximum(Calendar.DATE));
					xDate = xCalTemp.getTime();
				}else{
					xDate = isNowOrHistory(isHistory, study) ;
				}
				// year
				if( xCalTemp.get(Calendar.YEAR) != year){
					year = xCalTemp.get(Calendar.YEAR) ;
					if(i != xKikanList.size()-1){
						xDate = xCalTemp.getTime();
					}else{
						xDate = isNowOrHistory(isHistory, study) ;
					}
					dataCount++;
				}
			}else if("week".equals(modelFlg)){
				if(xDate.compareTo(isNowOrHistory(isHistory, study)) < 0 && getWeekOfYear(xDate) < getWeekOfYear(isNowOrHistory(isHistory, study)) &&  getYear(xDate) <= getYear(isNowOrHistory(isHistory, study))){
					xCalTemp.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
					xDate = xCalTemp.getTime() ;
				}else{
					xDate = isNowOrHistory(isHistory, study) ;
				}
				// week
				if( xCalTemp.get(Calendar.WEEK_OF_YEAR) != weekOfYear){
					weekOfYear = xCalTemp.get(Calendar.WEEK_OF_YEAR) ;
					if(xDate.compareTo(isNowOrHistory(isHistory, study)) < 0 && getWeekOfYear(xDate) < getWeekOfYear(isNowOrHistory(isHistory, study)) &&  getYear(xDate) <= getYear(isNowOrHistory(isHistory, study))){
						xCalTemp.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
						xDate = xCalTemp.getTime() ;
					}else{
						xDate = isNowOrHistory(isHistory, study) ;
					}
					
					dataCount++;
				}
			}else if("day".equals(modelFlg)){
				dayDataCount++ ;
				dataCount = dayDataCount;
			}
			// WEEKS
			for (int j = 0; j < listFact.size(); j++) {
			
//				System.out.println( "J="+j+"***********"+"I="+i);
				Map<String, Object> underWayinfor = listFact.get(j);
				Integer issueId =(Integer) underWayinfor.get("id") ;
				testResult.add(issueId) ;
				Date lv1_due_date = (Date) underWayinfor.get("lv1_due_date");
				Date lv1_start_date = (Date) underWayinfor.get("lv1_start_date");
				Date lv1_end_date = null ;
				
				if(isNotNullAndSpace(underWayinfor.get("lv1_end_date") )){
					lv1_end_date = new Date(((java.sql.Date)underWayinfor.get("lv1_end_date")).getTime());
				}
						
				if (isNotNullAndSpace(lv1_start_date)) {
					if (lv1_start_date.compareTo(xDate) >= 0) {
						continue  ;
					}
					
				}
				
				if (!isNotNullAndSpace(lv1_end_date)) {
					int duration =  daysBetween(xDate, lv1_due_date)  ;
					Calendar cd = Calendar.getInstance() ;
					cd.setTime(lv1_due_date);
					int daysOfMonth = cd.getActualMaximum(Calendar.DATE);
					if(duration < 0 ){
//						warn[dataCount] = warn[dataCount] + 1 ;
//						warn_artificial[dataCount] = warn_artificial[dataCount] + ((double[])(kouka.get(issueId)))[1]  ;
//						warn_budget[dataCount] = warn_budget[dataCount] + ((double[])(kouka.get(issueId)))[0] ;
					}
					else if(duration >= daysOfMonth){
						danger[dataCount] = danger[dataCount] + 1 ;
						
						danger_artificial[dataCount] = danger_artificial[dataCount] + ((double[])(kouka.get(issueId)))[1]  ;
						danger_budget[dataCount] = danger_budget[dataCount] + ((double[])(kouka.get(issueId)))[0] ;
						testResult.add(issueId) ;
					}
					else if(duration <= daysOfMonth && duration > 0){
						warn[dataCount] = warn[dataCount] + 1 ;
						
						warn_artificial[dataCount] = warn_artificial[dataCount] + ((double[])(kouka.get(issueId)))[1]  ;
						warn_budget[dataCount] = warn_budget[dataCount] + ((double[])(kouka.get(issueId)))[0] ;
					}
					
					continue ;
				}else {
					if(lv1_due_date.compareTo(xDate) >= 0 ){
						continue ;
					}
					else if(xDate.compareTo(lv1_due_date) > 0 && lv1_end_date.compareTo(xDate) > 0){
						int duration =  daysBetween(xDate, lv1_due_date) ;
						Calendar cd = Calendar.getInstance() ;
						cd.setTime(lv1_due_date);
						int daysOfMonth = cd.getActualMaximum(Calendar.DATE);
						if(duration >= daysOfMonth){
							danger[dataCount] = danger[dataCount] + 1 ;
							
							danger_artificial[dataCount] = danger_artificial[dataCount] + ((double[])(kouka.get(issueId)))[1]  ;
							danger_budget[dataCount] = danger_budget[dataCount] + ((double[])(kouka.get(issueId)))[0] ;
							testResult.add(issueId) ;
							continue ;
						}
						else {
							// xDate  2017/9/22
							warn[dataCount] = warn[dataCount] + 1 ;
							
							warn_artificial[dataCount] = warn_artificial[dataCount] + ((double[])(kouka.get(issueId)))[1]  ;
							warn_budget[dataCount] = warn_budget[dataCount] + ((double[])(kouka.get(issueId)))[0] ;
							continue ;
						}
						
					}
				}
				
				
//				LV2
				
				Date lv2_due_date = (Date) underWayinfor.get("lv2_due_date");
				Date lv2_start_date = (Date) underWayinfor.get("lv2_start_date");
				Date lv2_end_date = null ;
				
				if(isNotNullAndSpace(underWayinfor.get("lv2_end_date") )){
					lv2_end_date = new Date(((java.sql.Date)underWayinfor.get("lv2_end_date")).getTime());
				}
						
				if (isNotNullAndSpace(lv2_start_date)) {
					if (lv2_start_date.compareTo(xDate) >= 0) {
						continue  ;
					}
					
				}
				if (!isNotNullAndSpace(lv2_end_date)) {
					int duration =  daysBetween(xDate, lv2_due_date)  ;
					Calendar cd = Calendar.getInstance() ;
					cd.setTime(lv2_due_date);
					int daysOfMonth = cd.getActualMaximum(Calendar.DATE);
					if(duration < 0 ){
//						warn[dataCount] = warn[dataCount] + 1 ;
//						
//						warn_artificial[dataCount] = warn_artificial[dataCount] + ((double[])(kouka.get(issueId)))[1]  ;
//						warn_budget[dataCount] = warn_budget[dataCount] + ((double[])(kouka.get(issueId)))[0] ;
					}
					else if(duration >= daysOfMonth){
						danger[dataCount] = danger[dataCount] + 1 ;
						
						danger_artificial[dataCount] = danger_artificial[dataCount] + ((double[])(kouka.get(issueId)))[1]  ;
						danger_budget[dataCount] = danger_budget[dataCount] + ((double[])(kouka.get(issueId)))[0] ;
						testResult.add(issueId) ;
					}
					else if(duration <= daysOfMonth && duration > 0){
						warn[dataCount] = warn[dataCount] + 1 ;
						
						warn_artificial[dataCount] = warn_artificial[dataCount] + ((double[])(kouka.get(issueId)))[1]  ;
						warn_budget[dataCount] = warn_budget[dataCount] + ((double[])(kouka.get(issueId)))[0] ;
					}
					
					continue ;
				}else {
					if(lv2_due_date.compareTo(xDate) >= 0 ){
						continue ;
					}
					else if(xDate.compareTo(lv2_due_date) > 0 && lv2_end_date.compareTo(xDate) > 0){
						int duration =  daysBetween(xDate, lv2_due_date) ;
						Calendar cd = Calendar.getInstance() ;
						cd.setTime(lv2_due_date);
						int daysOfMonth = cd.getActualMaximum(Calendar.DATE);
						if(duration >= daysOfMonth){
							danger[dataCount] = danger[dataCount] + 1 ;
							
							danger_artificial[dataCount] = danger_artificial[dataCount] + ((double[])(kouka.get(issueId)))[1]  ;
							danger_budget[dataCount] = danger_budget[dataCount] + ((double[])(kouka.get(issueId)))[0] ;
							testResult.add(issueId) ;
							continue ;
						}
						else {
							warn[dataCount] = warn[dataCount] + 1 ;
							
							warn_artificial[dataCount] = warn_artificial[dataCount] + ((double[])(kouka.get(issueId)))[1]  ;
							warn_budget[dataCount] = warn_budget[dataCount] + ((double[])(kouka.get(issueId)))[0] ;
							continue ;
						}
						
					}
				}	
			
//				lv3
				
				Date lv3_due_date = (Date) underWayinfor.get("lv3_due_date");
				Date lv3_start_date = (Date) underWayinfor.get("lv3_start_date");
				Date lv3_end_date = null ;
				
				
				if(isNotNullAndSpace(underWayinfor.get("lv3_end_date") )){
//					lv3_end_date = fmt.parse((String) underWayinfor.get("lv3_end_date"));
					lv3_end_date = new Date(((java.sql.Date)underWayinfor.get("lv3_end_date")).getTime());
				}
						
				if (isNotNullAndSpace(lv3_start_date)) {
					if (lv3_start_date.compareTo(xDate) >= 0) {
						continue  ;
					}
					
				}
				
				if (!isNotNullAndSpace(lv3_end_date)) {
					int duration =  daysBetween(xDate, lv3_due_date)  ;
					Calendar cd = Calendar.getInstance() ;
					cd.setTime(lv3_due_date);
					int daysOfMonth = cd.getActualMaximum(Calendar.DATE);
					if(duration < 0 ){
//						warn[dataCount] = warn[dataCount] + 1 ;
//						
//						warn_artificial[dataCount] = warn_artificial[dataCount] + ((double[])(kouka.get(issueId)))[1]  ;
//						warn_budget[dataCount] = warn_budget[dataCount] + ((double[])(kouka.get(issueId)))[0] ;
					}
					else if(duration >= daysOfMonth){
						danger[dataCount] = danger[dataCount] + 1 ;
						
						danger_artificial[dataCount] = danger_artificial[dataCount] + ((double[])(kouka.get(issueId)))[1]  ;
						testResult.add(issueId) ;
						danger_budget[dataCount] = danger_budget[dataCount] + ((double[])(kouka.get(issueId)))[0] ;
					}
					else if(duration <= daysOfMonth && duration > 0){
						warn[dataCount] = warn[dataCount] + 1 ;
						
						warn_artificial[dataCount] = warn_artificial[dataCount] + ((double[])(kouka.get(issueId)))[1]  ;
						warn_budget[dataCount] = warn_budget[dataCount] + ((double[])(kouka.get(issueId)))[0] ;
					}
					
					continue ;
				}else {
					if(lv3_due_date.compareTo(xDate) >= 0 ){
						continue ;
					}
					else if(xDate.compareTo(lv3_due_date) > 0 && lv3_end_date.compareTo(xDate) > 0){
						int duration =  daysBetween(xDate, lv3_due_date) ;
						Calendar cd = Calendar.getInstance() ;
						cd.setTime(lv3_due_date);
						int daysOfMonth = cd.getActualMaximum(Calendar.DATE);
						if(duration >= daysOfMonth){
							danger[dataCount] = danger[dataCount] + 1 ;
							
							danger_artificial[dataCount] = danger_artificial[dataCount] + ((double[])(kouka.get(issueId)))[1]  ;
							danger_budget[dataCount] = danger_budget[dataCount] + ((double[])(kouka.get(issueId)))[0] ;
							testResult.add(issueId) ;
							continue ;
						}
						else {
							// xDate  2017/9/22
							warn[dataCount] = warn[dataCount] + 1 ;
							
							warn_artificial[dataCount] = warn_artificial[dataCount] + ((double[])(kouka.get(issueId)))[1]  ;
							warn_budget[dataCount] = warn_budget[dataCount] + ((double[])(kouka.get(issueId)))[0] ;
						
							continue ;
						}
						
					}
				}	
			
				
//				lv4
				
				Date lv4_due_date = (Date) underWayinfor.get("lv4_due_date");
				Date lv4_start_date = (Date) underWayinfor.get("lv4_start_date");
				Date lv4_end_date = null ;
				
				
				if(isNotNullAndSpace(underWayinfor.get("lv4_end_date") )){
					lv4_end_date = new Date(((java.sql.Date)underWayinfor.get("lv4_end_date")).getTime());
				}
						
				if (isNotNullAndSpace(lv4_start_date)) {
					if (lv4_start_date.compareTo(xDate) >= 0) {
						continue  ;
					}
					
				}
				
				if (!isNotNullAndSpace(lv4_end_date)) {
					int duration =  daysBetween(xDate, lv4_due_date)  ;
					Calendar cd = Calendar.getInstance() ;
					cd.setTime(lv4_due_date);
					int daysOfMonth = cd.getActualMaximum(Calendar.DATE);
					if(duration < 0 ){
//						warn[dataCount] = warn[dataCount] + 1 ;
//						
//						warn_artificial[dataCount] = warn_artificial[dataCount] + ((double[])(kouka.get(issueId)))[1]  ;
//						warn_budget[dataCount] = warn_budget[dataCount] + ((double[])(kouka.get(issueId)))[0] ;
					}
					else if(duration >= daysOfMonth){
						danger[dataCount] = danger[dataCount] + 1 ;
						
						danger_artificial[dataCount] = danger_artificial[dataCount] + ((double[])(kouka.get(issueId)))[1]  ;
						danger_budget[dataCount] = danger_budget[dataCount] + ((double[])(kouka.get(issueId)))[0] ;
						testResult.add(issueId) ;
					}
					else {
						warn[dataCount] = warn[dataCount] + 1 ;
						
						warn_artificial[dataCount] = warn_artificial[dataCount] + ((double[])(kouka.get(issueId)))[1]  ;
						warn_budget[dataCount] = warn_budget[dataCount] + ((double[])(kouka.get(issueId)))[0] ;
					}
					
					continue ;
				}else {
					if(lv4_due_date.compareTo(xDate) >= 0 ){
						continue ;
					}
					else if(xDate.compareTo(lv4_due_date) > 0 && lv4_end_date.compareTo(xDate) > 0){
						int duration =  daysBetween(xDate, lv4_due_date) ;
						Calendar cd = Calendar.getInstance() ;
						cd.setTime(lv4_due_date);
						int daysOfMonth = cd.getActualMaximum(Calendar.DATE);
						if(duration >= daysOfMonth){
							danger[dataCount] = danger[dataCount] + 1 ;
							
							danger_artificial[dataCount] = danger_artificial[dataCount] + ((double[])(kouka.get(issueId)))[1]  ;
							danger_budget[dataCount] = danger_budget[dataCount] + ((double[])(kouka.get(issueId)))[0] ;
							testResult.add(issueId) ;
							continue ;
						}
						else if(duration <= daysOfMonth && duration > 0){
							warn[dataCount] = warn[dataCount] + 1 ;
							
							warn_artificial[dataCount] = warn_artificial[dataCount] + ((double[])(kouka.get(issueId)))[1]  ;
							warn_budget[dataCount] = warn_budget[dataCount] + ((double[])(kouka.get(issueId)))[0] ;
							continue ;
						}
						
					}
				}	
			
				
			}
//			System.out.println(testResult.size());
		}
		if(SISAKUSUU.equals(statusId)){
			for (int j = 0; j < xKikanList.size(); j++) {
				int all = count ;
				
				warn[j]   = new Long(Math.round(Double.valueOf(warn[j]) /Double.valueOf(all )*100)).intValue();
				danger[j] = new Long(Math.round(Double.valueOf(danger[j]) /Double.valueOf(all )*100)).intValue();
				
				if(warn[j] + danger[j] == 101 ){
					if(warn[j] > danger[j]){
						
						warn[j] -=1 ;
						
					}else{
						danger[j] -=1 ;
					}
				}
				normal[j] =  100 - warn[j] - danger[j] ;
			}	
			listMap.put(LEVEL1, danger);
			listMap.put(LEVEL2, warn);
			listMap.put(LEVEL3, normal);
		}
		else if(KINGAKU.equals(statusId)){
			for (int j = 0; j < xKikanList.size(); j++) {
				double all = plan_budget ;
				
				warn_budget[j] =  new Long(Math.round(Double.valueOf(warn_budget[j]) /Double.valueOf(all )*100)).intValue();
			
				danger_budget[j] =  new Long(Math.round(Double.valueOf(danger_budget[j]) /Double.valueOf(all )*100)).intValue();
				if(warn_budget[j] + danger_budget[j] == 101 ){
					if(warn_budget[j] > danger_budget[j]){
						
						warn_budget[j] -=1 ;
						
					}else{
						danger_budget[j] -=1 ;
					}
				}
				normal_budget[j] =  100 - warn_budget[j] - danger_budget[j] ;
			}	
			listMap.put(LEVEL1, danger_budget);
			listMap.put(LEVEL2, warn_budget);
			listMap.put(LEVEL3, normal_budget);
		} else if(StringUtils.isEmpty(statusId) || JINKOU.equals(statusId)){
			for (int j = 0; j < xKikanList.size(); j++) {
				double all = plan_artificial ;
				
				warn_artificial[j] =  new Long(Math.round(Double.valueOf(warn_artificial[j]) /Double.valueOf(all )*100)).intValue();
				danger_artificial[j] =  new Long(Math.round(Double.valueOf(danger_artificial[j]) /Double.valueOf(all )*100)).intValue();
				if(warn_artificial[j] + danger_artificial[j] == 101 ){
					if(warn_artificial[j] > danger_artificial[j]){
						
						warn_artificial[j] -=1 ;
						
					}else{
						danger_artificial[j] -=1 ;
					}
				}				
				normal_artificial[j] =  100 - warn_artificial[j] - danger_artificial[j];
			}	
			listMap.put(LEVEL1, danger_artificial);
			listMap.put(LEVEL2, warn_artificial);
			listMap.put(LEVEL3, normal_artificial);
		}				 
	}
	
	
	private Map<Integer,double[]> getKouka(List<Map<String,Object>> param){
		Map<Integer ,double[]> result = Maps.newHashMap() ;
		for (Map<String, Object> map : param) {
			double[] kouka = new double[2] ; 
			kouka[0] = ((BigDecimal) map.get("plan_budget")).doubleValue() ;
			kouka[1] = ((BigDecimal) map.get("plan_artificial")).doubleValue() ;
			result.put((Integer)map.get("id"), kouka)  ;
		}
		return result ;
	}
	private int getYear(Date date){
		Calendar cal = Calendar.getInstance() ;
		cal.setTime(date);
		return cal.get(Calendar.YEAR) ;
	}
	
	private int getWeekOfYear(Date date){
		Calendar cal = Calendar.getInstance() ;
		cal.setFirstDayOfWeek(Calendar.MONDAY);
		cal.setTime(date);
		return cal.get(Calendar.WEEK_OF_YEAR) ;
	}
	private int getMonthOfYear(Date date){
		Calendar cal = Calendar.getInstance() ;
		cal.setTime(date);
		return cal.get(Calendar.MONTH) + 1 ;
	}
	/**
	 * 履歴かどうか
	 * @param isHistory
	 * @param time
	 * @return
	 * @throws ParseException
	 */
	private Date isNowOrHistory(boolean isHistory,String time) throws ParseException{
		if(isHistory && !StringUtils.isEmpty(time) && time.length() == 14){
			String year = time.substring(0, 4);
			String month = time.substring(4, 6);
			String day = time.substring(6, 8);
			time = year + "-" + month + "-" + day ; 
			Calendar cal = Calendar.getInstance() ;
			SimpleDateFormat fmt =  new SimpleDateFormat("yyyy-MM-dd");
			Date dt = fmt.parse(time);
			cal.setTime(dt);
			return cal.getTime();
		
		}
		return new Date() ;
	}
}
