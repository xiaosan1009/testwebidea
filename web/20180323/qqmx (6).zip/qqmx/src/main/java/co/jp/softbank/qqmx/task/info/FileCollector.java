package co.jp.softbank.qqmx.task.info;

import java.io.File;
import java.util.ArrayList;
import java.util.Collection;
import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicLong;

import org.apache.commons.io.FileUtils;

import co.jp.softbank.qqmx.task.bean.DataObjectBean;
import co.jp.softbank.qqmx.task.bean.FileBean;
import co.jp.softbank.qqmx.task.face.ITaskContext;
import co.jp.softbank.qqmx.util.StringUtils;

public class FileCollector<P> extends AbstractCollector<P> {
	
	private List<Map<String, Object>> paths;
	
	private Map<String, String> suffixMap;
	
	public static final String PROJECT_NAME_KEY = "projectName";
	
	public static final String PROJECT_FOLDER_KEY = "projectFolder";
	
	public static final String SRC_FOLDERS_KEY = "srcFolders";
	
	public static final String LIB_FOLDERS_KEY = "libFolders";
	
	@SuppressWarnings("unchecked")
	@Override
	public Integer call() throws Exception {
		AtomicLong dataCount = new AtomicLong(0);
        try {
        	if (paths == null) {
        		return Integer.valueOf(-1);
			}
        	
        	for (int i = 0; i < paths.size(); i++) {
        		Map<String, Object> pathMap = paths.get(i);
        		String projectFolder = StringUtils.toString(pathMap.get(PROJECT_FOLDER_KEY));
        		File file = new File(projectFolder);
        		try {
        			analysisFile(file, dataCount, pathMap);
        		} catch (InterruptedException e) {
        			break;
        		} catch (Throwable e) {
        			try {
        				addQueue(new DataObjectBean(e, dataCount.incrementAndGet()));
        			} catch (InterruptedException ie) {
        				break;
        			}
        		}
        	}
        } catch (Throwable e) {
            if (!isFinish()) {
                try {
                    addQueue(new DataObjectBean(e, dataCount.incrementAndGet()));
                } catch (InterruptedException ie) {
                }
            }

            return Integer.valueOf(-1);
        } finally {
            setFinish();
        }

        return Integer.valueOf(0);
    }
	
	private void analysisFile(File file, AtomicLong dataCount, Map<String, Object> pathMap) throws InterruptedException {
		if (file.isDirectory()) {
			for (int i = 0; i < file.listFiles().length; i++) {
				analysisFile(file.listFiles()[i], dataCount, pathMap);
			}
		} else {
			if (isAdd(file)) {
				FileBean fileBean = new FileBean();
				fileBean.setAbstractPath(file.getAbsolutePath());
				fileBean.setFileName(file.getName());
				fileBean.setClassPath((String[])pathMap.get(LIB_FOLDERS_KEY));
				fileBean.setSourcePath((String[])pathMap.get(SRC_FOLDERS_KEY));
				fileBean.setProjectName(StringUtils.toString(pathMap.get(PROJECT_NAME_KEY)));
				addQueue(new DataObjectBean(fileBean, dataCount.incrementAndGet()));
			}
		}
	}
	
	public void setFilePath(List<Map<String, Object>> paths) {
		this.paths = paths;
	}

	public void setSuffixMap(Map<String, String> suffixMap) {
		this.suffixMap = suffixMap;
	}
	
	@SuppressWarnings("unchecked")
	public String[] createClassPath(List<String> folderPath) {
		Collection<File> allJarFiles = new ArrayList<File>();
		String[] getClassPath = null;
		
		if (folderPath != null && folderPath.size() > 0) {
			for (String fp : folderPath) {
				Collection<File> tmpJarFiles = FileUtils.listFiles(new File(fp), new String[] { "jar" }, true);
				allJarFiles.addAll(tmpJarFiles);
			}
			File[] jarArray = allJarFiles.toArray(new File[allJarFiles.size()]);
			getClassPath = new String[allJarFiles.size()];
			for (int k = 0; k < jarArray.length; k++) {
				getClassPath[k] = jarArray[k].getAbsolutePath();
			}
		}
		return getClassPath;
	}
	
	private boolean isAdd(File file) {
		if (suffixMap == null || suffixMap.size() == 0) {
			return true;
		}
		String fileName = file.getName();
		String fileExt = fileName.substring(fileName.lastIndexOf(".") + 1).toLowerCase();
		if (suffixMap.containsKey(fileExt)) {
			return true;
		}
		return false;
	}

	@SuppressWarnings("unchecked")
	@Override
	public void prepare(ITaskContext context) {
		for (int i = 0; i < paths.size(); i++) {
			Map<String, Object> pathMap = paths.get(i);
			String projectFolder = StringUtils.toString(pathMap.get(PROJECT_FOLDER_KEY));
			if (pathMap.get(SRC_FOLDERS_KEY) instanceof List) {
				List<String> srcFolderList = (List<String>)pathMap.get(SRC_FOLDERS_KEY);
				if (srcFolderList != null) {
					String[] srcFolders = new String[srcFolderList.size()];
					for (int j = 0; j < srcFolderList.size(); j++) {
						srcFolders[j] = projectFolder + srcFolderList.get(j);
					}
					pathMap.put(SRC_FOLDERS_KEY, srcFolders);
				}
			}
			if (pathMap.get(LIB_FOLDERS_KEY) instanceof List) {
				String[] srcFolders = createClassPath((List<String>)pathMap.get(LIB_FOLDERS_KEY));
				pathMap.put(LIB_FOLDERS_KEY, srcFolders);
			}
		}
		context.getParam().put(ITaskContext.READER_COLLECTOR_CONFIG, paths);
	}

}
