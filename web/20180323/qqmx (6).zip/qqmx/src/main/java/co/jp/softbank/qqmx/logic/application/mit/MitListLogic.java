package co.jp.softbank.qqmx.logic.application.mit;

import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Map;

import org.springframework.util.StringUtils;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.PageListBean;


public class MitListLogic extends AbstractBaseLogic {
	
	public void getMitProjectListInfo() throws SoftbankException, UnsupportedEncodingException {
		Map<String, Object> conditions = Maps.newHashMap();
		String divisionId = context.getParam().get("divisionId");
		String departmentId = context.getParam().get("departmentId");
		String regionId = context.getParam().get("regionId");
		String statusId = context.getParam().get("statusId");
		String type = context.getParam().get("mit_list_select");
		String searchName = "";
		try {
			searchName = URLDecoder.decode(context.getParam().get("searchName"), "utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		
		String organizationCd = divisionId;
		if (!"9898".equals(regionId)) {
			organizationCd = regionId;
		} else if (!"9898".equals(departmentId)) {
			organizationCd = departmentId;
		}
		conditions.put("organization_cd", organizationCd);
		conditions.put("status_Id", Integer.valueOf(statusId));
		conditions.put("search_name", searchName);
		
		PageListBean pageListBean = new PageListBean();
		// バージョン指定ません
		if(StringUtils.isEmpty(type) || "1".equals(type)){
			pageListBean = pageList("mitlist.getMitProjectNoversionListInfo",conditions);
		}
		else{
			// バージョン含む
			pageListBean = pageList("mitlist.getMitProjectListInfo",conditions);
		}
		context.getResultBean().setData(pageListBean);
	}

	public void getMitSumProjectListInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String divisionId = context.getParam().get("divisionId");
		String departmentId = context.getParam().get("departmentId");
		String regionId = context.getParam().get("regionId");
		String statusId = context.getParam().get("statusId");
		String searchName = "";
		try {
			searchName = URLDecoder.decode(context.getParam().get("searchName"), "utf-8");
		} catch (UnsupportedEncodingException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}
		
		String organizationCd = divisionId;
		if (!"9898".equals(regionId)) {
			organizationCd = regionId;
		} else if (!"9898".equals(departmentId)) {
			organizationCd = departmentId;
		}
		conditions.put("organization_cd", organizationCd);
		conditions.put("status_Id", Integer.valueOf(statusId));
		conditions.put("search_name", searchName);
		
		PageListBean pageListBean = pageList("mitlist.getMitSumProjectListInfo",conditions);
		context.getResultBean().setData(pageListBean);
	}
}
