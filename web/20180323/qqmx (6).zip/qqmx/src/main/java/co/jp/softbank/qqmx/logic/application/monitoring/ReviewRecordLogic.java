package co.jp.softbank.qqmx.logic.application.monitoring;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.DecimalFormat;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.PageListBean;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class ReviewRecordLogic extends AbstractBaseLogic {

	public void getReviewRecord() throws SoftbankException, ParseException {
		Map<String, Object> conditions = select();
		
		List<Map<String, Object>> info = new ArrayList<Map<String, Object>>();
		if (!"".equals(conditions.get("documentId")) && conditions.get("documentId") != null) {
			info = db.querys("deliverables.getDeliverablesList", conditions);
		}
		
		if (info.size() != 0 ) {
			info = infoEdit(info);
		} else {
			info = infoEditNull(info);
		}

		context.getResultBean().setData(info);
	}
	
	public void submitBatchPost() throws SoftbankException, ParseException {
		String documentId = context.getParam().get("documentId");
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("issues_id", Integer.parseInt(documentId));
		List<Map<String, Object>> issuesInfo = db.querys("reviewRecord.getCheckFlg", conditions);
		if (issuesInfo.size() < 1 ){
			return;
		}
		String issue_value = String.valueOf(issuesInfo.get(0).get("value"));
		if (StringUtils.isEmpty(issue_value)){
			conditions.put("issues_id", Integer.parseInt(documentId));
			List<Map<String, Object>> fileDate = db.querys("reviewRecord.getFileDate", conditions);
			String createdData = String.valueOf(fileDate.get(0).get("filecreate_date"));
			String gitPath = String.valueOf(fileDate.get(0).get("path"));
			
			Map<String, String> params = Maps.newHashMap();
			params.put("dispCode", "900006");
			params.put("cmdCode", "1");
			params.put("issueId", documentId);
			params.put("gitFlg", "0");
			params.put("createdData", createdData);
			params.put("gitUrl", gitPath);
			externalHttpServer.post(messageAccessor.getMessage("application.path") + ":8080/qqrp/qqrp.mx", params);
			externalHttpServer.post(messageAccessor.getMessage("application.path") + ":8080/qqrp/qqrp.mx?dispCode=900005&cmdCode=1&issueId=" + documentId); //本番環境 コメント
		} else {
			externalHttpServer.post(messageAccessor.getMessage("application.path") + ":8080/qqrp/qqrp.mx?dispCode=900006&cmdCode=1&issueId=" + documentId); //本番環境 誤字脱字
			externalHttpServer.post(messageAccessor.getMessage("application.path") + ":8080/qqrp/qqrp.mx?dispCode=900005&cmdCode=1&issueId=" + documentId); //本番環境 コメント
		}
	}

	public void getReviewRecordDetailed() throws SoftbankException {
		
		Map<String, Object> conditions = select();
		if ("".equals(conditions.get("projectId")) || conditions.get("projectId") == null ||
				"".equals(conditions.get("documentId")) || conditions.get("documentId") == null) {
			conditions.put("issue_id", 0);
		} else {
			conditions.put("issue_id", conditions.get("documentId"));
		}
		
		String clickData = context.getParam().get("clickSortData");
		String clickSort = context.getParam().get("clickSort");
		String error_info_hidden_from = context.getParam().get("error_info_hidden_from");
		String c_comment_hidden_from = context.getParam().get("c_comment_hidden_from");
		String c_date_hidden_from = context.getParam().get("c_date_hidden_from");
		String comment_contents_hidden_from = context.getParam().get("comment_contents_hidden_from");
		String comment_author_hidden_from = context.getParam().get("comment_author_hidden_from");
		String up_date_hidden_from = context.getParam().get("up_date_hidden_from");
		String error_path_hidden_from = context.getParam().get("error_path_hidden_from");
		String check_type_hidden_from = context.getParam().get("check_type_hidden_from");
		String solve_date_hidden_from = context.getParam().get("solve_date_hidden_from");
		String comment_status_hidden_from = context.getParam().get("comment_status_hidden_from");
		
		conditions.put("click", clickData);
		conditions.put("sort", clickSort);
		conditions.put("error_info_hidden_from", error_info_hidden_from);
		conditions.put("c_comment_hidden_from", c_comment_hidden_from);
		conditions.put("c_date_hidden_from", c_date_hidden_from);
		conditions.put("comment_contents_hidden_from", comment_contents_hidden_from);
		if (comment_contents_hidden_from.indexOf("空白") > 0) {
			conditions.put("comment_contents_hidden_from_flag", "1");
		} else {
			conditions.put("comment_contents_hidden_from_flag", "");
		}
		conditions.put("comment_author_hidden_from", comment_author_hidden_from);
		if (comment_author_hidden_from.indexOf("空白") > 0) {
			conditions.put("comment_author_hidden_from_flag", "1");
		} else {
			conditions.put("comment_author_hidden_from_flag", "");
		}
		conditions.put("up_date_hidden_from", up_date_hidden_from);
		if (up_date_hidden_from.indexOf("空白") > 0) {
			conditions.put("up_date_hidden_from_flag", "1");
		} else {
			conditions.put("up_date_hidden_from_flag", "");
		}
		
		conditions.put("error_path_hidden_from", error_path_hidden_from);
		conditions.put("check_type_hidden_from", check_type_hidden_from);
		conditions.put("solve_date_hidden_from", solve_date_hidden_from);
		if (solve_date_hidden_from.indexOf("空白") > 0) {
			conditions.put("solve_date_hidden_from_flag", "1");
		} else {
			conditions.put("solve_date_hidden_from_flag", "");
		}
		conditions.put("comment_status_hidden_from", comment_status_hidden_from.replaceAll("'", ""));
		
		context.getResultBean().setData(db.querys("reviewRecord.getReviewRecord",conditions));
	}
	
	public void getReviewRecordDetailedFilter() throws SoftbankException {
		
		Map<String, Object> conditions = select();
		if ("".equals(conditions.get("projectId")) || conditions.get("projectId") == null ||
				"".equals(conditions.get("documentId")) || conditions.get("documentId") == null) {
			conditions.put("issue_id", 0);
		} else {
			conditions.put("issue_id", conditions.get("documentId"));
		}
		String clickData = context.getParam().get("clickData");
		conditions.put("click", clickData.replace("_hidden_from", ""));
		context.getResultBean().setData(db.querys("reviewRecord.getReviewRecordFilter", conditions));
	}
	
	public void getSystemList() throws SoftbankException{
		Map<String, Object> conditions = select();
		
		List<Map<String, Object>> info = new ArrayList<Map<String, Object>>();
		if (!"".equals(conditions.get("documentId")) && conditions.get("documentId") != null) {
			info = db.querys("deliverables.getDeliverablesList", conditions);
		}

		if (info.size() != 0 ) {
			info = infoEdit(info);
		} else {
			info = infoEditNull(info);
		}

		List<Map<String, Object>> systemList = db.querys("deliverables.getSystemList", conditions);
		
		List<Map<String, Object>> versionList = db.querys("deliverables.getVersionList", conditions);
		
		List<Map<String, Object>> authorList = db.querys("deliverables.getAuthorList", conditions);
		
		List<Map<String, Object>> documentList = db.querys("deliverables.getDocumentList", conditions);
		
//		for(int j = 0;j < documentList.size();j++){
//			// filename
//			String filename = documentList.get(j).get("filename").toString();
//			filename = filename.substring(filename.lastIndexOf("\\")+1, filename.length());
//			documentList.get(j).put("filename", filename);
//		}
		
		Map<String, Object> listMap = Maps.newHashMap();
		listMap.put("systemList", systemList);
		listMap.put("versionList", versionList);
		listMap.put("authorList", authorList);
		listMap.put("documentList", documentList);
		listMap.put("info", info);
		
		context.getResultBean().setData(listMap);
	}
	
	public Map<String, Object> select(){
		
		Map<String, Object> conditions = Maps.newHashMap();
		
		String projectId = context.getParam().get("projectId");
		String systemId = context.getParam().get("systemId");
		String versionId = context.getParam().get("versionId");
		String authorId = context.getParam().get("authorId");
		String documentId = context.getParam().get("documentId");
		if(!"".equals(versionId)){
			conditions.put("versionId", Integer.parseInt(versionId));
		}
		if(!"".equals(authorId)){
			conditions.put("authorId", Integer.parseInt(authorId));
		}
		if(!"".equals(systemId)){
			conditions.put("systemId", Integer.parseInt(systemId));
			conditions.put("systemId", systemId);
		}
		if (!"".equals(projectId)){
			conditions.put("projectId", Integer.parseInt(projectId));
		}
		if (!"".equals(documentId)){
			conditions.put("documentId", Integer.parseInt(documentId));
		}
		
		return conditions;
	}
	
	public String isNull(Object info){
		String vaule = "";
		if (info != null) {
			vaule = info.toString();
		} 
		
		return vaule;
	}
	
	public List<Map<String, Object>> infoEdit(List<Map<String, Object>> info) throws SoftbankException{
		
		String orderDateS = isNull(info.get(0).get("start_date"));
		String orderDateE = isNull(info.get(0).get("due_date"));
		String executiveDateS = isNull(info.get(0).get("create_date"));
		String executiveDateE = isNull(info.get(0).get("end_date"));
		String pages = isNull(info.get(0).get("pages"));
		
		// レビュー時間(h)
		String reviewTime = "0";
		if(info.get(0).get("hours") != null){
			reviewTime = info.get(0).get("hours").toString();
		}
		// レビュー時間(str)
		String reviewTimeStr = "0h 0min";
		if(info.get(0).get("review_date") != null){
			reviewTimeStr = info.get(0).get("review_date").toString();
		}

		Map<String, Object> conditions = Maps.newHashMap();
		String documentId = context.getParam().get("documentId");
		if (!"".equals(documentId)){
			conditions.put("issue_id", Integer.parseInt(documentId));
		}
		List<Map<String, Object>> statusList = db.querys("reviewRecord.getStatus", conditions);
		
		String done_ratio = "";
		double statusCount_sum = 0.00;
		if (statusList.size() == 0) {
			done_ratio = "100%";
		} else {
			double statusCount_0 = 0.00;
			for (int i = 0; i < statusList.size(); i++) {
				if ("0".equals(statusList.get(i).get("comment_status").toString())) {
					statusCount_0 = Double.parseDouble(statusList.get(i).get("count").toString());
				}
				statusCount_sum = statusCount_sum + Double.parseDouble(statusList.get(i).get("count").toString());
			}
			
			int ratioVal = (int) Math.round((statusCount_0/statusCount_sum) * 100);
			
			done_ratio = ratioVal + "%";
		}
		
		String total = String.valueOf((int)statusCount_sum);

		if (!"".equals(executiveDateS) && executiveDateS.length() != 5) {
			executiveDateS = executiveDateS.substring(5, 10);
			executiveDateS = executiveDateS.replace("-", "/");
		}
		
		if (!"".equals(executiveDateE) && executiveDateE.length() != 5) {
			executiveDateE = executiveDateE.substring(5, 10);
			executiveDateE = executiveDateE.replace("-", "/");
		}
		
		String orderDate = orderDateS + "～" + orderDateE + "　";
		String executiveDate = "";
		if (!"".equals(executiveDateS)) {
			executiveDate = executiveDateS + "～" + executiveDateE + "　";
		}
		
		DecimalFormat df = new DecimalFormat("0.00");
		String reviewDensity = "0.00";
		String reviewEfficiency = "0.00";
		if (!"".equals(isNull(info.get(0).get("review_density")))) {
			reviewDensity = isNull(info.get(0).get("review_density"));
		}
		if (!"".equals(pages) && total != "" && !"0".equals(pages)) {
			reviewEfficiency = df.format(Double.parseDouble(reviewTime) / Double.parseDouble(pages));
		}
		
		info.get(0).put("orderDate", orderDate);
		info.get(0).put("executiveDate", executiveDate);
		info.get(0).put("reviewTime", reviewTime);
		info.get(0).put("reviewTimeStr", reviewTimeStr);
		info.get(0).put("reviewDensity", reviewDensity);
		info.get(0).put("reviewEfficiency", reviewEfficiency);
		info.get(0).put("done_ratio", done_ratio);
		info.get(0).put("total", total);

		return info;
	}
	
	public List<Map<String, Object>> infoEditNull(List<Map<String, Object>> info){
		Map<String, Object> infoNull =  Maps.newHashMap();

		infoNull.put("pages", "0");
		infoNull.put("username", "");
		infoNull.put("orderDate", "");
		infoNull.put("executiveDate", "");
		infoNull.put("total", "0");
		infoNull.put("reviewTime", "0");
		infoNull.put("reviewTimeStr", "0時 0分");
		infoNull.put("reviewDensity", "0.00");
		infoNull.put("reviewEfficiency", "0.00");
		infoNull.put("done_ratio", "0%");
		
		info.add(infoNull);

		return info;
	}
	
	// レビュー開始、終了時間　DB登録
	public void setReviewTime() throws SoftbankException {

		String documentId = context.getParam().get("documentId");
		String startDate = context.getParam().get("startTime");
		String endDate = context.getParam().get("endTime");
		String authorId = context.getParam().get("authorId");
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("issue_id", Integer.parseInt(documentId));
		conditions.put("start_date", startDate);
		conditions.put("end_date", endDate);
		if(!"".equals(authorId) && authorId != null){
			conditions.put("login_id", Integer.parseInt(authorId));
		}

		db.insert("reviewRecord.insertReviewTime", conditions);
	}
	
	
	// 画面入力レビュー時間　DB登録
	public void inputReviewTime() throws SoftbankException {

		String documentId = context.getParam().get("documentId");
		String startDate = context.getParam().get("startTimeInput");
		String endDate = context.getParam().get("endTimeInput");
		String authorId = context.getParam().get("authorId");
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("issue_id", Integer.parseInt(documentId));
		conditions.put("start_date", startDate);
		conditions.put("end_date", endDate);
		if(!"".equals(authorId) && authorId != null){
			conditions.put("login_id", Integer.parseInt(authorId));
		}
		
		if (!StringUtils.isEmpty(documentId) && !StringUtils.isEmpty(startDate) && !StringUtils.isEmpty(endDate)) {
			db.delete("reviewRecord.clearReviewTime", conditions);
			db.insert("reviewRecord.insertReviewTime", conditions);
		}
	}
	
	// レビュー時間取得
	public void getReviewTime() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String documentId = context.getParam().get("documentId");
		if (!"".equals(documentId)){
			conditions.put("issue_id", Integer.parseInt(documentId));
		}
		
		List<Map<String, Object>> list = db.querys("reviewRecord.getReviewTime", conditions);

		context.getResultBean().setData(list);
	}
	
	// 既存選択したルール取得
	public void getCheckedRule() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String documentId = context.getParam().get("documentId");
		String defultFlg = context.getParam().get("defultFlg");
		if (!"".equals(documentId)){
			conditions.put("issue_id", Integer.parseInt(documentId));
		}
		
		List<Map<String, Object>> list = db.querys("reviewRecord.getCheckedRuleList", conditions);
		// 既存ルールなし　デフォルトルール取得
		if(list.size() == 0 || "1".equals(defultFlg)){
			conditions.put("issue_id", 999999);
			list = db.querys("reviewRecord.getCheckedRuleList", conditions);
		}
		context.getResultBean().setData(list);
		
	}
	
	// チェックルールDB保存
	public void submitCheckRuleInfo() throws SoftbankException {
		// 当documentIdに関するデータクリア
		Map<String, Object> clearConditions = Maps.newHashMap();
		String documentId = context.getParam().get("documentId");
		if (!"".equals(documentId)){
			clearConditions.put("issue_id", Integer.parseInt(documentId));
		}
		db.delete("reviewRecord.clearCheckRuleList", clearConditions);
		
		// チェックルールDB保存
		List<Map<String, Object>> ruleList = Lists.newArrayList();
		ruleList =  db.querys("reviewRecord.getRuleList");
		for (int i = 0; i < ruleList.size(); i++) {
			Map<String, Object> ruleData = ruleList.get(i);
			String ruleId = StringUtils.toString(ruleData.get("id"));
			
			String isChecked = "false";
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("issue_id", Integer.parseInt(documentId));
			conditions.put("rules_id", Integer.parseInt(ruleId));
			// ルールchecked
			if (StringUtils.isNotEmpty(context.getParam().get(ruleId))) {
				isChecked = "true";
			}
			conditions.put("ischecked", isChecked);
			// ruletype=3　enter_rule　の場合
			String input_value = context.getParam().get(ruleId + "_value");
			if (input_value != null && input_value !="") {
				conditions.put("input_value", Integer.parseInt(input_value));
			}
			db.insert("reviewRecord.insertCheckRuleList", conditions);
		}
	}
	
	
	// チェックルールDB保存
	public void modifyCheckedRule() throws SoftbankException {
		// 当documentIdに関するデータクリア
		Map<String, Object> conditions = Maps.newHashMap();
		String documentId = context.getParam().get("documentId");
		String name = context.getParam().get("ruleName");
		if (!StringUtils.isEmpty(documentId) && !StringUtils.isEmpty(name)){
			conditions.put("issue_id", Integer.parseInt(documentId));
			conditions.put("name", name);
			// チェックルールDB保存
			db.update("reviewRecord.upDateCheckRuleList", conditions);
			db.delete("reviewRecord.deleteRuleList", conditions);
		}
		
	}
		// 対応内容登録
	public void setComments() throws SoftbankException, ParseException {

		String file_Id = context.getParam().get("file_Id");
		String comment_Id = context.getParam().get("comment_Id");
		String comment_contents = context.getParam().get("comment_contents");
		String comment_supporter = context.getParam().get("comment_supporter");
		String commentUpdate = context.getParam().get("comment_update");
		String comment_flg = context.getParam().get("comment_flg");
		
		Date comment_update = null;
		if (!StringUtils.isEmpty(commentUpdate)){
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			comment_update =  sdf.parse(commentUpdate);
		}

		
		Map<String, Object> conditions = Maps.newHashMap();
		if (StringUtils.isEmpty(comment_contents)) {
			comment_contents = null;
		}
		if (StringUtils.isEmpty(comment_supporter)) {
			comment_supporter = null;
		}
		conditions.put("comment_contents", comment_contents);
		conditions.put("comment_supporter", comment_supporter);
		conditions.put("comment_update", comment_update);
		conditions.put("comment_flg", comment_flg);

		if (!"".equals(file_Id) && !"".equals(comment_Id)){
			conditions.put("file_Id", Integer.parseInt(file_Id));
			conditions.put("comment_Id", Integer.parseInt(comment_Id));
			
			List<Map<String, Object>> list = db.querys("reviewRecord.getComments", conditions);
			
			if(list.size() == 0){
				// 対応内容追加
				db.insert("reviewRecord.insertComments", conditions);
			}
			else{
				// 対応内容更新
				if (StringUtils.isEmpty(comment_flg)) {
					return;
				}
				db.update("reviewRecord.updateComments", conditions);
			}
		}
	}
	
	// コメントステータス設定
	public void setCommentStatus() throws SoftbankException {

		String file_Id = context.getParam().get("file_Id");
		String comment_Id = context.getParam().get("comment_Id");
		String comment_status = context.getParam().get("comment_status");
		
		Map<String, Object> conditions = Maps.newHashMap();
		if (!"".equals(file_Id) && !"".equals(comment_Id) && !"".equals(comment_status)){
			conditions.put("file_Id", Integer.parseInt(file_Id));
			conditions.put("comment_Id", Integer.parseInt(comment_Id));
			conditions.put("comment_status", Integer.parseInt(comment_status));
			
			List<Map<String, Object>> list = db.querys("reviewRecord.getCommentFileDatas", conditions);

			if(list.size() == 0){
				// 処理なし
				return;
			}
			else{
				// 対応内容更新
				String comment_count = list.get(0).get("comment_count").toString();
				String type = list.get(0).get("type").toString();
				String status_count = "1";
				String status_total = "1";
				if(type.equals("xlsx") || type.equals("xlsm")){
					//excel
					db.update("reviewRecord.updateComment_excel_Datas", conditions);
					List<Map<String, Object>> statusCount = db.querys("reviewRecord.excelStatusCount", conditions);
					status_count = statusCount.get(0).get("unsolved").toString();
					status_total = statusCount.get(0).get("total").toString();
					if(!comment_count.equals(status_count)){
						conditions.put("comment_count", Integer.parseInt(status_count));
						db.update("reviewRecord.updateCommentCount", conditions);
					}
				}else if(type.equals("pptx")){
					//ppt
					db.update("reviewRecord.updateComment_ppt_Datas", conditions);
					List<Map<String, Object>> statusCount = db.querys("reviewRecord.pptStatusCount", conditions);
					status_count = statusCount.get(0).get("unsolved").toString();
					status_total = statusCount.get(0).get("total").toString();
					if(!comment_count.equals(status_count)){
						conditions.put("comment_count", Integer.parseInt(status_count));
						db.update("reviewRecord.updateCommentCount", conditions);
					}
				}else if(type.equals("docx")){
					//doc
					db.update("reviewRecord.updateComment_doc_Datas", conditions);
					List<Map<String, Object>> statusCount = db.querys("reviewRecord.docStatusCount", conditions);
					status_count = statusCount.get(0).get("unsolved").toString();
					status_total = statusCount.get(0).get("total").toString();
					if(!comment_count.equals(status_count)){
						conditions.put("comment_count", Integer.parseInt(status_count));
						db.update("reviewRecord.updateCommentCount", conditions);
					}
				}
				int temp = Integer.parseInt(status_total)-Integer.parseInt(status_count);
				context.getResultBean().setData(temp);
			}
		}
	}
	
	public void fileCopy() throws SoftbankException, ParseException {
		String documentId = context.getParam().get("document_id");
		externalHttpServer.post(messageAccessor.getMessage("application.path") + ":8080/qqrp/qqrp.mx?dispCode=900007&cmdCode=1&issueId=" + documentId); //fileCopy
	}
	
	/**
	* @param urlStr
	* @param fileName
	* @param savePath
	* @throws IOException
	*/
	public void mdDownLoad() throws IOException {
		
		try {
			String urlStr = context.getParam().get("urlStr");
			String fileName = context.getParam().get("fileName");
			String savePath = System.getProperties().getProperty("user.dir") + context.getParam().get("savePath") + System.currentTimeMillis() ;
			
			URL url = new URL(urlStr);  
			HttpURLConnection conn = (HttpURLConnection)url.openConnection();  

			conn.setConnectTimeout(3*1000);

			InputStream inputStream = conn.getInputStream();  

			byte[] getData = readInputStream(inputStream);    


			File saveDir = new File(savePath);
			if(!saveDir.exists()){
				saveDir.mkdir();
			}
			File file = new File(saveDir+File.separator+fileName);
			FileOutputStream fos = new FileOutputStream(file);
			fos.write(getData); 
			if(fos!=null){
				fos.close();  
			}
			if(inputStream!=null){
				inputStream.close();
			}
			
			Runtime.getRuntime().exec("explorer.exe /select," + (savePath + "//" + fileName).replace("//", "\\"));
		} catch (IOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

	}
	/**
	* @param inputStream
	* @return
	* @throws IOException
	*/
	public static  byte[] readInputStream(InputStream inputStream) throws IOException {  
		byte[] buffer = new byte[1024];  
		int len = 0;  
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		while((len = inputStream.read(buffer)) != -1) {
			bos.write(buffer, 0, len);
		}
		bos.close();  
		return bos.toByteArray();  
	}
}
