package co.jp.softbank.qqmx.dao.common;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.SqlSession;

import co.jp.softbank.qqmx.dao.SqlHelper;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.info.ControlSettingMap;
import co.jp.softbank.qqmx.info.ControlSettingMap.SettingKey;
import co.jp.softbank.qqmx.util.LogUtil;

public class QueryDao extends DaoCommon implements IQueryDao {
	
	@Override
	public <E> E executeForObject(String sqlID, Class<?> clazz) throws SoftbankException {
		log.info(LogUtil.s("namespace = {}"), sqlID);
		try {
			SqlSession session = sqlSessionFactory.openSession();
			final E result = session.selectOne(sqlID);
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID);
				log.info("sql = \n{}\n", sqlString.replaceAll("\n", ""));
			}
			log.info(LogUtil.e("namespace = {}"), sqlID);
			return result;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		}
	}

	@Override
	public <E> E executeForObject(String sqlID, Object conditions, Class<?> clazz) throws SoftbankException {
		log.info(LogUtil.s("namespace = {}"), sqlID);
		try {
			SqlSession session = sqlSessionFactory.openSession();
			final E result = session.selectOne(sqlID, conditions);
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID, conditions);
				log.info("sql = \n{}\n", sqlString.replaceAll("\n", ""));
			}
			log.info(LogUtil.e("namespace = {}"), sqlID);
			return result;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		}
	}
	
	@Override
	public <E> List<E> executeForObjectList(String sqlID) throws SoftbankException {
		log.info(LogUtil.s("namespace = {}"), sqlID);
		try {
			SqlSession session = sqlSessionFactory.openSession();
			final List<E> result = session.selectList(sqlID);
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID);
				log.info("sql = \n{}\n", sqlString.replaceAll("\n", ""));
			}
			log.info(LogUtil.e("namespace = {}"), sqlID);
			return result;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		}
	}
	
	@Override
	public <E> List<E> executeForObjectListAndClosed(String sqlID) throws SoftbankException {
		log.info(LogUtil.s("namespace = {}"), sqlID);
		SqlSession session = sqlSessionFactory.openSession();
		try {
			final List<E> result = session.selectList(sqlID);
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID);
				log.info("sql = \n{}\n", sqlString.replaceAll("\n", ""));
			}
			log.info(LogUtil.e("namespace = {}"), sqlID);
			return result;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		} finally {
			session.close();
		}
	}

	@Override
	public <E> List<E> executeForObjectList(String sqlID, Object conditions) throws SoftbankException {
		log.info(LogUtil.s("namespace = {}"), sqlID);
		try {
			SqlSession session = sqlSessionFactory.openSession();
			final List<E> result = session.selectList(sqlID, conditions);
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID, conditions);
				log.info("sql = \n{}\n", sqlString.replaceAll("\n", ""));
			}
			log.info(LogUtil.e("namespace = {}"), sqlID);
			return result;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		}
	}
	
	@Override
	public <E> List<E> executeForObjectListAndClosed(String sqlID, Object conditions) throws SoftbankException {
		log.info(LogUtil.s("namespace = {}"), sqlID);
		SqlSession session = sqlSessionFactory.openSession();
		try {
			final List<E> result = session.selectList(sqlID, conditions);
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID, conditions);
				log.info("sql = \n{}\n", sqlString.replaceAll("\n", ""));
			}
			log.info(LogUtil.e("namespace = {}"), sqlID);
			return result;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		} finally {
			session.close();
		}
	}
	
	@Override
	public Map<String, Object> executeForMap(String sqlID) throws SoftbankException {
		log.info(LogUtil.s("namespace = {}"), sqlID);
		try {
			SqlSession session = sqlSessionFactory.openSession();
			final Map<String, Object> result = session.selectOne(sqlID);
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID);
				log.info("sql = \n{}\n", sqlString.replaceAll("\n", ""));
			}
			log.info(LogUtil.e("namespace = {}"), sqlID);
			return result;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		}
	}
	
	@Override
	public Map<String, Object> executeForMapAndClosed(String sqlID) throws SoftbankException {
		if (ControlSettingMap.getInstance().getBoolean(SettingKey.CASH_SQL_LOG_PRINT)) {
			log.info(LogUtil.s("namespace = {}"), sqlID);
		}
		SqlSession session = sqlSessionFactory.openSession();
		try {
			final Map<String, Object> result = session.selectOne(sqlID);
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT) 
					&& ControlSettingMap.getInstance().getBoolean(SettingKey.CASH_SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID);
				log.info("sql = \n{}\n", sqlString.replaceAll("\n", ""));
			}
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.CASH_SQL_LOG_PRINT)) {
				log.info(LogUtil.e("namespace = {}"), sqlID);
			}
			return result;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		} finally {
			session.close();
		}
	}

	@Override
	public Map<String, Object> executeForMap(String sqlID, Object conditions) throws SoftbankException {
		log.info(LogUtil.s("namespace = {}"), sqlID);
		try {
			SqlSession session = sqlSessionFactory.openSession();
			final Map<String, Object> result = session.selectOne(sqlID, conditions);
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID, conditions);
				log.info("sql = \n{}\n", sqlString.replaceAll("\n", ""));
			}
			log.info(LogUtil.e("namespace = {}"), sqlID);
			return result;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		}
	}
	
	@Override
	public Map<String, Object> executeForMapAndClosed(String sqlID, Object conditions) throws SoftbankException {
		if (ControlSettingMap.getInstance().getBoolean(SettingKey.CASH_SQL_LOG_PRINT)) {
			log.info(LogUtil.s("namespace = {}"), sqlID);
		}
		SqlSession session = sqlSessionFactory.openSession();
		try {
			final Map<String, Object> result = session.selectOne(sqlID, conditions);
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT) 
					&& ControlSettingMap.getInstance().getBoolean(SettingKey.CASH_SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID, conditions);
				log.info("sql = \n{}\n", sqlString.replaceAll("\n", ""));
			}
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.CASH_SQL_LOG_PRINT)) {
				log.info(LogUtil.e("namespace = {}"), sqlID);
			}
			return result;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		} finally {
			session.close();
		}
	}
	
	@Override
	public List<Map<String, Object>> executeForMapList(String sqlID) throws SoftbankException {
		log.info(LogUtil.s("namespace = {}"), sqlID);
		try {
			SqlSession session = sqlSessionFactory.openSession();
			final List<Map<String, Object>> result = session.selectList(sqlID);
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID);
				log.info("namespace = {}, sql = \n{}\n", sqlID, sqlString.replaceAll("\n", ""));
			}
			log.info(LogUtil.e("namespace = {}"), sqlID);
			return result;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		}
	}
	
	@Override
	public List<Map<String, Object>> executeForMapListAndClosed(String sqlID) throws SoftbankException {
		if (ControlSettingMap.getInstance().getBoolean(SettingKey.CASH_SQL_LOG_PRINT)) {
			log.info(LogUtil.s("namespace = {}"), sqlID);
		}
		SqlSession session = sqlSessionFactory.openSession();
		try {
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT) 
					&& ControlSettingMap.getInstance().getBoolean(SettingKey.CASH_SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID);
				log.info("sql = \n{}\n", sqlString.replaceAll("\n", ""));
			}
			final List<Map<String, Object>> result = session.selectList(sqlID);
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.CASH_SQL_LOG_PRINT)) {
				log.info(LogUtil.e("namespace = {}"), sqlID);
			}
			return result;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		} finally {
			session.close();
		}
	}

	@Override
	public List<Map<String, Object>> executeForMapList(String sqlID, Object conditions) throws SoftbankException {
		log.info(LogUtil.s("namespace = {}"), sqlID);
		try {
			SqlSession session = sqlSessionFactory.openSession();
			final List<Map<String, Object>> result = session.selectList(sqlID, conditions);
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID, conditions);
				log.info("sql = \n{}\n", sqlString.replaceAll("\n", ""));
			}
			log.info(LogUtil.e("namespace = {}"), sqlID);
			return result;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		}
	}
	
	@Override
	public List<Map<String, Object>> executeForMapListAndClosed(String sqlID, Object conditions) throws SoftbankException {
		if (ControlSettingMap.getInstance().getBoolean(SettingKey.CASH_SQL_LOG_PRINT)) {
			log.info(LogUtil.s("namespace = {}"), sqlID);
		}
		SqlSession session = sqlSessionFactory.openSession();
		try {
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT) 
					&& ControlSettingMap.getInstance().getBoolean(SettingKey.CASH_SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID, conditions);
				log.info("sql = \n{}\n", sqlString.replaceAll("\n", ""));
			}
			final List<Map<String, Object>> result = session.selectList(sqlID, conditions);
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.CASH_SQL_LOG_PRINT)) {
				log.info(LogUtil.e("namespace = {}"), sqlID);
			}
			return result;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		} finally {
			session.close();
		}
	}

	@Override
	public SqlSession getQuerySession() {
		return sqlSessionFactory.openSession();
	}

	@Override
	public <E> E executeForObject(String sqlID) throws SoftbankException {
		log.info(LogUtil.s("namespace = {}"), sqlID);
		try {
			SqlSession session = sqlSessionFactory.openSession();
			final E result = session.selectOne(sqlID);
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID);
				log.info("sql = \n{}\n", sqlString.replaceAll("\n", ""));
			}
			log.info(LogUtil.e("namespace = {}"), sqlID);
			return result;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		}
	}

	@Override
	public <E> E executeForObject(String sqlID, Object conditions) throws SoftbankException {
		log.info(LogUtil.s("namespace = {}"), sqlID);
		try {
			SqlSession session = sqlSessionFactory.openSession();
			final E result = session.selectOne(sqlID, conditions);
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID, conditions);
				log.info("sql = \n{}\n", sqlString.replaceAll("\n", ""));
			}
			log.info(LogUtil.e("namespace = {}"), sqlID);
			return result;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		}
	}

	@Override
	public <E> E executeForObjectAndClosed(String sqlID) throws SoftbankException {
		if (ControlSettingMap.getInstance().getBoolean(SettingKey.CASH_SQL_LOG_PRINT)) {
			log.info(LogUtil.s("namespace = {}"), sqlID);
		}
		SqlSession session = sqlSessionFactory.openSession();
		try {
			final E result = session.selectOne(sqlID);
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT) 
					&& ControlSettingMap.getInstance().getBoolean(SettingKey.CASH_SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID);
				log.info("sql = \n{}\n", sqlString.replaceAll("\n", ""));
			}
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.CASH_SQL_LOG_PRINT)) {
				log.info(LogUtil.e("namespace = {}"), sqlID);
			}
			return result;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		} finally {
			session.close();
		}
	}

	@Override
	public <E> E executeForObjectAndClosed(String sqlID, Object conditions) throws SoftbankException {
		if (ControlSettingMap.getInstance().getBoolean(SettingKey.CASH_SQL_LOG_PRINT)) {
			log.info(LogUtil.s("namespace = {}"), sqlID);
		}
		SqlSession session = sqlSessionFactory.openSession();
		try {
			final E result = session.selectOne(sqlID, conditions);
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT) 
					&& ControlSettingMap.getInstance().getBoolean(SettingKey.CASH_SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID, conditions);
				log.info("sql = \n{}\n", sqlString.replaceAll("\n", ""));
			}
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.CASH_SQL_LOG_PRINT)) {
				log.info(LogUtil.e("namespace = {}"), sqlID);
			}
			return result;
		} catch (Exception e) {
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		} finally {
			session.close();
		}
	}

}
