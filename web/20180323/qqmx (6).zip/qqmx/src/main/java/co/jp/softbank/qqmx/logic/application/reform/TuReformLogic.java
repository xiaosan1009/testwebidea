package co.jp.softbank.qqmx.logic.application.reform;

import java.io.UnsupportedEncodingException;
import java.text.ParseException;
import java.util.List;
import java.util.Map;

import org.ho.yaml.Yaml;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.ControlDbMemory;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.DateUtils;
import co.jp.softbank.qqmx.util.StringUtils;


public class TuReformLogic extends AbstractBaseLogic {
	
	public void getSelectList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String selectId = context.getParam().get("selectFlg");
		//統括
		String headquartersId = context.getParam().get("headquartersId").equals("")? "9898": context.getParam().get("headquartersId");
		//本部
		String divisionId = context.getParam().get("divisionId").equals("")? "9898": context.getParam().get("divisionId");
		//統括部
		String departmentId = context.getParam().get("departmentId").equals("")? "9898": context.getParam().get("departmentId");
		
		if ("headquarters".equals(selectId)){
			context.getResultBean().setData(db.querys("tuReform.getHeadquartersList"));
		} else if ("division".equals(selectId)){
			conditions.put("headquarters_Id", Integer.parseInt(headquartersId));
			context.getResultBean().setData(db.querys("tuReform.getDivisionList", conditions));
		} else if ("department".equals(selectId)){
			conditions.put("division_id", Integer.parseInt(divisionId));
			context.getResultBean().setData(db.querys("tuReform.getDepartmentList", conditions));
		} else if ("region".equals(selectId)){
			conditions.put("department_Id", Integer.parseInt(departmentId));
			context.getResultBean().setData(db.querys("tuReform.getRegionList", conditions));
		} else {
			context.getResultBean().setData(Lists.newArrayList());
		}
	}
	
	public void getStudyList() throws SoftbankException {
		context.getResultBean().setData(db.querys("tuReform.getStudyList"));
	}
	
	public void getStudyInitInfo() throws SoftbankException {
		context.getResultBean().setData(db.querys("tuReform.getStudyInitInfo"));
	}
	
	public void getTuSettingsStudyInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		//保存履歴
		String study = null;
		if (!StringUtils.isEmpty(context.getParam().get("tuStudy"))) {
			if (!"9898".equals(context.getParam().get("tuStudy"))) {
				study = context.getParam().get("tuStudy");
				conditions.put("tu_created_on", study);
				context.getResultBean().setData(db.query("tuReform.getTuSettingsStudyInfo", conditions));
			}
		}
	}
	
	public void upTuSettingsInfo() throws SoftbankException,UnsupportedEncodingException {
		
		Map<String, Object> conditions = Maps.newHashMap();
		String dateDt = context.getParam().get("dateDt");
		conditions.put("monthInfor", dateDt);
		context.getResultBean().setData(db.update("tuReform.updateChartMonthInfo", conditions));
	}
	
	public void getTuSettingsInfo() throws SoftbankException,UnsupportedEncodingException {
		
		context.getResultBean().setData(db.query("tuReform.getChartMonthInfo"));
	}
	
	public void getUserInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("flg", false);
		if (context.getSessionData().getUserInfo().isAdmin()) {
			conditions.put("flg", true);
		} else {
			if (context.getSessionData().getRoles().get("manage_users") != null) {
				conditions.put("flg", true);
			}
		}
		context.getResultBean().setData(conditions);
	}
	
	public void delStudyInfo() throws SoftbankException {
		String id =  context.getParam().get("id");
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("id", id);
		db.delete("tuReform.deleteTitleInfById", conditions);
		db.delete("tuReform.delStudyInfo", conditions);
	}
	
	public void setStudyInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String date = context.getParam().get("date");
		
		String date1 = context.getParam().get("date1");
		conditions.put("tu_created_on", DateUtils.formatToDate(date, DateUtils.FORMAT_YYYYMMDDHHMMSS_DASH));
		String name = context.getParam().get("tuReformName");
		String flg = context.getParam().get("flg");
		if ("update".equals(flg)) {
			conditions.put("name", "0" );
			db.insert("tuReform.setStudyInfo", conditions);
			db.delete("tuReform.deleteStudyInfo");
			ControlDbMemory.getInstance().setTuNewDate(date1);
		} else {
			conditions.put("name", name );
			this.insertTitle(name);
			db.insert("tuReform.setStudyInfo", conditions);
		}
	}
	
	public void upStudyNameInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String date = context.getParam().get("date");
		String name = context.getParam().get("name");
		conditions.put("tu_created_on", date);
		conditions.put("name", name);
		db.update("tuReform.updateChartNameInfo", conditions);
		db.insert("tuReform.upStudyNameInfo", conditions);
	}

	public void getPopSelectList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String selectId = context.getParam().get("selectFlg");
		//統括
		String headquartersId = context.getParam().get("headquartersIdPop").equals("")? "9898": context.getParam().get("headquartersIdPop");
		//本部
		String divisionId = context.getParam().get("divisionIdPop").equals("")? "9898": context.getParam().get("divisionIdPop");
		//統括部
		String departmentId = context.getParam().get("departmentIdPop").equals("")? "9898": context.getParam().get("departmentIdPop");
		
		if ("headquarters".equals(selectId)){
			context.getResultBean().setData(db.querys("tuReform.getHeadquartersList"));
		} else if ("division".equals(selectId)){
			conditions.put("headquarters_Id", Integer.parseInt(headquartersId));
			context.getResultBean().setData(db.querys("tuReform.getDivisionList", conditions));
		} else if ("department".equals(selectId)){
			conditions.put("division_id", Integer.parseInt(divisionId));
			context.getResultBean().setData(db.querys("tuReform.getDepartmentList", conditions));
		} else if ("region".equals(selectId)){
			conditions.put("department_Id", Integer.parseInt(departmentId));
			context.getResultBean().setData(db.querys("tuReform.getRegionList", conditions));
		} else {
			context.getResultBean().setData(Lists.newArrayList());
		}
	}
	
	public void getNewDate() throws SoftbankException {
		context.getResultBean().setData(ControlDbMemory.getInstance().getTuNewDate());
	}
	
	public void doFilter() throws SoftbankException {
		UserInfoData userInfoData = context.getSessionData().getUserInfo();
		if (userInfoData == null || userInfoData.isAdmin()) {
			context.getResultBean().setFilter(true);
			return;
		}
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", 1593);
		List<Map<String, Object>> roles = db.querys("roles.selectUserRolesForProject", conditions);
		if (roles == null || roles.size() == 0) {
			return;
		}
		for (int i = 0; i < roles.size(); i++) {
			Map<String, Object> roleData = roles.get(i);
			List<String> nonRoles = (List<String>)Yaml.load(StringUtils.toString(roleData.get("permissions")));
			if (nonRoles!= null && nonRoles.size() > 0) {
				for (int j = 0; j < nonRoles.size(); j++) {
					String role = nonRoles.get(j);
					if (role.startsWith(ConstantsUtil.Str.COLON)) {
						role = role.substring(1);
					}
					if ("ipf_exec_graph_pattern_project".equals(role)) {
						context.getResultBean().setFilter(true);
						return;
					}
				}
			}
		}
		return;
	}
	private void insertTitle (String code) throws SoftbankException{
		Map<String, Object> conditions = Maps.newHashMap();
		Map<String, Object> dateConditions = db.query("tuReform.getChartMonthInfo");
		
		conditions.put("code", code);
		conditions.put("name", dateConditions.get("name"));
		db.insert("tuReform.insertTitle", conditions);
	}
}
