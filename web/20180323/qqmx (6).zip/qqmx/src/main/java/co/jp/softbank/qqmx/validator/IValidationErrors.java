package co.jp.softbank.qqmx.validator;

import org.apache.commons.validator.Field;
import org.apache.commons.validator.ValidatorAction;

public interface IValidationErrors {

	void addError(Object bean, Field field, ValidatorAction va);
	
	void addError(Object bean, Field field, ValidatorAction va, Object[] args);
	
	void addError(Object bean, Field field, ValidatorAction va, String errorCode);
	
	void addError(Object bean, Field field, ValidatorAction va, Object[] args, String errorCode);
	
}
