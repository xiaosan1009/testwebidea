package co.jp.softbank.qqmx.handle.impl;

import co.jp.softbank.qqmx.handle.AbstractTaskScriptHandler;

public class ScriptTaskhandlerImpl extends AbstractTaskScriptHandler {

}
