package co.jp.softbank.qqmx.dao.project;

import java.util.List;
import java.util.Map;

public interface GaiyouDao {
	
	List<Map<String, Object>> getMembers(Map<String, Object> conditions);
	
	List<Map<String, Object>> getTrackers(Map<String, Object> conditions);
	
	List<Map<String, Object>> getTrackerCounts(Map<String, Object> conditions);
	
	List<Map<String, Object>> getTrackerAllCounts(Map<String, Object> conditions);
	
	List<Map<String, Object>> getCustomValues(Map<String, Object> conditions);

}
