package co.jp.softbank.qqmx.task.face;

import java.util.Iterator;

public interface IFileIterator<T> extends Iterator {
	
	void close();

}
