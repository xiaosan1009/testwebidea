package co.jp.softbank.qqmx.dao.common;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.session.ExecutorType;
import org.apache.ibatis.session.SqlSession;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.dao.SqlHelper;
import co.jp.softbank.qqmx.dao.common.DbExecuteImpl.MakeConditionsListener;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.info.ControlSettingMap;
import co.jp.softbank.qqmx.info.ControlSettingMap.SettingKey;
import co.jp.softbank.qqmx.info.bean.UserInfoData;

public class UpdateDao extends DaoCommon implements IUpdateDao {

	@Override
	public int insert(String sqlID) throws SoftbankException {
		log.info("insert start! sqlID = {}", sqlID);
		SqlSession session = getSession();
		int result = session.insert(sqlID);
		if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT)) {
			String sqlString = SqlHelper.getNamespaceSql(session, sqlID);
			log.info("namespace = {}, sql = \n{}\n", sqlID, sqlString.replaceAll("\n", ""));
		}
		log.info("update end!");
		return result;
	}
	
	@Override
	public int insertC(String sqlID) throws SoftbankException {
		log.info("insert start! sqlID = {}", sqlID);
		SqlSession session = getSession();
		try {
			int result = session.insert(sqlID);
			session.commit();
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID);
				log.info("namespace = {}, sql = \n{}\n", sqlID, sqlString.replaceAll("\n", ""));
			}
			log.info("update end!");
			return result;
		} catch (Exception e) {
			session.rollback();
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		} finally {
			session.close();
		}
	}

	@Override
	public int insert(String sqlID, Object conditions) throws SoftbankException {
		log.info("insert start! sqlID = {}", sqlID);
		try {
			SqlSession session = getSession();
			int result = session.insert(sqlID, conditions);
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID, conditions);
				log.info("namespace = {}, sql = \n{}\n", sqlID, sqlString.replaceAll("\n", ""));
			}
			log.info("update end!");
			return result;
		} catch (Exception e) {
			log.error("namespace = {}, conditions = \n{}\n", sqlID, getSqlConditions(conditions));
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		}
	}
	
	@Override
	public void ins(String sqlID, List<Map<String, Object>> datas) throws SoftbankException {
		SqlSession session = getBatchSession();
		try {
			for (Map<String, Object> kv : datas) {
				session.insert(sqlID, kv);
			}
//			session.flushStatements();
//			session.clearCache();
		} catch (Exception e) {
			log.error("namespace = {}, conditions = \n{}\n", sqlID, datas);
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		}
	}
	
	@Override
	public int insertC(String sqlID, Object conditions) throws SoftbankException {
		log.info("insert start! sqlID = {}", sqlID);
		SqlSession session = getSession();
		try {
			int result = session.insert(sqlID, conditions);
			session.commit();
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID, conditions);
				log.info("namespace = {}, sql = \n{}\n", sqlID, sqlString.replaceAll("\n", ""));
			}
			log.info("update end!");
			return result;
		} catch (Exception e) {
			session.rollback();
			log.error("namespace = {}, conditions = \n{}\n", sqlID, getSqlConditions(conditions));
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		} finally {
			session.close();
		}
	}

	@Override
	public int update(String sqlID) throws SoftbankException {
		log.info("update start! sqlID = {}", sqlID);
		SqlSession session = getSession();
		int result = session.update(sqlID);
		if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT)) {
			String sqlString = SqlHelper.getNamespaceSql(session, sqlID);
			log.info("namespace = {}, sql = \n{}\n", sqlID, sqlString.replaceAll("\n", ""));
		}
		log.info("update end!");
		return result;
	}
	
	@Override
	public int updateC(String sqlID) throws SoftbankException {
		log.info("update start! sqlID = {}", sqlID);
		SqlSession session = getSession();
		try {
			int result = session.update(sqlID);
			session.commit();
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID);
				log.info("namespace = {}, sql = \n{}\n", sqlID, sqlString.replaceAll("\n", ""));
			}
			log.info("update end!");
			return result;
		} catch (Exception e) {
			session.rollback();
			log.error("namespace = {}\n", sqlID);
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		} finally {
			session.close();
		}
	}

	@Override
	public int update(String sqlID, Object conditions) throws SoftbankException {
		log.info("update start! sqlID = {}", sqlID);
		try {
			SqlSession session = getSession();
			int result = session.update(sqlID, conditions);
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID, conditions);
				log.info("namespace = {}, sql = \n{}\n", sqlID, sqlString.replaceAll("\n", ""));
			}
			log.info("update end!");
			return result;
		} catch (Exception e) {
			log.error("namespace = {}, conditions = \n{}\n", sqlID, getSqlConditions(conditions));
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		}
	}
	
	@Override
	public int updateC(String sqlID, Object conditions) throws SoftbankException {
		log.info("update start! sqlID = {}", sqlID);
		SqlSession session = getSession();
		try {
			int result = session.update(sqlID, conditions);
			session.commit();
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID, conditions);
				log.info("namespace = {}, sql = \n{}\n", sqlID, sqlString.replaceAll("\n", ""));
			}
			log.info("update end!");
			return result;
		} catch (Exception e) {
			session.rollback();
			log.error("namespace = {}, conditions = \n{}\n", sqlID, getSqlConditions(conditions));
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		} finally {
			session.close();
		}
	}

	@Override
	public int delete(String sqlID) throws SoftbankException {
		log.info("delete start! sqlID = {}", sqlID);
		SqlSession session = getSession();
		int result = session.delete(sqlID);
		if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT)) {
			String sqlString = SqlHelper.getNamespaceSql(session, sqlID);
			log.info("namespace = {}, sql = \n{}\n", sqlID, sqlString.replaceAll("\n", ""));
		}
		log.info("delete end!");
		return result;
	}
	
	@Override
	public int deleteC(String sqlID) throws SoftbankException {
		log.info("delete start! sqlID = {}", sqlID);
		SqlSession session = getSession();
		try {
			int result = session.delete(sqlID);
			session.commit();
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID);
				log.info("namespace = {}, sql = \n{}\n", sqlID, sqlString.replaceAll("\n", ""));
			}
			log.info("delete end!");
			return result;
		} catch (Exception e) {
			session.rollback();
			log.error("namespace = {}\n", sqlID);
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		} finally {
			session.close();
		}
	}

	@Override
	public int delete(String sqlID, Object conditions) throws SoftbankException {
		log.info("delete start! sqlID = {}", sqlID);
		try {
			SqlSession session = getSession();
			int result = session.delete(sqlID, conditions);
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID, conditions);
				log.info("namespace = {}, sql = \n{}\n", sqlID, sqlString.replaceAll("\n", ""));
			}
			log.info("delete end!");
			return result;
		} catch (Exception e) {
			log.error("namespace = {}, conditions = \n{}\n", sqlID, getSqlConditions(conditions));
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		}
	}
	
	@Override
	public int deleteC(String sqlID, Object conditions) throws SoftbankException {
		log.info("delete start! sqlID = {}", sqlID);
		SqlSession session = getSession();
		try {
			int result = session.delete(sqlID, conditions);
			session.commit();
			if (ControlSettingMap.getInstance().getBoolean(SettingKey.SQL_LOG_PRINT)) {
				String sqlString = SqlHelper.getNamespaceSql(session, sqlID, conditions);
				log.info("namespace = {}, sql = \n{}\n", sqlID, sqlString.replaceAll("\n", ""));
			}
			log.info("delete end!");
			return result;
		} catch (Exception e) {
			session.rollback();
			log.error("namespace = {}, conditions = \n{}\n", sqlID, getSqlConditions(conditions));
			log.error(e.getMessage(), e);
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		} finally {
			session.close();
		}
	}

	@Override
	public void inserts(String sqlID, List<Map<String, Object>> datas, MakeConditionsListener listener)
			throws SoftbankException {
		SqlSession session = getBatchSession();
		try {
			for (Map<String, Object> kv : datas) {
				session.insert(sqlID, listener.makeConditions(kv));
			}
//			session.flushStatements();
			session.commit();
			session.clearCache();
		} catch (Exception e) {
			session.rollback();
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		} finally {
			session.close();
		}
	}
	
	@Override
	public void updates(String sqlID, List<Map<String, Object>> datas, MakeConditionsListener listener) throws SoftbankException {
		SqlSession session = getBatchSession();
		try {
			for (Map<String, Object> kv : datas) {
				session.update(sqlID, listener.makeConditions(kv));
			}
			session.commit();
			session.clearCache();
		} catch (Exception e) {
			session.rollback();
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		} finally {
			session.close();
		}
	}
	
	@Override
	public void deletes(String sqlID, List<Map<String, Object>> datas) throws SoftbankException {
		SqlSession session = getBatchSession();
		try {
			for (Map<String, Object> kv : datas) {
				session.delete(sqlID, kv);
			}
			session.commit();
			session.clearCache();
		} catch (Exception e) {
			session.rollback();
			throw new SoftbankException(SoftbankExceptionType.SQLException, e);
		} finally {
			session.close();
		}
	}
	
	private SqlSession getSession() {
		return sqlSessionFactory.openSession();
	}
	
	private SqlSession getBatchSession() {
		return sqlSessionFactory.openSession(ExecutorType.BATCH);
	}

}
