package co.jp.softbank.qqmx.logic.application.mit;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Collections;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.util.StringUtils;

public class MitAccessGraphLogic extends AbstractBaseLogic {
	private final static String DATE_FORMAT = "yyyy/MM/dd";
	
	private final static SimpleDateFormat SDF = new SimpleDateFormat(DATE_FORMAT);
	public void getLineData() throws SoftbankException, ParseException {
		Map<String, Object> conditions = Maps.newHashMap();
		String organizationCd = context.getParam().get("organizationCd");
		if(StringUtils.isNotEmpty(organizationCd)) {
			conditions.put("organization_cd", organizationCd);
		} 	
		String model = context.getParam().get("mit_access_select");
		int type =  StringUtils.toInt(model);
		List<String> xDate = Lists.newArrayList();
		
		String datepickerStart = context.getParam().get("datepickerStart");
		if(StringUtils.isNotEmpty(datepickerStart)){
			conditions.put("start_date", datepickerStart);
			datepickerStart = datepickerStart.replace("-", "/");
			xDate.add(getFirstDay(datepickerStart , type));
		}
		String datepickerEnd = context.getParam().get("datepickerEnd");
		if(StringUtils.isNotEmpty(datepickerEnd)){
			conditions.put("end_date", datepickerEnd);
		}
		
		String format = "YYYY/MM/DD";
		
		if ("1".equals(model)) {
			format = "YYYY";
		} else if ("2".equals(model)) {
			format = "YYYY/MM";
		} 
		conditions.put("format", format);

		
		List<Map<String,Object>> resultDB = db.querys("mitAccess.selectMitAccessInfoForLine", conditions);
		Map<String,Object> resultCodeAndName = Maps.newHashMap();
		
		Map<String,Object> resultMain = db.query("mitAccess.selectMitAccessMain", conditions);
		resultCodeAndName.put(organizationCd, resultMain.get("organization_name"));
		Map<String,Object> result = Maps.newHashMap();
		
		Map<String,List<Object[]>> resultData = Maps.newHashMap();
	
		conditions.put("organization_cd", organizationCd);
		
	
		String orgna_id = "";
		Object[] ob = new Object[2];
		
		for (int i = 0; i < resultDB.size(); i++) {
			int weekOfYearTemp = -1;
			int YearTemp = -1;
			Map<String, Object> resultTemp = resultDB.get(i);
			String org_id = StringUtils.toString(resultTemp.get("root_cd"));
			String org_name = StringUtils.toString(resultTemp.get("root_name"));
			String dataOfResult = formatDateByType(StringUtils.toString(resultTemp.get("created_on")), model);
			resultCodeAndName.put(org_id, org_name);
			if("3".equals(model)){
				weekOfYearTemp = inforOfStringDate(dataOfResult, Calendar.WEEK_OF_YEAR);
				YearTemp = inforOfStringDate(dataOfResult, Calendar.YEAR);
				dataOfResult = getMonday(dataOfResult);
			}
			int accessCount = StringUtils.toInt(resultTemp.get("count"));
		
			if (!orgna_id.equals(org_id)) {
				orgna_id = org_id;
				ob = new Object[3];
				ob[0] = dataOfResult;
				ob[1] = accessCount;
				ob[2] = org_name;
				List<Object[]> res = Lists.newArrayList();
				res.add(ob);
				resultData.put(org_id, res);
				if(!xDate.contains(dataOfResult)){
					xDate.add(dataOfResult);
				}
				
			} else {
				List<Object[]> resultExist = resultData.get(org_id);
				String exsitDate = StringUtils.toString(resultExist.get(resultExist.size() - 1)[0]);
				int exsitAcess = StringUtils.toInt(resultExist.get(resultExist.size() - 1)[1]);
				
				int  existWk = -2;
				int  existYear = -2;
				if("3".equals(model)){
					existWk = inforOfStringDate(exsitDate, Calendar.WEEK_OF_YEAR);
					existYear = inforOfStringDate(exsitDate, Calendar.YEAR);
				}
			
				if ("3".equals(model) && existWk == weekOfYearTemp && existYear == YearTemp) {
					ob = new Object[3];
					ob[0] = exsitDate;
					ob[1] = exsitAcess + accessCount;
					ob[2] = org_name;
					resultExist.remove(resultExist.size() -1);
//					resultExist = Lists.newArrayList();
					resultExist.add(ob);
					resultData.put(org_id, resultExist);
				} else {
					weekOfYearTemp = existWk;
					YearTemp = existYear;
					ob = new Object[3];
					ob[0] = dataOfResult;
					ob[1] = accessCount;
					ob[2] = org_name;
					resultExist.add(ob);
					resultData.put(org_id, resultExist);
					if(!xDate.contains(dataOfResult)){
						xDate.add(dataOfResult);
					}
					
				}
			}
		}
		String minDay = "";
		if(xDate.size() > 0 ){
			Collections.sort(xDate);
			
			if(StringUtils.isNotEmpty(datepickerEnd)){
				result.put("maxDate", datepickerEnd.replace("-", "/"));
			} else {
				result.put("maxDate", SDF.format(new Date()));
			}
		 
			String dateStartTemp = xDate.get(0);
			String dateEndTemp = StringUtils.toString(result.get("maxDate"));
			List<String> tickValue = Lists.newArrayList();
			xDate = Lists.newArrayList();
			xDate = getXdateSeries(dateStartTemp, dateEndTemp, type);
			int size = xDate.size() - 1;
			int loop = 3;
				
			Double timeBetweenTemp = (Math.ceil( Double.valueOf(size) /  Double.valueOf(loop)));
			int timeBetween = timeBetweenTemp.intValue();
			tickValue.add(getFirstDay(dateStartTemp , type));
				
			for (int i = 1; i < loop; i++) {
				tickValue.add(stringDateAdd(dateStartTemp, i * timeBetween , type));
			}
			tickValue.add(getFirstDay(dateEndTemp , type));
			result.put("tickValue", tickValue); 
			minDay = xDate.get(0);
		}
	
	
		if(StringUtils.isNotEmpty(datepickerStart) && datepickerStart.compareTo(minDay)  < 0){
			minDay =  datepickerStart.replace("-", "/");
		} 
		for (Entry<String, List<Object[]>> entry : resultData.entrySet()) {
			List<Object[]> resultTemp = entry.getValue();
			List<Object[]> resultT = ArrayInit(resultTemp, type, minDay);
			resultData.put(entry.getKey(), resultT);
		}
		// 处理成以部门/组织为key，时间-访问数量为value的map
		result.put("lineCodeAndName", resultCodeAndName);
		result.put("resultData", resultData);
		context.getResultBean().setData(result);
	}
	
	public void getPieData() throws SoftbankException, ParseException {

		Map<String, Object> conditions = Maps.newHashMap();
		String organizationCd = context.getParam().get("organizationCd");
		if(StringUtils.isNotEmpty(organizationCd)) {
			conditions.put("organization_cd", organizationCd);
		} 											 
		String datepickerStart = context.getParam().get("datepickerStart");
		if(StringUtils.isNotEmpty(datepickerStart)){
			conditions.put("start_date", datepickerStart);
		}
		String datepickerEnd = context.getParam().get("datepickerEnd");
		if(StringUtils.isNotEmpty(datepickerEnd)){
			conditions.put("end_date", datepickerEnd);
		}
		String format = "YYYY/MM/DD";
		conditions.put("format", format);

		List<Map<String,Object>> resultDB = db.querys("mitAccess.selectMitAccessInfoForPie", conditions);
		Map<String,Object> result = Maps.newHashMap();
		Map<String,Integer> resultData = Maps.newHashMap();
		Map<String,Object> resultIdAndName = Maps.newHashMap();
		Map<String,Object> resultMain = db.query("mitAccess.selectMitAccessMain", conditions);
		resultIdAndName.put(organizationCd, resultMain.get("organization_name"));
		// 年
		for (int i = 0; i < resultDB.size(); i++) {
			Map<String, Object> resultTemp = resultDB.get(i);
			String org_id = StringUtils.toString(resultTemp.get("root_cd"));
			String org_name = StringUtils.toString(resultTemp.get("root_name"));
			

			int accessCount = StringUtils.toInt(resultTemp.get("count"));
			
			if(!resultData.containsKey(org_name)){
				resultData.put(org_name, accessCount);
				resultIdAndName.put(org_name, org_id);
			} else {
				resultData.put(org_name, StringUtils.toInt(resultData.get(org_name)) + accessCount);
			}
		}
		
		// 处理成以部门/组织为key，访问数量为value的map
		result.put("resultData", resultData);
		result.put("resultIdAndName", resultIdAndName);
		context.getResultBean().setData(result);
	}
	private Date stringToDate (String str) throws ParseException{
		Date dt = SDF.parse(str);
		return dt;
	}
	
	private int getInforOfDate (Date date,int model){
		Calendar cal = Calendar.getInstance();
		cal.setTime(date);
		if(Calendar.WEEK_OF_YEAR == model){
			cal.setFirstDayOfWeek(Calendar.MONDAY);
		}
		return cal.get(model);
	}
	private int inforOfStringDate (String date ,int model) throws ParseException{
		Date dt = stringToDate(date);
		int infor = getInforOfDate(dt ,model);
		return infor;
	}
	private String formatDateByType (String date ,String model) throws ParseException{
		if(Calendar.YEAR == StringUtils.toInt(model)){
			return date + "/01/01";
		}
		else if(Calendar.MONTH == StringUtils.toInt(model)){
			 return date + "/01";
		}
		else return date;
	}
	private String getMonday (String date) throws ParseException{
		Date dt = stringToDate(date);
		Calendar cal = Calendar.getInstance();
		cal.setTime(dt);
		cal.setFirstDayOfWeek(Calendar.MONDAY);
		cal.set(Calendar.DAY_OF_WEEK, Calendar.MONDAY);
		String result = SDF.format(cal.getTime());
		return result;
	}
	private String stringDateAdd (String date,int weeks , int type) throws ParseException {
		Date dt = stringToDate(date);
		Calendar cal = Calendar.getInstance();
		cal.setTime(dt);
		cal.add(type, weeks);
		Date resultDate = cal.getTime();
		String result = SDF.format(resultDate);
		return result;
	}
	

	private List<String> getXdateSeries (String startDate, String endDate ,int type) throws ParseException {
		List<String> result = Lists.newArrayList();
		int i = 0;
		while (stringDateAdd(startDate, i , type).compareTo(endDate) <= 0){
			result.add(stringDateAdd(startDate, i, type));
			i++;
		}
		
		return result;
	}
	private List<Object[]> ArrayInit (List<Object[]> list ,int type, String minDay) throws ParseException{
		if(list.isEmpty() || StringUtils.isEmpty(minDay)){
			return Lists.newArrayList();
		}
		String maxDay = StringUtils.toString(list.get(list.size() - 1)[0]);
		List<Object[]> result = Lists.newArrayList();
		int count = 0;
		int listCount = 0;
		
		String date = stringDateAdd(minDay, count, type);
		
		while (date.compareTo(maxDay) <= 0) {
		
			Object[] data = list.get(listCount);
			if(StringUtils.toString(data[0]).compareTo(date) <= 0) {
				result.add(data);
				count++;
				listCount++;
			}else{
				count++;
				result.add(new Object[]{date, 0 ,data[2]});
			}
			date = stringDateAdd(minDay, count, type);
		}
		maxDay = stringDateAdd(maxDay, 1, type);
		String now = SDF.format(new Date());
		String datepickerEnd = context.getParam().get("datepickerEnd");
		if(StringUtils.isNotEmpty(datepickerEnd)){
			now =  datepickerEnd.replace("-", "/");
		} 
			if(maxDay.compareTo(now) <= 0){
				while (maxDay.compareTo( now) <= 0) {
					result.add(new Object[]{maxDay, 0 ,list.get(0)[2]});
					maxDay = stringDateAdd(maxDay, 1, type); 
				}
			}	
			
		return result;
	}
	private String getFirstDay (String date,int type) throws ParseException {
	
		Date dt = stringToDate(date);
		Calendar cal = Calendar.getInstance();
		cal.setTime(dt);
		if(Calendar.MONTH == type){
			cal.set(Calendar.DAY_OF_MONTH, 1);
		}
		else if(Calendar.YEAR == type) {
			cal.set(Calendar.DAY_OF_YEAR, 1);
		}
		
		Date resultDate = cal.getTime();
		String result = SDF.format(resultDate);
		return result;	
	}
}
