package co.jp.softbank.qqmx.logic.application.project;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.util.StringUtils;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class ForumBoardsLogic extends AbstractBaseLogic {

	public void getBoardsList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		int projectId = context.getParam().projectId;
		conditions.put("project_id", projectId);
		List<Map<String, Object>> attachments = db.querys("forumBoardsList.getBoardsList", conditions);
		
		String[][] forumArr = new String[attachments.size()][9];
		
		for (int i = 0; i < attachments.size(); i++) {
			Map<String, Object> dataMap = attachments.get(i);
			
			// フォーラム題名
			String name = StringUtils.toString(dataMap.get("name"));
			// フォーラム説明
			String description = StringUtils.toString(dataMap.get("description"));
			forumArr[i][0] = name;
			forumArr[i][5] = description;
			
			String topic = "0";
			String message = "0";
			// topic件数
			if (StringUtils.isNotEmpty(dataMap.get("topic"))) {
				topic=StringUtils.toString(dataMap.get("topic"));
			}
			// メッセージ件数
			if (StringUtils.isNotEmpty(dataMap.get("message"))) {
				message=StringUtils.toString(dataMap.get("message"));
			}
			forumArr[i][1] = topic;
			forumArr[i][2] = message;
			
			// 最新メッセージ情報
			if (StringUtils.isNotEmpty(dataMap.get("mnc_user_nm"))
					&& StringUtils.isNotEmpty(dataMap.get("mnc_created_on"))) {
				
				forumArr[i][3] = StringUtils.toString(dataMap.get("mnc_user_nm")) + " が "
						+ StringUtils.toString(dataMap.get("mnc_created_on")) + " に追加";
			}
			
			forumArr[i][6] = StringUtils.toString(dataMap.get("subject"));
			
			// フォーラムID
			forumArr[i][4] = StringUtils.toString(dataMap.get("id"));
			
			// 最新メッセージID
			if (StringUtils.isNotEmpty(dataMap.get("parent_id"))) {
				forumArr[i][7] = StringUtils.toString(dataMap.get("parent_id"));
			} else {
				forumArr[i][7] = StringUtils.toString(dataMap.get("message_id"));
			}
			
			forumArr[i][8] = StringUtils.toString(dataMap.get("position"));
			
		}
		
		context.getResultBean().setData(forumArr);
	}
	
	public void updatePosition() throws SoftbankException {
		
		String changeData = context.getParam().get("param");
		if (StringUtils.isEmpty(changeData)) {
			return;
		}
		JSONArray positions = JSONArray.fromObject(changeData);
		
		for (int i = 0; i < positions.size(); i++) {
			JSONObject dataJason = positions.getJSONObject(i);
			Map<String, Object> dataMap = Maps.newHashMap();
			dataMap.put("id", dataJason.getInt("id"));
			dataMap.put("position", dataJason.getInt("position"));
			db.update("boards.updatePositionById", dataMap);
		}
	}
	
	public void selectBoardsCount() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		int projectId = context.getParam().projectId;
		conditions.put("project_id", projectId);
		context.getResultBean().setData(db.querys("forumBoardsList.selectBoardsCount", conditions));
	}
	
	public void delBoardsInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		int boardsId = StringUtils.toInt(context.getParam().get("boardsId"));
		conditions.put("boardsId", boardsId);
		
		List<Integer> messages = Lists.newArrayList();
		messages = db.queryos("messages.getMessagesByBoardId", conditions);
		
		for (int i = 0; i < messages.size(); i++) {
			// realファイルを削除
			int mId = messages.get(i);
			deleteAttachmentFileByContainer(mId, "Message");
		}
		
		context.getResultBean().setData(db.querys("boards.deleteBoardsById", conditions));
		context.getResultBean().setData(db.querys("forumBoardsList.deleteMessagesByBoardId", conditions));
		
		int position = StringUtils.toInt(context.getParam().get("position"));
		conditions.put("position", position);
		context.getResultBean().setData(db.querys("forumBoardsList.updatePosition", conditions));
		
	}
	
}
