package co.jp.softbank.qqmx.message;

import java.util.Locale;

import org.springframework.context.support.ApplicationObjectSupport;

import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.util.CommonUtil;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.StringUtils;

public class MessageAccessorImpl extends ApplicationObjectSupport implements IMessageAccessor {
	
	@Override
	public String getMessage(String code) {
		return getMessageSourceAccessor().getMessage(code);
	}

	@Override
	public String getMessage(String code, Object[] args, Locale locale) {
		return getMessageSourceAccessor().getMessage(code, args, locale);
	}

	@Override
	public String getMessage(String code, Object[] args) {
		return getMessageSourceAccessor().getMessage(code, args);
	}

	@Override
	public String getMessage(String code, Object[] args, HttpContext context) {
		if (StringUtils.isEmpty(code)) {
			return ConstantsUtil.Str.EMPTY;
		}
		return getMessageSourceAccessor().getMessage(code, args, CommonUtil.getLocale(context.getLang()));
	}

	@Override
	public String getMessage(String code, Object[] args, String defaultMessage, HttpContext context) {
		if (StringUtils.isEmpty(code)) {
			return ConstantsUtil.Str.EMPTY;
		}
		return getMessageSourceAccessor().getMessage(code, args, defaultMessage, CommonUtil.getLocale(context.getLang()));
	}

}
