package co.jp.softbank.qqmx.server.gantt;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import co.jp.softbank.qqmx.server.ExternalHttpServer;
import co.jp.softbank.qqmx.util.HttpUtils;
import co.jp.softbank.qqmx.util.StringUtils;

/**
 * Servlet implementation class GanttServlet
 */
public class GitLabServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static final String encoding = "UTF-8";
	
	private static final String TOKEN = "M2tm-iLkE6okYpTZ_pz8";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GitLabServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			String urlString = "";
			String ps = request.getParameter("ps");
			if ( StringUtils.isNotEmpty(request.getParameter("utf8")) && StringUtils.isNotEmpty(request.getParameter("ref")) ) {
				//urlString = "http://10.229.17.11/service-develop/CorelisCareClient/refs/switch?utf8=" + request.getParameter("utf8") + "&destination=graphs&ref=" + request.getParameter("ref") + "&private_token=GG64Pw_ixcdBYaLMeWd7";
				urlString = "http://10.229.17.11" + ps + "refs/switch?utf8=%E2%9C%93&destination=graphs&ref=" + request.getParameter("ref") + "&private_token=" + TOKEN;
			} else if ( StringUtils.isNotEmpty(request.getParameter("ref")) ) {
				String ref = request.getParameter("ref");
				if (ref.startsWith("#")) {
					ref = ref.replaceAll("#", "%23");
				}
				urlString = "http://10.229.17.11" + ps + "refs?ref=" + ref + "&private_token=" + TOKEN;
			} else {
				String action = "master";
				if (StringUtils.isNotEmpty(request.getParameter("action"))) {
					action = request.getParameter("action");
				}
				if (action.startsWith("#")) {
					action = action.replaceAll("#", "%23");
				}
				//http://10.229.17.11" + ps + "graphs/%23174?format=json
				urlString = "http://10.229.17.11" + ps + "graphs/"+action+"?format=json&private_token=" + TOKEN;
			}
			ExternalHttpServer externalHttpServer = new ExternalHttpServer(null);
			String gitGraph = externalHttpServer.getStrUrl(urlString);
			response.setCharacterEncoding(encoding);
			response.setContentType("application/json; charset=" + encoding);
			response.getWriter().write(gitGraph);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			response.getWriter().close();
		}
	}

}
