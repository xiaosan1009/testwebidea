package co.jp.softbank.qqmx.logic.face;

public interface IScriptLogicFace {

}
