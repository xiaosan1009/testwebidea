package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Maps;

public class WorkflowListLogic extends AbstractBaseLogic {

	public void getWorkflowRoleInfo() throws SoftbankException {
		context.getResultBean().setData(db.querys("workflowList.getWorkflowRoleInfo"));
	}
	
	public void getWorkflowTrackerInfo() throws SoftbankException {
		context.getResultBean().setData(db.querys("workflowList.getWorkflowTrackerInfo"));
	}
	
	// cmd:3 検索
	public void getWorkflowListInfo() throws SoftbankException {
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, Object> conditions = Maps.newHashMap();
		String tracker_id = context.getParam().get("tracker_id");
		String used_statuses_only = context.getParam().get("used_statuses_only");
		if ("1".equals(used_statuses_only)) {
			conditions.put("tracker_id", Integer.parseInt(tracker_id));
		} else {
			conditions.put("tracker_id", 0);
		}
		// header部_範囲
		String statusId = db.queryo("workflowList.getWorkflowStatusesInfo", conditions);
		if (StringUtils.isEmpty(statusId)) {
			Map<String, Object> conditions1 = Maps.newHashMap();
			conditions1.put("tracker_id", 0);
			statusId = db.queryo("workflowList.getWorkflowStatusesInfo", conditions1);
		}
		conditions.put("id", statusId);
		conditions.put("tracker_id", Integer.parseInt(tracker_id));
		// header部_詳細内容
		List<Map<String, Object>> statusList = db.querys("workflowList.getWorkflowIssueStatusesInfo" , conditions);
		
		String role_id = context.getParam().get("role_id");
		conditions.put("role_id", Integer.parseInt(role_id));
		
		resultMap.put("statusList", statusList);
		// ワークフロー詳細
		resultMap.put("workflowList", db.querys("workflowList.getWorkflowListInfo" , conditions));
		context.getResultBean().setData(resultMap);
	}
	
	public void getWorkflowRoleTrackerListInfo() throws SoftbankException {
		context.getResultBean().setData(db.querys("workflowList.getWorkflowRoleTrackerListInfo"));
	}
	
	public void cpWorkflowRoleTrackerInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String source_tracker_id = context.getParam().get("source_tracker_id");
		String source_role_id = context.getParam().get("source_role_id");
		String target_tracker_ids = context.getParam().get("target_tracker_ids");
		String target_role_ids = context.getParam().get("target_role_ids");
		String[] str_tracker_id = target_tracker_ids.split(",", 0);
		String[] str_role_id = target_role_ids.split(",", 0);

		conditions.put("source_tracker_id", Integer.parseInt(source_tracker_id));
		conditions.put("source_role_id", Integer.parseInt(source_role_id));
		String tracker_id;
		String role_id;
		for (int i=0; i<str_tracker_id.length; i++){
			tracker_id = str_tracker_id[i];
			for (int j=0; j<str_role_id.length; j++){
				role_id = str_role_id[j];
				conditions.put("target_tracker_ids", Integer.parseInt(tracker_id));
				conditions.put("target_role_ids", Integer.parseInt(role_id));
				context.getResultBean().setData(db.delete("workflowList.delWorkflowRoleTrackerInfo", conditions));
				context.getResultBean().setData(db.insert("workflowList.insertWorkflowRoleTrackerInfo", conditions));
			}
		}
	}
	
	// 保存
	public void saveWorkflowInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String tracker_id = context.getParam().get("tracker_id");
		String role_id = context.getParam().get("role_id");
		
		// このトラッカーで使われているステータスのみ表示する
		String used_statuses_only = context.getParam().get("used_statuses_only");
		conditions.put("target_tracker_ids", Integer.parseInt(tracker_id));
		conditions.put("target_role_ids", Integer.parseInt(role_id));
		
		if ("1".equals(used_statuses_only)) {
			conditions.put("tracker_id", Integer.parseInt(tracker_id));
		} else {
			conditions.put("tracker_id", 0);
		}
		String statusId = db.queryo("workflowList.getWorkflowStatusesInfo", conditions);
		if (StringUtils.isEmpty(statusId)) {
			Map<String, Object> conditions1 = Maps.newHashMap();
			conditions1.put("tracker_id", 0);
			statusId = db.queryo("workflowList.getWorkflowStatusesInfo", conditions1);
		}
		
		conditions.put("id", statusId);
		List<Map<String, Object>> statusList = db.querys("workflowList.getWorkflowIssueStatusesInfo" , conditions);
		db.insert("workflowList.delWorkflowRoleTrackerInfo", conditions);
		Map<Integer, String> indexMap = Maps.newHashMap();
		for (int i = 0; i < statusList.size(); i++) {
			Map<String, Object> status = statusList.get(i);
			String sid = StringUtils.toString(status.get("id"));
			indexMap.put(i, sid);
		}
		for (int i = 0; i < statusList.size(); i++) {
			Map<String, Object> status = statusList.get(i);
			String sid = StringUtils.toString(status.get("id"));
			String[] checks1 = context.getParam().getList("list1_" + sid);
			String[] checks2 = context.getParam().getList("list2_" + sid);
			String[] checks3 = context.getParam().getList("list3_" + sid);
			for (int j = 0; j < checks1.length; j++) {
				if ("1".equals(checks1[j])) {
					Map<String, Object> data = Maps.newHashMap();
					data.put("target_tracker_ids", Integer.parseInt(tracker_id));
					data.put("target_role_ids", Integer.parseInt(role_id));
					data.put("old_status_id", Integer.parseInt(sid));			
					data.put("new_status_id", Integer.parseInt(indexMap.get(j)));			
					data.put("author", false);			
					data.put("assignee", false);
					db.insert("workflowList.saveWorkflowInfo", data);
				}
			}
			for (int j = 0; j < checks2.length; j++) {
				if ("1".equals(checks2[j])) {
					Map<String, Object> data = Maps.newHashMap();
					data.put("target_tracker_ids", Integer.parseInt(tracker_id));
					data.put("target_role_ids", Integer.parseInt(role_id));
					data.put("old_status_id", Integer.parseInt(sid));			
					data.put("new_status_id", Integer.parseInt(indexMap.get(j)));			
					data.put("assignee", false);
					data.put("author", true);			
					db.insert("workflowList.saveWorkflowInfo", data);
				}
			}
			for (int j = 0; j < checks3.length; j++) {
				if ("1".equals(checks3[j])) {
					Map<String, Object> data = Maps.newHashMap();
					data.put("target_tracker_ids", Integer.parseInt(tracker_id));
					data.put("target_role_ids", Integer.parseInt(role_id));
					data.put("old_status_id", Integer.parseInt(sid));			
					data.put("new_status_id", Integer.parseInt(indexMap.get(j)));			
					data.put("assignee", true);
					data.put("author", false);			
					db.insert("workflowList.saveWorkflowInfo", data);
				}
			}
		}
		
	}	
}
