package co.jp.softbank.qqmx.logic.application.reform;


import java.io.UnsupportedEncodingException;
import java.math.BigDecimal;
import java.math.RoundingMode;
import java.net.URLDecoder;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.ControlDbMemory;
import co.jp.softbank.qqmx.util.StringUtils;

public class TuChartMultipeLogic extends TuLogicBase {
	private static final Map<String,String> listMap ;
	private static SimpleDateFormat SDF = new SimpleDateFormat("yyyyMM");
	static {
		listMap = new HashMap<String,String>();
		listMap.put("1801","1701") ;
		listMap.put("1802","1702") ;
		listMap.put("1803","1703") ;
		listMap.put("1901","1801") ;
		listMap.put("1902","1802") ;
		listMap.put("1903","1803") ;
	};
	public void setChartMultipeInfo() throws SoftbankException,UnsupportedEncodingException {
		//統括
		String headquartersId = null;
		if (StringUtils.isEmpty(context.getParam().get("headquartersId"))) {
			headquartersId = "9898";
		} else {
			headquartersId = context.getParam().get("headquartersId");
		}
		//本部
		String divisionId = null;
		if (StringUtils.isEmpty(context.getParam().get("divisionId"))) {
			divisionId = "9898";
		} else {
			divisionId = context.getParam().get("divisionId");
		}
		//統括部
		String departmentId = null;
		if (StringUtils.isEmpty(context.getParam().get("departmentId"))) {
			departmentId = "9898";
		} else {
			departmentId = context.getParam().get("departmentId");
		}
		//部
		String regionId = null;
		if (StringUtils.isEmpty(context.getParam().get("regionId"))) {
			regionId = "9898";
		} else {
			regionId = context.getParam().get("regionId");
		}
		//全従業員/社員/業託
		String dispartch = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("dispartchId"))) {
			dispartch = URLDecoder.decode(context.getParam().get("dispartchId"),"utf-8");
		}
		//新規/既存
		String category = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("categoryId"))) {
			category = URLDecoder.decode(context.getParam().get("categoryId"),"utf-8");
		}
		
		//人工数/金額/施策数
		String status = "";
		if (!StringUtils.isEmpty(context.getParam().get("statusId"))) {
			status = URLDecoder.decode(context.getParam().get("statusId"),"utf-8");
		} 
		
		//保存履歴
		String study = "";
		if (!StringUtils.isEmpty(context.getParam().get("tuStudy"))) {
			if ("9898".equals(context.getParam().get("tuStudy"))) {
				study = ControlDbMemory.getInstance().getTuNewDate();
			} else {
				study = context.getParam().get("tuStudy");
			}
		}
		
		String jsonDate = context.getParam().get("jsonDate");
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("id", 1);
		conditions.put("headquarters_id", Integer.parseInt(headquartersId));
		conditions.put("division_id", Integer.parseInt(divisionId));
		conditions.put("department_id", Integer.parseInt(departmentId));
		conditions.put("region_id", Integer.parseInt(regionId));
		conditions.put("dispartch", dispartch);
		conditions.put("category", category);
		conditions.put("status", status);
		conditions.put("study", study);
		context.getResultBean().setData(db.delete("tuChartMultipe.delChartMultipeInfo", conditions));
		
		conditions.put("json_date", jsonDate);
		context.getResultBean().setData(db.insert("tuChartMultipe.setChartMultipeInfo", conditions));
	}
	
	public void getChartMultipeInfo() throws SoftbankException,UnsupportedEncodingException, ParseException {
		//統括
		String headquartersId = null;
		if (StringUtils.isEmpty(context.getParam().get("headquartersId"))) {
			headquartersId = "9898";
		} else {
			headquartersId = context.getParam().get("headquartersId");
		}
		//本部
		String divisionId = null;
		if (StringUtils.isEmpty(context.getParam().get("divisionId"))) {
			divisionId = "9898";
		} else {
			divisionId = context.getParam().get("divisionId");
		}
		//統括部
		String departmentId = null;
		if (StringUtils.isEmpty(context.getParam().get("departmentId"))) {
			departmentId = "9898";
		} else {
			departmentId = context.getParam().get("departmentId");
		}
		//部
		String regionId = null;
		if (StringUtils.isEmpty(context.getParam().get("regionId"))) {
			regionId = "9898";
		} else {
			regionId = context.getParam().get("regionId");
		}
		//全従業員/社員/業託
		String dispartch = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("dispartchId"))) {
			dispartch = URLDecoder.decode(context.getParam().get("dispartchId"),"utf-8");
		}
		//新規/既存
		String category = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("categoryId"))) {
			category = URLDecoder.decode(context.getParam().get("categoryId"),"utf-8");
		}
		
		//人工数/金額/施策数
		String status = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("statusId"))) {
			status = URLDecoder.decode(context.getParam().get("statusId"),"utf-8");
		} 
		
		//保存履歴
		String study = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("tuStudy"))) {
			if ("9898".equals(context.getParam().get("tuStudy"))) {
				study = ControlDbMemory.getInstance().getTuNewDate();
			} else {
				study = context.getParam().get("tuStudy");
			}
		}
		
		String dateDt = null;
		if (StringUtils.isEmpty(context.getParam().get("dateInfor"))) {
			dateDt = study.substring(0, 6);
		} else {
			dateDt = context.getParam().get("dateInfor");
		}
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("id", 1);
		conditions.put("headquarters_id", Integer.parseInt(headquartersId));
		conditions.put("division_id", Integer.parseInt(divisionId));
		conditions.put("department_id", Integer.parseInt(departmentId));
		conditions.put("region_id", Integer.parseInt(regionId));
		conditions.put("dispartch", dispartch);
		conditions.put("category", category);
		conditions.put("status", status);
		
		if("9898".equals(status) || "人工数".equals(status)){
			conditions.put("artificial_unit", "人工");
		}
		conditions.put("study", study);
		
		Map<String, Object> graph = db.query("tuChartMultipe.getChartMultipeInfo", conditions);
		BigDecimal vtu[][] = new BigDecimal[3][2]; 
		bigDecimalArrayInit(vtu);
		List<Map<String, Object>> vtu1 = db.querys("tuChartMultipe.getTotalInfor", conditions);
		
		String lastMonth = getLastMonth(dateDt);
		conditions.put("lastMonth", "TU50経営会議"+lastMonth.substring(2, 6));
		
		List<Map<String, Object>> vtu2 = db.querys("tuChartMultipe.getGyoumuItakuSengetuTotalInfor", conditions);
		List<Map<String, Object>> vtu3 = db.querys("tuChartMultipe.getGyoumuItakuKongetuTotalInfor", conditions);
		if (vtu1.size() > 0) {
			if (vtu1.size() == 2) {
				vtu[0][0] = objectToBigDecimal(vtu1.get(0).get("sum_plan_artificial17"));
				vtu[0][1] = objectToBigDecimal(vtu1.get(1).get("sum_plan_artificial17"));
			} else {
				if ("正社員".equals(vtu1.get(0).get("dispartch"))) {
					vtu[0][0] =  objectToBigDecimal(vtu1.get(0).get("sum_plan_artificial17"));
				} else {
					vtu[0][1] =  objectToBigDecimal(vtu1.get(0).get("sum_plan_artificial17"));
				}
			}
		}
		if (vtu2.size() > 0) {
			if (vtu2.size() == 2) {
				vtu[1][0] = objectToBigDecimal(vtu2.get(0).get("plan_artificial1904"));
				vtu[2][0] =  objectToBigDecimal(vtu2.get(1).get("plan_artificial1904"));
			} else {
				if ("正社員".equals(vtu2.get(0).get("dispartch"))) {
					vtu[1][0] =  objectToBigDecimal(vtu2.get(0).get("plan_artificial1904"));
				} else {
					vtu[2][0] =  objectToBigDecimal(vtu2.get(0).get("plan_artificial1904"));
				}
			}
		}
		if (vtu3.size() > 0) {
			if (vtu3.size() == 2) {
				vtu[1][1] =  objectToBigDecimal(vtu3.get(0).get("plan_artificial1904"));
				vtu[2][1] =  objectToBigDecimal(vtu3.get(1).get("plan_artificial1904"));
			} else {
				if ("正社員".equals(vtu3.get(0).get("dispartch"))) {
					vtu[1][1] = objectToBigDecimal(vtu3.get(0).get("plan_artificial1904"));
				} else {
					vtu[2][1] = objectToBigDecimal(vtu3.get(0).get("plan_artificial1904"));
				}
			}
		}
		
		Map<String, Object> dateConditions = Maps.newHashMap();
		dateConditions.put("graph", graph);
		dateConditions.put("vtu", vtu);
		String title1 = lastMonth.substring(4, 6);
		String title2 = dateDt.substring(4, 6);
		if(lastMonth.substring(4, 5).startsWith("0")){
			title1 = lastMonth.substring(4, 6).replace("0", "") ;
		}
		if(dateDt.substring(4, 5).startsWith("0")){
			title2 = dateDt.substring(4, 6).replace("0", "") ;
		}
		dateConditions.put("lastMonth", title1 + "月末" );
		dateConditions.put("lastMonth1", title2 + "月末" );
		
		context.getResultBean().setData(dateConditions);
	}
	
	public void delChartMultipeInfo() throws SoftbankException,UnsupportedEncodingException {
		//統括
		String headquartersId = null;
		if (StringUtils.isEmpty(context.getParam().get("headquartersId"))) {
			headquartersId = "9898";
		} else {
			headquartersId = context.getParam().get("headquartersId");
		}
		//本部
		String divisionId = null;
		if (StringUtils.isEmpty(context.getParam().get("divisionId"))) {
			divisionId = "9898";
		} else {
			divisionId = context.getParam().get("divisionId");
		}
		//統括部
		String departmentId = null;
		if (StringUtils.isEmpty(context.getParam().get("departmentId"))) {
			departmentId = "9898";
		} else {
			departmentId = context.getParam().get("departmentId");
		}
		//部
		String regionId = null;
		if (StringUtils.isEmpty(context.getParam().get("regionId"))) {
			regionId = "9898";
		} else {
			regionId = context.getParam().get("regionId");
		}
		//全従業員/社員/業託
		String dispartch = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("dispartchId"))) {
			dispartch = URLDecoder.decode(context.getParam().get("dispartchId"),"utf-8");
		}
		//新規/既存
		String category = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("categoryId"))) {
			category = URLDecoder.decode(context.getParam().get("categoryId"),"utf-8");
		}
		
		//人工数/金額/施策数
		String status = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("statusId"))) {
			status = URLDecoder.decode(context.getParam().get("statusId"),"utf-8");
		} 
		
		//保存履歴
		String study = "9898";
		if (!StringUtils.isEmpty(context.getParam().get("tuStudy"))) {
			if ("9898".equals(context.getParam().get("tuStudy"))) {
				study = ControlDbMemory.getInstance().getTuNewDate();
			} else {
				study = context.getParam().get("tuStudy");
			}
		}
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("id", 1);
		conditions.put("headquarters_id", Integer.parseInt(headquartersId));
		conditions.put("division_id", Integer.parseInt(divisionId));
		conditions.put("department_id", Integer.parseInt(departmentId));
		conditions.put("region_id", Integer.parseInt(regionId));
		conditions.put("dispartch", dispartch);
		conditions.put("category", category);
		conditions.put("status", status);
		conditions.put("study", study);

		context.getResultBean().setData(db.delete("tuChartMultipe.delChartMultipeInfo", conditions));
	}
	
	private String getLastMonth(String lastMonthTemp) throws ParseException{
		
		SimpleDateFormat sdf = new SimpleDateFormat("yyyyMM");
		Date dt = sdf.parse(lastMonthTemp) ;
		
		Calendar cal = Calendar.getInstance();
		cal.setTime(dt);
		cal.add(Calendar.MONTH, -1);
		Date lastMonthDt = cal.getTime();
		return sdf.format(lastMonthDt);
	}
	/**
	 * objectからBigDecimalへ換える
	 * @return BigDecimal
	 */
	private BigDecimal objectToBigDecimal(Object obj){
		BigDecimal result = new BigDecimal(StringUtils.toString(obj));
		result = result.setScale(0, RoundingMode.HALF_UP) ;
		return result;
	}
	private void bigDecimalArrayInit(BigDecimal[][] array){
		for (int i = 0; i < array.length; i++) {
			BigDecimal[] ele = array[i] ;
			for (int j = 0; j < ele.length; j++) {
				ele[j] = BigDecimal.ZERO ;
			}
			
		}
	}
}
