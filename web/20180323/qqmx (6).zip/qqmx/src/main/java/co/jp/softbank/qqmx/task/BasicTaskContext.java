package co.jp.softbank.qqmx.task;

import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.task.face.IOutputCollector;
import co.jp.softbank.qqmx.task.face.ITaskContext;

public class BasicTaskContext implements ITaskContext {
	
	private IOutputCollector<?> collector;
	
	private Map<String, Object> param = Maps.newHashMap();
	
	private HttpContext httpContext;

	@Override
	public <V> void setCollector(IOutputCollector<V> collector) {
	}

	@SuppressWarnings("unchecked")
	@Override
	public <V> IOutputCollector<V> getCollector() {
		return (IOutputCollector<V>) collector;
	}
	
	public <T extends ITaskContext> T copy() {
        BasicTaskContext copyCtx = null;
        try {
            copyCtx = (BasicTaskContext) super.clone();

        } catch (CloneNotSupportedException e) {
            throw new IllegalArgumentException(e);
        }
        return (T) copyCtx;
    }

	@Override
	public Map<String, Object> getParam() {
		return param;
	}

	@Override
	public void setHttpContext(HttpContext httpContext) {
		this.httpContext = httpContext;
	}

	@Override
	public HttpContext getHttpContext() {
		return httpContext;
	}
	
}
