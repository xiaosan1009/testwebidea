

package co.jp.softbank.qqmx.logic.application.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.Iterator;
import java.util.Map;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang.StringUtils;
import org.eclipse.jgit.lib.AnyObjectId;
import org.eclipse.jgit.lib.Repository;
import org.eclipse.jgit.revwalk.RevCommit;
import org.eclipse.jgit.revwalk.RevWalk;
import org.eclipse.jgit.treewalk.TreeWalk;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import net.sf.json.JSONObject;

/**
 * 版管理ツール(Git)からソースファイルを取得して、
 * ソース規模情報を収集する処理を行う。
 */
public class SourceScaleCountGitLogic extends SourceScaleCount {

    /** 一時ディレクトリ（変更前） */
    private static final String OLD_TMP_DIR = "ipf_git_old_";
    /** 一時ディレクトリ（変更後） */
    private static final String NEW_TMP_DIR = "ipf_git_new_";
    
    /**
     * ソース規模データ収集(Subversion用) 
     * 
     */
    public void sourceScale() {
    	final String projectId   = context.getParam().get("projectId");
        final String gitPath   = context.getParam().get("gitPath");
        final String repoPath    = gitPath + "/.git";
        final String oldRevision    = context.getParam().get("oldRevision");
        
        final String branch      = context.getParam().get("branch");
        
		BufferedReader br = null;
		StringBuilder sb = new StringBuilder();
		try {
			br = new BufferedReader(new InputStreamReader(context.getRequest().getInputStream()));
			String c = "";
//			log.debug("br = " +  br);
			while ((c = br.readLine()) != null) {
				sb.append(c);
			}
			br.close();
		} catch (IOException e1) {
			// TODO 自動生成された catch ブロック
			e1.printStackTrace();
		}
		final String gitRequest = sb.toString();
//		log.debug("request body : " + sb.toString());
//		log.debug("request body : " + gitRequest);
        
		Thread t = new Thread(new Runnable() {
			public void run() {
				try {
					
//					try {
//						Thread.sleep(20000);
//					} catch (InterruptedException e) {
//						throw new SoftbankException(SoftbankExceptionType.SystemException,e);
//					}
//					externalHttpServer.getStrUrl(
//							messageAccessor.getMessage("application.path") + ":8080/qqmx/qqmx.mx?dispCode=610011&cmdCode=1&projectId=" + projectId + "&gitPath=" + gitPath + "&repoPath=" + repoPath  + "&branch=" + branch);
					Map<String, String> params = Maps.newHashMap();
					params.put("dispCode", "610011");
					params.put("cmdCode", "1");
					params.put("projectId", projectId);
					params.put("gitPath", gitPath);
					params.put("repoPath", repoPath);
					params.put("gitRequest", gitRequest);
					params.put("branch", branch);
					externalHttpServer.post(messageAccessor.getMessage("application.path") + ":8080/qqmx/qqmx.mx", params);
					
					Map<String, String> paramsDiff = Maps.newHashMap();
					paramsDiff.put("dispCode", "610008");
					paramsDiff.put("cmdCode", "1");
					paramsDiff.put("projectId", projectId);
					paramsDiff.put("gitPath", gitPath);
					paramsDiff.put("repoPath", repoPath);
					paramsDiff.put("oldRevision", oldRevision);
					paramsDiff.put("gitRequest", gitRequest);
					paramsDiff.put("branch", branch);
					externalHttpServer.post(messageAccessor.getMessage("application.path") + ":8080/qqmx/qqmx.mx", paramsDiff);
					
				} catch (SoftbankException e) {
					e.printStackTrace();
					log.error(e.getErrorMsg(), e);
				}
			}
		});
		t.start();
        
    }
    /**
     * ソース規模データ収集(Subversion用) 
     * 
     */
    public void sourceScaleTime() {
    	log.debug("☆☆☆ sourceScaleTime  ☆☆☆☆☆☆☆☆☆ Start ☆☆☆");
    	try {
    		
    		String projectId   = context.getParam().get("projectId");
    		String gitPath   = context.getParam().get("gitPath");
    		String repoPath    = context.getParam().get("repoPath");
    		String gitRequest   = context.getParam().get("gitRequest");
    		String gitBranch   = context.getParam().get("branch");
    		log.debug("☆☆☆ sourceScaleTime  ☆☆☆☆☆☆☆☆☆  gitRequest ☆☆☆" + gitRequest);
			if (StringUtils.isEmpty(gitRequest)){
				return;
			}
			JSONObject json = JSONObject.fromObject(gitRequest);
			
			String ref = "";
			if ( json.containsKey("ref") && json.get("ref") != null ) {
				ref = json.get("ref").toString();
			}
			// ブランチ
			String branch = getBranch(ref);
			log.debug("☆☆☆ sourceScaleTime  ☆☆☆☆☆☆☆☆☆  gitRequest ☆☆☆ branch ☆☆☆☆☆" + branch);
			log.debug("☆☆☆ sourceScaleTime  ☆☆☆☆☆☆☆☆☆  gitRequest ☆☆☆ gitBranch ☆☆☆☆☆" + gitBranch);
			if ( !StringUtils.isEmpty(gitBranch) ) {
				if (!gitBranch.equals(branch)){
					return;
				}
			}
    		Integer project_id = 0;
    		if (projectId != null && projectId != "") {
    			project_id = Integer.parseInt(projectId);
    		}
    		
    		checkoutFile(gitPath, branch);
    		
    		sourceScaleCollect(project_id, repoPath, branch);
    		
    	} catch (Exception e) {
    		
    	} finally {
    		
    	}
//    	log.debug("☆☆☆ sourceScaleTime  ☆☆☆☆☆☆☆☆☆ End ☆☆☆");
    }
    
    public void checkoutFile(String gitPath, String branch) {
		try {
			String cmd = "/opt/ipftools/review-platform.git/checkoutGitFile.sh " 
	    			 + gitPath + " " + branch;
			Process process = Runtime.getRuntime().exec(cmd);

			process.waitFor();
			process.destroy();
			
			log.debug("☆☆☆ cmd ☆☆☆" + cmd);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
    }
    
    /**
     * ソース規模データを集計してIPF・DBに登録する。
     * 
     * @param project_id プロジェクトID
     * @param repoPath リポジトリパス
     * @param oldRev 旧リビジョン（収集開始リビジョンの１つ前のリビジョン。旧リビション自身は収集されないので注意。）
     * @param newRev 新リビジョン
     * @param configInfo Pentaho 設定ファイル情報
     * @throws Exception 
     */
    public void sourceScaleCollect(
            Integer project_id, 
            String repoPath,
            String branch
        ) throws Exception {

        File oldTmpDir = null;
        File newTmpDir = null;
        
        RevWalk rwalk = null;
        try {
            // 一時ディレクトリ作成
            oldTmpDir = createTempDirectory(OLD_TMP_DIR, ".tmp");
            newTmpDir = createTempDirectory(NEW_TMP_DIR, ".tmp");
            
            // Git コミットログ取得
            Repository repository = IpfJGitUtils.getGitRepository(repoPath);
            // リビジョンリストを取得
            rwalk = IpfJGitUtils.getAllRevWalk(repository);
            
            // DBの最新リビジョンを取得
            String oldRev = getLatestRevision(project_id, repoPath, branch);
            
            log.debug("☆☆☆ oldRev　： ☆☆☆" + oldRev);

            String newRev = branch;
            log.debug("☆☆☆ newRev　： ☆☆☆" + newRev);
            
            Iterator<RevCommit> revIter = null;
            if (StringUtils.isNotBlank(oldRev)) {
                if (StringUtils.isNotBlank(newRev)) {
                	
                	log.debug("newRev is not Blank.");
                	
                    // 指定リビジョン(oldRev ... newRev)
                    revIter = IpfJGitUtils.getRevList(repository, oldRev, newRev);
                } else {
                	log.debug("newRev is Blank.");
                	
                    // 指定リビジョン(oldRev ... )
                    revIter = IpfJGitUtils.getRevList(repository, oldRev);
                }
            } else {
            	log.debug("全リビジョン取得.");
                // 全リビジョン
                revIter = IpfJGitUtils.getRevList(repository);
            }
            
            // リビジョンで繰り返し
            if (!revIter.hasNext()){
            	log.info("☆☆☆ flg !revIter.hasNext() ☆☆☆");
            }
            while (revIter.hasNext()) {
                RevCommit commit = revIter.next();
                
                TreeWalk twalk = null;
                try {
                    
                    twalk = IpfJGitUtils.getTreeWalk(repository, commit, rwalk);
                    // ソースファイル数分繰り返し
                    while (twalk.next()) {
                        // ソースファイル取得、ソース規模情報取得、DB登録
                    	log.debug("☆☆☆ repository　： ☆☆☆" + repository);
                    	log.debug("☆☆☆ branch　： ☆☆☆" + branch);
                    	log.debug("☆☆☆ twalk　： ☆☆☆" + twalk.getObjectId(0));
                    	log.debug("☆☆☆ twalk　： ☆☆☆" + twalk.getObjectId(1));
                        sourceScaleCollectAndDbInsert(project_id, repository, repoPath, branch, commit, twalk, oldTmpDir, newTmpDir);
                    }

                } catch (IpfSQLNormalException isne) {
                    
                } catch (Exception e) {
                    
                } finally {
                    if (twalk != null) {
                      twalk.release();
                    }
                }
            }
            // リビジョンで繰り返し
            
        } finally {

        }
        
    }
    
    /**
     * ソースファイルを取得して、ソース規模データを集計しDBに登録する。
     * 
     * @param conn DBコネクション
     * @param pstmt プレペアド・ステートメント
     * @param projectId プロジェクトID
     * @param repository リポジトリ
     * @param repoPath
     * @param branch
     * @param revCommit 
     * @param treeWalk 
     * @param oldTmpDir 一時ディレクトリ（変更前）
     * @param newTmpDir 一時ディレクトリ（変更後）
     * @throws Exception 
     */
    protected void sourceScaleCollectAndDbInsert (
            Integer project_id,
            Repository repository,
            String repoPath,
            String branch,
            RevCommit commit,
            TreeWalk twalk,
            File oldTmpDir,
            File newTmpDir) throws Exception {
        String revision     = commit.getName();                     // リビジョン
        String message      = commit.getFullMessage();              // コミットメッセージ
        String author       = commit.getCommitterIdent().getName(); // 更新者
        Date updDate        = IpfJGitUtils.getCommitDate(commit);   // 更新日時
        
        byte[] filePathBytes = twalk.getRawPath();                          // ファイルフルパス（ファイル名含む） バイト配列
        String filePath      = IpfJGitUtils.getDecodeStr(filePathBytes);    // ファイルフルパス（ファイル名含む）

        String filePathOnly = FilenameUtils.getPathNoEndSeparator(filePath);  // ファイルパスのみ（ファイル名除く）
        String fileName     = FilenameUtils.getName(filePath);                // ファイル名（拡張子含む）
        String fileExt      = FilenameUtils.getExtension(filePath);           // 拡張子
        
        AnyObjectId[] objectIds = new AnyObjectId[2];
        char chg            = IpfJGitUtils.getChangeType(twalk, objectIds);   // 変更種別
        AnyObjectId  oldObjectId = objectIds[0];   // 旧ファイルオブジェクト
        AnyObjectId  newObjectId = objectIds[1];   // 新ファイルオブジェクト
        log.debug("☆☆☆ sourceScaleCollectAndDbInsert　： ☆☆☆chg" + chg);
        File oldTmpFile = null;
        File newTmpFile = null;
        try {
            // ソースファイル取得
            oldTmpFile = new File(oldTmpDir, fileName);
            newTmpFile = new File(newTmpDir, fileName);
            
            // 一時ファイル作成
            log.debug("☆☆☆ sourceScaleCollectAndDbInsert　： ☆☆☆chg ☆☆☆ newObjectId" + newObjectId);
            log.debug("☆☆☆ sourceScaleCollectAndDbInsert　： ☆☆☆chg ☆☆☆ newTmpFile" + newTmpFile);
            
            log.debug("☆☆☆ sourceScaleCollectAndDbInsert　： ☆☆☆chg ☆☆☆ oldObjectId" + oldObjectId);
            log.debug("☆☆☆ sourceScaleCollectAndDbInsert　： ☆☆☆chg ☆☆☆ oldTmpFile" + oldTmpFile);
            log.debug("Temp File Create.");
            switch (chg) {
            case 'A':
                IpfJGitUtils.createFile(repository, filePath, newObjectId, newTmpFile);
                break;
            case 'D':
                IpfJGitUtils.createFile(repository, filePath, oldObjectId, oldTmpFile);
                break;
            case 'M':
                IpfJGitUtils.createFile(repository, filePath, oldObjectId, oldTmpFile);
                IpfJGitUtils.createFile(repository, filePath, newObjectId, newTmpFile);
                break;
            }
            
            // ソース規模取得
            SourceScaleResult result = count(oldTmpFile, newTmpFile);
            if (result.getFileSize() == 0) {
            	return;
            }
            result.setRevision(revision);
            result.setAuthor(author);
            result.setUpdDate(updDate);
            result.setMessage(message);
            result.setFilePath(filePathOnly);
            result.setFileName(fileName);
            result.setFileExt(fileExt);
            
            // ソース規模DB登録
            insertSourceScale(project_id, repoPath, branch, result);
            
        } finally {
            // 一時ファイル削除
            if(oldTmpFile != null) FileUtils.deleteQuietly(oldTmpFile);
            if(newTmpFile != null) FileUtils.deleteQuietly(newTmpFile);
            log.debug("Temp File Remove.");
        }
    }

    /**
     * ソース規模データの最新リビジョンを取得する
     * 
     * @param configInfo Pentaho 設定ファイル情報
     * @param projectId プロジェクトID
     * @return 最新リビジョン
     * @throws Exception 
     */
    protected String getLatestRevision (
            Integer projectId,
            String repoPath,
            String branch) throws Exception {
    	
    	String rev = "";

        Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		conditions.put("repository", repoPath);
		conditions.put("branch", branch);
		
		Map<String, Object> latestRevision = db.query("sourceScale.getLatestRevision", conditions);
		
		if (latestRevision != null) {
			rev = latestRevision.get("revision").toString();
		}
        
        return rev;
    }

	protected String getBranch (String ref) throws Exception {
		String gBranch = ref.replace("refs/heads/", "");
		return gBranch;
	}
}
