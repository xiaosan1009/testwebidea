package co.jp.softbank.qqmx.logic.application.project;

import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;

public class ForumListLogic extends AbstractBaseLogic {

	public void getMessageList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		int projectId = context.getParam().projectId;
		conditions.put("project_id", projectId);
		context.getResultBean().setData(pageList("forumList.getMessageList", conditions));
	}
	
	public void getBoardsInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		int projectId = context.getParam().projectId;
		conditions.put("project_id", projectId);
		context.getResultBean().setData(db.querys("forumList.getBoardsInfo", conditions));
	}
	
}
