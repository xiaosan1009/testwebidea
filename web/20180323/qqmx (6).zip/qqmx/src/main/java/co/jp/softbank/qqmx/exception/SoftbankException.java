package co.jp.softbank.qqmx.exception;

import java.util.List;

public class SoftbankException extends Exception {
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private SoftbankExceptionType exceptionType;
	
	private String errorCode;
	
	private String errorMsg;
	
	private String errorWidgetId;
	
	private boolean error = true;
	
	private Object errorInfos;
	
	public SoftbankException() {
		super();
	}
	
	public SoftbankException(String errorCode) {
		super();
		this.errorCode = errorCode;
	}
	
	public SoftbankException(String errorWidgetId, String errorMsg) {
		super();
		this.errorWidgetId = errorWidgetId;
		this.errorMsg = errorMsg;
	}
	
	public SoftbankException(String errorMsg, boolean error) {
		super();
		this.error = error;
		this.errorMsg = errorMsg;
	}
	
	public SoftbankException(Throwable e) {
		super(e);
	}
	
	public SoftbankException(SoftbankExceptionType type) {
		super();
		this.exceptionType = type;
	}
	
	public SoftbankException(SoftbankExceptionType type, Object errorInfos) {
		super();
		this.exceptionType = type;
		this.errorInfos = errorInfos;
	}
	
	public SoftbankException(SoftbankExceptionType type, Throwable e) {
		super(e);
		this.exceptionType = type;
	}

	public String getErrorMsg() {
		return errorMsg;
	}

	public void setErrorMsg(String errorMsg) {
		this.errorMsg = errorMsg;
	}

	public SoftbankExceptionType getExceptionType() {
		return exceptionType;
	}

	public void setExceptionType(SoftbankExceptionType exceptionType) {
		this.exceptionType = exceptionType;
	}

	public String getErrorWidgetId() {
		return errorWidgetId;
	}

	public void setErrorWidgetId(String errorWidgetId) {
		this.errorWidgetId = errorWidgetId;
	}

	public boolean isError() {
		return error;
	}

	public void setError(boolean error) {
		this.error = error;
	}

	public Object getErrorInfos() {
		return errorInfos;
	}

	public void setErrorInfos(Object errorInfos) {
		this.errorInfos = errorInfos;
	}

	public String getErrorCode() {
		return errorCode;
	}

	public void setErrorCode(String errorCode) {
		this.errorCode = errorCode;
	}

}
