package co.jp.softbank.qqmx.server.gantt;

import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import co.jp.softbank.qqmx.util.HttpUtils;

/**
 * Servlet implementation class GanttServlet
 */
public class GanttServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private static final String encoding = "UTF-8";
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public GanttServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doPost(request, response);
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		try {
			Map<String, String> conditions = new HashMap<String, String>();
			conditions.put(HttpUtils.COOKIE_SESSION_ID, "7677e252f8bb8e185ff2e51418e7ebd4");
			String result = HttpUtils.doGet("http://10.172.17.62/redmine/gantts/show_ajax?project_id=parentpj", conditions);
			response.setCharacterEncoding(encoding);
			response.setContentType("text/html; charset=" + encoding);
			response.getWriter().write(result);
		} catch (Exception e) {
			e.printStackTrace();
		} finally {
			response.getWriter().close();
		}
	}

}
