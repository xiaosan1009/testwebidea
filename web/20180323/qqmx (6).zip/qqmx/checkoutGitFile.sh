#!/bin/bash
#path
gitpath=$1
#gitbranch
gitbranch=$2

cd $gitpath
git fetch origin
git pull origin
git checkout $gitbranch
