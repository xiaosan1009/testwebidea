package co.jp.softbank.qqmx.logic.bean;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

public class PageListBean {
	
	private List<Map<String, Object>> datas;
	
	private long allRows;
	
	private int currentPage;
	
	private long allPage;
	
	private int pageRowNumber;
	
	private Map<String, Object> dataMap = Maps.newHashMap();

	public List<Map<String, Object>> getDatas() {
		return datas;
	}

	public void setDatas(List<Map<String, Object>> datas) {
		this.datas = datas;
	}

	public long getAllRows() {
		return allRows;
	}

	public void setAllRows(long allRows) {
		this.allRows = allRows;
	}

	public int getCurrentPage() {
		return currentPage;
	}

	public void setCurrentPage(int currentPage) {
		this.currentPage = currentPage;
	}

	public long getAllPage() {
		return allPage;
	}

	public void setAllPage(long allPage) {
		this.allPage = allPage;
	}

	public int getPageRowNumber() {
		return pageRowNumber;
	}

	public void setPageRowNumber(int pageRowNumber) {
		this.pageRowNumber = pageRowNumber;
	}

	public Map<String, Object> getDataMap() {
		return dataMap;
	}

	public void setDataMap(Map<String, Object> dataMap) {
		this.dataMap = dataMap;
	}

	public void setData(String key, Object data) {
		dataMap.put(key, data);
	}
}
