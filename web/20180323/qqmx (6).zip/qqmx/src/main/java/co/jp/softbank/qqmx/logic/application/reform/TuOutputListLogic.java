package co.jp.softbank.qqmx.logic.application.reform;


import java.io.UnsupportedEncodingException;
import java.net.URLDecoder;
import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.ControlDbMemory;
import co.jp.softbank.qqmx.logic.bean.PageListBean;
import co.jp.softbank.qqmx.util.StringUtils;

public class TuOutputListLogic extends TuLogicBase {
	
	public void getOutputListInfo() throws SoftbankException,UnsupportedEncodingException {
		//統括
		String headquartersId = null;
		if (StringUtils.isEmpty(context.getParam().get("headquartersId"))) {
			headquartersId = "9898";
		} else {
			headquartersId = context.getParam().get("headquartersId");
		}
		//本部
		String divisionId = null;
		if (StringUtils.isEmpty(context.getParam().get("divisionId"))) {
			divisionId = "9898";
		} else {
			divisionId = context.getParam().get("divisionId");
		}
		//統括部
		String departmentId = null;
		if (StringUtils.isEmpty(context.getParam().get("departmentId"))) {
			departmentId = "9898";
		} else {
			departmentId = context.getParam().get("departmentId");
		}
		//部
		String regionId = null;
		if (StringUtils.isEmpty(context.getParam().get("regionId"))) {
			regionId = "9898";
		} else {
			regionId = context.getParam().get("regionId");
		}
		//全従業員/社員/業託
		String dispartch = null;
		if (!StringUtils.isEmpty(context.getParam().get("dispartchId"))) {
			dispartch = URLDecoder.decode(context.getParam().get("dispartchId"),"utf-8");
		}
		//新規/既存
		String category = null;
		if (!StringUtils.isEmpty(context.getParam().get("categoryId"))) {
			category = URLDecoder.decode(context.getParam().get("categoryId"),"utf-8");
		}
		
		//人工数/金額/施策数
		String status = null;
		if (!StringUtils.isEmpty(context.getParam().get("statusId"))) {
			status = URLDecoder.decode(context.getParam().get("statusId"),"utf-8");
		} 

		//保存履歴
		String study = null;
		if (!StringUtils.isEmpty(context.getParam().get("tuStudy"))) {
			if ("9898".equals(context.getParam().get("tuStudy"))) {
				study = ControlDbMemory.getInstance().getTuNewDate();
			} else {
				study = context.getParam().get("tuStudy");
			}
		}
		
		Integer yearmonth = null;
		if (!StringUtils.isEmpty(context.getParam().get("yearmonth"))) {
			yearmonth = Integer.valueOf(context.getParam().get("yearmonth").toString().replace("20", "").toString());
		}else{
			yearmonth = 1709;
		}
						
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("headquarters_Id", Integer.parseInt(headquartersId));
		conditions.put("division_id", Integer.parseInt(divisionId));
		conditions.put("department_id", Integer.parseInt(departmentId));
		conditions.put("region_id", Integer.parseInt(regionId));
		conditions.put("dispartch", dispartch);
		conditions.put("category", category);
		conditions.put("status", status);
		conditions.put("yearmonth", yearmonth);
		conditions.put("study", study);
		PageListBean pageListBean = pageList("tuOutputList.getOutputList",conditions);
		context.getResultBean().setData(pageListBean);
	}
}
