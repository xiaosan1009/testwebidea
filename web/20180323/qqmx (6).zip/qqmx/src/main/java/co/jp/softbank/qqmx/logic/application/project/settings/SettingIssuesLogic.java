package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import org.ho.yaml.Yaml;

import co.jp.softbank.qqmx.dao.common.bean.PluginInfoBean;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class SettingIssuesLogic extends AbstractBaseLogic {

	public void getSettingsInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String nameValue = context.getParam().get("name");
		conditions.put("name", nameValue);
		context.getResultBean().setData(db.querys("settingIssues.getSettingsInfo", conditions));
	}
	
	public LogicBean getProjectCustomFieldsInfos() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		List<Map<String, Object>> issueListDefaultColumns = db.querys("settingIssues.getIssueListDefaultColumns");
		Map<String, Object> issueListDefaultColumnsData = issueListDefaultColumns.get(0);
		String issueListDefaultColumnsValue = StringUtils.toString(issueListDefaultColumnsData.get("value"));
		Yaml yaml = new Yaml();
		List<String> issueListDefaultColumnsValueList2 = (List<String>)yaml.load(issueListDefaultColumnsValue);
		Map<String, String> issueListDefaultColumnsValueMap = Maps.newHashMap();
		for (int i = 0; i < issueListDefaultColumnsValueList2.size(); i++) {
			issueListDefaultColumnsValueMap.put(issueListDefaultColumnsValueList2.get(i), issueListDefaultColumnsValueList2.get(i));
		}
		
		List<PluginInfoBean> pluginInfoBeanList = Lists.newArrayList(); 

		PluginInfoBean project = pluginInfoSet("project", "プロジェクト");
		pluginInfoBeanList.add(project);
		PluginInfoBean tracker = pluginInfoSet("tracker", "トラッカー");
		pluginInfoBeanList.add(tracker);
		PluginInfoBean parent = pluginInfoSet("parent", "親チケット");
		pluginInfoBeanList.add(parent);
		PluginInfoBean status = pluginInfoSet("status", "ステータス");
		pluginInfoBeanList.add(status);
		PluginInfoBean priority = pluginInfoSet("priority", "優先度");
		pluginInfoBeanList.add(priority);
		PluginInfoBean subject = pluginInfoSet("subject", "題名");
		pluginInfoBeanList.add(subject);
		PluginInfoBean description = pluginInfoSet("description", "説明");
		pluginInfoBeanList.add(description);
		PluginInfoBean author = pluginInfoSet("author", "作成者");
		pluginInfoBeanList.add(author);
		PluginInfoBean assigned_to = pluginInfoSet("assigned_to", "担当者");
		pluginInfoBeanList.add(assigned_to);
		PluginInfoBean updated_on = pluginInfoSet("updated_on", "更新日");
		pluginInfoBeanList.add(updated_on);
		PluginInfoBean category = pluginInfoSet("category", "カテゴリ");
		pluginInfoBeanList.add(category);
		PluginInfoBean fixed_version = pluginInfoSet("fixed_version", "対象バージョン");
		pluginInfoBeanList.add(fixed_version);
		PluginInfoBean organization_name = pluginInfoSet("organization_name", "組織");
		pluginInfoBeanList.add(organization_name);
		PluginInfoBean start_date = pluginInfoSet("start_date", "開始日");
		pluginInfoBeanList.add(start_date);
		PluginInfoBean due_date = pluginInfoSet("due_date", "期日");
		pluginInfoBeanList.add(due_date);
		PluginInfoBean estimated_hours = pluginInfoSet("estimated_hours", "予定工数");
		pluginInfoBeanList.add(estimated_hours);
		PluginInfoBean spent_hours = pluginInfoSet("spent_hours", "作業時間の記録");
		pluginInfoBeanList.add(spent_hours);
		PluginInfoBean done_ratio = pluginInfoSet("done_ratio", "進捗 %");
		pluginInfoBeanList.add(done_ratio);
		PluginInfoBean created_on = pluginInfoSet("created_on", "作成日");
		pluginInfoBeanList.add(created_on);
		PluginInfoBean story_points = pluginInfoSet("story_points", "ストーリーポイント");
		pluginInfoBeanList.add(story_points);
		PluginInfoBean velocity_based_estimate = pluginInfoSet("velocity_based_estimate", "残り時間に基づくベロシティ");
		pluginInfoBeanList.add(velocity_based_estimate);
		PluginInfoBean position = pluginInfoSet("position", "Position");
		pluginInfoBeanList.add(position);
		PluginInfoBean remaining_hours = pluginInfoSet("remaining_hours", "残り時間");
		pluginInfoBeanList.add(remaining_hours);

		List<Map<String, Object>> customFieldsList = db.querys("settingIssues.getCustomFieldsList");
		for (int j = 0; j < customFieldsList.size(); j++) {
			PluginInfoBean pluginInfoBean = new PluginInfoBean();
			pluginInfoBean.setValue("cf_" + customFieldsList.get(j).get("id"));
			pluginInfoBean.setName(String.valueOf(customFieldsList.get(j).get("name")));
			pluginInfoBeanList.add(pluginInfoBean);
		}
		
		resultMap.put("issueListDefaultColumns", issueListDefaultColumnsValueMap);
		resultMap.put("customFields", pluginInfoBeanList);
		logicBean.setData(resultMap);
		return logicBean;
	}

	public void saveSettingInfos() throws SoftbankException {
		String	settings_cross_project_issue_relations = context.getParam().get("settings_cross_project_issue_relations");
		String	settings_issue_group_assignment = context.getParam().get("settings_issue_group_assignment");
		String	settings_display_subprojects_issues = context.getParam().get("settings_display_subprojects_issues");
		String	settings_issue_done_ratio = context.getParam().get("settings_issue_done_ratio");
		String	settings_issues_export_limit = context.getParam().get("settings_issues_export_limit");
		
		
		String[] settings_issue_list_default_columns = context.getParam().getList("settings_issue_list_selected_name");
		updataSettings(settings_cross_project_issue_relations, "cross_project_issue_relations");
		updataSettings(settings_issue_group_assignment, "issue_group_assignment");
		updataSettings(settings_display_subprojects_issues, "display_subprojects_issues");
		updataSettings(settings_issue_done_ratio, "issue_done_ratio");
		updataSettings(settings_issues_export_limit, "issues_export_limit");
		List<String> permissionsList = Lists.newArrayList(); 
		if (settings_issue_list_default_columns != null){
			for (int p = 0; p < settings_issue_list_default_columns.length; p++) {
				String strPermission = settings_issue_list_default_columns[p];
				permissionsList.add(strPermission);
			}
		}
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("name", "issue_list_default_columns");
		conditions.put("value", Yaml.dump(permissionsList));
		db.update("settingIssues.updataSettings" , conditions);
	}
	public PluginInfoBean pluginInfoSet(String value, String name) throws SoftbankException {
		PluginInfoBean pluginInfoBean = new PluginInfoBean();
		pluginInfoBean.setValue(value);
		pluginInfoBean.setName(name);
		return pluginInfoBean;
	}
	public void updataSettings(String value, String name) throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("name", name);
		conditions.put("value", value);
		db.update("settingIssues.updataSettings" , conditions);
	}
}
