package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

//import co.jp.softbank.qqmx.dao.project.settings.TrackerListDao;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.util.StringUtils;

public class NewProjectsAccessLogic extends AbstractBaseLogic {
	
	
	public LogicBean getProjectSettingRoleList() throws SoftbankException {
		LogicBean groupBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("member_id", Integer.parseInt(context.getParam().get("memberId")));
		groupBean.setData(db.querys("newProjectsAccess.getProjectSettingRoleList", conditions));
		return groupBean;
	}
	
	public LogicBean getProjectList() throws SoftbankException {
		LogicBean groupBean = new LogicBean();
		String groupId = context.getParam().get("groupId");
		Map<String, Object> conditions = Maps.newHashMap();
		
		
		conditions.put("group_id", Integer.parseInt(groupId));
		conditions.put("input_date", context.getParam().get("input_date"));
		groupBean.setData(db.querys("newProjectsAccess.getProjectList", conditions));
		return groupBean;
	}
	public LogicBean saveProjectGroupUser() throws SoftbankException {
		String[] projectSettingProject = new String[]{};
		String[] projectSettingProjectTemp = context.getParam().getList("member_project_ids_selected_name");
		if(StringUtils.isNotEmpty(projectSettingProjectTemp)){
			 projectSettingProject = projectSettingProjectTemp ;
		}
		String[] projectSettingRole = new String[]{};
		String[] projectSettingRoleTemp = context.getParam().getList("member_project_role_selected_name");
		if(StringUtils.isNotEmpty(projectSettingRoleTemp)){
			projectSettingRole = projectSettingRoleTemp ;
		}
		String groupId = context.getParam().get("groupId");
		
		LogicBean groupBean = new LogicBean();
		Map<String, Integer> conditions = Maps.newHashMap();
		conditions.put("group_id", Integer.parseInt(groupId));
		List<Map<String, Object>> selectGroupUser = db.querys("newProjectsAccess.selectProjectSettingGroupUsers", conditions);
		//プロジェクト
		for (int i = 0; i < projectSettingProject.length; i++) {
			int project_id = Integer.valueOf(projectSettingProject[i]);
			
			Map<String, Object> conditionMembers = Maps.newHashMap();
			conditionMembers.put("project_id", project_id);
			conditionMembers.put("user_id", Integer.parseInt(groupId));
			db.insert("newProjectsAccess.insertProjectSettingUser", conditionMembers);
			int mGroupRoleId = Integer.parseInt(StringUtils.toString(conditionMembers.get("id")));
			int inherited_from_id = insertRole(projectSettingRole, project_id, mGroupRoleId, 0);
			//グループユーザ
			for (int j = 0; j < selectGroupUser.size(); j++) {
				conditionMembers.put("user_id", StringUtils.toInt(selectGroupUser.get(j).get("user_id")));
				List<Map<String, Object>> selectMemberGroupUsersId = db.querys("newProjectsAccess.selectProjectSettingMembers",conditionMembers);
				if (selectMemberGroupUsersId.size() == 0 ){
					
					db.insert("newProjectsAccess.insertProjectSettingUser", conditionMembers);
					int mUserRoleId = Integer.parseInt(StringUtils.toString(conditionMembers.get("id")));
					//ロール
					insertRole(projectSettingRole, project_id, mUserRoleId, inherited_from_id);
				}else{
					insertRole(projectSettingRole, project_id, Integer.valueOf(String.valueOf(selectMemberGroupUsersId.get(0).get("id"))), inherited_from_id);
				}
			}
		}
		return groupBean;
	}

	private int insertRole(String[] projectSettingRole, int project_id ,int members_id, int inherited_from) throws SoftbankException{
		int mUserRoleId = 0;
		for (int m = 0; m < projectSettingRole.length; m++) {
			Map<String, Object> conditionRoles = Maps.newHashMap();
			conditionRoles.put("member_id", members_id);
			conditionRoles.put("role_id", Integer.parseInt(projectSettingRole[m]));
			List<Map<String, Object>> selectMemberRoles = db.querys("newProjectsAccess.selectProjectMemberRoles" ,conditionRoles);
			
			if (selectMemberRoles.size() == 0){
				if (inherited_from == 0){
					conditionRoles.put("inherited_from", null);
				}else{
					conditionRoles.put("inherited_from", inherited_from);
				}
				db.insert("newProjectsAccess.insertProjectSettingMembers" ,conditionRoles);
				mUserRoleId = Integer.parseInt(StringUtils.toString(conditionRoles.get("id")));
			}
		}
		return mUserRoleId;
	}
	
}
