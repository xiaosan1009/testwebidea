package co.jp.softbank.qqmx.logic.application.project;

import java.util.Map;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Maps;

public class NewsAddLogic extends TicketBaseLogic {
	
	public void getComments() throws SoftbankException {
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("news_id", context.getParam().get("news_id"));
		
		context.getResultBean().setData(db.querys("newsAdd.selectComments", conditions));
		
	}
	public void setComments() throws SoftbankException {

		UserInfoData userInfo = this.context.getSessionData().getUserInfo();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("commented_type", "News");
		conditions.put("commented_id", StringUtils.toInt(context.getParam().get("commented_id")));
		conditions.put("author_id", userInfo.getId());
		conditions.put("comments", context.getParam().get("comment_content"));
		db.insert("comments.addCommentsInfo", conditions);
		
		// comments_countを更新
		conditions.put("news_id", StringUtils.toInt(context.getParam().get("news_id")));
		db.update("news.updateCommentsCountUp", conditions);
	}
	
	public void delComments() throws SoftbankException {
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("commented_id", StringUtils.toInt(context.getParam().get("commented_id")));
		db.delete("comments.deleteCommentsById", conditions);
		
		// comments_countを更新
		conditions.put("news_id", StringUtils.toInt(context.getParam().get("news_id")));
		UserInfoData userInfo = this.context.getSessionData().getUserInfo();
		conditions.put("author_id", userInfo.getId());
		db.update("news.updateCommentsCountDown", conditions);
		
	}

}
