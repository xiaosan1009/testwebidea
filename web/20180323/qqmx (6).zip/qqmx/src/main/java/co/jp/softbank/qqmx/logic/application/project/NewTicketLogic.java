package co.jp.softbank.qqmx.logic.application.project;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.bean.InputErrorBean;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.application.face.IssueKey;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.Param;
import co.jp.softbank.qqmx.util.StringUtils;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class NewTicketLogic extends TicketBaseLogic {
	
	public LogicBean getTicketInfos() throws SoftbankException {

		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();

		Map<String, Object> conditions = Maps.newHashMap();

		Integer projectId = context.getParam().projectId;
		
		Integer issue_id = null;
		Map<String, Object> issue = null;
		if (StringUtils.isNotEmpty(context.getParam().get("issue_id"))) {
			issue_id = Integer.valueOf(context.getParam().get("issue_id"));
			conditions.put("issue_id", issue_id);
			issue = db.query("issues.selectIssueById", conditions);
			resultMap.put("issue", issue);
			projectId = (Integer)issue.get("project_id");
		}

		conditions.put("project_id", projectId);
		List<Map<String, Object>> trackers = db.querys("newTicket.getTrackers",conditions);
		resultMap.put("trackers", trackers);

		Object tracker_id = null;
		if (StringUtils.isNotEmpty(context.getParam().get("issue_tracker_id")) ) {
			tracker_id = Integer.parseInt(context.getParam().get("issue_tracker_id"));
		} else {
			if (issue != null) {
				tracker_id = issue.get("tracker_id");
			} else {
				tracker_id = trackers.get(0).get("id");
			}
		}
		
		conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		conditions.put("user_id", ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId());
		conditions.put("tracker_id", tracker_id);
		List<Map<String, Object>> issueStatuses = db.querys("newTicket.getIssueStatuses",conditions);
		resultMap.put("issueStatuses", issueStatuses);
		
		Map<String, Object> issuePrivates = db.query("newTicket.getIssuePrivates",conditions);
		resultMap.put("issuePrivates", issuePrivates);
		

		List<Map<String, Object>> issuePrioritys = db.querys("newTicket.getIssuePrioritys");
		resultMap.put("issuePrioritys", issuePrioritys);

		List<Map<String, Object>> phases = db.querys("newTicket.getPhases");
		resultMap.put("phases", phases);
		List<Map<String, Object>> testPhases = db.querys("newTicket.getTestPhases");
		resultMap.put("testPhases", testPhases);

		conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		List<Map<String, Object>> members = db.querys("newTicket.getMembers", conditions);
		resultMap.put("members", members);

		conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		List<Map<String, Object>> versions = db.querys("newTicket.getVersions", conditions);
		resultMap.put("versions", versions);

		conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		conditions.put("tracker_id", tracker_id);
		if (issue != null) {
			conditions.put("issue_id", issue.get("id"));
			resultMap.put("issueCustomFields", db.querys("issues.selectIssueCustomFieldsAndValues", conditions));
		} else {
			resultMap.put("issueCustomFields", db.querys("issues.getIssueCustomFields", conditions));
		}
		logicBean.setData(resultMap);
		return logicBean;
	}
	
	public LogicBean changeProject() throws SoftbankException {

		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, Object> conditions = Maps.newHashMap();

		Integer projectId = Integer.valueOf(context.getParam().get("issue_project_id"));

		conditions.put("project_id", projectId);
		List<Map<String, Object>> trackers = db.querys("newTicket.getTrackers", conditions);
		resultMap.put("trackers", trackers);

		Integer tracker_id = (Integer)trackers.get(0).get("id");
		for (Map<String, Object> tracker : trackers) {
			if ((Integer)tracker.get("id") == Integer.parseInt(context.getParam().get("issue_tracker_id"))) {
				tracker_id = (Integer)tracker.get("id");
				break;
			}
		}

		conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		List<Map<String, Object>> members = db.querys("newTicket.getMembers", conditions);
		resultMap.put("members", members);

		conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		List<Map<String, Object>> versions = db.querys("newTicket.getVersions", conditions);
		resultMap.put("versions", versions);

		conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		conditions.put("user_id", ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId());
		conditions.put("tracker_id", tracker_id);
		List<Map<String, Object>> issueStatuses = db.querys("newTicket.getIssueStatuses", conditions);
		resultMap.put("issueStatuses", issueStatuses);

		List<Map<String, Object>> phases =  db.querys("newTicket.getPhases");
		resultMap.put("phases", phases);
		List<Map<String, Object>> testPhases = db.querys("newTicket.getTestPhases");
		resultMap.put("testPhases", testPhases);

		conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		conditions.put("tracker_id", tracker_id);
		resultMap.put("issueCustomFields", db.querys("issues.getIssueCustomFields", conditions));
		
		//対象システム
		List<Map<String, Object>> systems = db.querys("target_systems.getTargetSystemsForCmb", conditions);
		resultMap.put("systems", systems);

		logicBean.setData(resultMap);
		return logicBean;
	}
	
	public LogicBean changeTracker() throws SoftbankException {

		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, Object> conditions = Maps.newHashMap();

		Integer projectId = Integer.valueOf(context.getParam().get("issue_project_id"));
		Integer tracker_id = Integer.parseInt(context.getParam().get("issue_tracker_id"));
		
		conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		conditions.put("user_id", ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId());
		conditions.put("tracker_id", tracker_id);
		List<Map<String, Object>> issueStatuses = db.querys("newTicket.getIssueStatuses", conditions);
		resultMap.put("issueStatuses", issueStatuses);

		List<Map<String, Object>> phases = db.querys("newTicket.getPhases");
		resultMap.put("phases", phases);
		List<Map<String, Object>> testPhases = db.querys("newTicket.getTestPhases");
		resultMap.put("testPhases", testPhases);

		conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		List<Map<String, Object>> members = db.querys("newTicket.getMembers", conditions);
		resultMap.put("members", members);

		conditions = Maps.newHashMap();
		conditions.put("project_id", projectId);
		conditions.put("tracker_id", tracker_id);
		resultMap.put("issueCustomFields", db.querys("issues.getIssueCustomFields", conditions));

		//対象システム
		List<Map<String, Object>> systems = db.querys("target_systems.getTargetSystemsForCmb", conditions);
		resultMap.put("systems", systems);
		
		logicBean.setData(resultMap);
		return logicBean;
	}
	
	public LogicBean searchTcketForParent() throws SoftbankException {

		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		
		String search_keyword = "";
		if (StringUtils.isNotEmpty(context.getParam().get("search_keyword")) ) {
			search_keyword = context.getParam().get("search_keyword");
		}
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", Integer.parseInt(context.getParam().get("projectTicketId")));
		conditions.put("search_keyword", search_keyword);
		List<Map<String, Object>> parentIssues = db.querys("newTicket.searchTcketForParent", conditions);
		resultMap.put("parentIssues", parentIssues);

		logicBean.setData(resultMap);
		return logicBean;
	}
	
	public LogicBean createTicket() throws SoftbankException {
		doCheck();
		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", Integer.parseInt(context.getParam().get("projectTicketId")));
		conditions.put("tracker_id", Integer.parseInt(context.getParam().get("issue_tracker_id")));
		conditions.put("subject", context.getParam().get("issue_subject"));
		conditions.put("description", context.getParam().get("issue_description"));
		conditions.put("due_date", context.getParam().get("issue_due_date"));
		
		if (StringUtils.isNotEmpty(context.getParam().get("issue_category_id"))) {
			conditions.put("category_id", Integer.parseInt(context.getParam().get("issue_category_id")));
		}
		
		if (StringUtils.isNotEmpty(context.getParam().get("issue_status_id"))) {
			conditions.put("status_id", Integer.parseInt(context.getParam().get("issue_status_id")));
		} else {
			conditions.put("status_id", null);
		}
		
		if (StringUtils.isNotEmpty(context.getParam().get("issue_assigned_to_id"))) {
			conditions.put("assigned_to_id", Integer.parseInt(context.getParam().get("issue_assigned_to_id")));
		}
		if (StringUtils.isNotEmpty(context.getParam().get("issue_priority_id"))) {
			conditions.put("priority_id", Integer.parseInt(context.getParam().get("issue_priority_id")));
		} else {
			conditions.put("priority_id", null);
		}
		
		if (StringUtils.isNotEmpty(context.getParam().get("issue_fixed_version_id"))) {
			conditions.put("fixed_version_id", Integer.parseInt(context.getParam().get("issue_fixed_version_id")));
		} else {
			conditions.put("fixed_version_id", null);
		}
		conditions.put("organization_cd", context.getParam().get("issue_organization_cd"));
		conditions.put("author_id", ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId());
		conditions.put("start_date", context.getParam().get("issue_start_date"));
		
		if (StringUtils.isNotEmpty(context.getParam().get("issue_done_ratio"))) {
			conditions.put("done_ratio", Integer.parseInt(context.getParam().get("issue_done_ratio")));
		} else {
			conditions.put("done_ratio", null);
		}
		
		if (StringUtils.isNotEmpty(context.getParam().get("issue_estimated_hours"))) {
			conditions.put("estimated_hours", Double.valueOf(context.getParam().get("issue_estimated_hours")));
		} else {
			conditions.put("estimated_hours", null);
		}
		if (StringUtils.isNotEmpty(context.getParam().get("issue_parent_issue_id"))) {
			conditions.put("parent_id", Integer.parseInt(context.getParam().get("issue_parent_issue_id")));
		} else {
			conditions.put("parent_id", null);
		}
		conditions.put("is_private", "1".equals(context.getParam().get("issue_is_private")) ? true : false);
		
		db.insert("newTicket.insertIssueInfo", conditions);
		
		final int issueId = StringUtils.toInt(conditions.get("id"));
		
		// 添付ファイルを保存
		String upload_datas = context.getParam().get("upload_datas");
		if (StringUtils.isNotEmpty(upload_datas)) {
			JSONArray importFile = JSONArray.fromObject(upload_datas);
			
			for (int i = 0; i < importFile.size(); i++) {
				JSONObject fileData = importFile.getJSONObject(i);
				
				Map<String, Object> dataMap = Maps.newHashMap();
				dataMap.put("attachments_id", fileData.getInt("id"));
				dataMap.put("issue_id", issueId);
				if (fileData.containsKey("description")) {
					dataMap.put("description", fileData.getString("description"));
				}
				
				db.update("newTicket.updateAttachmentsByIdAfterInsert", dataMap);
			}
		}
		
		final Map<Integer, Object> customValues = Maps.newHashMap();
		
		final List<Map<String, Object>> customValuesList = Lists.newArrayList();
		context.getParam().each(new Param.EachFilter() {
			
			@Override
			public void filter(String key, String value) {
				if (key.startsWith("issue_custom_field_values_")) {
					Map<String, Object> customValueInfo = Maps.newHashMap();
					int fieldId = StringUtils.toInt(key.substring("issue_custom_field_values_".length()));
					customValueInfo.put("customized_id", issueId);
					customValueInfo.put("custom_field_id", fieldId);
					customValueInfo.put("value", value);
					customValues.put(fieldId, value);
					customValuesList.add(customValueInfo);
				}
			}
		});
		
		afterInsertTicket(conditions);
		
		if (customValuesList != null && customValuesList.size() > 0) {
			conditions = Maps.newHashMap();
			conditions.put("customValues", customValuesList);
			db.insert("newTicket.insertIssueCustomValues", conditions);
		}

		String[] issue_watcher_user_ids = context.getParam().getList("issue_watcher_user_ids");
		if (issue_watcher_user_ids != null && issue_watcher_user_ids.length > 0) {
			for (String issue_watcher_user_id : issue_watcher_user_ids) {
				conditions.put("watchable_type", "Issue");
				conditions.put("watchable_id", issueId);
				conditions.put("user_id", Integer.parseInt(issue_watcher_user_id));
				db.insert("newTicket.insertWatchers", conditions);
			}
		}

		resultMap.put("issue_id", issueId);
		logicBean.setData(resultMap);

		return logicBean;
	}
	
	private void doCheck()  throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		if (StringUtils.isNotEmpty(context.getParam().get("issue_tracker_id"))) {
			conditions.put("issue_tracker_id", StringUtils.toInt(context.getParam().get("issue_tracker_id")));
		} else {
			conditions.put("issue_tracker_id", null);
		}
		conditions.put("issue_subject", context.getParam().get("issue_subject"));
		conditions.put("issue_due_date", context.getParam().get("issue_due_date"));
		
		if (StringUtils.isNotEmpty(context.getParam().get("issue_status_id"))) {
			conditions.put("issue_status_id", StringUtils.toInt(context.getParam().get("issue_status_id")));
		} else {
			conditions.put("issue_status_id", null);
		}
		
		if (StringUtils.isNotEmpty(context.getParam().get("issue_priority_id"))) {
			conditions.put("issue_priority_id", StringUtils.toInt(context.getParam().get("issue_priority_id")));
		} else {
			conditions.put("issue_priority_id", null);
		}
		
		if (StringUtils.isNotEmpty(context.getParam().get("issue_fixed_version_id"))) {
			conditions.put("issue_fixed_version_id", StringUtils.toInt(context.getParam().get("issue_fixed_version_id")));
		} else {
			conditions.put("issue_fixed_version_id", null);
		}
		conditions.put("issue_start_date", context.getParam().get("issue_start_date"));
		
		
		if (StringUtils.isNotEmpty(context.getParam().get("issue_done_ratio"))) {
			conditions.put("issue_done_ratio", StringUtils.toInt(context.getParam().get("issue_done_ratio")));
		} else {
			conditions.put("issue_done_ratio", null);
		}
		
		if (StringUtils.isNotEmpty(context.getParam().get("issue_estimated_hours"))) {
			conditions.put("issue_estimated_hours", Double.valueOf(context.getParam().get("issue_estimated_hours")));
		} else {
			conditions.put("issue_estimated_hours", null);
		}
		
		final Map<Integer, Object> customValues = Maps.newHashMap();
		
		context.getParam().each(new Param.EachFilter() {
			
			@Override
			public void filter(String key, String value) {
				if (key.startsWith("issue_custom_field_values_")) {
					int fieldId = StringUtils.toInt(key.substring("issue_custom_field_values_".length()));
					customValues.put(fieldId, value);
				}
			}
		});
		
		conditions.put(IssueKey.CUSTOMVALUES.KEY, customValues);
		
		doValidate(conditions);
	}
	
	@Override
	public void doValidate(List<InputErrorBean> errorInfos) throws SoftbankException {
		if ("3".equals(context.getParam().cmdCode)) {
			
			String status_id = context.getParam().get("issue_status_id");
			String done_ratio = context.getParam().get("issue_done_ratio");
			String parent_issue_id = context.getParam().get("issue_parent_issue_id");
			String str_start_date = context.getParam().get("issue_start_date");
			String str_due_date = context.getParam().get("issue_due_date");

			if ("1".equals(status_id) && !"0".equals(done_ratio) || "3".equals(status_id) && !"100".equals(done_ratio)){
				InputErrorBean inputErrorStatusBean = new InputErrorBean();
				inputErrorStatusBean.setTargetId("issue_status_id");
				inputErrorStatusBean.setMessage("ステータスと進捗率の内容が不整合です。再度入力してください。");
				errorInfos.add(inputErrorStatusBean);
				InputErrorBean inputErrorDoneRatioBean = new InputErrorBean();
				inputErrorDoneRatioBean.setTargetId("issue_done_ratio");
				inputErrorDoneRatioBean.setMessage("ステータスと進捗率の内容が不整合です。再度入力してください。");
				errorInfos.add(inputErrorDoneRatioBean);
			}

			if (!"".equals(parent_issue_id) && null != parent_issue_id){
				Map<String, Object> conditions = Maps.newHashMap();
				conditions.put("search_keyword", parent_issue_id);
				List<Map<String, Object>> parentIssues = db.querys("newTicket.searchExistTcketForParent", conditions);
				if (parentIssues.size() == 0){
					InputErrorBean inputErrorParentIssueBean = new InputErrorBean();
					inputErrorParentIssueBean.setTargetId("issue_parent_issue_id");
					inputErrorParentIssueBean.setMessage("親チケットは存在しません。");
					errorInfos.add(inputErrorParentIssueBean);
				}else{
					if (!parentIssues.get(0).get("project_id").equals(context.getParam().projectId)){
						InputErrorBean inputErrorParentIssueBean = new InputErrorBean();
						inputErrorParentIssueBean.setTargetId("issue_parent_issue_id");
						inputErrorParentIssueBean.setMessage("親チケット 同じプロジェクトに属していません。");
						errorInfos.add(inputErrorParentIssueBean);
					}
				}
			}
			
			if (!"".equals(str_start_date) && !"".equals(str_due_date)){
				SimpleDateFormat format = new SimpleDateFormat("yyyy-MM-dd");
				Date start_date = null;
				Date due_date = null;
				try {
					start_date = format.parse(str_start_date);
					due_date = format.parse(str_due_date);
				} catch (ParseException e) {
					e.printStackTrace();
				}
				
				if (start_date.compareTo(due_date) > 0){
					InputErrorBean inputErrorSDateBean = new InputErrorBean();
					inputErrorSDateBean.setTargetId("issue_start_date");
					inputErrorSDateBean.setMessage("期日 を開始日より後にしてください。");
					errorInfos.add(inputErrorSDateBean);
					InputErrorBean inputErrorDateBean = new InputErrorBean();
					inputErrorDateBean.setTargetId("issue_due_date");
					inputErrorDateBean.setMessage("期日 を開始日より後にしてください。");
					errorInfos.add(inputErrorDateBean);
				}
			}
		}
	}
	
	public void doCustomFieldRequired(List<InputErrorBean> errorInfos, String id, String messages, String value) throws SoftbankException {
		if ("".equals(value)){
			InputErrorBean inputErrorBean = new InputErrorBean();
			inputErrorBean.setTargetId("issue_custom_field_values_" + id);
			inputErrorBean.setMessage(messages + "は入力必須項目です.");
			errorInfos.add(inputErrorBean);
		}
	}
	
	public int selectRootIdInfo(int issueId) throws SoftbankException {
		int rootId = 0;
		if (!"null".equals(issueId)){
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("issueId", issueId);
			List<Map<String, Object>> rootIdList = db.querys("issues.selectIssueRootId", conditions);
			if (rootIdList.size() > 0){
				rootId = Integer.parseInt(String.valueOf(rootIdList.get(0)));
			}
		}
		return rootId;
	}
//		
//	@Override
//	protected IDaoInterface getDao() {
//		return newTicketDao;
//	}

}
