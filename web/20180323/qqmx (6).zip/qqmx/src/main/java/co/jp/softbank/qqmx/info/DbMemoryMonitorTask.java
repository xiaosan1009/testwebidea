package co.jp.softbank.qqmx.info;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.dao.common.IDbExecute;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.TimestampData;

public class DbMemoryMonitorTask extends DbMemoryTaskBase {
	
	private IDbExecute db;
	
	public DbMemoryMonitorTask(IDbExecute db) {
		this.db = db;
	}
	
	@Override
	public void run() {
		try {
			@SuppressWarnings("unchecked")
			HashMap<Integer, TimestampData> timestampMap = (HashMap<Integer, TimestampData>)((HashMap<Integer, TimestampData>)ControlDbMemory.getInstance().getTimestampMap()).clone();
			for (Map.Entry<Integer, TimestampData> projectTimestamp : timestampMap.entrySet()) {
				int projectId = projectTimestamp.getKey();
				TimestampData timestampData = projectTimestamp.getValue();
				Date memoryTimestamp = timestampData.getTimestamp();
				Map<String, Object> conditions = Maps.newHashMap();
				conditions.put("project_id", projectId);
				Date issueUpdateTimestamp = db.queryoC("issue_update_timestamp.getMaxIssueUpdateTimestampForProject", conditions);
				if (issueUpdateTimestamp != null && issueUpdateTimestamp.compareTo(memoryTimestamp) > 0) {
					ControlDbMemory.getInstance().setTimestampMap(projectId, issueUpdateTimestamp, true);
					List<Integer> userList = db.queryosC("issue_update_timestamp.getNotFinishUserId", conditions);
					ControlDbMemory.getInstance().refreshTicketsSync(projectId, userList);
				}

			}
		} catch (SoftbankException e) {
			log.error(e.getMessage(), e);
			e.printStackTrace();
		}
	}
}
