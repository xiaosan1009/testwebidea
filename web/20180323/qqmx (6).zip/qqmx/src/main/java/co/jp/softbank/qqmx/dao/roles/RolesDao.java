package co.jp.softbank.qqmx.dao.roles;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.dao.IDaoInterface;
import co.jp.softbank.qqmx.dao.roles.bean.RolesBaseBean;

public interface RolesDao extends IDaoInterface {
	
	List<Map<String, Object>> selectAllRolesInfo();
	
	List<RolesBaseBean> selectAllRolesBaseInfo();

}
