package co.jp.softbank.qqmx.logic.face;

import org.apache.commons.fileupload.FileItem;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.bean.UploadFileInfo;

public interface IUploadLogicFace {
	
	void doUpload(FileItem item, UploadFileInfo fileInfo) throws SoftbankException;

}
