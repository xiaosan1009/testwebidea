/**
 *   <Quantitative project management tool.>
 *   Copyright (C) 2012 IPA, Japan.
 *
 *   This program is free software: you can redistribute it and/or modify
 *   it under the terms of the GNU General Public License as published by
 *   the Free Software Foundation, either version 3 of the License, or
 *   (at your option) any later version.
 *
 *   This program is distributed in the hope that it will be useful,
 *   but WITHOUT ANY WARRANTY; without even the implied warranty of
 *   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 *   GNU General Public License for more details.
 *
 *   You should have received a copy of the GNU General Public License
 *   along with this program.  If not, see <http://www.gnu.org/licenses/>.
 */

package co.jp.softbank.qqmx.logic.application.batch;

import java.io.File;
import java.io.FileInputStream;
import java.util.ArrayList;
import java.util.List;

import org.apache.commons.io.FileUtils;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.io.IOUtils;
import org.mozilla.universalchardet.UniversalDetector;

import tk.stepcounter.diffcount.Cutter;
import tk.stepcounter.diffcount.CutterFactory;
import tk.stepcounter.diffcount.DiffCounterUtil;
import tk.stepcounter.diffcount.DiffSource;

import co.jp.softbank.qqmx.logic.application.batch.SourceScaleResult.Status;

/**
 * ソースステップ数カウント用クラスの抽象クラス。
 * 
 */
public abstract class IpfSourceScaleCounter {
    /** 文字コード判定用クラス */
    protected static UniversalDetector detector = new UniversalDetector(null);
	
    /** ソースステップ数カウント対象ファイルの拡張子を格納 */
	protected final List<String> fileExtList = new ArrayList<String>();
	
	public IpfSourceScaleCounter() {
		this.setFileExt(this.fileExtList);
	}

	/**
	 * 変更前ファイル、変更後ファイルから変更種別を判別し
	 * ソース規模収集処理を呼ぶ。
	 * 
	 * @param oldFile 変更前ファイル
	 * @param newFile 変更後ファイル
	 * @return ソース規模収集結果
	 */
    public static SourceScaleResult count(File oldFile, File newFile) {
        
        SourceScaleResult result = new SourceScaleResult();
        
        if ((oldFile != null && oldFile.exists()) &&
            (newFile != null && newFile.exists())) {
            // 変更前、変更後両方のファイルがある場合
            // 更新
            result = countSourceScale(oldFile, newFile, Status.MODIFIED);
            
        } else if ((oldFile != null && oldFile.isFile()) &&
                (newFile == null || !newFile.exists())) {
            // 変更前ファイルのみ存在する場合
            // 削除
            result = countSourceScale(oldFile, null, Status.REMOVED);
            
        } else if ((newFile != null && newFile.isFile()) &&
                (oldFile == null || !oldFile.exists())) {
            // 変更後ファイルのみ存在する場合
            // 新規       
            result = countSourceScale(null, newFile, Status.ADDED);
        }
        
        return result;
    }
    
	public abstract void setFileExt(List<String> fileExtList);
	
	/**
	 * 変更前ファイル、変更後ファイルからソース規模を収集して返す。
	 * 
	 * @param oldFile 変更前ファイル
	 * @param newFile 変更後ファイル
	 * @param status 変更種別
	 * @return ソース規模収集結果
	 */
	public static SourceScaleResult countSourceScale(
			File oldFile, File newFile, Status status) {
		
		SourceScaleResult result = new SourceScaleResult();
		
		// ステータス
		result.setStatus(status);
		
		// ファイルサイズ
		long fileSize = 0;
		if (newFile != null) {
			fileSize = newFile.length();
		}
		result.setFileSize(fileSize);
		
		// ファイルタイプに応じたカッター（コメント、空行を除去）
		Cutter cutter2 = CutterFactory.getCutter(newFile != null ? newFile : oldFile);
		if (cutter2 == null) {
			// カッターを取得できなかった場合 → カウントしない
			result.setFileType("UNDEF");
			return result;
		}
		// ファイル種別
		String fileType = cutter2.getFileType();
		result.setFileType(fileType);
		
		// 何もしないカッター（コメント、空行を除去しない）
		Cutter cutter = new NoCutter(fileType);
		
		long newLine  = 0;
		long newLine2 = 0;
		long oldLine  = 0;
		long oldLine2 = 0;
		
		DiffSource newSource  = null;
		DiffSource newSource2 = null;
		DiffSource oldSource  = null;
		DiffSource oldSource2 = null;
		
		String charset = null;
		
		if (newFile != null) {
			// 変更後ファイルが存在する
		    charset = getEncoding(newFile);
		    newSource  = cutter.cut(DiffCounterUtil.getSource(newFile, charset));	
			newSource2 = cutter2.cut(DiffCounterUtil.getSource(newFile, charset));
			
			newLine  = DiffCounterUtil.split(newSource.getSource()).length;
			newLine2 = DiffCounterUtil.split(newSource2.getSource()).length;
		}
		
		if (oldFile != null) {
			// 変更前ファイルが存在する
		    if (charset == null) {
	            charset = getEncoding(oldFile);
		    }
			oldSource  = cutter.cut(DiffCounterUtil.getSource(oldFile, charset));	
			oldSource2 = cutter2.cut(DiffCounterUtil.getSource(oldFile, charset));
			
			oldLine  = DiffCounterUtil.split(oldSource.getSource()).length;
			oldLine2 = DiffCounterUtil.split(oldSource2.getSource()).length;
		}
		
		switch (status) {
			case ADDED :
				// 新規
				result.setSourceLine(newLine);
				result.setSourceLine2(newLine2);
				result.setAddLine(newLine);
				result.setAddLine2(newLine2);
				result.setDelLine(0);
				result.setDelLine2(0);
				result.setModLine(0);
				result.setModLine2(0);
				
				break;
			case MODIFIED :
				// 変更
				
				result.setSourceLine(newLine);
				result.setSourceLine2(newLine2);
				
				IpfDiffCountHandler handler = new IpfDiffCountHandler();
				IpfDiffEngine engine = new IpfDiffEngine(handler, oldSource.getSource(), newSource.getSource());
				engine.doDiff();
				result.setAddLine(handler.getAddCount());
				result.setDelLine(handler.getDelCount());
				result.setModLine(handler.getModCount());
				
				IpfDiffCountHandler handler2 = new IpfDiffCountHandler();
				IpfDiffEngine engine2 = new IpfDiffEngine(handler2, oldSource2.getSource(), newSource2.getSource());
				engine2.doDiff();
				result.setAddLine2(handler2.getAddCount());
				result.setDelLine2(handler2.getDelCount());
				result.setModLine2(handler2.getModCount());
				
				break;
			case REMOVED :
				// 削除
				result.setSourceLine(0);
				result.setSourceLine2(0);
				result.setAddLine(0);
				result.setAddLine2(0);
				result.setDelLine(oldLine);
				result.setDelLine2(oldLine2);
				result.setModLine(0);
				result.setModLine2(0);
				
				break;
		}
		
	    // 変化行数（前回リビジョンからの変化行数（削除された行数はマイナス値でカウント））
		result.setIncreaseLine(result.getAddLine() - result.getDelLine());
		result.setIncreaseLine2(result.getAddLine2() - result.getDelLine2());
		
	    // 変更行数（前回リビジョンから変更行数（追加・変更・削除行数の総和））
		result.setChangeLine(result.getAddLine() + result.getDelLine() + result.getModLine());
		result.setChangeLine2(result.getAddLine2() + result.getDelLine2() + result.getModLine2());
		
		return result;
	}
	
	public List<String> getFileExtList() {
		return this.fileExtList;
	}
	
    /**
     * 指定したファイルのソース規模が収集可能かどうかを返す。
     * 
     * @param filename ファイル名
     * @return true : 収集可能、false : 収集不可
     */
	public boolean isCountable(String filename) {
        
        if (filename != null) {
            String ext = FilenameUtils.getExtension(filename);
            if (fileExtList.contains(ext)) {
                return true;
            }
        }
        return false;
    }
	
    /**
     * ファイルの文字コードを判別して返す。
     * 
     * @param file ファイル
     * @return 文字コード
     */
    private static String getEncoding(File file) {
        
        String encoding = System.getProperty("file.encoding");
        
        FileInputStream fis = null;
        try {
            byte[] buf = new byte[4096];
            fis = FileUtils.openInputStream(file);
            int nread;
            while ((nread = fis.read(buf)) > 0 && !detector.isDone()) {
                detector.handleData(buf, 0, nread);
            }
            detector.dataEnd();
            
            if (detector.getDetectedCharset() != null) {
                encoding = detector.getDetectedCharset();
            }
            
        } catch (Exception e) {
            //
        } finally {
            IOUtils.closeQuietly(fis);
            detector.reset();
        }

        return encoding;
    }

}
