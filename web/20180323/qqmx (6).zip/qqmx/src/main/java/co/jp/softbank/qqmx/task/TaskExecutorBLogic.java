package co.jp.softbank.qqmx.task;

import java.util.LinkedList;
import java.util.List;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.Future;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;

import com.google.common.io.Closeables;
import com.google.common.io.Closer;

import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.task.bean.Worker;
import co.jp.softbank.qqmx.task.face.IContextFactory;
import co.jp.softbank.qqmx.task.face.IKey;
import co.jp.softbank.qqmx.task.face.IOutputCollector;
import co.jp.softbank.qqmx.task.face.IReader;
import co.jp.softbank.qqmx.task.face.ITask;
import co.jp.softbank.qqmx.task.face.ITaskContext;
import co.jp.softbank.qqmx.task.face.ITaskLogic;
import co.jp.softbank.qqmx.task.face.IWorker;
import co.jp.softbank.qqmx.task.info.TaskInfo;
import co.jp.softbank.qqmx.util.LogUtil;

public class TaskExecutorBLogic extends BaseTask implements ITaskLogic {
	
	public TaskExecutorBLogic() throws SoftbankException {
		super();
	}

	private IContextFactory contextFactory;
	
	private LinkedList<TaskInfo> taskList = new LinkedList<TaskInfo>();
	
	private IOutputCollector<? extends Object> collector;
	
	protected Logger log = new LogUtil(this.getClass()).getLog();
	
	public interface TaskExecuteStatus {
		int OK = 100;
		int ERROR = 0;
	}

	@Override
	public int execute(HttpContext httpContext) {
		int status = TaskExecuteStatus.ERROR;
		ITaskContext context = contextFactory.getTaskContext();
		if (context == null) {
            return status;
        }
		context.setHttpContext(httpContext);
		try {
			collector = runTasks(context);
		} catch (Exception e) {
			e.printStackTrace();
			log.error(e.getMessage(), e);
		}
		return TaskExecuteStatus.OK;
	}
	
	@SuppressWarnings({ "rawtypes" })
	private IOutputCollector runTasks(ITaskContext context) throws Exception {
		TaskInfo taskInfo = taskList.getFirst();
		collector.prepare(context);
		while (taskInfo != null) {
			Closer closer = Closer.create();
			try {
				IReader<? extends Object> reader = taskInfo.getReader();
				closer.register(reader);
				reader.prepare(context);
				
				runTask(context, taskInfo);
				
                reader.cleanup(context);
                taskInfo = taskInfo.getNext();
			} catch (Exception e) {
				e.printStackTrace();
				 Closeables.close(collector, true);
				 throw e;
			} finally {
				collector.cleanup(context);
				closer.close();
			}
		}
		return collector;
	}
	
	protected void runTask(ITaskContext ctx, TaskInfo taskInfo) throws Exception {

        try {
            handleTaskStart(ctx, taskInfo);

            ITask<?> task = taskInfo.getTask();
            try {
                List<Future<IWorker>> futures = new LinkedList<Future<IWorker>>(executor.invokeAll(workers));

                IReader<? extends Object> reader = taskInfo.getReader();
                while (reader.hasNext()) {
                    IKey key = reader.getKey();
                    Object value = reader.getValue();
                    IWorker worker = null;
                    do {
                        worker = pollWorker(futures);
                    } while (worker == null);
                    ((Worker)worker).setKeyValue(key, value);
                    futures.add(executor.submit(worker));
                }

                while (!futures.isEmpty()) {
                	IWorker worker = pollWorker(futures);
                    if (worker == null || ((Worker)worker).getContext() == null) {
                        continue;
                    }
                }

            } catch (SoftbankException e) {
                if (e.getCause() instanceof Error) {
                    throw (Error) e.getCause();
                }
            }
        } finally {
            handleTaskEnd(ctx, taskInfo);
        }
    }
	
	public void handleTaskStart(ITaskContext context, TaskInfo taskInfo) throws Exception {

        int threads = taskInfo.numOfThreads();
        // タスクを処理するExecutor。スレッド名をline-worker-Xとする
        init(threads);
        AtomicInteger lines = new AtomicInteger(0);
        taskInfo.getTask().prepare(context);
        for (int i = 0; i < threads; i++) {
            workers.add(new Worker(context.copy(), taskInfo.getTask(), lines));
        }
    }
	
	public void handleTaskEnd(ITaskContext context, TaskInfo taskInfo) throws Exception {
        try {
            clear();
            taskInfo.getTask().reprocess(context);
        } finally {
        }
    }

	public void setContextFactory(IContextFactory contextFactory) {
		this.contextFactory = contextFactory;
	}

	public void setTasks(List<ITask<?>> tasks) throws SoftbankException {
		for (int i = 0; i < tasks.size(); i++) {
			TaskInfo taskInfo = new TaskInfo(tasks.get(i));
			TaskInfo preTaskInfo = null;
			if (this.taskList.size() > 0) {
				preTaskInfo = taskList.getLast();
				preTaskInfo.setNext(taskInfo);
			}
			taskInfo.setPre(preTaskInfo);
			taskList.addLast(taskInfo);
		}
	}

	public void setCollector(IOutputCollector<? extends Object> collector) {
		this.collector = collector;
	}

	@Override
	public boolean createWorkers() throws SoftbankException {
		return false;
	}

	@Override
	public IWorker createWorker() throws SoftbankException {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

}
