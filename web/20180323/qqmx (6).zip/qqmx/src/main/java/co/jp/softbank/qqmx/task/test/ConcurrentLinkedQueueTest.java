package co.jp.softbank.qqmx.task.test;

import java.util.concurrent.ConcurrentLinkedQueue;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.LinkedBlockingQueue;

public class ConcurrentLinkedQueueTest {
	
	private static ConcurrentLinkedQueue<Integer> queue = new ConcurrentLinkedQueue<Integer>();
//	private static LinkedBlockingQueue<Integer> queue = new LinkedBlockingQueue<Integer>();
	
	private static int count = 1000000;
	
	private static int threadCount = 4;
	
	private static CountDownLatch cd = new CountDownLatch(threadCount);
	
	public static void main(String[] args) throws InterruptedException {
		long timeStart = System.currentTimeMillis();
		for (int i = 0; i < count; i++) {
			queue.offer(i);
		}

		ExecutorService eService = Executors.newFixedThreadPool(4);
		Poll poll = new Poll();
		for (int i = 0; i < threadCount; i++) {
			eService.submit(poll);
		}
		cd.await();
		System.out.println("cost : " + (System.currentTimeMillis() - timeStart) + "ms");
		eService.shutdown();
	}
	
	public static class Poll implements Runnable {

		@Override
		public void run() {
			while (!queue.isEmpty()) {
				System.out.println(queue.poll());
			}
			cd.countDown();
		}
		
	}

}
