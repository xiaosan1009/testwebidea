package co.jp.softbank.qqmx.task.test;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.util.Iterator;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.math.NumberUtils;
import org.ho.yaml.Yaml;

import sun.misc.BASE64Decoder;
import sun.misc.BASE64Encoder;

public class TestYaml {

	public static void main(String[] args) throws UnsupportedEncodingException, IOException {
//		String aString = "--- \n \n\n- !binary |\n  5ZOB6LOq\n\n- !binary |\n  44Kz44K544OI\n\n- !binary |\n  5Yq55p6c\n\n- !binary |\n  44K544Kz44O844OX\n";
		String aString = "--- \n- !binary |\n  5Lq655qE44Oq44K944O844K55LiN6Laz\n\n- !binary |\n  5b+F6KaB44K544Kt44Or5LiN6Laz\n\n- !binary |\n  44K344K544OG44Og6ZaL55m65LiN6Laz\n\n- !binary |\n  5LqI566X5LiN6Laz\n\n- !binary |\n  5LuW6YOo6ZaA44Go44Gu5qiq5Liy6YCj5pC644Gr6LW35Zug44GZ44KL5YGc\n  5rue\n\n- !binary |\n  44Gd44Gu5LuWKOWCmeiAg+OBq+imgeiomOi8iSk=";
		String regexp = "^[-]?\\s*([\"\\w\\+\\=/\\.&-]+)";
		String regexp1 = "(?<=\\w)\\s+(?=\\w)";
		// ^[-]?\s*(["\w\+\=/\.&-]+)
//		String regexp = "^[-]?\\s*([\"\\w\\+\\=/\\.&]+[^-\\s]*[\"\\w\\+\\=/\\.&]+)";
		String bString = "JavaDoc数";
//		String cString = "--- \n- CAPEX\n- OPEX";
		String cString = "--- \n- SB\n- WCP";
		String dString = "--- \n- 04.PMO\n- 05.Package Construction Group\n- 06.Package Design Team\n- 07.Package Development Team\n- 08.Business Design Group\n- 09.Business Process Design Team\n- 10.User Interface Design Team\n- 11.Business Rule & Master Group\n- 13.Architecture\n- !binary |\n  MTQu56e76KGM44Kw44Or44O844OX\n\n- !binary |\n  MTUu6YGL55So44Kw44Or44O844OX\n\n- !binary |\n  MTYu6Kmm6aiT\n\n- 20.DataModel Group\n\n- !binary |\n  MjEu5ZOB6LOq566h55CG\n\n- !binary |\n  MjIu5YWx6YCa5qmf6IO9\n\n- !binary |\n  MjMu5paw5pen5aSJ5o+b\n\n- !binary |\n  MjQu44OB44Kn44OD44Kv\n\n- !binary |\n  MjUu5aSW6YOo5qWt5YuZ56qT5Y+j\n\n- 26.PG-Test\n- !binary |\n  Mjcu44OB44O844Og77yI44Kv44Or44O8VE9Q77yJ\n\n- !binary |\n  Mjgu44OB44O844Og77yI5Y+X5LuY54q25rOB54Wn5Lya77yJ\n\n- !binary |\n  Mjku44OB44O844Og77yI6aGn5a6i54Wn5Lya77yJ\n\n- !binary |\n  MzAu44OB44O844Og77yI6LKp5aOy77yI54mp6LKp77yJ77yJ\n\n- !binary |\n  MzEu44OB44O844Og77yI44Oi44OQ44Kk44Or44K15aSJ77yJ\n\n- !binary |\n  MzIu44OB44O844Og77yI44Oi44OQ44Kk44Or5qmf5aSJ77yJ\n\n- !binary |\n  MzMu44OB44O844Og77yIU0Ljgqvjg7zjg4nvvIk=\n\n- !binary |\n  MzQu44OB44O844Og77yIQkLosqnlo7LvvIhTQuWFie+8ie+8iQ==\n\n- !binary |\n  MzUu44OB44O844Og77yI6aGn5a6i5oOF5aCx5aSJ5pu077yJ\n\n- !binary |\n  MzYu44OB44O844Og77yI44Oi44OQ44Kk44Or6LKp5aOy77yJ\n\n- !binary |\n  Mzcu44OB44O844Og77yI44Gn44KT44GN6LKp5aOy77yJ\n\n- !binary |\n  Mzgu44OB44O844Og77yI6Kej57SE77yJ\n\n- !binary |\n  MzkuU3ByaW505a++5b+cLeOCteODs+ODl+ODq+OCouODl+ODqg==";
		String eString = "- !binary |\n  MTYu6Kmm6aiT\n\n- 20.DataModel Group\n";
		eString = eString.replaceAll(regexp1, "").replaceAll("\n\n", "\n");
//		System.out.println(eString);
		BASE64Decoder decoder = new BASE64Decoder();
		BASE64Encoder encoder = new BASE64Encoder();
		Pattern p = Pattern.compile(regexp, Pattern.MULTILINE);
		Matcher m = p.matcher(eString);
//		while(m.find()){
//			if (m.groupCount() > 0) {
//				String ticketId = m.group(1);
////				System.out.println(m.start());
////				System.out.println(m.end());
//				System.out.println(ticketId);
////				System.out.println(new String(decoder.decodeBuffer(ticketId), "UTF-8"));
//			}
//		}
		String encode = encoder.encodeBuffer(bString.getBytes("UTF-8"));
		System.out.println(encode);
//		System.out.println(new String(decoder.decodeBuffer(encode), "UTF-8"));
//		Yaml yaml = new Yaml();
//		List<String> statusYaml = (List<String>)yaml.load(aString);
//		for (int i = 0; i < statusYaml.size(); i++) {
//			try {
//				
//				System.out.println(new String(decoder.decodeBuffer(statusYaml.get(i)), "UTF-8"));
//			} catch (UnsupportedEncodingException e) {
//				// TODO 自動生成された catch ブロック
//				e.printStackTrace();
//			} catch (IOException e) {
//				// TODO 自動生成された catch ブロック
//				e.printStackTrace();
//			}
//		}
	}

}
