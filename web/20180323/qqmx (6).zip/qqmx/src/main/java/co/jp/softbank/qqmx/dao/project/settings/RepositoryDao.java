package co.jp.softbank.qqmx.dao.project.settings;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.dao.IDaoInterface;

public interface RepositoryDao extends IDaoInterface {
	List<Map<String, Object>> getRepositoriesList(Map<String, Object> conditions);
	List<Map<String, Object>> editRepositorie(Map<String, Object> conditions);
	void saveRepositorie(Map<String, Object> conditions);
	void deleteRepositorie(Map<String, Object> conditions);
	void updateRepositorie(Map<String, Object> conditions);
}
