package co.jp.softbank.qqmx.info.bean;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.info.bean.BacklogRefreshDataBean.BacklogRefreshDataType;
import co.jp.softbank.qqmx.util.CreateSequencesUtil;

public class BacklogRefreshBean {
	
	private List<BacklogRefreshDataBean> dataList;
	
	private Map<String, Integer> indexMap;
	
	public BacklogRefreshBean() {
		dataList = Lists.newArrayList();
		indexMap = Maps.newHashMap();
	}
	
	public synchronized void addData(BacklogRefreshDataBean bean) {
		createKeyMap(bean);
		dataList.add(bean);
	}

	private String createKeyMap(BacklogRefreshDataBean bean) {
		String key = CreateSequencesUtil.createID("BR");
		bean.setKey(key);
		indexMap.put(key, dataList.size());
		return key;
	}
	
	public synchronized String getLastKey() {
		if (dataList.size() == 0) {
			BacklogRefreshDataBean bean = new BacklogRefreshDataBean(BacklogRefreshDataType.def);
			return createKeyMap(bean);
		}
		return dataList.get(dataList.size() - 1).getKey();
	}
	
	public List<BacklogRefreshDataBean> getDatas(String key) {
		List<BacklogRefreshDataBean> result = Lists.newArrayList();
		if (!indexMap.containsKey(key)) {
			return null;
		}
		int index = indexMap.get(key);
		if (index >= dataList.size() - 1) {
			return null;
		}
		for (int i = index + 1; i < dataList.size(); i++) {
			result.add(dataList.get(i));
		}
		return result;
	}

}
