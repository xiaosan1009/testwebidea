package co.jp.softbank.qqmx.dao.project.settings;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.dao.IDaoInterface;

public interface TrackerListDao extends IDaoInterface {
	List<Map<String, Object>> getTrackerListInfo();
	List<Map<String, Object>> getTrackerListIdInfo(Map<String, Object> conditions);
	List<Map<String, Object>> selectRoles();
	List<Map<String, Object>> getTrackerListCustomFields(Map<String, Object> conditions);
	List<Map<String, Object>> getTrackerListProjects(Map<String, Object> conditions);
	List<Map<String, Object>> getUpdateTrackers(Map<String, Object> conditions);
	
	
	
	
	void delTrackerListId(Map<String, Object> conditions);
	void insertTrackers(Map<String, Object> conditions);
	void insertProjectsTrackers(Map<String, Object> conditions);
	void insertCustomFieldsTrackers(Map<String, Object> conditions);
	void deleteWorkflows(Map<String, Object> conditions);
	void inserWorkflows(Map<String, Object> conditions);
	void delWorkflows(Map<String, Object> conditions);
	void updataTrackers(Map<String, Object> conditions);
	void delCustomFieldsTrackers(Map<String, Object> conditions);
	void delProjectsTrackers(Map<String, Object> conditions);
	void updateTrackers(Map<String, Object> conditions);
	void upCommonMSort(Map<String, Object> conditions);
	void upCommonPSort(Map<String, Object> conditions);
	void upCommonSort(Map<String, Object> conditions);

}
