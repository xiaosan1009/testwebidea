package co.jp.softbank.qqmx.info.face;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.ExcelInfoBean;
import co.jp.softbank.qqmx.info.bean.ExcelInfoBean.DiffAnalizy;

public interface IExcelReader {
	
	ExcelInfoBean getSheetInfos() throws SoftbankException;
	
	ExcelInfoBean getSheetFirstRowInfos(String sheetName) throws SoftbankException;
	
	ExcelInfoBean getSheetFirstRowInfos(String sheetName, DiffAnalizy diff, int headerRow) throws SoftbankException;
	
	ExcelInfoBean getSheetFirstRowInfos(int sheetIndex, DiffAnalizy diff, int headerRow) throws SoftbankException;
	
	ExcelInfoBean getAllCellInfos(String sheetName) throws SoftbankException;
	
	ExcelInfoBean getAllCellInfos(String sheetName, boolean referFirst, int startRow) throws SoftbankException;
	
	ExcelInfoBean getAllCellInfos(int sheetIndex, boolean referFirst, int startRow) throws SoftbankException;

}
