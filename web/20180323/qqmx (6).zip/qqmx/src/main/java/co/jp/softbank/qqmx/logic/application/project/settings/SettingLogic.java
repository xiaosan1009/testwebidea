package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import org.ho.yaml.Yaml;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.dao.common.bean.PluginInfoBean;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.ControlDbMemory;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.util.StringUtils;

public class SettingLogic extends AbstractBaseLogic {

//	@Autowired
//	private setting setting;

	public LogicBean getSettingsInfo() throws SoftbankException {
		LogicBean statuseBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		String nameValue = context.getParam().get("name");
		
		conditions.put("name", nameValue);
		statuseBean.setData(db.querys("setting.getSettingsInfo", conditions));
		return statuseBean;
	}
	public LogicBean getProjectEnabledScmInfos() throws SoftbankException {
		LogicBean statuseBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		String nameValue = context.getParam().get("enabled_scm");
		
		conditions.put("name", nameValue);
		statuseBean.setData(db.querys("setting.getProjectEnabledScmInfos", conditions));
		return statuseBean;
	}
	
	public LogicBean getProjectPluginInfos() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		List<Map<String, Object>> settingsList = db.querys("setting.getSettings");
		Map<String, Object> settingsData = settingsList.get(0);
		String settingsValue = StringUtils.toString(settingsData.get("value"));
		Yaml yaml = new Yaml();
		List<String> settingsList2 = (List<String>)yaml.load(settingsValue);
		Map<String, String> settingsMap = Maps.newHashMap();
		for (int i = 0; i < settingsList2.size(); i++) {
			settingsMap.put(settingsList2.get(i), settingsList2.get(i));
		}
		resultMap.put("settings", settingsMap);
		resultMap.put("plugins", ControlDbMemory.getInstance().getPluginInfoBeans());
		logicBean.setData(resultMap);
		return logicBean;
	}
	
	public LogicBean getProjectCustomFieldsInfos() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		List<Map<String, Object>> issueListDefaultColumns = db.querys("setting.getIssueListDefaultColumns");
		Map<String, Object> issueListDefaultColumnsData = issueListDefaultColumns.get(0);
		String issueListDefaultColumnsValue = StringUtils.toString(issueListDefaultColumnsData.get("value"));
		Yaml yaml = new Yaml();
		List<String> issueListDefaultColumnsValueList2 = (List<String>)yaml.load(issueListDefaultColumnsValue);
		Map<String, String> issueListDefaultColumnsValueMap = Maps.newHashMap();
		for (int i = 0; i < issueListDefaultColumnsValueList2.size(); i++) {
			issueListDefaultColumnsValueMap.put(issueListDefaultColumnsValueList2.get(i), issueListDefaultColumnsValueList2.get(i));
		}
		
		List<PluginInfoBean> pluginInfoBeanList = Lists.newArrayList(); 

		PluginInfoBean project = pluginInfoSet("project", "プロジェクト");
		pluginInfoBeanList.add(project);
		PluginInfoBean tracker = pluginInfoSet("tracker", "トラッカー");
		pluginInfoBeanList.add(tracker);
		PluginInfoBean parent = pluginInfoSet("parent", "親チケット");
		pluginInfoBeanList.add(parent);
		PluginInfoBean status = pluginInfoSet("status", "ステータス");
		pluginInfoBeanList.add(status);
		PluginInfoBean priority = pluginInfoSet("priority", "優先度");
		pluginInfoBeanList.add(priority);
		PluginInfoBean subject = pluginInfoSet("subject", "題名");
		pluginInfoBeanList.add(subject);
		PluginInfoBean description = pluginInfoSet("description", "説明");
		pluginInfoBeanList.add(description);
		PluginInfoBean author = pluginInfoSet("author", "作成者");
		pluginInfoBeanList.add(author);
		PluginInfoBean assigned_to = pluginInfoSet("assigned_to", "担当者");
		pluginInfoBeanList.add(assigned_to);
		PluginInfoBean updated_on = pluginInfoSet("updated_on", "更新日");
		pluginInfoBeanList.add(updated_on);
		PluginInfoBean category = pluginInfoSet("category", "カテゴリ");
		pluginInfoBeanList.add(category);
		PluginInfoBean fixed_version = pluginInfoSet("fixed_version", "対象バージョン");
		pluginInfoBeanList.add(fixed_version);
		PluginInfoBean organization_name = pluginInfoSet("organization_name", "組織");
		pluginInfoBeanList.add(organization_name);
		PluginInfoBean start_date = pluginInfoSet("start_date", "開始日");
		pluginInfoBeanList.add(start_date);
		PluginInfoBean due_date = pluginInfoSet("due_date", "期日");
		pluginInfoBeanList.add(due_date);
		PluginInfoBean estimated_hours = pluginInfoSet("estimated_hours", "予定工数");
		pluginInfoBeanList.add(estimated_hours);
		PluginInfoBean spent_hours = pluginInfoSet("spent_hours", "作業時間の記録");
		pluginInfoBeanList.add(spent_hours);
		PluginInfoBean done_ratio = pluginInfoSet("done_ratio", "進捗 %");
		pluginInfoBeanList.add(done_ratio);
		PluginInfoBean created_on = pluginInfoSet("created_on", "作成日");
		pluginInfoBeanList.add(created_on);
		PluginInfoBean story_points = pluginInfoSet("story_points", "ストーリーポイント");
		pluginInfoBeanList.add(story_points);
		PluginInfoBean velocity_based_estimate = pluginInfoSet("velocity_based_estimate", "残り時間に基づくベロシティ");
		pluginInfoBeanList.add(velocity_based_estimate);
		PluginInfoBean position = pluginInfoSet("position", "Position");
		pluginInfoBeanList.add(position);
		PluginInfoBean remaining_hours = pluginInfoSet("remaining_hours", "残り時間");
		pluginInfoBeanList.add(remaining_hours);

		List<Map<String, Object>> customFieldsList = db.querys("setting.getCustomFieldsList");
		for (int j = 0; j < customFieldsList.size(); j++) {
			PluginInfoBean pluginInfoBean = new PluginInfoBean();
			pluginInfoBean.setValue("cf_" + customFieldsList.get(j).get("id"));
			pluginInfoBean.setName(String.valueOf(customFieldsList.get(j).get("name")));
			pluginInfoBeanList.add(pluginInfoBean);
		}
		
		resultMap.put("issueListDefaultColumns", issueListDefaultColumnsValueMap);
		resultMap.put("customFields", pluginInfoBeanList);
		logicBean.setData(resultMap);
		return logicBean;
	}
	
	public LogicBean getProjectNotificationOptionInfos() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		List<Map<String, Object>> noListDefaultColumns = db.querys("setting.getProjectNotificationOptionInfos");
		Map<String, Object> noListDefaultColumnsData = noListDefaultColumns.get(0);
		String noListDefaultColumnsValue = StringUtils.toString(noListDefaultColumnsData.get("value"));
		Yaml yaml = new Yaml();
		List<String> noDefaultColumnsValueList2 = (List<String>)yaml.load(noListDefaultColumnsValue);
		Map<String, String> noListDefaultColumnsValueMap = Maps.newHashMap();
		for (int i = 0; i < noDefaultColumnsValueList2.size(); i++) {
			noListDefaultColumnsValueMap.put(noDefaultColumnsValueList2.get(i), noDefaultColumnsValueList2.get(i));
		}
		
		List<PluginInfoBean> pluginInfoBeanList = Lists.newArrayList(); 
		
		PluginInfoBean issue_added = pluginInfoSet("issue_added", "チケットが追加されました");
		pluginInfoBeanList.add(issue_added);
		PluginInfoBean issue_updated = pluginInfoSet("issue_updated", "チケットが更新されました");
		pluginInfoBeanList.add(issue_updated);
		PluginInfoBean issue_note_added = pluginInfoSet("issue_note_added", "注記が追加されました");
		pluginInfoBeanList.add(issue_note_added);
		PluginInfoBean issue_status_updated = pluginInfoSet("issue_status_updated", "ステータスが更新されました");
		pluginInfoBeanList.add(issue_status_updated);
		PluginInfoBean issue_priority_updated = pluginInfoSet("issue_priority_updated", "影響度が更新されました");
		pluginInfoBeanList.add(issue_priority_updated);
		PluginInfoBean news_added = pluginInfoSet("news_added", "ニュースが追加されました");
		pluginInfoBeanList.add(news_added);
		PluginInfoBean news_comment_added = pluginInfoSet("news_comment_added", "ニュースにコメントが追加されました");
		pluginInfoBeanList.add(news_comment_added);
		PluginInfoBean document_added = pluginInfoSet("document_added", "文書が追加されました");
		pluginInfoBeanList.add(document_added);
		PluginInfoBean file_added = pluginInfoSet("file_added", "ファイルが追加されました");
		pluginInfoBeanList.add(file_added);
		PluginInfoBean message_posted = pluginInfoSet("message_posted", "メッセージが追加されました");
		pluginInfoBeanList.add(message_posted);
		PluginInfoBean wiki_content_added = pluginInfoSet("wiki_content_added", "Wikiページが追加されました");
		pluginInfoBeanList.add(wiki_content_added);
		PluginInfoBean wiki_content_updated = pluginInfoSet("wiki_content_updated", "Wikiページが更新されました");
		pluginInfoBeanList.add(wiki_content_updated);
		PluginInfoBean wiki_comment_added = pluginInfoSet("wiki_comment_added", "Wikiコメントが追加されました");
		pluginInfoBeanList.add(wiki_comment_added);
		
		resultMap.put("noDefaultColumns", noListDefaultColumnsValueMap);
		resultMap.put("noValue", pluginInfoBeanList);
		logicBean.setData(resultMap);
		return logicBean;
	}
	public LogicBean getProjectRolesInfos() throws SoftbankException {
		LogicBean statuseBean = new LogicBean();
		statuseBean.setData(db.update("setting.getProjectRolesInfos"));
		return statuseBean;
	}
	public LogicBean getProjectIssueStatusesInfos() throws SoftbankException {
		LogicBean statuseBean = new LogicBean();
		statuseBean.setData(db.update("setting.getProjectIssueStatusesInfos"));
		return statuseBean;
	}
	public LogicBean getProjectEnumerationsInfos() throws SoftbankException {
		LogicBean statuseBean = new LogicBean();
		statuseBean.setData(db.update("setting.getProjectEnumerationsInfos"));
		return statuseBean;
	}
	public void saveSettingInfos() throws SoftbankException {
		String flg = context.getParam().get("flgId");
		// 全般
		if ("setting-tab-general".equals(flg)){
			String	settings_app_title = context.getParam().get("settings_app_title");
			String	settings_welcome_text = context.getParam().get("settings_welcome_text");
			String	settings_attachment_max_size = context.getParam().get("settings_attachment_max_size");
			String	settings_per_page_options = context.getParam().get("settings_per_page_options");
			String	settings_activity_days_default = context.getParam().get("settings_activity_days_default");
			String	settings_host_name = context.getParam().get("settings_host_name");
			String	settings_protocol = context.getParam().get("settings_protocol");
			String	settings_text_formatting = context.getParam().get("settings_text_formatting");
			String settings_cache_formatted_text = StringUtils.isNotEmpty(context.getParam().get(
					"settings_cache_formatted_text")) ? context.getParam().get("settings_cache_formatted_text") : "0";			
			String	settings_wiki_compression = context.getParam().get("settings_wiki_compression");
			String	settings_feeds_limit = context.getParam().get("settings_feeds_limit");
			String	settings_file_max_size_displayed = context.getParam().get("settings_file_max_size_displayed");
			String	settings_diff_max_lines_displayed = context.getParam().get("settings_diff_max_lines_displayed");
			
			updataSettings(settings_app_title, "app_title");
			updataSettings(settings_welcome_text, "welcome_text_2");
			updataSettings(settings_attachment_max_size, "attachment_max_size");
			updataSettings(settings_per_page_options, "per_page_options");
			updataSettings(settings_activity_days_default, "activity_days_default");
			updataSettings(settings_host_name, "host_name");
			updataSettings(settings_protocol, "protocol");
			updataSettings(settings_text_formatting, "text_formatting");
			updataSettings(settings_cache_formatted_text, "cache_formatted_text");
			updataSettings(settings_wiki_compression, "wiki_compression");
			updataSettings(settings_feeds_limit, "feeds_limit");
			updataSettings(settings_file_max_size_displayed, "file_max_size_displayed");
			updataSettings(settings_diff_max_lines_displayed, "diff_max_lines_displayed");
			
		// 表示	
		}else if ("setting-tab-display".equals(flg)){
			String	settings_ui_theme = context.getParam().get("settings_ui_theme");
			String	settings_default_language = context.getParam().get("settings_default_language");
			String	settings_start_of_week = context.getParam().get("settings_start_of_week");
			String	settings_date_format = context.getParam().get("settings_date_format");
			String	settings_time_format = context.getParam().get("settings_time_format");
			String	settings_user_format = context.getParam().get("settings_user_format");
			String settings_gravatar_enabled = StringUtils.isNotEmpty(context.getParam().get(
					"settings_gravatar_enabled")) ? context.getParam().get("settings_gravatar_enabled") : "0";
			String	settings_gravatar_default = context.getParam().get("settings_gravatar_default");
					
			updataSettings(settings_ui_theme, "ui_theme");
			updataSettings(settings_default_language, "default_language");
			updataSettings(settings_start_of_week, "start_of_week");
			updataSettings(settings_date_format, "date_format");
			updataSettings(settings_time_format, "time_format");
			updataSettings(settings_user_format, "user_format");
			updataSettings(settings_gravatar_enabled, "gravatar_enabled");
			updataSettings(settings_gravatar_default, "gravatar_default");
			
		// 	認証
		}else if ("setting-tab-authentication".equals(flg)){
			String settings_login_required = StringUtils.isNotEmpty(context.getParam().get(
					"settings_login_required")) ? context.getParam().get("settings_login_required") : "0";
			String	settings_autologin = context.getParam().get("settings_autologin");
			String	settings_self_registration = context.getParam().get("settings_self_registration");
			String	settings_password_min_length = context.getParam().get("settings_password_min_length");
			String	settings_lost_password = StringUtils.isNotEmpty(context.getParam().get(
					"settings_lost_password")) ? context.getParam().get("settings_lost_password") : "0";
			String	settings_openid = StringUtils.isNotEmpty(context.getParam().get(
					"settings_openid")) ? context.getParam().get("settings_openid") : "0";
			String	settings_rest_api_enabled = StringUtils.isNotEmpty(context.getParam().get(
					"settings_rest_api_enabled")) ? context.getParam().get("settings_rest_api_enabled") : "0";
			
			updataSettings(settings_login_required, "login_required");
			updataSettings(settings_autologin, "autologin");
			updataSettings(settings_self_registration, "self_registration");
			updataSettings(settings_password_min_length, "password_min_length");
			updataSettings(settings_lost_password, "lost_password");
			updataSettings(settings_openid, "openid");
			updataSettings(settings_rest_api_enabled, "rest_api_enabled");
			
		}else if ("setting-tab-projects".equals(flg)){
			String	settings_new_project_user_role_id = context.getParam().get("settings_new_project_user_role_id");
			String[] settings_default_projects_modules = context.getParam().getList("settings_default_projects_modules");
			
			List<String> permissionsList = Lists.newArrayList(); 
			if (settings_default_projects_modules != null){
				for (int p = 0; p < settings_default_projects_modules.length; p++) {
					String strPermission = settings_default_projects_modules[p];
					permissionsList.add(strPermission);
				}
			}
			updataSettings(settings_new_project_user_role_id, "new_project_user_role_id");
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("name", "default_projects_modules");
			conditions.put("value", Yaml.dump(permissionsList));
			db.update("setting.updataSettings", conditions);
			
		}else if ("setting-tab-issues".equals(flg)){
			String	settings_cross_project_issue_relations = context.getParam().get("settings_cross_project_issue_relations");
			String	settings_issue_group_assignment = context.getParam().get("settings_issue_group_assignment");
			String	settings_display_subprojects_issues = context.getParam().get("settings_display_subprojects_issues");
			String	settings_issue_done_ratio = context.getParam().get("settings_issue_done_ratio");
			String	settings_issues_export_limit = context.getParam().get("settings_issues_export_limit");
			String[] settings_issue_list_default_columns = context.getParam().getList("settings_issue_list_default_columns");
			updataSettings(settings_cross_project_issue_relations, "cross_project_issue_relations");
			updataSettings(settings_issue_group_assignment, "issue_group_assignment");
			updataSettings(settings_display_subprojects_issues, "display_subprojects_issues");
			updataSettings(settings_issue_done_ratio, "issue_done_ratio");
			updataSettings(settings_issues_export_limit, "issues_export_limit");
			List<String> permissionsList = Lists.newArrayList(); 
			if (settings_issue_list_default_columns != null){
				for (int p = 0; p < settings_issue_list_default_columns.length; p++) {
					String strPermission = settings_issue_list_default_columns[p];
					permissionsList.add(strPermission);
				}
			}
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("name", "issue_list_default_columns");
			conditions.put("value", Yaml.dump(permissionsList));
			db.update("setting.updataSettings", conditions);
		
		// メール通知 
		}else if ("setting-tab-notifications".equals(flg)){
			String	settings_mail_from = context.getParam().get("settings_mail_from");
			
			String	settings_bcc_recipients = StringUtils.isNotEmpty(context.getParam().get(
					"settings_bcc_recipients")) ? context.getParam().get("settings_bcc_recipients") : "0";
			String	settings_plain_text_mail = StringUtils.isNotEmpty(context.getParam().get(
					"settings_plain_text_mail")) ? context.getParam().get("settings_plain_text_mail") : "0";		
			String	settings_default_notification_option = context.getParam().get("settings_default_notification_option");
			String	settings_emails_header = context.getParam().get("settings_emails_header");
			String	settings_emails_footer = context.getParam().get("settings_emails_footer");
			
			String[] settings_notified_events = context.getParam().getList("settings_notified_selected");
			
			updataSettings(settings_mail_from, "mail_from");
			updataSettings(settings_bcc_recipients, "bcc_recipients");
			updataSettings(settings_plain_text_mail, "plain_text_mail");
			updataSettings(settings_default_notification_option, "default_notification_option");
			updataSettings(settings_emails_header, "emails_header");
			updataSettings(settings_emails_footer, "emails_footer");
			List<String> permissionsList = Lists.newArrayList(); 
			if (settings_notified_events != null){
				for (int p = 0; p < settings_notified_events.length; p++) {
					String strPermission = settings_notified_events[p];
					permissionsList.add(strPermission);
				}
			}
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("name", "notified_events");
			conditions.put("value", Yaml.dump(permissionsList));
			db.update("setting.updataSettings", conditions);
		}else if ("setting-tab-repositories".equals(flg)){
			String	settings_autofetch_changesets = context.getParam().get("settings_autofetch_changesets");
			String	settings_sys_api_enabled = context.getParam().get("settings_sys_api_enabled");
			String	settings_sys_api_key = context.getParam().get("settings_sys_api_key");
			String	settings_repositories_encodings = context.getParam().get("settings_repositories_encodings");
			String	settings_repository_log_display_limit = context.getParam().get("settings_repository_log_display_limit");
			String	settings_commit_ref_keywords = context.getParam().get("settings_commit_ref_keywords");
			String	settings_commit_fix_keywords = context.getParam().get("settings_commit_fix_keywords");
			String	settings_commit_fix_status_id = context.getParam().get("settings_commit_fix_status_id");
			String	settings_commit_fix_done_ratio = context.getParam().get("settings_commit_fix_done_ratio");
			String	settings_commit_logtime_enabled = context.getParam().get("settings_commit_logtime_enabled");
			String	settings_commit_logtime_activity_id = context.getParam().get("settings_commit_logtime_activity_id");
			String	settings_git = context.getParam().get("git");
			String	settings_subversion = context.getParam().get("subversion");
			updataSettings(settings_autofetch_changesets, "autofetch_changesets");
			updataSettings(settings_sys_api_enabled, "sys_api_enabled");
			updataSettings(settings_sys_api_key, "sys_api_key");
			updataSettings(settings_repositories_encodings, "repositories_encodings");
			updataSettings(settings_repository_log_display_limit, "repository_log_display_limit");
			updataSettings(settings_commit_ref_keywords, "commit_ref_keywords");
			updataSettings(settings_commit_fix_keywords, "commit_fix_keywords");
			updataSettings(settings_commit_fix_status_id, "commit_fix_status_id");
			updataSettings(settings_commit_fix_done_ratio, "commit_fix_done_ratio");
			updataSettings(settings_commit_logtime_enabled, "commit_logtime_enabled");
			updataSettings(settings_commit_logtime_activity_id, "commit_logtime_activity_id");
			List<String> permissionsList = Lists.newArrayList(); 
			permissionsList.add(settings_git);
			permissionsList.add(settings_subversion);
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("name", "enabled_scm");
			conditions.put("value", Yaml.dump(permissionsList));
			db.update("setting.updataSettings", conditions);
		}
	}
	public PluginInfoBean pluginInfoSet(String value, String name) throws SoftbankException {
		PluginInfoBean pluginInfoBean = new PluginInfoBean();
		pluginInfoBean.setValue(value);
		pluginInfoBean.setName(name);
		return pluginInfoBean;
	}
	public void updataSettings(String value, String name) throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("name", name);
		conditions.put("value", value);
		db.update("setting.updataSettings",conditions);
	}
}
