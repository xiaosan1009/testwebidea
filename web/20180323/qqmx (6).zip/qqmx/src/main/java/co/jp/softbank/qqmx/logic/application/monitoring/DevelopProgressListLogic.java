package co.jp.softbank.qqmx.logic.application.monitoring;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.PageListBean;
import net.sf.json.JSONArray;

public class DevelopProgressListLogic extends AbstractBaseLogic {

	public void getSourceScale() throws SoftbankException {
		Map<String, Object> conditions = select();
		
		List<Map<String, Object>> sourceScaleInfo = new ArrayList<Map<String, Object>>();
		
		if (conditions.get("projectId") == null || "".equals(conditions.get("projectId").toString())) {
			sourceScaleInfo = infoEdit(sourceScaleInfo);
		} else {
			sourceScaleInfo = db.querys("developProgress.getSourceScale", conditions);
			
			if ("0".equals(sourceScaleInfo.get(0).get("days_sum").toString())){
				sourceScaleInfo = infoEdit(sourceScaleInfo);
			}
		}
		
		context.getResultBean().setData(sourceScaleInfo);
	}
	
	public void getSourceScaleList() throws SoftbankException, ParseException {
		Map<String, Object> conditions = select();
		
		if (conditions.get("projectId") == null || "".equals(conditions.get("projectId").toString())) {
			return;
		}
		
		List<Map<String, Object>> sourceScaleInfoList = new ArrayList<Map<String, Object>>();
		PageListBean pageListBean = null;
		
		String flg = context.getParam().get("flg");
		if ("1".equals(flg)) {
			String monitoring_List_data = context.getParam().get("monitoring_List_data");
			if(!"[]".equals(monitoring_List_data) && !"".equals(monitoring_List_data) ){
				JSONArray array = JSONArray.fromObject(monitoring_List_data); 
				for(int i = 0;i<array.size();i++){
					if(array.get(i).toString().equals("user")){
						conditions.put("userKey","userKey");
					}else if(array.get(i).toString().equals("system1")){
						conditions.put("systemKey","systemKey");
					}else if(array.get(i).toString().equals("version")){
						conditions.put("versionKey","versionKey");
					}
				}
				sourceScaleInfoList = db.querys("developProgress.getListByPOP", conditions);
			}else{
				sourceScaleInfoList = db.querys("developProgress.getSourceScaleList", conditions);
			}
		}else{
			String monitoring_List_data = context.getParam().get("monitoring_List_data");
			if(!"[]".equals(monitoring_List_data) && !"".equals(monitoring_List_data) ){
				JSONArray array = JSONArray.fromObject(monitoring_List_data); 
				for(int i = 0;i<array.size();i++){
					if(array.get(i).toString().equals("user")){
						conditions.put("userKey","userKey");
					}else if(array.get(i).toString().equals("system1")){
						conditions.put("systemKey","systemKey");
					}else if(array.get(i).toString().equals("version")){
						conditions.put("versionKey","versionKey");
					}
				}
				pageListBean = pageList("developProgress.getListByPOP", conditions);
			}else{
				pageListBean = pageList("developProgress.getSourceScaleList", conditions);
			}
			sourceScaleInfoList = pageListBean.getDatas();
		}

		for (int i = 0; i < sourceScaleInfoList.size(); i ++) {
			//遅れ原因
			String delay_reason = "";
			Integer plan_days = Integer.valueOf(sourceScaleInfoList.get(i).get("plan_days").toString());
			if(plan_days > 0){
				delay_reason = "スケジュール着手遅れ";
			}
			
			Integer delay_ratio = Integer.valueOf(sourceScaleInfoList.get(i).get("delay_ratio").toString());
			if(delay_ratio >= 20 ){
				if(delay_reason.length() == 0){
					delay_reason = "生産性悪い";
				}else{
					delay_reason = delay_reason + "</br>" + "生産性悪い";
				}
			}
			conditions = Maps.newHashMap();
			if(sourceScaleInfoList.get(i).get("assigned_to_id")!=null && sourceScaleInfoList.get(i).get("assigned_to_id").toString().length() != 0){
				Integer assigned_to_id = Integer.valueOf(sourceScaleInfoList.get(i).get("assigned_to_id").toString());
				conditions.put("authorId", assigned_to_id);
				conditions.put("issue_id", sourceScaleInfoList.get(i).get("ticket_id"));
				SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd");
				try {
					conditions.put("start_date", sdf.parse(sourceScaleInfoList.get(i).get("start_date0").toString()));
					conditions.put("due_date", sdf.parse(sourceScaleInfoList.get(i).get("due_date0").toString()));
				} catch (ParseException e) {
					e.printStackTrace();
				}
				
				// TODO 10281
				Map<String, Object> map = db.query("deliverables.getHoursByDay", conditions);
				if(map != null){
					Double d = (Double)map.get("hours");
					if(d > 9.6){
						if(delay_reason.length() == 0){
							delay_reason = "工数不足";
						}else{
							delay_reason = delay_reason + "</br>" + "工数不足";
						}
					}
				}
			}
			
			sourceScaleInfoList.get(i).put("delay_reason", delay_reason);
		}
		flg = context.getParam().get("flg");
		if ("1".equals(flg)) {
			context.getResultBean().setData(sourceScaleInfoList);
		}else{
			context.getResultBean().setData(pageListBean);
		}
	}
	
	public void getScaleProgress() throws SoftbankException {
		Map<String, Object> conditions = select();
		
		if (conditions.get("projectId") == null || "".equals(conditions.get("projectId").toString())) {
			return;
		}
		
		List<Map<String, Object>> scaleProgress = db.querys("developProgress.getScaleProgress", conditions);
		
		context.getResultBean().setData(scaleProgress);
	}
	
	public void getEfficiencyProgress() throws SoftbankException {
		Map<String, Object> conditions = select();
		
		if (conditions.get("projectId") == null || "".equals(conditions.get("projectId").toString())) {
			return;
		}
		
		List<Map<String, Object>> ticketIdList = db.querys("developProgress.getTicketIds", conditions);
		
		List<Map<String, Object>> dateList = db.querys("developProgress.getDateList", conditions);
		
		List<Map<String, Object>> efficiencyProgress = db.querys("developProgress.getEfficiencyProgress", conditions);
		
		List<List<Map<String, Object>>> efficiencyProgressList = new ArrayList<List<Map<String, Object>>>();

		for (int i = 0; i < ticketIdList.size(); i++) {
			String ticket_id = ticketIdList.get(i).get("ticket_id").toString();
			boolean ticket_id_flg = false;
			for (int k = 0; k < efficiencyProgress.size(); k++) {
				String ticket_id_info = efficiencyProgress.get(k).get("ticket_id").toString();
				if (ticket_id.equals(ticket_id_info)) {
					ticket_id_flg = true;
				}
			}
			if (!ticket_id_flg) {
				continue;
			}
			
			List<Map<String, Object>> efficiencyProgressByTicket = new ArrayList<Map<String, Object>>();
			
			for (int j = 0; j < dateList.size(); j ++) {
				String count_date = dateList.get(j).get("count_date").toString();
				
				boolean f = false;
				for (int m = 0; m < efficiencyProgress.size(); m++) {
					String ticket_id_info = efficiencyProgress.get(m).get("ticket_id").toString();
					String count_date_info = efficiencyProgress.get(m).get("count_date").toString();
					
					if (ticket_id.equals(ticket_id_info) && count_date.equals(count_date_info)) {
						Map<String, Object> info = Maps.newHashMap();
						info.put("ticket_id", ticket_id);
						info.put("count_date", count_date);
						info.put("subject", ticketIdList.get(i).get("subject"));
						info.put("efficiency", Integer.valueOf(efficiencyProgress.get(m).get("efficiency").toString()));
						
						efficiencyProgressByTicket.add(info);
						
						f = true;
					}
				}
				
				if (!f) {
					Map<String, Object> info = Maps.newHashMap();
					info.put("ticket_id", ticket_id);
					info.put("count_date", count_date);
					info.put("subject", ticketIdList.get(i).get("subject"));
					
					if (efficiencyProgressByTicket.size() == 0) {
						info.put("efficiency", 0);
					} else {
						info.put("efficiency", efficiencyProgressByTicket.get(efficiencyProgressByTicket.size() - 1).get("efficiency"));
					}
					
					efficiencyProgressByTicket.add(info);
				}
				
			}

			efficiencyProgressList.add(efficiencyProgressByTicket);
		}
		
		context.getResultBean().setData(efficiencyProgressList);
	}
	
	public void getTypeProgress() throws SoftbankException {
		Map<String, Object> conditions = select();
		
		if (conditions.get("projectId") == null || "".equals(conditions.get("projectId").toString())) {
			return;
		}
		
		List<Map<String, Object>> typeProgress = db.querys("developProgress.getTypeProgress", conditions);
		
		context.getResultBean().setData(typeProgress);
	}
	
	public void getSystemList() throws SoftbankException{
		Map<String, Object> conditions = select();
		
		if (conditions.get("projectId") == null || "".equals(conditions.get("projectId").toString())) {
			return;
		}
		
		List<Map<String, Object>> info = new ArrayList<Map<String, Object>>();
		
		info = db.querys("developProgress.getSourceScale", conditions);
		
		if ("0".equals(info.get(0).get("days_sum").toString())){
			info = infoEdit(info);
		}

		List<Map<String, Object>> systemList = db.querys("deliverables.getSystemList", conditions);

		List<Map<String, Object>> versionList = db.querys("deliverables.getVersionList", conditions);

		List<Map<String, Object>> authorList = db.querys("deliverables.getAuthorList", conditions);

		List<Map<String, Object>> documentList = db.querys("developProgress.getTicketIds", conditions);
		
		Map<String, Object> listMap = Maps.newHashMap();
		listMap.put("systemList", systemList);
		listMap.put("versionList", versionList);
		listMap.put("authorList", authorList);
		listMap.put("documentList", documentList);
		listMap.put("info", info);
		
		context.getResultBean().setData(listMap);
	}
	
	public List<Map<String, Object>> infoEdit(List<Map<String, Object>> info){
		if (info.size() == 0 ) {
			Map<String, Object> item = Maps.newHashMap();
			item.put("start_date1", "");
			item.put("end_date1", "");
			item.put("start_date2", "");
			item.put("end_date2", "");
			item.put("add_line_sum", "");
			item.put("divert_source_sum", "");
			item.put("mod_line_sum", "");
			item.put("del_line_sum", "");
			item.put("days_sum", "");
			item.put("efficiency_sum", "");
			
			info.add(item);
		} else {
			info.get(0).put("start_date1", "");
			info.get(0).put("end_date1", "");
			info.get(0).put("start_date2", "");
			info.get(0).put("end_date2", "");
			info.get(0).put("add_line_sum", "");
			info.get(0).put("divert_source_sum", "");
			info.get(0).put("mod_line_sum", "");
			info.get(0).put("del_line_sum", "");
			info.get(0).put("days_sum", "");
			info.get(0).put("efficiency_sum", "");
		}

		return info;
	}
	
	public Map<String, Object> select(){
		
		Map<String, Object> conditions = Maps.newHashMap();
		
		String projectId = context.getParam().get("projectId");
		String systemId = context.getParam().get("systemId");
		String versionId = context.getParam().get("versionId");
		String authorId = context.getParam().get("authorId");
		String documentId = context.getParam().get("documentId");
		
		if(!"".equals(versionId)){
			conditions.put("versionId", Integer.parseInt(versionId));
		}
		if(!"".equals(authorId)){
			conditions.put("authorId", Integer.parseInt(authorId));
		}
		if(!"".equals(systemId)){
			conditions.put("systemId", systemId);
		}
		if (!"".equals(projectId)){
			conditions.put("projectId", Integer.parseInt(projectId));
		}
		if (!"".equals(documentId)){
			conditions.put("documentId", Integer.parseInt(documentId));
		}

		return conditions;
	}
	

}
