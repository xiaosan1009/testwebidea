package co.jp.softbank.qqmx.info;

import java.util.List;
import java.util.concurrent.ConcurrentHashMap;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.BacklogRefreshBean;
import co.jp.softbank.qqmx.info.bean.BacklogRefreshDataBean;

public class BacklogRefreshMemory {
	
	private static BacklogRefreshMemory me;
	
	private ConcurrentHashMap<Integer, BacklogRefreshBean> projectMap;
	
	private BacklogRefreshMemory() throws SoftbankException {
		super();
		projectMap = new ConcurrentHashMap<Integer, BacklogRefreshBean>();
	}
	
	public static BacklogRefreshMemory getInstance() throws SoftbankException {
		synchronized (BacklogRefreshMemory.class) {
			if (me == null) {
				me = new BacklogRefreshMemory();
			}
		}
		return me;
	}
	
	public void addData(int projectId, BacklogRefreshDataBean bean) {
		projectMap.putIfAbsent(projectId, new BacklogRefreshBean());
		projectMap.get(projectId).addData(bean);
	}
	
	public String getLastKey(int projectId) {
		projectMap.putIfAbsent(projectId, new BacklogRefreshBean());
		return projectMap.get(projectId).getLastKey();
	}
	
	public List<BacklogRefreshDataBean> getDatas(int projectId, String key) {
		if (!projectMap.containsKey(projectId)) {
			return null;
		}
		return projectMap.get(projectId).getDatas(key);
	}

}
