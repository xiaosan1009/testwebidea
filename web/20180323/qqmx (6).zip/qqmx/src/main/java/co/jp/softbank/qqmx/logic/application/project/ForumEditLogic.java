package co.jp.softbank.qqmx.logic.application.project;

import java.util.Iterator;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.StringUtils;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

public class ForumEditLogic extends AbstractBaseLogic {
	
	// 新規メッセージ
	public void saveNewsInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		
		conditions.put("board_id", StringUtils.toInt(context.getParam().get("board_id")));
		conditions.put("parent_id", null);
		conditions.put("subject", context.getParam().get("messages_subject"));
		conditions.put("content", context.getParam().get("messages_content"));
		conditions.put("user_id", context.getSessionData().getUserInfo().getId());
		conditions.put("last_reply_id", null);
		conditions.put("locked", "1".equals(context.getParam().get("messages_locked")) ? true : false);
		conditions.put("sticky", context.getParam().get("messages_sticky"));
		
		db.insert("messages.addMessagesInfo", conditions);	
		db.update("boards.updateLastMessageId", conditions);	
		
		// 添付ファイル
		String upload_datas = context.getParam().get("upload_datas");
		updateAttachmentsData(upload_datas, StringUtils.toString(conditions.get("id")));
		
	}
	
	// 添付ファイルを保存
	public void updateAttachmentsData(String upload_datas, String newsId) throws SoftbankException {

		if (StringUtils.isNotEmpty(upload_datas)) {
			JSONArray importFile = JSONArray.fromObject(upload_datas);

			for (int i = 0; i < importFile.size(); i++) {
				JSONObject fileData = importFile.getJSONObject(i);

				String description = ConstantsUtil.Str.EMPTY;
				if (fileData.containsKey("description")) {
					description = fileData.getString("description");
				}

				Map<String, Object> dataMap = Maps.newHashMap();
				dataMap.put("attachments_id", fileData.getInt("id"));
				dataMap.put("container_type", "Message");
				dataMap.put("id", StringUtils.toInt(newsId));
				dataMap.put("description", description);

				// 既存ファイルを削除場合
				if (fileData.containsKey("delete")) {
					dataMap.put("id", fileData.getInt("id"));
					db.update("attachments.deleteFileInfo", dataMap);
				} else {
					db.update("attachments.updateAttachmentsByIdAfterInsert", dataMap);
				}
			}
		}
	}
	
	// 編集メッセージ
	public void updateNewsInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String newsId = context.getParam().get("news_id");
		conditions.put("news_id", newsId);
		
		conditions.put("subject", context.getParam().get("messages_subject"));
		conditions.put("locked", "1".equals(context.getParam().get("messages_locked")) ? true : false);
		conditions.put("sticky", "1".equals(context.getParam().get("messages_sticky")) ? 1 : 0);
		conditions.put("content", context.getParam().get("messages_content"));
		
		// 親フォーラム変更場合
		if (StringUtils.isNotEmpty(context.getParam().get("messages_board_id"))) {
			conditions.put("board_id", StringUtils.toInt(context.getParam().get("messages_board_id")));
			// 返答メッセージを更新
			db.update("messages.updateMessagesForum", conditions);		
			// topicメッセージを更新
			db.update("messages.updateMessagesInfo", conditions);	
			
			// last_message_idを更新(変更後)
			db.update("boards.updateLastMessageId", conditions);
			
			// last_message_idを更新(変更前)
			conditions.put("board_id", StringUtils.toInt(context.getParam().get("messages_old_board_id")));
			db.update("boards.updateLastMessageId", conditions);
			
		} else {
			// メッセージ内容を更新
			db.update("messages.updateMessagesInfo", conditions);	
		}
		
		// 添付ファイル
		String upload_datas = context.getParam().get("upload_datas");
		updateAttachmentsData(upload_datas, newsId);
		
	}
	
	// 削除（topic）メッセージ
	public void delNewsInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		int messagesId = StringUtils.toInt(context.getParam().get("messages_id"));
		conditions.put("messages_id", messagesId);		
		
		List<Integer> messages = Lists.newArrayList();
		messages = db.queryos("messages.getMessagesId", conditions);
		
		for (int i = 0; i < messages.size(); i++) {
			// realファイルを削除
			int mId = messages.get(i);
			deleteAttachmentFileByContainer(mId, "Message");
		}
		
		db.update("messages.deleteMessagesById", conditions);
		db.update("messages.deleteMessagesByParentId", conditions);
		
		// last_message_idを更新
		conditions.put("board_id", StringUtils.toInt(context.getParam().get("board_id")));	
		db.update("boards.updateLastMessageId", conditions);
		
		
		
	}
}
