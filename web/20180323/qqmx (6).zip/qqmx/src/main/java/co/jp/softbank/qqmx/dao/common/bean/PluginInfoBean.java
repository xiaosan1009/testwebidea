package co.jp.softbank.qqmx.dao.common.bean;

import net.sf.json.JSONObject;

public class PluginInfoBean implements DaoBeanInterface {
	
	private int id;
	
	private String name;
	
	private String value;
	

	public int getId() {
		return id;
	}


	public void setId(int id) {
		this.id = id;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public String getValue() {
		return value;
	}


	public void setValue(String value) {
		this.value = value;
	}


	@Override
	public void toJson(JSONObject dataObj) {
		dataObj.put("id", this.id);
		dataObj.put("name", this.name);
		dataObj.put("value", this.value);
	}

}
