package co.jp.softbank.qqmx.logic.application.watchable;

import java.math.BigInteger;
import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class DashboardLogic extends AbstractBaseLogic {
	
	public LogicBean getDashboardInfo() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, Object> conditions = Maps.newHashMap();
		
		Integer projectId = context.getParam().projectId;
		
		conditions.put("project_id", projectId);
		conditions.put("organization_cd", ""); //TODO:組織

		List<Map<String, Object>> project = db.querys("dashboard.getProject", conditions);
		resultMap.put("project", project);

		List<Map<String, Object>> qualityColor = db.querys("dashboard.getStAndAllStColor", conditions);
		resultMap.put("qualityColor", qualityColor);
		
		setQualityData("PHASE_006", "qualitySt", resultMap, conditions);
		setQualityData("PHASE_007", "qualityAllSt", resultMap, conditions);

		conditions.put("tracker_id", 2);
		List<Map<String, Object>> issueCount = db.querys("dashboard.getIssueCount", conditions);
		resultMap.put("issueCount", issueCount);
		
		List<Map<String, Object>> issueSeriesGraphData = db.querys("dashboard.getIssueSeriesGraphData", conditions);
		resultMap.put("issueSeriesGraphData", issueSeriesGraphData);

		List<Map<String, Object>> issuePriorityGraphData = db.querys("dashboard.getIssuePriorityGraphData", conditions);
		resultMap.put("issuePriorityGraphData", issuePriorityGraphData);

		conditions.put("tracker_id", 18);
		List<Map<String, Object>> crCount = db.querys("dashboard.getIssueCount", conditions);
		resultMap.put("crCount", crCount);
		
		List<Map<String, Object>> crSeriesGraphData = db.querys("dashboard.getIssueSeriesGraphData", conditions);
		resultMap.put("crSeriesGraphData", crSeriesGraphData);

		List<Map<String, Object>> crPriorityGraphData = db.querys("dashboard.getIssuePriorityGraphData", conditions);
		resultMap.put("crPriorityGraphData", crPriorityGraphData);

		List<Map<String, Object>> humanResourceGraphData = db.querys("dashboard.getHumanResource", conditions);
		resultMap.put("humanResourceGraphData", humanResourceGraphData);

//		List<Map<String, Object>> humanResourceCountGraphData = db.querys("dashboard.getHumanResourceCount", conditions);
//		if (humanResourceCountGraphData.size() > 0) {
//			humanResourceCountGraphData.get(0).put("member_task_cnt", humanResourceGraphData.size());
//		}
//		resultMap.put("humanResourceCountGraphData", humanResourceCountGraphData);
		
		logicBean.setData(resultMap);
		return logicBean;
	}
	
	public LogicBean getEasyActionInfo() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, Object> conditions = Maps.newHashMap();
		
		Integer projectId = context.getParam().projectId;
		Integer userId = ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId();
		
		conditions.put("project_id", projectId);
		conditions.put("user_id", userId);
		
		List<Map<String, Object>> userMailList = Lists.newArrayList();
		List<Map<String, Object>> userCount = db.querys("dashboard.getUserCount", conditions);
		if (userCount != null && userCount.size() > 0) {
			userMailList = db.querys("dashboard.getUserMailList", conditions);
			resultMap.put("userMailList", userMailList);

			resultMap.put("PROJECT_ID", projectId);
			resultMap.put("PROJECT_NAME", getProjectName());
			resultMap.put("FIXED_USER_NUMBER", "0083303");  // ログインユーザの共通社員番号(0083303)
			resultMap.put("AUTH_TOKEN", getMD5("0083303OACPTF"));
			resultMap.put("COMMON_EMPLOYEE_NUMBER", ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getCommonEmployeeNumber());
		}
		
		logicBean.setData(resultMap);
		return logicBean;
	}
	
	private void setQualityData(String phase, String key, Map<String, Object> resultMap, Map<String, Object> conditions) throws SoftbankException {
		conditions.put("phase", phase);
		List<Map<String, Object>> qualitySt = db.querys("dashboard.getQualityGraphData", conditions);
		resultMap.put(key, qualitySt);
		int test_count = 0;
		int test_end_count = 0;
		int bug_count = 0;
		int bug_end_count = 0;
		if (qualitySt != null && qualitySt.size() > 0) {
			test_count = (Integer)qualitySt.get(0).get("test_count");
			for (Map<String, Object> map : qualitySt) {
				if (map.get("test_end_count") != null) {
					test_end_count = (Integer)map.get("test_end_count");
				}
				if (map.get("bug_count") != null) {
					bug_count = (Integer)map.get("bug_count");
				}
				if (map.get("bug_end_count") != null) {
					bug_end_count = (Integer)map.get("bug_end_count");
				}
			}
		}
		List<Map<String, Object>> qualityStCount = Lists.newArrayList();
		Map<String, Object> map = Maps.newHashMap();
		map.put("test_count", test_count);
		map.put("test_end_count", test_count - test_end_count);
		map.put("bug_count", bug_count);
		map.put("bug_end_count", bug_end_count);
		qualityStCount.add(map);
		resultMap.put(key + "Count", qualityStCount);
	}
	
	private String getMD5(String input) {
	    try {
	        MessageDigest md = MessageDigest.getInstance("MD5");
	        byte[] messageDigest = md.digest(input.getBytes());
	        BigInteger number = new BigInteger(1, messageDigest);
	        String hashtext = number.toString(16);
	        while (hashtext.length() < 32) {
	            hashtext = "0" + hashtext;
	        }
	        return hashtext;
	    }
	    catch (NoSuchAlgorithmException e) {
	        throw new RuntimeException(e);
	    }
	}
	
	private String getProjectName() throws SoftbankException {
		String projectName = "";

		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("project_id", context.getParam().projectId);

		List<Map<String, Object>> project = db.querys("dashboard.getProject", conditions);
		if (project != null && project.size() > 0) {
			projectName = project.get(0).get("name").toString();
		}
		return projectName;
	}

	public void getSelectList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String selectId = context.getParam().get("selectFlg");
		String headquartersId = context.getParam().get("headquartersId").equals("")? "9898": context.getParam().get("headquartersId");
		String divisionId = context.getParam().get("divisionId").equals("")? "9898": context.getParam().get("divisionId");
		String department_id = context.getParam().get("departmentId").equals("")? "9898": context.getParam().get("departmentId");
		String project_id = context.getParam().get("proId").equals("")? "9898": context.getParam().get("proId");
		String category_id = context.getParam().get("categoryId").equals("")? "9898": context.getParam().get("categoryId");
		String status_Id = context.getParam().get("statusId").equals("")? "90000001": context.getParam().get("statusId");
		int loginUserId = ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId();
		
		if ("headquarters".equals(selectId)){
			context.getResultBean().setData(db.querys("projectList.getHeadquartersList"));
		}else if ("division".equals(selectId)){
			conditions.put("headquarters_Id", headquartersId);
			context.getResultBean().setData(db.querys("projectList.getDivisionList", conditions));
		}else if ("department".equals(selectId)){
			if ("9898".equals(divisionId)){
				conditions.put("division_id", headquartersId);
			}else{
				conditions.put("division_id", divisionId);
			}
			context.getResultBean().setData(db.querys("projectList.getDepartmentList", conditions));
		}else if ("prj".equals(selectId)){
			
	        if ("9898".equals(department_id)){
	            if ("9898".equals(divisionId)){
	                conditions.put("department_id", Integer.parseInt(headquartersId));
	            }else{
	            	conditions.put("department_id", Integer.parseInt(divisionId));
	            }
	        }else{
	        	conditions.put("department_id", Integer.parseInt(department_id));
	        }
			
			conditions.put("category_id", Integer.parseInt(category_id));
			conditions.put("status_Id", Integer.parseInt(status_Id));
			conditions.put("user_id", loginUserId);
			
			String searchName = context.getParam().get("search_name");
			conditions.put("search_name", searchName);
			context.getResultBean().setData(db.querys("projectList.getPrjList", conditions));
		}else if ("subPrj".equals(selectId)){
			
			if (!"".equals(project_id)){
				conditions.put("project_id", Integer.parseInt(project_id));
				conditions.put("user_id", loginUserId);
				context.getResultBean().setData(db.querys("projectList.getSubPrjList", conditions));
			}
		}
	}
	
	public void getProjectListInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		Integer projectId = context.getParam().projectId;
		conditions.put("project_id", projectId);
		context.getResultBean().setData(db.querys("dashboard.getProjectList", conditions));
	}
	
	public void getTopicCommentInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		Integer projectId = context.getParam().projectId;
		conditions.put("project_id", projectId);
		conditions.put("organization_cd", "");
		context.getResultBean().setData(db.querys("dashboard.getTopicCommentInfo", conditions));
	}
	public void getTopicCommentValueInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		Integer projectId = context.getParam().projectId;
		String shoriTime = context.getParam().get("shoriTime");
		conditions.put("project_id", projectId);
		conditions.put("organization_cd", "");
		conditions.put("shori_time", shoriTime);
		context.getResultBean().setData(db.querys("dashboard.getTopicCommentValueInfo", conditions));
	}
	public void getTopicCommentRole() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		Integer projectId = context.getParam().projectId;
		int loginUserId = ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId();
		conditions.put("project_id", projectId);
		conditions.put("user_id", loginUserId);
		context.getResultBean().setData(db.querys("dashboard.getTopicCommentRole", conditions));
	}
	public void insertTopicComment() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String shoriTime = context.getParam().get("shoriTime");
		String subPId = context.getParam().get("subPrjId");
		String pId = context.getParam().get("proId");
		String comment = context.getParam().get("commentData");
		
		int projectParentId = 0;
		int projectId = 0;
		if ("9898".equals(subPId)){
			projectParentId = Integer.parseInt(pId);
			projectId = Integer.parseInt(pId);
		}else{
			projectParentId = Integer.parseInt(pId);
			projectId = Integer.parseInt(subPId);
		}
		conditions.put("project_id", projectId);
		conditions.put("project_parent_id", projectParentId);
		conditions.put("shori_time", shoriTime);
		conditions.put("comment", comment);
		context.getResultBean().setData(db.insert("dashboard.insertTopicComment", conditions));
	}
	public void getUrlList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String clickId = context.getParam().get("projectClick");
		conditions.put("click_project_id", Integer.parseInt(clickId));
		context.getResultBean().setData(db.querys("projectList.getUrlList", conditions));
	}
	
	public void getProjectInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		Integer projectId = context.getParam().projectId;
		conditions.put("project_id", projectId);
		context.getResultBean().setData(db.querys("dashboard.getProjectInfo", conditions));
	}
	
	public void getUserIdAccount() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		int loginUserId = ((UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY)).getId();
		conditions.put("user_id", loginUserId);
		context.getResultBean().setData(db.querys("dashboard.getUserIdAccount", conditions));
	}
	
	public void getCustomField1266() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		Integer projectId = context.getParam().projectId;
		conditions.put("project_id", projectId);
		context.getResultBean().setData(db.querys("dashboard.getCustomField1266", conditions));
	}
	
}
