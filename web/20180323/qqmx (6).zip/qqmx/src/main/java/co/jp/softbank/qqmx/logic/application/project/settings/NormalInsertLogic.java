package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.PageListBean;
import co.jp.softbank.qqmx.util.StringUtils;

public class NormalInsertLogic extends AbstractBaseLogic {

//	@Autowired
//	private projectNormalInsert projectNormalInsert;

	public LogicBean getGroupListInfo() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();

		List<Map<String, Object>> groupList = db.querys("projectNormalInsert.getGroupList");
		resultMap.put("groups", groupList);

		List<Map<String, Object>> statusList = db.querys("projectNormalInsert.getStatusList");
		resultMap.put("status", statusList);

		logicBean.setData(resultMap);
		return logicBean;
	}

	public void getUserListInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		int status = 1;
		if (StringUtils.isNotEmpty(context.getParam().get("status"))) {
			status = Integer.parseInt(context.getParam().get("status"));
		}
		int groupId = 0;
		if (StringUtils.isNotEmpty(context.getParam().get("group_id"))) {
			groupId = Integer.parseInt(context.getParam().get("group_id"));
		}
		conditions.put("status", status);
		conditions.put("group_id", groupId);
		conditions.put("users_name", context.getParam().get("users_name"));
		PageListBean pageListBean = pageList("projectNormalInsert.getUserList", conditions);
		List<Map<String, Object>> statusList = db.querys("projectNormalInsert.getStatusList");
		for (int i = 0; i < statusList.size(); i++) {
			switch (Integer.parseInt(StringUtils.toString(statusList.get(i).get("status")))) {
			case 1:
				pageListBean.setData("lockCount", statusList.get(i).get("count"));
				break;
			case 2:
				pageListBean.setData("registCount", statusList.get(i).get("count"));
				break;
			case 3:
				pageListBean.setData("unlockCount", statusList.get(i).get("count"));
				break;

			default:
				break;
			}
		}
		context.getResultBean().setData(pageListBean);
	}

	public LogicBean getSelectUserListInfo() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, Object> conditions = Maps.newHashMap();

		int groupId = 0;
		if (StringUtils.isNotEmpty(context.getParam().get("group_id"))) {
			groupId = Integer.parseInt(context.getParam().get("group_id"));
		}
		conditions.put("status",
				Integer.parseInt(context.getParam().get("status")));
		conditions.put("group_id", groupId);
		conditions.put("users_name", context.getParam().get("users_name"));
		List<Map<String, Object>> userList = db.querys("projectNormalInsert.getUserList", conditions);
		resultMap.put("users", userList);

		logicBean.setData(resultMap);
		return logicBean;
	}

	public void lockUserInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();

		conditions.put("id", Integer.parseInt(context.getParam().get("id")));
		db.update("projectNormalInsert.updateUsersLock", conditions);
		db.update("projectNormalInsert.updateMembers", conditions);
	}

	public void unlockUserInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();

		conditions.put("id", Integer.parseInt(context.getParam().get("id")));
		db.update("projectNormalInsert.updateUsersUnlock", conditions);
		db.update("projectNormalInsert.updateMembers", conditions);
	}

	public void deleteUserInfo() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();

		conditions.put("id", Integer.parseInt(context.getParam().get("id")));
		db.update("projectNormalInsert.updateNormalInsertUsersAttachments", conditions);
		db.update("projectNormalInsert.updateNormalInsertUsersChangesets", conditions);
		db.update("projectNormalInsert.updateNormalInsertUsersComments", conditions);
		db.update("projectNormalInsert.updateNormalInsertUsersIssueCategories", conditions);
		db.update("projectNormalInsert.updateNormalInsertUsersIssuesAssigned", conditions);
		db.update("projectNormalInsert.updateNormalInsertUsersIssuesAuthor", conditions);
		db.update("projectNormalInsert.updateNormalInsertUsersJournalDetails", conditions);
		db.update("projectNormalInsert.updateNormalInsertUsersJournalDetailsOld", conditions);
		db.update("projectNormalInsert.updateNormalInsertUsersJournals", conditions);
		db.update("projectNormalInsert.updateNormalInsertUsersMessages", conditions);
		db.update("projectNormalInsert.updateNormalInsertUsersNews", conditions);
		db.update("projectNormalInsert.updateNormalInsertUsersQueries", conditions);
		db.update("projectNormalInsert.updateNormalInsertUsersTimeEntries", conditions);
		db.update("projectNormalInsert.updateNormalInsertUsersWikiContentVersions", conditions);
		db.update("projectNormalInsert.updateNormalInsertUsersWikiContents", conditions);
		db.delete("projectNormalInsert.deleteNormalInsertCustomValues", conditions);
		db.delete("projectNormalInsert.deleteNormalInsertQueries", conditions);
		db.delete("projectNormalInsert.deleteNormalInsertTokens", conditions);
		db.delete("projectNormalInsert.deleteNormalInsertUserPreferences", conditions);
		db.delete("projectNormalInsert.deleteNormalInsertUsers", conditions);
		db.delete("projectNormalInsert.deleteNormalInsertWatchers", conditions);
	}
}
