package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import org.ho.yaml.Yaml;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.dao.common.bean.PluginInfoBean;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.ControlDbMemory;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.util.StringUtils;

public class SettingProjectsLogic extends AbstractBaseLogic {

	public LogicBean getProjectPluginInfos() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> resultMap = Maps.newHashMap();
		List<Map<String, Object>> settingsList = db.querys("settingProjects.getSettings");
		Map<String, Object> settingsData = settingsList.get(0);
		String settingsValue = StringUtils.toString(settingsData.get("value"));
		Yaml yaml = new Yaml();
		List<String> settingsList2 = (List<String>)yaml.load(settingsValue);
		Map<String, String> settingsMap = Maps.newHashMap();
		for (int i = 0; i < settingsList2.size(); i++) {
			settingsMap.put(settingsList2.get(i), settingsList2.get(i));
		}
		resultMap.put("settings", settingsMap);
		resultMap.put("plugins", ControlDbMemory.getInstance().getPluginInfoBeans());
		logicBean.setData(resultMap);
		return logicBean;
	}
	
	public void getProjectRolesInfos() throws SoftbankException {
		context.getResultBean().setData(db.querys("settingProjects.getProjectRolesInfos"));
	}
	
	public void saveSettingInfos() throws SoftbankException {
		String	settings_new_project_user_role_id = context.getParam().get("settings_new_project_user_role_id");
		String[] settings_default_projects_modules = context.getParam().getList("settings_default_projects_modules_right");
		
		List<String> permissionsList = Lists.newArrayList(); 
		if (settings_default_projects_modules != null){
			for (int p = 0; p < settings_default_projects_modules.length; p++) {
				String strPermission = settings_default_projects_modules[p];
				permissionsList.add(strPermission);
			}
		}
		updataSettings(settings_new_project_user_role_id, "new_project_user_role_id");
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("name", "default_projects_modules");
		conditions.put("value", Yaml.dump(permissionsList));
		db.update("settingIssues.updataSettings" , conditions);
	}
	public PluginInfoBean pluginInfoSet(String value, String name) throws SoftbankException {
		PluginInfoBean pluginInfoBean = new PluginInfoBean();
		pluginInfoBean.setValue(value);
		pluginInfoBean.setName(name);
		return pluginInfoBean;
	}
	public void updataSettings(String value, String name) throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("name", name);
		conditions.put("value", value);
		db.update("settingIssues.updataSettings" , conditions);
	}
}
