package co.jp.softbank.qqmx.task.info;

import java.io.IOException;
import java.util.Iterator;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import co.jp.softbank.qqmx.task.face.IKey;
import co.jp.softbank.qqmx.task.face.IReadableCollector;
import co.jp.softbank.qqmx.task.face.ITaskContext;

import com.google.common.io.Closer;

public class MemoryCollector<V> implements IReadableCollector<V> {
	
	private ConcurrentMap<IKey, Object> lockMap = new ConcurrentHashMap<IKey, Object>();
	
	private Map<IKey, BaseQueue<V>> collectionMap;
	
	private Closer closer;
	
	public MemoryCollector() {
		this.collectionMap = new ConcurrentHashMap<IKey, BaseQueue<V>>();
	}

	@Override
	public void emit(V value) {
	}
	
	@Override
	public void emit(IKey key, V value) {
		key = key == null ? new GroupKey(GroupKey.DEFAULT_GROUP, 1) : key;
		
		lockMap.putIfAbsent(key, new Object());

        synchronized (lockMap.get(key)) {
            if (!collectionMap.containsKey(key)) {
                BaseQueue<V> queue = new MemoryQueue<V>();
                collectionMap.put(key, closer.register(queue));
            }
        }

        if (value != null) {
        	collectionMap.get(key).add(value);
        }
	}

	@Override
	public void prepare(ITaskContext context) {
		this.closer = Closer.create();
	}

	@Override
	public void cleanup(ITaskContext context) {
	}

	@Override
	public void close() throws IOException {
		collectionMap.clear();
        closer.close();
	}

	@Override
	public Iterator<V> iterator(IKey key) {
		
		return collectionMap.get(key).iterator();
	}
}
