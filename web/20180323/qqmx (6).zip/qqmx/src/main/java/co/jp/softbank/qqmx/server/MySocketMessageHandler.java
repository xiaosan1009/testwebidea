package co.jp.softbank.qqmx.server;

import javax.websocket.MessageHandler;
import javax.websocket.RemoteEndpoint;
import javax.websocket.Session;

import net.sf.json.JSONObject;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.server.SocketLogicFactory.SocketLogicType;
import co.jp.softbank.qqmx.util.StringUtils;

public class MySocketMessageHandler implements MessageHandler.Whole<String> {
	
	private Session session;

	public MySocketMessageHandler(Session session, RemoteEndpoint.Basic remote) {
		this.session = session;
	}
	
	@Override
	public void onMessage(String arg0) {
		if (StringUtils.isEmpty(arg0)) {
			return;
		}
		JSONObject message = JSONObject.fromObject(arg0);
		if (StringUtils.isEmpty(message.get("logic"))) {
			return;
		}
		try {
			SocketLogicFactory.getLogic(SocketLogicType.get(message.getString("logic"))).recieve(this.session, message);
		} catch (SoftbankException e) {
			e.printStackTrace();
		}
	}
	
}
