package co.jp.softbank.qqmx.logic.application.batch;

import java.io.BufferedReader;
import java.io.File;
import java.io.IOException;
import java.io.InputStreamReader;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import org.apache.commons.lang.StringUtils;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.server.ExternalHttpServer;
import net.sf.json.JSONArray;
import net.sf.json.JSONException;
import net.sf.json.JSONObject;


public class GitFileCheckLogic extends SourceScaleCount {
	// push
	// チケットID
	private String issue_Id = "";
	// ブランチ
	private String branch = "";
	// チケット新規日付
	private String createdData = "";
	// ファイル名
	private String file_name = "";
	private String isStop = "0";
	private String object_kind = "";
//	private String gitBranch = "";
	// note
	private String comment_line = "";
	private String comment_author = "";
	private String comment_content = "";
	private String comment_date = "";
	private String url = "";
	
	private String MergeRequest = "MergeRequest";
	private String comment_id = "";
	private String noteable_id = "";
	private String path_with_namespace = "";

	public void sourceCheck() throws SoftbankException {
		final String gitPath   = context.getParam().get("gitPath");
		final String projectId   = context.getParam().get("projectId");
		log.debug("API:gitPath" + gitPath);
		BufferedReader br = null;
		StringBuilder sb = new StringBuilder();
		try {
			br = new BufferedReader(new InputStreamReader(context.getRequest().getInputStream()));
			String c = "";
			log.debug("br = " +  br);
			while ((c = br.readLine()) != null) {
				sb.append(c);
			}
			br.close();
		} catch (IOException e1) {
			// TODO 自動生成された catch ブロック
			e1.printStackTrace();
		}
		final String gitRequest = sb.toString();
		log.debug("request body : " + sb.toString());
		log.info("request body : " + gitRequest);
		Thread t = new Thread(new Runnable() {
			public void run() {
				try {
					
//					try {
//						Thread.sleep(20000);
//					} catch (InterruptedException e) {
//						throw new SoftbankException(SoftbankExceptionType.SystemException,e);
//					}
					
					
//					url = "http://os62:wang03chen20@code-dev.ark.sbb-sys.info/api/v3/projects/qqmx%2Freview-platform/merge_requests/69201/notes";
//					url = "http://code-dev.ark.sbb-sys.info/api/v3/projects/qqmx%2Freview-platform/merge_requests/69201/notes";
//					ExternalHttpServer externalHttpServer = new ExternalHttpServer(null);
//					String checkStyle = externalHttpServer.getStrUrl(url);
//					
//					log.debug(checkStyle);
//					if (!StringUtils.isEmpty(checkStyle)) {
//						return;
//					}
//					
					
					log.debug("url : " + messageAccessor.getMessage("application.path") + ":8080/qqmx/qqmx.mx?dispCode=610010&cmdCode=2&projectId=1073&gitPath=" + gitPath
							+ "&gitRequest="+ gitRequest);
//					log.debug("url : " + messageAccessor.getMessage("application.path") + ":8080/qqmx/qqmx.mx?dispCode=610010&cmdCode=2&projectId="+projectId+"&gitPath=" + gitPath);
					Map<String, String> params = Maps.newHashMap();
					params.put("dispCode", "610010");
					params.put("cmdCode", "2");
					params.put("projectId", projectId);
					params.put("gitPath", gitPath);
					params.put("gitRequest", gitRequest);
					externalHttpServer.post(messageAccessor.getMessage("application.path") + ":8080/qqmx/qqmx.mx", params);
				} catch (SoftbankException e) {
					e.printStackTrace();
					log.error(e.getErrorMsg(), e);
				} catch (Exception e) {
					log.error(e.getMessage(), e);
				}
			}
		});
		t.start();
	}
	
	public void sourceCheckSync() {
		try {
			isStop = "0";
			String gitPath   = context.getParam().get("gitPath");
			String gitRequest   = context.getParam().get("gitRequest");
//			gitRequest = "{\"object_kind\":\"note\",\"user\":{\"name\":\"- O Shin - 王 晨（情報システム本部）\",\"username\":\"shin-o01\",\"avatar_url\":null},\"project_id\":3963,\"project\":{\"name\":\"review-platform\",\"description\":\"\",\"web_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform\",\"avatar_url\":null,\"git_ssh_url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"git_http_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform.git\",\"namespace\":\"qqmx\",\"visibility_level\":10,\"path_with_namespace\":\"qqmx/review-platform\",\"default_branch\":\"master\",\"homepage\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform\",\"url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"ssh_url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"http_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform.git\"},\"object_attributes\":{\"id\":267763,\"note\":\"test 11270950 ou\",\"noteable_type\":\"Commit\",\"author_id\":405,\"created_at\":\"2017-11-27 00:51:33 UTC\",\"updated_at\":\"2017-11-27 00:51:33 UTC\",\"project_id\":3963,\"attachment\":null,\"line_code\":\"0adf5b5c6a2089294dde5b2a6aca4128619a76a3_8_7\",\"commit_id\":\"6dbbdad77033c4c4ba54339ce142d2416e25dc73\",\"noteable_id\":null,\"system\":false,\"st_diff\":null,\"updated_by_id\":null,\"type\":\"DiffNote\",\"position\":{\"old_path\":\"lfs/20_基本設計/testmark.md\",\"new_path\":\"lfs/20_基本設計/testmark.md\",\"old_line\":null,\"new_line\":7,\"base_sha\":\"1fec896653fc0fbf6deb9454389bcf099053286b\",\"start_sha\":\"1fec896653fc0fbf6deb9454389bcf099053286b\",\"head_sha\":\"6dbbdad77033c4c4ba54339ce142d2416e25dc73\"},\"original_position\":{\"old_path\":\"lfs/20_基本設計/testmark.md\",\"new_path\":\"lfs/20_基本設計/testmark.md\",\"old_line\":null,\"new_line\":7,\"base_sha\":\"1fec896653fc0fbf6deb9454389bcf099053286b\",\"start_sha\":\"1fec896653fc0fbf6deb9454389bcf099053286b\",\"head_sha\":\"6dbbdad77033c4c4ba54339ce142d2416e25dc73\"},\"resolved_at\":null,\"resolved_by_id\":null,\"discussion_id\":\"8e31e91fb8b174c0ef35ac69488c664c9a7feac2\",\"original_discussion_id\":\"8e31e91fb8b174c0ef35ac69488c664c9a7feac2\",\"url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform/commit/6dbbdad77033c4c4ba54339ce142d2416e25dc73#note_267763\"},\"repository\":{\"name\":\"review-platform\",\"url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"description\":\"\",\"homepage\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform\"},\"commit\":{\"id\":\"6dbbdad77033c4c4ba54339ce142d2416e25dc73\",\"message\":\"refs #917844\",\"timestamp\":\"2017-11-27T09:47:50+09:00\",\"url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform/commit/6dbbdad77033c4c4ba54339ce142d2416e25dc73\",\"author\":{\"name\":\"- O Shin - 王 晨（情報システム本部）\",\"email\":\"shin.o01@g.softbank.co.jp\"}}}";
//			gitRequest = "{\"object_kind\":\"note\",\"user\":{\"name\":\"王　冕\",\"username\":\"wangm72\",\"avatar_url\":\"http://code-dev.ark.sbb-sys.info/uploads/user/avatar/3914/avatar.png\"},\"project_id\":3963,\"project\":{\"name\":\"review-platform\",\"description\":\"\",\"web_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform\",\"avatar_url\":null,\"git_ssh_url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"git_http_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform.git\",\"namespace\":\"qqmx\",\"visibility_level\":10,\"path_with_namespace\":\"qqmx/review-platform\",\"default_branch\":\"master\",\"homepage\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform\",\"url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"ssh_url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"http_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform.git\"},\"object_attributes\":{\"id\":287543,\"note\":\"test comment 201801051321\",\"noteable_type\":\"Commit\",\"author_id\":3914,\"created_at\":\"2018-01-05 04:22:00 UTC\",\"updated_at\":\"2018-01-05 04:22:00 UTC\",\"project_id\":3963,\"attachment\":null,\"line_code\":\"713f1fa5ac501541ddface2474614894703936a4_8_7\",\"commit_id\":\"948166093cfa41b8f2110b77166311ef0c2ea27d\",\"noteable_id\":null,\"system\":false,\"st_diff\":null,\"updated_by_id\":null,\"type\":\"DiffNote\",\"position\":{\"old_path\":\"testmark.md\",\"new_path\":\"testmark.md\",\"old_line\":null,\"new_line\":7,\"base_sha\":\"0f99bac3a056c5c33ba7a25c777544331445d4ea\",\"start_sha\":\"0f99bac3a056c5c33ba7a25c777544331445d4ea\",\"head_sha\":\"948166093cfa41b8f2110b77166311ef0c2ea27d\"},\"original_position\":{\"old_path\":\"testmark.md\",\"new_path\":\"testmark.md\",\"old_line\":null,\"new_line\":7,\"base_sha\":\"0f99bac3a056c5c33ba7a25c777544331445d4ea\",\"start_sha\":\"0f99bac3a056c5c33ba7a25c777544331445d4ea\",\"head_sha\":\"948166093cfa41b8f2110b77166311ef0c2ea27d\"},\"resolved_at\":null,\"resolved_by_id\":null,\"discussion_id\":\"294dba64465ee788ff288b43b032729824d3c27a\",\"original_discussion_id\":\"294dba64465ee788ff288b43b032729824d3c27a\",\"url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform/commit/948166093cfa41b8f2110b77166311ef0c2ea27d#note_287543\"},\"repository\":{\"name\":\"review-platform\",\"url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"description\":\"\",\"homepage\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform\"},\"commit\":{\"id\":\"948166093cfa41b8f2110b77166311ef0c2ea27d\",\"message\":\"Merge branch 'feature/ver0.1' into 'feature/ver0.1test0104' refs #954061 See merge request !27\",\"timestamp\":\"2018-01-04T16:55:41+09:00\",\"url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform/commit/948166093cfa41b8f2110b77166311ef0c2ea27d\",\"author\":{\"name\":\"- O Shin - 王 晨（情報システム本部）\",\"email\":\"shin.o01@g.softbank.co.jp\"}}}";
//			gitRequest = "{\"object_kind\":\"note\",\"user\":{\"name\":\"王　冕\",\"username\":\"wangm72\",\"avatar_url\":\"http://code-dev.ark.sbb-sys.info/uploads/user/avatar/3914/avatar.png\"},\"project_id\":3963,\"project\":{\"name\":\"review-platform\",\"description\":\"\",\"web_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform\",\"avatar_url\":null,\"git_ssh_url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"git_http_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform.git\",\"namespace\":\"qqmx\",\"visibility_level\":10,\"path_with_namespace\":\"qqmx/review-platform\",\"default_branch\":\"master\",\"homepage\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform\",\"url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"ssh_url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"http_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform.git\"},\"object_attributes\":{\"id\":287541,\"note\":\"test comment 201801051313\",\"noteable_type\":\"MergeRequest\",\"author_id\":3914,\"created_at\":\"2018-01-05 04:13:37 UTC\",\"updated_at\":\"2018-01-05 04:13:37 UTC\",\"project_id\":3963,\"attachment\":null,\"line_code\":\"713f1fa5ac501541ddface2474614894703936a4_8_7\",\"commit_id\":\"\",\"noteable_id\":69201,\"system\":false,\"st_diff\":null,\"updated_by_id\":null,\"type\":\"DiffNote\",\"position\":{\"old_path\":\"testmark.md\",\"new_path\":\"testmark.md\",\"old_line\":null,\"new_line\":7,\"base_sha\":\"0f99bac3a056c5c33ba7a25c777544331445d4ea\",\"start_sha\":\"0f99bac3a056c5c33ba7a25c777544331445d4ea\",\"head_sha\":\"b312ffc817754204d419daebb3583cd69ab0a7de\"},\"original_position\":{\"old_path\":\"testmark.md\",\"new_path\":\"testmark.md\",\"old_line\":null,\"new_line\":7,\"base_sha\":\"0f99bac3a056c5c33ba7a25c777544331445d4ea\",\"start_sha\":\"0f99bac3a056c5c33ba7a25c777544331445d4ea\",\"head_sha\":\"b312ffc817754204d419daebb3583cd69ab0a7de\"},\"resolved_at\":null,\"resolved_by_id\":null,\"discussion_id\":\"d2dcd631eeb93135a0af42f93b2e70cd5271c97b\",\"original_discussion_id\":\"d2dcd631eeb93135a0af42f93b2e70cd5271c97b\",\"url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform/merge_requests/27#note_287541\"},\"repository\":{\"name\":\"review-platform\",\"url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"description\":\"\",\"homepage\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform\"},\"merge_request\":{\"id\":69201,\"target_branch\":\"feature/ver0.1test0104\",\"source_branch\":\"feature/ver0.1\",\"source_project_id\":3963,\"author_id\":405,\"assignee_id\":null,\"title\":\"refs #954061\",\"created_at\":\"2018-01-04 06:35:33 UTC\",\"updated_at\":\"2018-01-05 04:13:37 UTC\",\"milestone_id\":null,\"state\":\"merged\",\"merge_status\":\"can_be_merged\",\"target_project_id\":3963,\"iid\":27,\"description\":\"\",\"position\":0,\"locked_at\":null,\"updated_by_id\":405,\"merge_error\":null,\"merge_params\":{\"force_remove_source_branch\":\"0\"},\"merge_when_build_succeeds\":false,\"merge_user_id\":null,\"merge_commit_sha\":\"948166093cfa41b8f2110b77166311ef0c2ea27d\",\"deleted_at\":null,\"in_progress_merge_commit_sha\":null,\"lock_version\":null,\"time_estimate\":0,\"source\":{\"name\":\"review-platform\",\"description\":\"\",\"web_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform\",\"avatar_url\":null,\"git_ssh_url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"git_http_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform.git\",\"namespace\":\"qqmx\",\"visibility_level\":10,\"path_with_namespace\":\"qqmx/review-platform\",\"default_branch\":\"master\",\"homepage\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform\",\"url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"ssh_url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"http_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform.git\"},\"target\":{\"name\":\"review-platform\",\"description\":\"\",\"web_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform\",\"avatar_url\":null,\"git_ssh_url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"git_http_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform.git\",\"namespace\":\"qqmx\",\"visibility_level\":10,\"path_with_namespace\":\"qqmx/review-platform\",\"default_branch\":\"master\",\"homepage\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform\",\"url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"ssh_url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"http_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform.git\"},\"last_commit\":{\"id\":\"b312ffc817754204d419daebb3583cd69ab0a7de\",\"message\":\"refs #956791 【Charging2.0非機能】ARKアプリ定義書.xlsx\",\"timestamp\":\"2018-01-04T15:32:34+09:00\",\"url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform/commit/b312ffc817754204d419daebb3583cd69ab0a7de\",\"author\":{\"name\":\"- O Shin - 王 晨（情報システム本部）\",\"email\":\"shin.o01@g.softbank.co.jp\"}},\"work_in_progress\":false}}";
			log.debug("&gitRequest="+ gitRequest);
			
			if (StringUtils.isEmpty(gitRequest)){
				return;
			}
//			String gitRequest = "{\"object_kind\":\"note\",\"user\":{\"name\":\"- O Shin - 王 晨（情報システム本部）\",\"username\":\"shin-o01\",\"avatar_url\":null},\"project_id\":3963,\"project\":{\"name\":\"review-platform\",\"description\":\"\",\"web_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform\",\"avatar_url\":null,\"git_ssh_url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"git_http_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform.git\",\"namespace\":\"qqmx\",\"visibility_level\":10,\"path_with_namespace\":\"qqmx/review-platform\",\"default_branch\":\"master\",\"homepage\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform\",\"url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"ssh_url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"http_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform.git\"},\"object_attributes\":{\"id\":259661,\"note\":\"test201711130934\",\"noteable_type\":\"Commit\",\"author_id\":405,\"created_at\":\"2017-11-13 00:34:30 UTC\",\"updated_at\":\"2017-11-13 00:34:30 UTC\",\"project_id\":3963,\"attachment\":null,\"line_code\":\"1fe8f1b5d037b1de7d9add97eb2404e04c3f7205_34_33\",\"commit_id\":\"027201b757368df2194b1135d368e8ef65c37e67\",\"noteable_id\":null,\"system\":false,\"st_diff\":null,\"updated_by_id\":null,\"type\":\"DiffNote\",\"position\":{\"old_path\":\"git02.txt\",\"new_path\":\"git02.txt\",\"old_line\":null,\"new_line\":33,\"base_sha\":\"b637c8a2cdccb1913c8881f65929f2663bb9a7eb\",\"start_sha\":\"b637c8a2cdccb1913c8881f65929f2663bb9a7eb\",\"head_sha\":\"027201b757368df2194b1135d368e8ef65c37e67\"},\"original_position\":{\"old_path\":\"git02.txt\",\"new_path\":\"git02.txt\",\"old_line\":null,\"new_line\":33,\"base_sha\":\"b637c8a2cdccb1913c8881f65929f2663bb9a7eb\",\"start_sha\":\"b637c8a2cdccb1913c8881f65929f2663bb9a7eb\",\"head_sha\":\"027201b757368df2194b1135d368e8ef65c37e67\"},\"resolved_at\":null,\"resolved_by_id\":null,\"discussion_id\":\"173229851ba6dc30a5bafc3e3926c88ae79ae489\",\"original_discussion_id\":\"173229851ba6dc30a5bafc3e3926c88ae79ae489\",\"url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform/commit/027201b757368df2194b1135d368e8ef65c37e67#note_259661\"},\"repository\":{\"name\":\"review-platform\",\"url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"description\":\"\",\"homepage\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform\"},\"commit\":{\"id\":\"027201b757368df2194b1135d368e8ef65c37e67\",\"message\":\"refs #805322\",\"timestamp\":\"2017-10-19T17:16:55+09:00\",\"url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform/commit/027201b757368df2194b1135d368e8ef65c37e67\",\"author\":{\"name\":\"- O Shin - 王 晨（情報システム本部）\",\"email\":\"shin.o01@g.softbank.co.jp\"}}}";
//			String gitRequest = "{\"object_kind\":\"push\",\"event_name\":\"push\",\"before\":\"06841a223e1c9b8ddecc81aac05f23034e6d7467\",\"after\":\"22fabedf18bdfab31652834d56cbac2f74c666eb\",\"ref\":\"refs/heads/1-dltest\",\"checkout_sha\":\"22fabedf18bdfab31652834d56cbac2f74c666eb\",\"message\":null,\"user_id\":405,\"user_name\":\"- O Shin - 王 晨（情報システム本部）\",\"user_email\":\"shin.o01@g.softbank.co.jp\",\"user_avatar\":null,\"project_id\":3963,\"project\":{\"name\":\"review-platform\",\"description\":\"\",\"web_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform\",\"avatar_url\":null,\"git_ssh_url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"git_http_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform.git\",\"namespace\":\"qqmx\",\"visibility_level\":10,\"path_with_namespace\":\"qqmx/review-platform\",\"default_branch\":\"master\",\"homepage\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform\",\"url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"ssh_url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"http_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform.git\"},\"commits\":[{\"id\":\"22fabedf18bdfab31652834d56cbac2f74c666eb\",\"message\":\"refs #805322\",\"timestamp\":\"2017-11-13asdfasdfas\",\"url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform/commit/22fabedf18bdfab31652834d56cbac2f74c666eb\",\"author\":{\"name\":\"- O Shin - 王 晨（情報システム本部）\",\"email\":\"shin.o01@g.softbank.co.jp\"},\"added\":[],\"modified\":[\"test8.docx\"],\"removed\":[]},{\"id\":\"22fabedf18bdfab31652834d56cbac2f74c666eb\",\"message\":\"refs #805323\",\"timestamp\":\"2017-11-13asdfasdfas\",\"url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform/commit/22fabedf18bdfab31652834d56cbac2f74c666eb\",\"author\":{\"name\":\"- O Shin - 王 晨（情報システム本部）\",\"email\":\"shin.o01@g.softbank.co.jp\"},\"added\":[],\"modified\":[\"test9.docx\"],\"removed\":[]}],\"total_commits_count\":1,\"repository\":{\"name\":\"review-platform\",\"url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"description\":\"\",\"homepage\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform\",\"git_http_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform.git\",\"git_ssh_url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"visibility_level\":10}}";
//			String gitRequest = "{\"object_kind\":\"push\",\"event_name\":\"push\",\"before\":\"4c0ce600b71ac9408144257c607961201e3c3686\",\"after\":\"1e236b489cd36bcaaf973cc9db0a1a30d5a2fec0\",\"ref\":\"refs/heads/test1113\",\"checkout_sha\":\"1e236b489cd36bcaaf973cc9db0a1a30d5a2fec0\",\"message\":null,\"user_id\":405,\"user_name\":\"- O Shin - 王 晨（情報システム本部）\",\"user_email\":\"shin.o01@g.softbank.co.jp\",\"user_avatar\":null,\"project_id\":3963,\"project\":{\"name\":\"review-platform\",\"description\":\"\",\"web_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform\",\"avatar_url\":null,\"git_ssh_url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"git_http_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform.git\",\"namespace\":\"qqmx\",\"visibility_level\":10,\"path_with_namespace\":\"qqmx/review-platform\",\"default_branch\":\"master\",\"homepage\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform\",\"url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"ssh_url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"http_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform.git\"},\"commits\":[{\"id\":\"1e236b489cd36bcaaf973cc9db0a1a30d5a2fec0\",\"message\":\"Update git02.txt\",\"timestamp\":\"2017-11-15T16:29:51+09:00\",\"url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform/commit/1e236b489cd36bcaaf973cc9db0a1a30d5a2fec0\",\"author\":{\"name\":\"- O Shin - 王 晨（情報システム本部）\",\"email\":\"shin.o01@g.softbank.co.jp\"},\"added\":[],\"modified\":[\"git02.txt\"],\"removed\":[]}],\"total_commits_count\":1,\"repository\":{\"name\":\"review-platform\",\"url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"description\":\"\",\"homepage\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform\",\"git_http_url\":\"http://code-dev.ark.sbb-sys.info/qqmx/review-platform.git\",\"git_ssh_url\":\"git@code-dev.ark.sbb-sys.info:qqmx/review-platform.git\",\"visibility_level\":10}}";
			
			// Git情報取得
			getRequestInfo(gitRequest, gitPath);
			
		} catch (JSONException e) {
			log.error("☆☆☆ JSONException ： ☆☆☆" + e);
			return;
		} catch (Exception e) {
			
		} finally {

		}
	}
	
	protected void getRequestInfo(String gitRequest, String gitPath) throws Exception {
		isStop = "0";
		object_kind = "";
		url = "";
		
		JSONObject json = JSONObject.fromObject(gitRequest);
		
		
		if ( json.containsKey("object_kind") && json.get("object_kind") != null ) {
			object_kind = json.get("object_kind").toString();
			log.debug("☆☆☆ objectKind  ☆☆☆ : " + object_kind);
		} 
		if ( "push".equals(object_kind) ) {
			issue_Id = "";
			// ブランチ
			branch = "";
			// チケット新規日付
			createdData = "";
			// ファイル名
			file_name = "";
			// push
			log.debug("☆☆☆ objectKind  ☆☆☆ : " + object_kind);

			String ref = "";
			if ( json.containsKey("ref") && json.get("ref") != null ) {
				ref = json.get("ref").toString();
			}
			// ブランチ
			branch = getBranch(ref);
			if ( json.containsKey("commits") ) {
				JSONArray commits = json.getJSONArray("commits");
				
				for ( int i  = 0; i < commits.size(); i++ ) {
					String message = commits.getJSONObject(i).getString("message");
					String added = commits.getJSONObject(i).getString("added");
					String modified = commits.getJSONObject(i).getString("modified");
					String removed = commits.getJSONObject(i).getString("removed");
					String timestamp = commits.getJSONObject(i).getString("timestamp");
					url = commits.getJSONObject(i).getString("url");
					log.debug("☆☆☆ message ☆☆☆ : " + message);
					log.debug("☆☆☆ added  ☆☆☆ : " + added);
					log.debug("☆☆☆ modified  ☆☆☆ : " + modified);
					log.debug("☆☆☆ removed  ☆☆☆ : " + removed);
					log.debug("☆☆☆ timestamp  ☆☆☆ : " + timestamp);
					log.debug("☆☆☆ url  ☆☆☆ : " + url);
					log.debug("☆☆☆ ref  ☆☆☆ : " + ref);
					if ( StringUtils.isEmpty(message) || StringUtils.isEmpty(added) || StringUtils.isEmpty(modified) || StringUtils.isEmpty(removed) || StringUtils.isEmpty(timestamp) || StringUtils.isEmpty(ref) || StringUtils.isEmpty(url) ) {
						isStop = "1";
						return;
					}
					// チケットID
					issue_Id = getIssuesId(message);
					// チケット新規日付
					createdData = getcreatedData(timestamp);
					// ファイル名
					if( !"[]".equals(added) ){
						// 新規
						file_name = getFileName(added);
					}
					if( !"[]".equals(modified) ){
						// 修正
						file_name = getFileName(modified);
					}
					
					runBatch(gitPath, branch);
				}
			} 
		} else if ("note".equals(object_kind)) {
			// comment
			issue_Id = "";
			comment_content = "";
			comment_line = "";
			comment_date = "";
			comment_author ="";
			url = "";
			comment_id = "";
			noteable_id = "";
			path_with_namespace = "";
			
			String noteable_type = "";
			
			if ( json.containsKey("commit") ) {
				String commit = json.get("commit").toString();
				JSONObject jsonObj = JSONObject.fromObject(commit);
				if ( jsonObj.containsKey("message") ) {
					issue_Id = getIssuesId( jsonObj.get("message").toString() );
					log.debug("☆☆☆ issueId  ☆☆☆ : " + issue_Id);
				}
				if ( jsonObj.containsKey("url") ) {
					url = jsonObj.get("url").toString();
					log.debug("☆☆☆ url  ☆☆☆ : " + url);
				}
				if ( jsonObj.containsKey("timestamp") ) {
					comment_date = jsonObj.get("timestamp").toString();
					log.debug("☆☆☆ timestamp  ☆☆☆ : " + comment_date);
				}
				if ( jsonObj.containsKey("author") ) {
					String author = jsonObj.get("author").toString();
					log.debug("☆☆☆ author  ☆☆☆ : " + author);
					JSONObject jname = JSONObject.fromObject(author);
					if ( jname.containsKey("name") ) {
						comment_author = jname.get("name").toString();
						log.debug("☆☆☆ author  ☆☆☆ : " + comment_author);
					}
				}
			}
			if ( json.containsKey("merge_request") ) {
				String merge_request = json.get("merge_request").toString();
				JSONObject jsonObj = JSONObject.fromObject(merge_request);
				if ( jsonObj.containsKey("last_commit") ) {
					String last_commit = jsonObj.get("last_commit").toString();
					JSONObject jsonCom = JSONObject.fromObject(last_commit);
					if ( jsonCom.containsKey("message") ) {
						issue_Id = getIssuesId( jsonCom.get("message").toString() );
						log.debug("☆☆☆ issueId  ☆☆☆ : " + issue_Id);
					}
					if ( jsonCom.containsKey("url") ) {
						url = jsonCom.get("url").toString();
						log.debug("☆☆☆ url  ☆☆☆ : " + url);
					}
					if ( jsonCom.containsKey("timestamp") ) {
						comment_date = jsonCom.get("timestamp").toString();
						log.debug("☆☆☆ timestamp  ☆☆☆ : " + comment_date);
					}
				}
			}
			if ( json.containsKey("object_attributes") ) {
				String object_attributes = json.get("object_attributes").toString();
				JSONObject jsonObj = JSONObject.fromObject(object_attributes);
				
				if ( jsonObj.containsKey("noteable_type") ) {
					noteable_type = jsonObj.get("noteable_type").toString();
					log.debug("☆☆☆ noteable_type  ☆☆☆ : " + noteable_type);
				}
				// MergeRequestのみ
				if (!MergeRequest.equals(noteable_type)){
					return;
				}
				
				if ( jsonObj.containsKey("id") ) {
					comment_id = jsonObj.get("id").toString();
					log.debug("☆☆☆ comment_id  ☆☆☆ : " + comment_id);
				}
				
				if ( jsonObj.containsKey("noteable_id") ) {
					noteable_id = jsonObj.get("noteable_id").toString();
					log.debug("☆☆☆ noteable_id  ☆☆☆ : " + noteable_id);
				}
				
				if ( jsonObj.containsKey("note") ) {
					comment_content = jsonObj.get("note").toString();
					log.debug("☆☆☆ note  ☆☆☆ : " + comment_content);
				}
				if ( jsonObj.containsKey("position") ) {
					String position = jsonObj.get("position").toString();
					JSONObject jsonPos = JSONObject.fromObject(position);
					if ( jsonPos.containsKey("new_line") ) {
						comment_line = jsonPos.get("new_line").toString();
						log.debug("☆☆☆ newline ☆☆☆ : " + comment_line);
					}
					if (StringUtils.isEmpty(comment_line)) {
						if ( jsonPos.containsKey("old_line") ) {
							comment_line = jsonPos.get("old_line").toString();
							log.debug("☆☆☆ newline ☆☆☆ : " + comment_line);
						}
					} 
				}
			}
			
			if ( json.containsKey("user") ) {
				String user = json.get("user").toString();
				JSONObject jsonObj = JSONObject.fromObject(user);
				if ( jsonObj.containsKey("name") ) {
					comment_author = jsonObj.get("name").toString();
					log.debug("☆☆☆ author  ☆☆☆ : " + comment_author);
				}
			}
			
			if ( json.containsKey("project") ) {
				String tempProject = json.get("project").toString();
				JSONObject jsonObj = JSONObject.fromObject(tempProject);
				if ( jsonObj.containsKey("path_with_namespace") ) {
					path_with_namespace = jsonObj.get("path_with_namespace").toString();
					log.debug("☆☆☆ path_with_namespace  ☆☆☆ : " + path_with_namespace);
				}
			}
			
			if ( StringUtils.isEmpty(issue_Id) || StringUtils.isEmpty(comment_line) || StringUtils.isEmpty(comment_content) || StringUtils.isEmpty(comment_date) || StringUtils.isEmpty(comment_author) || StringUtils.isEmpty(url) || StringUtils.isEmpty(comment_id) || StringUtils.isEmpty(noteable_id) || StringUtils.isEmpty(path_with_namespace)) {
				return;
			}
			
			runBatch(gitPath, branch);
		} else {
			log.debug("☆☆☆ objectKind  ☆☆☆ : " + object_kind);
			return;
		}
		

	}
	
	protected void runBatch(String gitPath, String branch) {
		try {
			if (!"0".equals(isStop)) {
				log.debug("☆☆☆ 削除　： ☆☆☆");
				return;
			}
			
			log.debug("☆☆☆ issueId ☆☆☆ " + issue_Id);
			log.debug("☆☆☆ branch ☆☆☆ " + branch);
			log.debug("☆☆☆ createdData ☆☆☆ " + createdData);
			log.debug("☆☆☆ filename ☆☆☆ " + file_name);
			
			if (StringUtils.isEmpty(issue_Id)) {
				log.debug("☆☆☆ issue_Id 空　： ☆☆☆");
				return;
			}
			
			if (StringUtils.isEmpty(branch) && "push".equals(object_kind)) {
				log.debug("☆☆☆ branch 空　： ☆☆☆");
				return;
			}
			
			if (StringUtils.isEmpty(file_name) && "push".equals(object_kind)) {
				log.debug("☆☆☆ file_name 空　： ☆☆☆");
				return;
			}
			
			Map<String, Object> condition = Maps.newHashMap();
			condition.put("issue_id",Integer.parseInt(issue_Id));
			Map<String, Object> map1 =  db.query("sourceScale.getTrackerId", condition);
			log.debug("☆☆☆ tracker_id　： ☆☆☆" + map1.get("tracker_id").toString());
			// ドキュメントのみ
			if(map1 == null || !"46".equals(map1.get("tracker_id").toString())){  //tracker_id： 本番 → 46、230 → 43
				return;
			}
			if ( "push".equals(object_kind) ) {
				// 既存チケットの場合、チケット開始日取得
				Map<String, Object> map2 =  db.query("sourceScale.getCreatedData", condition);
				if(map2 != null){
					log.debug("☆☆☆ filecreate_date　： ☆☆☆" + map2.get("filecreate_date").toString());
					createdData = map2.get("filecreate_date").toString();
					log.debug("☆☆☆ createdData1　： ☆☆☆" + createdData + "(end");
				}
				checkoutFile(gitPath, branch);
			}
			
			doFileCheck(gitPath);
		}
		catch (Exception e) {
			
		} finally {
	
		}
	}
	
	protected void checkoutFile(String gitPath, String branch) {
		try {
//			String cmd = "/opt/ipftools/testreview-platform.git/checkoutGitFile.sh " //２３０
			String cmd = "/opt/ipftools/checkout-review-platform.git/checkoutGitFile.sh " //本番
					 + gitPath + " " + branch;
			Process process = Runtime.getRuntime().exec(cmd);

			log.debug("☆☆☆ cmd ☆☆☆" + cmd);
			process.waitFor();
			process.destroy();
			
			log.debug("☆☆☆ cmd ☆☆☆" + cmd);
		} catch (IOException e) {
			e.printStackTrace();
		} catch (InterruptedException e) {
			e.printStackTrace();
		}
	}
	
	protected void doFileCheck (String gitPath) throws Exception {
		if ( "push".equals(object_kind) ) {
			String filePath      = gitPath + "/" + file_name;    // ファイルフルパス（ファイル名含む）
			File file = new File(filePath);
			if(file == null || !file.exists()){
				log.debug("filePath(null): " + filePath);
				return;
			}
			
			String filetype = file_name.substring(file_name.lastIndexOf(".") + 1);
			log.debug("filePath: " + filePath);
			log.debug("issuesId: " + issue_Id);
			log.debug("createdData: " + createdData);
			log.debug("filetype: " + filetype);
			log.debug("filePath: " + filePath);
			Map<String, String> params = Maps.newHashMap();
			params.put("dispCode", "900006");
			params.put("cmdCode", "1");
			params.put("issueId", issue_Id);
			params.put("gitFlg", "1");
			params.put("filePath", filePath);
			params.put("createdData", createdData);
			params.put("gitUrl", url);
			externalHttpServer.post(messageAccessor.getMessage("application.path") + ":8080/qqrp/qqrp.mx", params);
			if ( !filetype.equalsIgnoreCase("md") ) {
				externalHttpServer.getStrUrl( messageAccessor.getMessage("application.path") + ":8080/qqrp/qqrp.mx?dispCode=900005&cmdCode=1&issueId=" + issue_Id); //230環境 コメント
			}
			log.debug("tempURL: " + params);			
		}
		else if ("note".equals(object_kind)) {
			log.debug("tempURL: " + object_kind);
			String tempURL = (":8080/qqrp/qqrp.mx?dispCode=900005&cmdCode=1&issueId=" + issue_Id + "&gitFlg=1&comment_line=" + comment_line + "&comment_author=" + URLEncoder.encode(comment_author,"utf-8") + "&comment_content=" + URLEncoder.encode(comment_content,"utf-8") + "&comment_date=" + comment_date + "&gitUrl=").replace(" ", "%20");
			Map<String, String> params = Maps.newHashMap();
			params.put("dispCode", "900005");
			params.put("cmdCode", "1");
			params.put("issueId", issue_Id);
			params.put("gitFlg", "1");
			params.put("comment_line", comment_line);
			params.put("comment_author", comment_author);
			params.put("comment_content", comment_content);
			params.put("comment_date", comment_date);
			params.put("gitUrl", url);
			params.put("comment_id", comment_id);
			params.put("noteable_id", noteable_id);
			params.put("path_with_namespace", path_with_namespace);
			externalHttpServer.post(messageAccessor.getMessage("application.path") + ":8080/qqrp/qqrp.mx", params);
			log.debug("test: " + messageAccessor.getMessage("application.path") + tempURL);
			log.debug("params: " + params);
		}
	}
	
	protected String getIssuesId (String message) throws Exception {
		String issuesId = "";
		// コミットログからチケットIDを抽出するための正規表現
		String regexp = 
			"(?:close|closed|closes|fix|fixed|fixes|addresses|references|refs|re|see|[\\s,&]+|[\\s]*and)[\\s]*" + 
			"(?:ticket\\:|issue\\:|bug\\:|#)([0-9]+)";
		
		Pattern p = Pattern.compile(regexp, Pattern.MULTILINE);
		Matcher m = p.matcher(message.toLowerCase());
		while(m.find()){
			if (m.groupCount() > 0) {
				String ticketId = m.group(1);
				log.debug("[Trac] ticketId:" + ticketId);
				issuesId = ticketId;
				return issuesId;
			}
		}
		return issuesId;
	}
	
	protected String getcreatedData (String timestamp) throws Exception {
		String cData = "";
		if (timestamp.length() >= 10 ) {
			cData = timestamp.substring(0, 10);
		} else {
			Date firstCommit = new Date();
			firstCommit.getTime();
			SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd");
			cData = sdf.format(firstCommit);
		}
		return cData;
	}
	
	protected String getFileName (String message) throws Exception {
		String fileName = "";
		fileName = message.substring(message.indexOf("[\""), message.lastIndexOf("\"]")).replace("[\"", "");
		return fileName;
	}
	
	protected String getBranch (String ref) throws Exception {
		String gBranch = ref.replace("refs/heads/", "");
		return gBranch;
	}
	
	public void mdCommentCheck() throws SoftbankException {
		
//		final String projectsId   = context.getParam().get("projectsId").replace("/", "%2F");

		Thread t = new Thread(new Runnable() {
			public void run() {
				try {
//					url = "http://os62:wang03chen20@code-dev.ark.sbb-sys.info/api/v3/projects/qqmx%2Freview-platform/merge_requests/69201/notes";
					List<Map<String, Object>> mdInfo =  db.querys("sourceScale.getMdInfo");
					
					int size = mdInfo.size();
					if ( size < 1 ){
						return;
					}
					
					for (int i = 0; i < size; i++) {
						String mdID = String.valueOf(mdInfo.get(i).get("id"));
						String commentID = String.valueOf(mdInfo.get(i).get("comment_id"));
						String noteableID = String.valueOf(mdInfo.get(i).get("noteable_id"));
						String comment_content = String.valueOf(mdInfo.get(i).get("comment_content"));
						String path_with_namespace = String.valueOf(mdInfo.get(i).get("path_with_namespace")).replace("/", "%2F");
						if ( StringUtils.isEmpty(commentID) || StringUtils.isEmpty(noteableID) || StringUtils.isEmpty(path_with_namespace)) {
							break;
						}
						int md_id = Integer.parseInt(mdID);
//						int comment_id = Integer.parseInt(commentID);
//						int noteable_id = Integer.parseInt(noteableID);
						
						String tempurl = "http://code-dev.ark.sbb-sys.info/api/v3/projects/" + path_with_namespace + "/merge_requests/" + noteableID + "/notes/" + commentID + "?private_token=uEAJQDpdrtzD-4Fngy4z";
						ExternalHttpServer externalHttpServer = new ExternalHttpServer(null);
						String checkStyle = externalHttpServer.getStrUrl(tempurl);
						
						log.debug(checkStyle);
						if ( StringUtils.isEmpty(checkStyle) ) {
							break;
						} else if ( "{\"message\":\"404 Not found\"}".equals(checkStyle) ) {
							// db delete
							Map<String, Object> condition = Maps.newHashMap();
							condition.put("md_id",md_id);
							db.delete("sourceScale.deleteMdIofo", condition);
						}
						
						JSONObject json = JSONObject.fromObject(checkStyle);
						if ( json.containsKey("body") ) {
							String commentBody = json.get("body").toString();
							String updatedAt = "";
							log.debug("☆☆☆ body  ☆☆☆ : " + commentBody);
							if (!comment_content.equals(commentBody)) {
								if ( json.containsKey("updated_at") ) {
									updatedAt = json.get("updated_at").toString();
								}
								SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSS");
								Date updated_at =  sdf.parse(updatedAt);
								Map<String, Object> condition = Maps.newHashMap();
								condition.put("md_id",md_id);
								condition.put("updated_at",updated_at);
								condition.put("comment_content",commentBody);
								db.update("sourceScale.upDateMdIofo", condition);
							}
						} 
						
					}
					
				} catch (SoftbankException e) {
					e.printStackTrace();
					log.error(e.getErrorMsg(), e);
				} catch (Exception e) {
					log.error(e.getMessage(), e);
				}
			}
		});
		t.start();
	}

}
