package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;
import java.util.Map.Entry;

import org.yaml.snakeyaml.Yaml;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.UserInfoData;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;
import com.google.common.collect.Maps;

public class PrivateSettingLogic extends AbstractBaseLogic {
	
	public LogicBean getPrivateSettingInfo() throws SoftbankException {
		
		LogicBean logicBean = new LogicBean();
		Map<String, Object> Conditions = Maps.newHashMap();
		Map<String, Object> resultMap = Maps.newHashMap();
		Map<String, String> settingsMap = Maps.newHashMap();
		
		UserInfoData userInfoData = (UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY);
		Conditions.put("id", userInfoData.getId());
		List<Map<String, Object>> projectsTrackerList = Lists.newArrayList();
		projectsTrackerList = db.querys("privateSetting.getPrivateSettingInfo", Conditions);
		Map<String, Object> projectsTrackerData = projectsTrackerList.get(0);
		String settingsValue = StringUtils.toString(projectsTrackerData.get("others"));
		Yaml yaml = new Yaml();
		Map<String, Object> projectsTracker2Data = (Map<String, Object>)yaml.load(settingsValue);
		
		if (String.valueOf(projectsTracker2Data.get(":no_self_notified")).equals("false")){
			settingsMap.put("no_self_notified", "");
		}else{
			settingsMap.put("no_self_notified", "1");
		}
		settingsMap.put("pref_comments_sorting", StringUtils.toString(projectsTracker2Data.get(":comments_sorting")));
		settingsMap.put("backlogs_task_color", StringUtils.toString(projectsTracker2Data.get(":backlogs_task_color")));
		settingsMap.put("pref_warn_on_leaving_unsaved", StringUtils.toString(projectsTracker2Data.get(":warn_on_leaving_unsaved")));
		
		resultMap.put("projectsTrackerOthers", settingsMap);
		resultMap.put("projectsTracker", projectsTrackerData);
		logicBean.setData(resultMap);
		return logicBean;
	}	
	
	public void updateUserInfo() throws SoftbankException {
		Map<String, Object> userConditions = Maps.newHashMap();
		UserInfoData userInfoData = (UserInfoData)context.getSessionData().get(UserInfoData.USER_INFO_KEY);
		
		String user_firstname = context.getParam().get("user_firstname");
		String user_lastname = context.getParam().get("user_lastname");
		String user_mail = context.getParam().get("user_mail");
		String user_landing_page = context.getParam().get("user_landing_page");
		String user_mail_notification = context.getParam().get("user_mail_notification");
		String user_language = context.getParam().get("user_language");
		
		userConditions.put("id", userInfoData.getId());
		userConditions.put("firstname", user_firstname);
		userConditions.put("lastname", user_lastname);
		userConditions.put("mail", user_mail);
		userConditions.put("language", user_language);
		userConditions.put("mail_notification", user_mail_notification);
		userConditions.put("landing_page", user_landing_page);
		db.update("privateSetting.updateUser", userConditions);

		Map<String, Object> userPreferenceConditions = Maps.newHashMap();
		String no_self_notified = context.getParam().get("no_self_notified");
		String pref_hide_mail = context.getParam().get("pref_hide_mail");
		String pref_time_zone = context.getParam().get("pref_time_zone");
		String pref_comments_sorting = context.getParam().get("pref_comments_sorting");
		String pref_warn_on_leaving_unsaved = context.getParam().get("pref_warn_on_leaving_unsaved");
		String backlogs_task_color = context.getParam().get("backlogs_task_color");
		
		List<Map<String, Object>> projectsTrackerList = Lists.newArrayList();
		projectsTrackerList = db.querys("privateSetting.getPrivateSettingInfo", userConditions);
		Map<String, Object> projectsTrackerData = projectsTrackerList.get(0);
		String settingsValue = StringUtils.toString(projectsTrackerData.get("others"));
		Yaml yaml = new Yaml();
		Map<String, Object> projectsTracker2Data = (Map<String, Object>)yaml.load(settingsValue);
		Map<String, Object> userPreferenceList = Maps.newHashMap();
		for (Entry<String, Object> date : projectsTracker2Data.entrySet()){
			if (":warn_on_leaving_unsaved".equals(date.getKey())){
				userPreferenceList.put(":warn_on_leaving_unsaved",pref_warn_on_leaving_unsaved);
			}else if (":backlogs_task_color".equals(date.getKey())){
				userPreferenceList.put(":backlogs_task_color", "\'" + backlogs_task_color + "\'");
			}else if (":comments_sorting".equals(date.getKey())){
				userPreferenceList.put(":comments_sorting", pref_comments_sorting);
			}else if (":no_self_notified".equals(date.getKey())){
				if ("1".equals(no_self_notified)) {
					userPreferenceList.put(":no_self_notified",true);
				}else{
					userPreferenceList.put(":no_self_notified",false);
				}
			}else{
				userPreferenceList.put(date.getKey(), date.getValue());
			}
		}
		String yamlDate = org.ho.yaml.Yaml.dump(userPreferenceList);
		userPreferenceConditions.put("others", yamlDate.replace("\"", "").replace("!java.util.LinkedHashMap", ""));
		userPreferenceConditions.put("user_id", userInfoData.getId());
		if ("1".equals(pref_hide_mail)) {
			userPreferenceConditions.put("hide_mail", true);
		}else{
			userPreferenceConditions.put("hide_mail", false);
		}
		userPreferenceConditions.put("time_zone", pref_time_zone);
		db.update("privateSetting.updateUserPreferences", userPreferenceConditions);
	
	}	
	
}
