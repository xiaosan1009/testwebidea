package co.jp.softbank.qqmx.logic;

public class DefaultLogic extends AbstractBaseLogic {

}
