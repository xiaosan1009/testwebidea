package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.PageListBean;
import co.jp.softbank.qqmx.util.StringUtils;

public class StatuseListLogic extends AbstractBaseLogic {

	public void getStatuseListInfo() throws SoftbankException {
		if (StringUtils.isEmpty(context.getParam().get("statuse_flg"))){
			PageListBean pageListBean = pageList("statuseList.getStatuseListInfo");
			context.getResultBean().setData(pageListBean);
		} else {			
			List<Map<String, Object>> info = new ArrayList<Map<String, Object>>();
			info = db.querys("statuseList.getStatuseListInfo");
			if (info.size() > 0) {
				Map<String, Object> statusInfo = info.get(0);
				if ( StringUtils.isEmpty((statusInfo.get("position_start"))) 
						|| StringUtils.isEmpty(statusInfo.get("position_end")) 
						|| StringUtils.isEmpty(statusInfo.get("total_count")) 
						|| !"1".equals(StringUtils.toString(statusInfo.get("position_start")))
						|| !(StringUtils.toString(statusInfo.get("position_end")).equals(StringUtils.toString(statusInfo.get("total_count"))))) {
					db.update("statuseList.updatePosition");
				}
			}
		}
	}

	public void delStatuseListId() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("statuse_id", Integer.parseInt(context.getParam().get("statuse_id")));
		List<Map<String, Object>> statuseListIdList = db.querys("statuseList.getStatuseListIdInfo", conditions);
		conditions.put("position_id", Integer.parseInt(String.valueOf(statuseListIdList.get(0).get("position"))));
		
		db.update("statuseList.updataStatuses", conditions);
		db.delete("statuseList.delStatuseListId", conditions);
	}
	
	public LogicBean checkStatusName() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("name", context.getParam().get("issue_status_name"));
		
		if (StringUtils.isNotEmpty(context.getParam().get("flg"))) {
			conditions.put("id", StringUtils.toInt(context.getParam().get("flg")));
		}
		Integer count = db.queryo("statuseList.getStatusName", conditions);
		
		if (count > 0) {
			logicBean.setResultFlg(false);
			logicBean.setResultCode("301420.status_name_error_result");
		}
		return logicBean;
	}
	
	public void saveStatuses() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("name", context.getParam().get("issue_status_name"));
		if (StringUtils.isEmpty(context.getParam().get("issue_default_done_ratio"))) {
			conditions.put("default_done_ratio", null);
		} else {
			conditions.put("default_done_ratio", StringUtils.toInt(context.getParam().get("issue_default_done_ratio")));
		}
		conditions.put("is_default", "true".equals(context.getParam().get("issue_status_is_default")) ? true : false);
		conditions.put("is_closed", "true".equals(context.getParam().get("issue_status_is_closed")) ? true : false);
		
		if (!"0".equals(context.getParam().get("flg"))) {
			conditions.put("id", Integer.parseInt(context.getParam().get("flg")));
			db.update("statuseList.upStatuses", conditions);
		} else {
			db.insert("statuseList.saveStatuses", conditions);
		}
	}
	
	public LogicBean getStatuseIdInfo() throws SoftbankException {
		LogicBean statuseBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("statuse_id", Integer.parseInt(context.getParam().get("statuse_id")));
		statuseBean.setData(db.querys("statuseList.getStatuseListIdInfo", conditions));
		return statuseBean;
	}
	
	public void upStatuseSort() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		List<Map<String, Object>> statuseListEndIdList = db.querys("statuseList.getStatuseListInfo");
		String str_end_position = String.valueOf(statuseListEndIdList.get(Integer.parseInt(context.getParam().get("end_pos"))).get("position"));
		
		conditions.put("statuse_id", Integer.parseInt(context.getParam().get("statuse_id")));
		List<Map<String, Object>> statuseListIdList = db.querys("statuseList.getStatuseListIdInfo", conditions);
		if (Integer.parseInt(str_end_position) > Integer.parseInt(String.valueOf(statuseListIdList.get(0).get("position")))){
			conditions.put("end_pos", Integer.parseInt(str_end_position));
			conditions.put("start_pos", Integer.parseInt(String.valueOf(statuseListIdList.get(0).get("position"))));
			db.update("statuseList.upCommonMSort", conditions);
		}else{
			conditions.put("end_pos", Integer.parseInt(String.valueOf(statuseListIdList.get(0).get("position"))));
			conditions.put("start_pos", Integer.parseInt(str_end_position));
			db.update("statuseList.upCommonPSort", conditions);
		}
		Map<String, Object> conditionSort = Maps.newHashMap();
		conditionSort.put("statuse_id", Integer.parseInt(context.getParam().get("statuse_id")));
		conditionSort.put("end_pos", Integer.parseInt(str_end_position));
		db.update("statuseList.upCommonSort", conditionSort);

	}
	
//	public void updatePosition() throws SoftbankException {
//		
//		db.update("statuseList.updatePosition");
//		
//	}
}
