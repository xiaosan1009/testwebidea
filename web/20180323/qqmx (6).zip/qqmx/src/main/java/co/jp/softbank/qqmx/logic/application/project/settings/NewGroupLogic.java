package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.PageListBean;
import co.jp.softbank.qqmx.util.StringUtils;

public class NewGroupLogic extends AbstractBaseLogic {


	public void getGroupUserList() throws SoftbankException {
		String groupId = context.getParam().get("groupId");
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("group_id", Integer.parseInt(groupId));
		PageListBean pageListBean = pageList("newGroup.getGroupUserList", conditions);
		context.getResultBean().setData(pageListBean);
	}
	public LogicBean getGroupName() throws SoftbankException {
		LogicBean groupBean = new LogicBean();
		String groupId = context.getParam().get("groupId");
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("group_id", Integer.parseInt(groupId));
		groupBean.setData(db.querys("newGroup.getGroupName",conditions));
		return groupBean;
	}
	public void getGroupProjectList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String groupId = context.getParam().get("groupId");
		conditions.put("group_id", Integer.parseInt(groupId));
		PageListBean pageListBean = pageList("newGroup.getGroupProjectList", conditions);
		context.getResultBean().setData(pageListBean);
	}
	
	public LogicBean saveProjectSettingRole() throws SoftbankException {
		LogicBean groupBean = new LogicBean();
		String membersId = context.getParam().get("memberId");
		String[] projectSettingRole = context.getParam().getList("group_member_role_ids");
		if (projectSettingRole != null) {
			Map<String, Object> conditionsRole = Maps.newHashMap();
			conditionsRole.put("member_id", Integer.parseInt(membersId));
			List<Map<String, Object>> selectMemberUsersList = db.querys("newGroup.selectProjectSettingMemberUsers", conditionsRole);
			String project_id = "";
			if (selectMemberUsersList.size() != 0){
				project_id = String.valueOf(selectMemberUsersList.get(0).get("project_id"));
				db.delete("newGroup.deleteProjectSettingMemberUsers", conditionsRole);
			}
			for (int i = 0; i < projectSettingRole.length; i++) {
				conditionsRole.put("role_id", Integer.parseInt(projectSettingRole[i]));
				conditionsRole.put("inherited_from", null);
				db.insert("newGroup.insertProjectSettingMembers",conditionsRole);
				final int roleId = Integer.parseInt(StringUtils.toString(conditionsRole.get("id")));
				
				Map<String, Integer> conditionsMemberRole = Maps.newHashMap();
				conditionsMemberRole.put("member_id", Integer.parseInt(membersId));
				List<Map<String, Object>> selectGroupUserList = db.querys("newGroup.selectProjectSettingGroupMemberUsers",conditionsMemberRole);
				for (int m = 0; m < selectGroupUserList.size(); m++) {
					
					Map<String, Object> conditionsUser = Maps.newHashMap();
					conditionsUser.put("user_id", StringUtils.toInt(selectGroupUserList.get(m).get("user_id")));
					conditionsUser.put("project_id", Integer.parseInt(project_id));
					List<Map<String, Object>> selectMemberGroupUsersId = db.querys("newGroup.selectProjectGroupMembers", conditionsUser);
					
					for (int n = 0; n < selectMemberGroupUsersId.size(); n++) {
						
						Map<String, Object> conditionsGroupUserMembers = Maps.newHashMap();
						conditionsGroupUserMembers.put("member_id", Integer.parseInt(String.valueOf(selectMemberGroupUsersId.get(n).get("id"))));
						db.delete("newGroup.deleteProjectSettingMemberUsers", conditionsGroupUserMembers);
						conditionsGroupUserMembers.put("role_id", Integer.parseInt(projectSettingRole[i]));
						conditionsGroupUserMembers.put("inherited_from", roleId);
						db.insert("newGroup.insertProjectSettingMembers" ,conditionsGroupUserMembers);
					}
				}
			}
		}
		return groupBean;
	}
	
	public LogicBean selectUserList() throws SoftbankException {
		LogicBean groupBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		String groupId = context.getParam().get("groupId");
		conditions.put("group_id", Integer.parseInt(groupId));
		conditions.put("input_date", context.getParam().get("input_date"));
		groupBean.setData(db.querys("newGroup.selectUserList", conditions));
		return groupBean;
	}
	public void deleteGroupListUsers() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		String groupId = context.getParam().get("groupId");
		conditions.put("user_id", Integer.parseInt(context.getParam().get("user_id")));
		conditions.put("group_id", Integer.parseInt(groupId));
		db.delete("newGroup.deleteGroupListUsers",conditions);
		
		List<Map<String, Object>> selectProjectMemberList = db.querys("newGroup.selectProjectGroupMemberId", conditions);
		if (selectProjectMemberList.size() > 0){
			for (int i = 0; i < selectProjectMemberList.size(); i++) {
				String member_id = String.valueOf(selectProjectMemberList.get(i).get("id"));
				delMembersId(member_id);
				delMembersRolesId(member_id);
			}
		}
	}
	public void saveGroupNewUser() throws SoftbankException {
		String[] projectSettingUser = context.getParam().getList("new_group_member_user_ids");
		String groupId = context.getParam().get("groupId");
		for (int i = 0; i < projectSettingUser.length; i++) {
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("user_id", Integer.parseInt(projectSettingUser[i]));
			conditions.put("group_id", Integer.parseInt(groupId));
			db.insert("newGroup.saveGroupNewUser", conditions);
			
			List<Map<String, Object>> selectMemberList = db.querys("newGroup.selectMember" ,conditions);
			if (selectMemberList.size()>0){
				for (int b = 0; b < selectMemberList.size(); b++) {
					conditions.put("project_id", Integer.parseInt(String.valueOf(selectMemberList.get(b).get("project_id"))));
					db.insert("newGroup.insertProjectSettingUser", conditions);
					int memberId = Integer.parseInt(StringUtils.toString(conditions.get("id")));
					
					List<Map<String, Object>> selectProjectMemberList = db.querys("newGroup.selectProjectMember" ,conditions);
					if (selectProjectMemberList.size()>0){
						for (int m = 0; m < selectProjectMemberList.size(); m++) {
							Map<String, Object> conditionsMembers = Maps.newHashMap();
							conditionsMembers.put("member_id", memberId);
							conditionsMembers.put("role_id", Integer.parseInt(String.valueOf(selectProjectMemberList.get(m).get("role_id"))));
							conditionsMembers.put("inherited_from", Integer.parseInt(String.valueOf(selectProjectMemberList.get(m).get("member_roles_id"))));
							db.insert("newGroup.insertProjectSettingMembers", conditionsMembers);
						}
					}
				}
			}
			
		}
	}
	
	public LogicBean getProjectSettingRoleList() throws SoftbankException {
		LogicBean groupBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("member_id", Integer.parseInt(context.getParam().get("member_id")));
		groupBean.setData(db.querys("newGroup.getProjectSettingRoleList", conditions));
		return groupBean;
	}
	
	public LogicBean getProjectList() throws SoftbankException {
		LogicBean groupBean = new LogicBean();
		String groupId = context.getParam().get("groupId");
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("group_id", Integer.parseInt(groupId));
		conditions.put("input_date", context.getParam().get("input_date"));
		groupBean.setData(db.querys("newGroup.getProjectList", conditions));
		return groupBean;
	}
	
	public void deleteGroupListProjects() throws SoftbankException {
		String member_id = context.getParam().get("member_id");
		delMembersId(member_id);
		delMembersRolesId(member_id);
	}

	public void updateGroupName() throws SoftbankException {
		String name = context.getParam().get("name");
		String groupId = context.getParam().get("groupId");
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("name", name);
		conditions.put("group_id", Integer.parseInt(groupId));
		db.update("newGroup.updateGroupName",conditions);
	}
	
	public LogicBean checkNameExists() throws SoftbankException {
		LogicBean logicBean = new LogicBean();
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("group_name", context.getParam().get("name"));
		
		if (StringUtils.isNotEmpty(context.getParam().get("groupId"))) {
			conditions.put("group_id", StringUtils.toInt(context.getParam().get("groupId")));
		} else {
			conditions.put("group_id", 0);
		}
		
		Integer getGroupCount = db.queryo("groupList.getGroupCount", conditions);
		if (getGroupCount > 0) {
			logicBean.setResultFlg(false);
			logicBean.setResultCode("301413.group_name_error_result");
		}
		return logicBean;
	}
	
	public LogicBean saveProjectGroupUser() throws SoftbankException {
		
		String[] projectSettingProject = context.getParam().getList("member_project_ids");
		String[] projectSettingRole = context.getParam().getList("member_project_role_ids");
		String groupId = context.getParam().get("groupId");
		LogicBean groupBean = new LogicBean();
		Map<String, Integer> conditions = Maps.newHashMap();
		conditions.put("group_id", Integer.parseInt(groupId));
		List<Map<String, Object>> selectGroupUser = db.querys("newGroup.selectProjectSettingGroupUsers", conditions);
		//プロジェクト
		for (int i = 0; i < projectSettingProject.length; i++) {
			int project_id = Integer.valueOf(projectSettingProject[i]);
			
			Map<String, Object> conditionMembers = Maps.newHashMap();
			conditionMembers.put("project_id", project_id);
			conditionMembers.put("user_id", Integer.parseInt(groupId));
			db.insert("newGroup.insertProjectSettingUser", conditionMembers);
			int mGroupRoleId = Integer.parseInt(StringUtils.toString(conditionMembers.get("id")));
			int inherited_from_id = insertRole(projectSettingRole, project_id, mGroupRoleId, 0);
			//グループユーザ
			for (int j = 0; j < selectGroupUser.size(); j++) {
				conditionMembers.put("user_id", StringUtils.toInt(selectGroupUser.get(j).get("user_id")));
				List<Map<String, Object>> selectMemberGroupUsersId = db.querys("newGroup.selectProjectSettingMembers",conditionMembers);
				if (selectMemberGroupUsersId.size() == 0 ){
					
					db.insert("newGroup.insertProjectSettingUser", conditionMembers);
					int mUserRoleId = Integer.parseInt(StringUtils.toString(conditionMembers.get("id")));
					//ロール
					insertRole(projectSettingRole, project_id, mUserRoleId, inherited_from_id);
				}else{
					insertRole(projectSettingRole, project_id, Integer.valueOf(String.valueOf(selectMemberGroupUsersId.get(0).get("id"))), inherited_from_id);
				}
			}
		}
		return groupBean;
	}
	
	public int insertRole(String[] projectSettingRole, int project_id ,int members_id, int inherited_from) throws SoftbankException{
		int mUserRoleId = 0;
		for (int m = 0; m < projectSettingRole.length; m++) {
			Map<String, Object> conditionRoles = Maps.newHashMap();
			conditionRoles.put("member_id", members_id);
			conditionRoles.put("role_id", Integer.parseInt(projectSettingRole[m]));
			List<Map<String, Object>> selectMemberRoles = db.querys("newGroup.selectProjectMemberRoles" ,conditionRoles);
			
			if (selectMemberRoles.size() == 0){
				if (inherited_from == 0){
					conditionRoles.put("inherited_from", null);
				}else{
					conditionRoles.put("inherited_from", inherited_from);
				}
				db.insert("newGroup.insertProjectSettingMembers" ,conditionRoles);
				mUserRoleId = Integer.parseInt(StringUtils.toString(conditionRoles.get("id")));
			}
		}
		return mUserRoleId;
	}
	
	public void delMembersRolesId(String member_id) throws SoftbankException{
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("member_id", Integer.parseInt(member_id));
		db.delete("newGroup.deleteProjectSettingMemberUsers", conditions);
	}
	public void delMembersId(String member_id) throws SoftbankException{
		Map<String, Object> conditions = Maps.newHashMap();
		conditions.put("member_id", Integer.parseInt(member_id));
		db.delete("newGroup.deleteProjectSettingUser" ,conditions);
	}
}
