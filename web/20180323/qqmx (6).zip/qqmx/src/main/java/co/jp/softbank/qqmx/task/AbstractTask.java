package co.jp.softbank.qqmx.task;

import java.util.List;
import java.util.Map;
import java.util.concurrent.atomic.AtomicInteger;

import org.slf4j.Logger;

import co.jp.softbank.qqmx.dao.common.IDbExecute;
import co.jp.softbank.qqmx.handle.face.ITaskScriptFace;
import co.jp.softbank.qqmx.handle.face.IScriptUtilFace;
import co.jp.softbank.qqmx.task.face.IKey;
import co.jp.softbank.qqmx.task.face.IReader;
import co.jp.softbank.qqmx.task.face.ITask;
import co.jp.softbank.qqmx.task.face.ITaskContext;
import co.jp.softbank.qqmx.util.LogUtil;

public abstract class AbstractTask<IN> implements ITask<IN> {
	
	protected Logger log = new LogUtil(this.getClass()).getLog();
	
	private int numOfThreads;
	
	protected IDbExecute db;
	
	protected AtomicInteger lines;
	
	private IReader<? extends Object> reader;
	
	protected ITaskScriptFace script;

	@Override
	public void prepare(ITaskContext context) throws Exception {
		script.setHandlerMethod(context);
	}

	@Override
	public void cleanup(ITaskContext context) {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	@Override
	public boolean isMultiline() {
		// TODO 自動生成されたメソッド・スタブ
		return false;
	}

	@Override
	public boolean isPrepared() {
		// TODO 自動生成されたメソッド・スタブ
		return false;
	}

	@Override
	public int numOfThreads() {
		return numOfThreads;
	}

	public void setNumOfThreads(int numOfThreads) {
		this.numOfThreads = numOfThreads;
	}

	@Override
	public long considersHangupMills() {
		// TODO 自動生成されたメソッド・スタブ
		return 0;
	}

	@Override
	public Map<String, List<Object>> keyOrder() {
		// TODO 自動生成されたメソッド・スタブ
		return null;
	}

	@Override
	public void handleException(ITaskContext context, IN value, Exception cause) throws Exception {
		// TODO 自動生成されたメソッド・スタブ
	}
	
	public void setDb(IDbExecute db) {
		this.db = db;
	}

	@Override
	public void setLines(AtomicInteger lines) {
		this.lines = lines;
	}

	@Override
	public void execute(ITaskContext context, IKey key, IN value)
			throws Exception {
		// TODO 自動生成されたメソッド・スタブ
		
	}

	@Override
	public IReader<? extends Object> getReader() {
		return reader;
	}

	public void setReader(IReader<? extends Object> reader) {
		this.reader = reader;
	}

	public void setScript(ITaskScriptFace script) {
		this.script = script;
	}

}
