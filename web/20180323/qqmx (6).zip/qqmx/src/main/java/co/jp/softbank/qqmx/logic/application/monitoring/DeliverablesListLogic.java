package co.jp.softbank.qqmx.logic.application.monitoring;

import java.io.ByteArrayOutputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.PageListBean;

import com.google.common.collect.Maps;

public class DeliverablesListLogic extends AbstractBaseLogic {
	
	
	public void getDeliverables() throws SoftbankException {
		
		Map<String, Object> conditions = select();
		
		List<Map<String, Object>> info = db.querys("deliverables.getDeliverables", conditions);
		
		context.getResultBean().setData(info);
		
	}

	public void getDeliverablesList() throws SoftbankException {
		
		Map<String, Object> conditions = select();
		PageListBean pageListBean = pageList("deliverables.getDeliverablesList", conditions);
		List<Map<String, Object>> list = pageListBean.getDatas();
		
		for(int i = 0;i < list.size();i++){
			
			// 指摘件数
			conditions = Maps.newHashMap();
			conditions.put("issue_id", Integer.valueOf(list.get(i).get("issue_id").toString()));
			List<Map<String, Object>> checkList = db.querys("deliverables.getCheckCount", conditions);
			int check_num = checkList.size();
			list.get(i).put("check_num", check_num);
			int totalNum = Integer.valueOf(list.get(i).get("total").toString()) + checkList.size();
			list.get(i).put("total", totalNum);
			
			// filename
//			String filename = list.get(i).get("filename").toString();
//			filename = filename.substring(filename.lastIndexOf("\\")+1, filename.length());
//			list.get(i).put("filename", filename);
					
			//　遅延原因
			String delay_reason = "";
			Integer plan_days = Integer.valueOf(list.get(i).get("plan_days").toString());
			if(plan_days > 0){
				delay_reason = "スケジュール着手遅れ";
			}
			
			Integer delay_ratio = Integer.valueOf(list.get(i).get("delay_ratio").toString());
			if(delay_ratio >= 20 ){
				if(delay_reason.length() == 0){
					delay_reason = "生産性悪い";
				}else{
					delay_reason = delay_reason + "</br>" + "生産性悪い";
				}
			}
			
			conditions = Maps.newHashMap();
			if(list.get(i).get("assigned_to_id")!=null && list.get(i).get("assigned_to_id").toString().length() != 0){
				Integer assigned_to_id = Integer.valueOf(list.get(i).get("assigned_to_id").toString());
				conditions.put("authorId", assigned_to_id);
				conditions.put("issue_id", list.get(i).get("issue_id"));
				conditions.put("projectId", list.get(i).get("project_id"));
				SimpleDateFormat sdf= new SimpleDateFormat("yyyy-MM-dd");
				try {
					conditions.put("start_date", sdf.parse(list.get(i).get("start_date1").toString()));
					conditions.put("due_date", sdf.parse(list.get(i).get("due_date1").toString()));
				} catch (ParseException e) {
					log.error(e.getMessage(), e);
					e.printStackTrace();
				}
				
				// TODO 10281
				Map<String, Object> map = db.query("deliverables.getHoursByDay", conditions);
				if(map != null){
					Double d = (Double)map.get("hours");
					if(d > 9.6){
						if(delay_reason.length() == 0){
							delay_reason = "工数不足";
						}else{
							delay_reason = delay_reason + "</br>" + "工数不足";
						}
					}
				}
			}
			
			list.get(i).put("delay_reason", delay_reason);
		}
		
		context.getResultBean().setData(pageListBean);
		
	}
	
	
	public void getSystemList() throws SoftbankException{
		Map<String, Object> conditions = select();
		
		List<Map<String, Object>> info = db.querys("deliverables.getDeliverables", conditions);
		
		List<Map<String, Object>> systemList = db.querys("deliverables.getSystemList", conditions);
		
		List<Map<String, Object>> versionList = db.querys("deliverables.getVersionList", conditions);
		
		List<Map<String, Object>> authorList = db.querys("deliverables.getAuthorList", conditions);
		
		List<Map<String, Object>> documentList = db.querys("deliverables.getDocumentList", conditions);
//		for(int j = 0;j < documentList.size();j++){
//			// filename
//			String filename = documentList.get(j).get("filename").toString();
//			filename = filename.substring(filename.lastIndexOf("\\")+1, filename.length());
//			documentList.get(j).put("filename", filename);
//		}
		
		Map<String, Object> listMap = Maps.newHashMap();
		listMap.put("systemList", systemList);
		listMap.put("versionList", versionList);
		listMap.put("authorList", authorList);
		listMap.put("documentList", documentList);
		
        //レビュー状況設定の為追加部分↓
		int totalCount = 0;
		int unfinished = 0;
		// 誤字脱字&コメント件数
		List<Map<String, Object>> errorList = db.querys("deliverables.getDeliverablesList", conditions);
		for(int i = 0;i < errorList.size();i++){
			//conditions = Maps.newHashMap();
			conditions.put("issue_id", Integer.valueOf(errorList.get(i).get("issue_id").toString()));
			List<Map<String, Object>> checkList = db.querys("deliverables.getCheckCount", conditions);
			int check_num = Integer.valueOf(errorList.get(i).get("comment_count").toString()) + checkList.size();
			errorList.get(i).put("check_num", check_num);
			int totalNum = Integer.valueOf(errorList.get(i).get("total").toString()) + checkList.size();
			errorList.get(i).put("total", totalNum);
			totalCount = totalCount + totalNum;
			unfinished = unfinished + check_num;
		}

		Map<String, Object> mapInfo = Maps.newHashMap();
		mapInfo.put("num", info.get(0).get("num"));
		mapInfo.put("review_end", info.get(0).get("review_end"));
		mapInfo.put("unreview_end", info.get(0).get("unreview_end"));
		mapInfo.put("totalCount", totalCount);
		mapInfo.put("finished",(Integer.valueOf(totalCount) - Integer.valueOf(unfinished)));
		mapInfo.put("unfinished", unfinished);
		info.set(0,mapInfo);
		//レビュー状況設定の為追加部分↑
		listMap.put("info", info);
		
		context.getResultBean().setData(listMap);
	}
	
	
	public Map<String, Object> select(){
		
		Map<String, Object> conditions = Maps.newHashMap();
		
		String projectId = context.getParam().get("projectId");
		String systemId = context.getParam().get("systemId");
		String versionId = context.getParam().get("versionId");
		String authorId = context.getParam().get("authorId");
		String documentId = context.getParam().get("documentId");
		if(!"".equals(versionId) && versionId != null){
			conditions.put("versionId", Integer.parseInt(versionId));
		}
		if(!"".equals(authorId) && authorId != null){
			conditions.put("authorId", Integer.parseInt(authorId));
		}
		if(!"".equals(systemId) && systemId != null){
			conditions.put("systemId", systemId);
		}
		if (!"".equals(projectId) && projectId != null){
			conditions.put("projectId", Integer.parseInt(projectId));
		}else{
			conditions.put("projectId", 0);
		}
		if (!"".equals(documentId) && documentId != null){
			conditions.put("documentId", Integer.parseInt(documentId));
		}
		
		return conditions;
	}
	
	public void fileCopy() throws SoftbankException, ParseException {
		String documentId = context.getParam().get("document_id");
		externalHttpServer.post(messageAccessor.getMessage("application.path") + ":8080/qqrp/qqrp.mx?dispCode=900007&cmdCode=1&issueId=" + documentId); //fileCopy
	}
	
	/**
	* @param urlStr
	* @param fileName
	* @param savePath
	* @throws IOException
	*/
	public void mdDownLoad() throws IOException {
		
		try {
			String urlStr = context.getParam().get("urlStr");
			String fileName = context.getParam().get("fileName");
			String savePath = System.getProperties().getProperty("user.home") + context.getParam().get("savePath") + System.currentTimeMillis() ;
			
			URL url = new URL(urlStr);  
			HttpURLConnection conn = (HttpURLConnection)url.openConnection();  

			conn.setConnectTimeout(3*1000);

			InputStream inputStream = conn.getInputStream();  

			byte[] getData = readInputStream(inputStream);    


			File saveDir = new File(savePath);
			if(!saveDir.exists()){
				saveDir.mkdir();
			}
			File file = new File(saveDir+File.separator+fileName);
			FileOutputStream fos = new FileOutputStream(file);
			fos.write(getData); 
			if(fos!=null){
				fos.close();  
			}
			if(inputStream!=null){
				inputStream.close();
			}
			
			Runtime.getRuntime().exec("explorer.exe /select," + (savePath + "//" + fileName).replace("//", "\\"));
		} catch (IOException e) {
			// TODO 自動生成された catch ブロック
			e.printStackTrace();
		}

	}
	/**
	* @param inputStream
	* @return
	* @throws IOException
	*/
	public static  byte[] readInputStream(InputStream inputStream) throws IOException {  
		byte[] buffer = new byte[1024];  
		int len = 0;  
		ByteArrayOutputStream bos = new ByteArrayOutputStream();
		while((len = inputStream.read(buffer)) != -1) {
			bos.write(buffer, 0, len);
		}
		bos.close();  
		return bos.toByteArray();  
	}
}
