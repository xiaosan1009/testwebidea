package co.jp.softbank.qqmx.logic.application.project.settings;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

//import co.jp.softbank.qqmx.dao.project.settings.projectList;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.PageListBean;
import co.jp.softbank.qqmx.util.StringUtils;

public class PrjectListLogic extends AbstractBaseLogic {

//	@Autowired
//	private projectList projectList;
	
	public void getProjectList() throws SoftbankException {
		Map<String, Object> conditions = Maps.newHashMap();
		int status = 1;
		if (StringUtils.isNotEmpty(context.getParam().get("status"))) {
			status = Integer.parseInt(context.getParam().get("status"));
		}
		conditions.put("status", status);
		conditions.put("user_name", context.getParam().get("user_name"));
		PageListBean pageListBean = pageList("prjectlist.getProjectList", conditions);

		context.getResultBean().setData(pageListBean);
	}

	public void updateProjectSave() throws SoftbankException {
		Map<String, Object> conditionsProjectId = Maps.newHashMap();
		int project_id = Integer.parseInt(context.getParam().get("project_id"));
		conditionsProjectId.put("id", project_id);
		
		if ("9".equals(context.getParam().get("status_id"))){
			// 親プロジェクトの検索。
			List<Map<String, Object>> selectProjectId = db.querys("prjectlist.selectProjectIdList",conditionsProjectId);
			
			for (int n=0; n<selectProjectId.size(); n++){
				Map<String, Object> conditions = Maps.newHashMap();
				conditions.put("status", Integer.parseInt(context.getParam().get("status_id")));
				conditions.put("id", selectProjectId.get(n).get("id"));
				db.update("prjectlist.updateProjectSave", conditions);
			}
		}else{
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("status", Integer.parseInt(context.getParam().get("status_id")));
			conditions.put("id", project_id);
			db.update("prjectlist.updateProjectSave", conditions);
		}
	}
	
	public void deleteProject() throws SoftbankException {
		Map<String, Object> conditionsProjectId = Maps.newHashMap();
		
		int project_id = Integer.parseInt(context.getParam().get("project_id"));
		conditionsProjectId.put("id", project_id);
		
		List<Map<String, Object>> projectInfo = db.querys("prjectlist.getProjectInfo", conditionsProjectId);
		int lft = StringUtils.toInt(projectInfo.get(0).get("rgt"));
		
		// 親プロジェクトの検索。
		List<Map<String, Object>> selectProjectId = db.querys("prjectlist.selectProjectIdList", conditionsProjectId);
		int lft_all = selectProjectId.size() * 2;
		Map<String, Object> conditionslft = Maps.newHashMap();
		conditionslft.put("lft", lft);
		conditionslft.put("lft_all", lft_all);
		db.update("prjectlist.upProjectLft", conditionslft);
		
		// 親プロジェクト、サブプロジェクトの削除する。
		for (int n=0; n<selectProjectId.size(); n++){
			Map<String, Object> conditions = Maps.newHashMap();
			conditions.put("id", selectProjectId.get(n).get("id"));
			
			// Issues関連テーブル
			db.delete("prjectlist.deleteProjectIssuesJournalDetails",conditions);
			db.delete("prjectlist.deleteProjectIssuesJournals",conditions);
			db.delete("prjectlist.deleteProjectIssuesIssueRelations",conditions);
			db.delete("prjectlist.deleteProjectIssuesCustomValues",conditions);
			db.delete("prjectlist.deleteProjectIssuesWatchers",conditions);
			db.delete("prjectlist.deleteProjectIssuesAttachments",conditions);
			db.delete("prjectlist.deleteProjectIssuesUserIssueMonths",conditions);
			db.delete("prjectlist.deleteProjectIssues",conditions);
			// Wikis関連テーブル
			List<Map<String, Object>> selectProjectWikis = db.querys("prjectlist.selectProjectWikis", conditions);
			Map<String, Object> conditionsWikis = Maps.newHashMap();
			if (selectProjectWikis.size() > 0){
				conditionsWikis.put("wiki_id", selectProjectWikis.get(0).get("id"));
				db.delete("prjectlist.deleteProjectWikiRedirects", conditionsWikis);
				db.delete("prjectlist.deleteProjectWatchers", conditionsWikis);
				db.delete("prjectlist.deleteProjectWikiAttachments", conditionsWikis);
				db.delete("prjectlist.deleteProjectWikiPages", conditionsWikis);
				db.delete("prjectlist.deleteProjectWikiContents", conditionsWikis);
				db.delete("prjectlist.deleteProjectWikis", conditionsWikis);
			}
			
			// repositoriesリポジトリ情報
			db.delete("prjectlist.deleteProjectChanges", conditions);
			db.delete("prjectlist.deleteProjectChangesetsIssues", conditions);
			db.delete("prjectlist.deleteProjectChangesets", conditions);
			db.delete("prjectlist.deleteProjectRepositories", conditions);
			
			
			// Project関連テーブル
			db.delete("prjectlist.deleteProjectWtMemberOrders", conditions);
			db.delete("prjectlist.deleteProjectGraphPatterns", conditions);
			db.delete("prjectlist.deleteProjectDashboards", conditions);
			db.delete("prjectlist.deleteProjectMetricsLinks", conditions);
			db.delete("prjectlist.deleteProjectBoards", conditions);
			db.delete("prjectlist.deleteProjectNews", conditions);
			db.delete("prjectlist.deleteProjectDocuments", conditions);
			db.delete("prjectlist.deleteProjectVersions", conditions);
			db.delete("prjectlist.deleteProjectEnabledModules", conditions);
			db.delete("prjectlist.deleteProjectTimeEntries", conditions);
			db.delete("prjectlist.deleteProjectQueries", conditions);
			db.delete("prjectlist.deleteProjectIssueCategories", conditions);
			db.delete("prjectlist.deleteProjectCustomValues", conditions);
			db.delete("prjectlist.deleteProjectMemberRoles", conditions);
			db.delete("prjectlist.deleteProjectMembers", conditions);
			db.delete("prjectlist.deleteProjectCustomFieldsProjects", conditions);
			db.delete("prjectlist.deleteProjectProjectsTrackers", conditions);
			db.delete("prjectlist.deleteProjectAttachments", conditions);
			db.delete("prjectlist.deleteProjectProjects", conditions);
			db.delete("prjectlist.deleteProjectRelation", conditions);
			
		}
	}
}
