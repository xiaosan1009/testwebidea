package co.jp.softbank.qqmx.task.face;

import java.util.concurrent.Callable;

public interface IWorker extends Callable<IWorker> {
	
	void cleanup() throws Exception;

}
