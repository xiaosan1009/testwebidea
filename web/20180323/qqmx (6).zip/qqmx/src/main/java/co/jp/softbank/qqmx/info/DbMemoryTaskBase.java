package co.jp.softbank.qqmx.info;

import java.util.TimerTask;

import org.slf4j.Logger;

import co.jp.softbank.qqmx.util.LogUtil;

public abstract class DbMemoryTaskBase extends TimerTask {

	protected Logger log = new LogUtil(this.getClass()).getLog();
	
}
