package co.jp.softbank.qqmx.util;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class LogUtil {
	
	public static final String UP_TAG = "↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑↑";
	
	public static final String DOWN_TAG = "↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓↓";
	
	private Logger log;
	
	public LogUtil(Class<?> clazz) {
		log = LoggerFactory.getLogger(clazz);
	}
	
	public Logger getLog() {
		return log;
	}
	
	public static String s() {
		return s(null);
	}
	
	public static String s(String tag) {
		if (StringUtils.isEmpty(tag)) {
			tag = "";
		}
		return DOWN_TAG + tag + "[start]" + DOWN_TAG;
	}
	
	public static String e() {
		return e(null);
	}
	
	public static String e(String tag) {
		if (StringUtils.isEmpty(tag)) {
			tag = "";
		}
		return UP_TAG + tag + "[end]" + UP_TAG;
	}

}
