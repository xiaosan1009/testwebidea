package co.jp.softbank.qqmx.dao.issues;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.dao.IDaoInterface;
import co.jp.softbank.qqmx.dao.issues.bean.IssuesBean;
import co.jp.softbank.qqmx.dao.issues.bean.IssuesPersonBean;

public interface IssuesDao extends IDaoInterface {
	
	List<IssuesBean> selectAllIssues();
	
	List<IssuesBean> selectNotFinishedIssuesForUser(Map<String, Object> param);
	
	List<IssuesPersonBean> selectIssuesPersonInfoByUser(Map<String, Object> param);
	
	List<IssuesPersonBean> selectIssuesPersonInfoByIssuesId(Map<String, Object> param);
	
	void insertIssuesPersonInfos(Map<String, Object> param);
	
	void insertIssuesPersonInfo(IssuesPersonBean param);
	
	void updateIssuesInfo(IssuesBean issuesBean);
	
	void updateIssuesPersonInfo(IssuesPersonBean personBean);
	
	void deleteIssuesPersonInfo(IssuesPersonBean personBean);

}
