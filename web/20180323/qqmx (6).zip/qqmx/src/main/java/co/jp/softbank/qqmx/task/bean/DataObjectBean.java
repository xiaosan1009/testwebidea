package co.jp.softbank.qqmx.task.bean;

import co.jp.softbank.qqmx.task.face.ICollectorStatus;
import co.jp.softbank.qqmx.task.info.ExceptionHandlerStatus;

public class DataObjectBean {
	
	private Object value;
	
	private Throwable throwable;
	
	private long index = -1;
	
	private ExceptionHandlerStatus exceptionStatus;
	
	protected ICollectorStatus collectorStatus = null;
	
	public DataObjectBean(Object value) {
        this.value = value;
    }
	
	public DataObjectBean(Object value, long index) {
        this.value = value;
        this.index = index;
    }
	
	public DataObjectBean(Throwable throwable) {
        this.throwable = throwable;
    }
	
	public DataObjectBean(Throwable throwable, long index) {
        this.throwable = throwable;
        this.index = index;
    }
	
	public DataObjectBean(ICollectorStatus collectorStatus) {
        this.collectorStatus = collectorStatus;
    }

	public Object getValue() {
		return value;
	}

	public void setValue(Object value) {
		this.value = value;
	}

	public Throwable getThrowable() {
		return throwable;
	}

	public void setThrowable(Throwable throwable) {
		this.throwable = throwable;
	}

	public long getIndex() {
		return index;
	}

	public void setIndex(long index) {
		this.index = index;
	}

	public ExceptionHandlerStatus getExceptionStatus() {
		return exceptionStatus;
	}

	public void setExceptionStatus(ExceptionHandlerStatus exceptionStatus) {
		this.exceptionStatus = exceptionStatus;
	}

	public ICollectorStatus getCollectorStatus() {
		return collectorStatus;
	}

	public void setCollectorStatus(ICollectorStatus collectorStatus) {
		this.collectorStatus = collectorStatus;
	}

}
