package co.jp.softbank.qqmx.info.bean;

import java.util.Map;

public class BacklogRefreshDataBean {
	
	private String key;
	
	private BacklogRefreshDataType type;
	
	private int userId;
	
	private String backgroundColor;
	
	private Map<String, Object> taskInfo;
	
	public BacklogRefreshDataBean(BacklogRefreshDataType type) {
		this.type = type;
	}

	public String getKey() {
		return key;
	}

	public void setKey(String key) {
		this.key = key;
	}
	
	public BacklogRefreshDataType getType() {
		return type;
	}

	public void setType(BacklogRefreshDataType type) {
		this.type = type;
	}

	public int getUserId() {
		return userId;
	}

	public void setUserId(int userId) {
		this.userId = userId;
	}

	public String getBackgroundColor() {
		return backgroundColor;
	}

	public void setBackgroundColor(String backgroundColor) {
		this.backgroundColor = backgroundColor;
	}

	public Map<String, Object> getTaskInfo() {
		return taskInfo;
	}

	public void setTaskInfo(Map<String, Object> taskInfo) {
		this.taskInfo = taskInfo;
	}

	public enum BacklogRefreshDataType {
		def, userColor, taskChange;
	}

}
