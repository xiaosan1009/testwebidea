package co.jp.softbank.qqmx.dao.project.settings;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.dao.IDaoInterface;

public interface SettingDao extends IDaoInterface {
	List<Map<String, Object>> getSettingsInfo(Map<String, Object> conditions);
	List<Map<String, Object>> getProjectEnabledScmInfos(Map<String, Object> conditions);
	List<Map<String, Object>> getSettings();
	List<Map<String, Object>> getProjectRolesInfos();
	List<Map<String, Object>> getIssueListDefaultColumns();
	List<Map<String, Object>> getCustomFieldsList();
	List<Map<String, Object>> getProjectNotificationOptionInfos();
	List<Map<String, Object>> getProjectIssueStatusesInfos();
	List<Map<String, Object>> getProjectEnumerationsInfos();
	void updataSettings(Map<String, Object> conditions);

}
