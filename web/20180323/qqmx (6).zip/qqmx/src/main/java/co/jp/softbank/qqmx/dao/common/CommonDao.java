package co.jp.softbank.qqmx.dao.common;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.dao.IDaoInterface;
import co.jp.softbank.qqmx.dao.common.bean.HolidaysBean;
import co.jp.softbank.qqmx.dao.common.bean.PluginInfoBean;
import co.jp.softbank.qqmx.dao.roles.bean.RolesBaseBean;

public interface CommonDao extends IDaoInterface {
	
	List<HolidaysBean> selectHolidaysInfo();
	
	List<PluginInfoBean> selectPluginInfo();
	
	List<RolesBaseBean> selectAllRolesBaseInfo();
	
	Map<String, Long> executeSqlForPageCount(Map<String, Object> conditions);
	
	List<Map<String, Object>> executeSqlForPage(Map<String, Object> conditions);
	
	List<Map<String, Object>> getEnabledScmInfos();

}
