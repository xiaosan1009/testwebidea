package co.jp.softbank.qqmx.logic.application.test;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;

public class TestRollBackLogic extends AbstractBaseLogic {
	
	public void doExecute() throws SoftbankException {
		db.insert("testTbl.addTestTbl");
//		throw new SoftbankException(SoftbankExceptionType.SystemException); 
	}

}
