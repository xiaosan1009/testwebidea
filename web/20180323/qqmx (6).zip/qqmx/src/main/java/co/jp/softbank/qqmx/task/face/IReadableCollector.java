package co.jp.softbank.qqmx.task.face;

import java.util.Iterator;


public interface IReadableCollector<V> extends IOutputCollector<V> {

	Iterator<V> iterator(IKey key);
}
