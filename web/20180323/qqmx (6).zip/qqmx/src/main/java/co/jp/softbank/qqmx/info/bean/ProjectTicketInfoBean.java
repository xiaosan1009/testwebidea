package co.jp.softbank.qqmx.info.bean;

import java.util.List;
import java.util.Map;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.logic.application.face.IssueKey;
import co.jp.softbank.qqmx.util.StringUtils;

public class ProjectTicketInfoBean {
	
	private List<Map<String, Object>> datas;
	
	private List<Map<String, Object>> projectList;
	
	private Map<String, Integer> issueMapping = Maps.newHashMap();
	
	private String minStartDate;
	
	private String maxEndDate;
	
	private Map<String, Map<String, Object>> projectProgressInfo;
	
	private Map<String, Map<String, Object>> versionProgressInfo;

	public List<Map<String, Object>> getDatas() {
		return datas;
	}

	public void setDatas(List<Map<String, Object>> datas) {
		this.datas = datas;
		createIssueMapping();
	}

	public List<Map<String, Object>> getProjectList() {
		return projectList;
	}

	public void setProjectList(List<Map<String, Object>> projectList) {
		this.projectList = projectList;
	}

	public String getMinStartDate() {
		return minStartDate;
	}

	public void setMinStartDate(String minStartDate) {
		if (StringUtils.isEmpty(minStartDate)) {
			return;
		}
		if (StringUtils.isEmpty(this.minStartDate) || this.minStartDate.compareTo(minStartDate) > 0) {
			this.minStartDate = minStartDate;
		}
	}

	public String getMaxEndDate() {
		return maxEndDate;
	}

	public void setMaxEndDate(String maxEndDate) {
		if (StringUtils.isEmpty(maxEndDate)) {
			return;
		}
		if (StringUtils.isEmpty(this.maxEndDate) || this.maxEndDate.compareTo(maxEndDate) < 0) {
			this.maxEndDate = maxEndDate;
		}
	}

	public void createIssueMapping(ProjectTicketInfoBean bean) {
		issueMapping.clear();
		issueMapping.putAll(bean.getIssueMapping());
	}
	
	public Map<String, Integer> getIssueMapping() {
		return issueMapping;
	}

	public void setIssueMapping(Map<String, Integer> issueMapping) {
		this.issueMapping = issueMapping;
	}
	
	/**
	 * チケット存在するかどうかを判断する
	 * @param issueId
	 * @return
	 */
	public boolean issueExist(String issueId) {
		return issueMapping.containsKey(issueId);
	}
	
	public Map<String, Object> getIssueData(String issueId) {
		return datas.get(issueMapping.get(issueId));
	}

	private void createIssueMapping() {
		issueMapping.clear();
		if (datas != null && datas.size() > 0) {
			for (int i = 0; i < datas.size(); i++) {
				Map<String, Object> data = datas.get(i);
				issueMapping.put(StringUtils.toString(data.get(IssueKey.ISSUE_ID.KEY_JSON)), i);
			}
		}
	}

	public Map<String, Map<String, Object>> getProjectProgressInfo() {
		return projectProgressInfo;
	}

	public void setProjectProgressInfo(Map<String, Map<String, Object>> projectProgressInfo) {
		this.projectProgressInfo = projectProgressInfo;
	}

	public Map<String, Map<String, Object>> getVersionProgressInfo() {
		return versionProgressInfo;
	}

	public void setVersionProgressInfo(Map<String, Map<String, Object>> versionProgressInfo) {
		this.versionProgressInfo = versionProgressInfo;
	}
	
	public void setProgressInfoForProject(Map<String, Object> projectInfo) {
		if (projectProgressInfo != null && projectProgressInfo.containsKey(StringUtils.toString(projectInfo.get("id")))) {
			Map<String, Object> progress = projectProgressInfo.get(StringUtils.toString(projectInfo.get("id")));
			projectInfo.put(IssueKey.START_DATE.KEY_JSON, progress.get("start_date"));
			projectInfo.put(IssueKey.DUE_DATE.KEY_JSON, progress.get("due_date"));
			projectInfo.put(IssueKey.ESTIMATED_HOURS.KEY_JSON, progress.get("estimated_hours"));
			projectInfo.put("exp", progress.get("expected"));
			projectInfo.put("act", progress.get("actual"));
		}
	}
	
	public void setProgressInfoForVersion(Map<String, Object> versionMap) {
		setProgressInfoForVersion(versionMap, StringUtils.toString(versionMap.get("id")));
	}
	
	public void setProgressInfoForVersion(Map<String, Object> versionMap, String versionId) {
		if (versionProgressInfo != null && versionProgressInfo.containsKey(versionId)) {
			Map<String, Object> progress = versionProgressInfo.get(versionId);
			versionMap.put(IssueKey.START_DATE.KEY_JSON, progress.get("start_date"));
			versionMap.put(IssueKey.DUE_DATE.KEY_JSON, progress.get("due_date"));
			versionMap.put(IssueKey.ESTIMATED_HOURS.KEY_JSON, progress.get("estimated_hours"));
			versionMap.put("exp", progress.get("expected"));
			versionMap.put("act", progress.get("actual"));
		}
	}

}
