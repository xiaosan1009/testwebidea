package co.jp.softbank.qqmx.dao.project.settings;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.dao.IDaoInterface;

public interface GroupListDao extends IDaoInterface {
	List<Map<String, Object>> getGroupList(Map<String, Object> conditions);
	List<Map<String, Integer>> selectProjectSettingMembers(Map<String, Integer> conditions);
	void saveGroup(Map<String, Object> conditions);
	void deleteGroup(Map<String, Integer> conditions);
	void deleteGroupUsers(Map<String, Integer> conditions);
	void deleteProjectSettingMemberUsers(Map<String, Integer> conditions);
	void deleteProjectSettingUser(Map<String, Integer> conditions);
}
