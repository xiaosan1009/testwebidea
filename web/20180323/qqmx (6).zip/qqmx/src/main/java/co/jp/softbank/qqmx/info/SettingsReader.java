package co.jp.softbank.qqmx.info;

import org.slf4j.Logger;
import org.w3c.dom.Document;
import org.w3c.dom.Element;
import org.w3c.dom.NodeList;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.bean.SettingInfoBean;
import co.jp.softbank.qqmx.util.LogUtil;

public class SettingsReader extends ReadXml {
	
	private Logger log = new LogUtil(this.getClass()).getLog();
	
	
	private static final String SETTING = "setting";
	
	private static final String KEY = "key";
	
	private static final String VALUE = "value";

	public SettingsReader(String path) throws SoftbankException {
		super(path);
	}
	
	public SettingInfoBean read() {
		if (docs == null || docs.size() == 0) {
			return null;
		}
		
		SettingInfoBean settingInfoBean = new SettingInfoBean();
		
		for (int i = 0; i < docs.size(); i++) {
			analyze(docs.get(i), settingInfoBean);
		}
		
		return settingInfoBean;
	}
	
	private void analyze(Document doc, SettingInfoBean settingInfoBean) {
		setSettings(doc, settingInfoBean);
	}
	
	private void setSettings(Document doc, SettingInfoBean settingInfoBean) {
		
		final NodeList settingList = doc.getElementsByTagName(SETTING);
		
		for (int i = 0; i < settingList.getLength(); i++) {
			final Element settingElement = (Element)settingList.item(i);
			setSetting(settingElement, settingInfoBean);
		}
	}

	private void setSetting(Element dispElement, SettingInfoBean settingInfoBean) {
		final String key = dispElement.getAttribute(KEY);
		final String value = dispElement.getAttribute(VALUE);
		settingInfoBean.putSetting(key, value);
	}
	

}
