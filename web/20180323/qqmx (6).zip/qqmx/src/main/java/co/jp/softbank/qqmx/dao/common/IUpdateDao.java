package co.jp.softbank.qqmx.dao.common;

import java.util.List;
import java.util.Map;

import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.dao.common.DbExecuteImpl.MakeConditionsListener;
import co.jp.softbank.qqmx.exception.SoftbankException;

public interface IUpdateDao {
	
	int insert(String sqlID) throws SoftbankException;
	
	int insert(String sqlID, Object conditions) throws SoftbankException;
	
	int update(String sqlID) throws SoftbankException;
	
	int update(String sqlID, Object conditions) throws SoftbankException;
	
	int delete(String sqlID) throws SoftbankException;
	
	int delete(String sqlID, Object conditions) throws SoftbankException;
	
	void deletes(String sqlID, List<Map<String, Object>> datas) throws SoftbankException;
	
	int insertC(String sqlID) throws SoftbankException;
	
	int insertC(String sqlID, Object conditions) throws SoftbankException;
	
	int updateC(String sqlID) throws SoftbankException;
	
	int updateC(String sqlID, Object conditions) throws SoftbankException;
	
	void updates(String sqlID, List<Map<String, Object>> datas, MakeConditionsListener listener) throws SoftbankException;
	
	int deleteC(String sqlID) throws SoftbankException;
	
	int deleteC(String sqlID, Object conditions) throws SoftbankException;
	
	void inserts(String sqlID, List<Map<String, Object>> datas, MakeConditionsListener listener) throws SoftbankException;
	
	void ins(String sqlID, List<Map<String, Object>> datas) throws SoftbankException;

}
