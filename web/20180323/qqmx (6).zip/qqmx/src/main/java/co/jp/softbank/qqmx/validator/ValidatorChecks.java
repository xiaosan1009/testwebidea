package co.jp.softbank.qqmx.validator;

import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;
import java.math.BigDecimal;
import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.commons.validator.Field;
import org.apache.commons.validator.GenericTypeValidator;
import org.apache.commons.validator.GenericValidator;
import org.apache.commons.validator.ValidatorAction;
import org.apache.commons.validator.ValidatorException;
import org.apache.commons.validator.util.ValidatorUtils;
import org.slf4j.Logger;
import org.springframework.context.ApplicationContext;

import com.google.common.collect.Maps;

import co.jp.softbank.qqmx.application.CustomLoaderListener;
import co.jp.softbank.qqmx.application.bean.HttpContext;
import co.jp.softbank.qqmx.dao.common.IDbExecute;
import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.info.ControlRequestMap;
import co.jp.softbank.qqmx.logic.AbstractBaseLogic;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.util.DateUtils;
import co.jp.softbank.qqmx.util.LogUtil;
import co.jp.softbank.qqmx.util.StringUtils;
import co.jp.softbank.qqmx.util.ValidationUtil;

public class ValidatorChecks extends BaseValidatorChecks {

	private Logger log = new LogUtil(this.getClass()).getLog();

	public boolean validateRequired(Object bean, Map<String, Object> param, ValidatorAction va, Field field, IValidationErrors errors) {
		// 検証値
		String value = extractValue(bean, param, field);

		// 検証
		if (GenericValidator.isBlankOrNull(value)) {
			rejectValue(errors, field, va, bean);
			return false;
		}
		return true;
	}
	
	public boolean validateListRequired(Object bean, Map<String, Object> param, ValidatorAction va, Field field, IValidationErrors errors) {
		// 検証値
		String[] value = extractListValue(bean, param, field);
		
		// 検証
		if (value == null || value.length == 0) {
			rejectValue(errors, field, va, bean);
			return false;
		}
		return true;
	}

	public boolean validateMask(Object bean, Map<String, Object> param, ValidatorAction va, Field field,
			IValidationErrors errors) throws ValidatorException {
		// 検証値
		String value = extractValue(bean, param, field);
		if (StringUtils.isEmpty(value)) {
			return true;
		}

		// 正規表現
		String mask = field.getVarValue("mask");

		if (StringUtils.isEmpty(mask)) {
			log.error("var[mask] must be specified.");
			throw new ValidatorException("var[mask] must be specified.");
		}

		// 検証
		if (!GenericValidator.matchRegexp(value, mask)) {
			rejectValue(errors, field, va, bean);
			return false;
		}
		return true;
	}

	public boolean validateByte(Object bean, Map<String, Object> param, ValidatorAction va, Field field,
			IValidationErrors errors) {
		// 検証値
		String value = extractValue(bean, param, field);
		if (StringUtils.isEmpty(value)) {
			return true;
		}

		// 検証
		if (GenericTypeValidator.formatByte(value) == null) {
			rejectValue(errors, field, va, bean);
			return false;
		}
		return true;
	}

	public boolean validateShort(Object bean, Map<String, Object> param, ValidatorAction va, Field field,
			IValidationErrors errors) {
		// 検証値
		String value = extractValue(bean, param, field);
		if (StringUtils.isEmpty(value)) {
			return true;
		}

		// 検証
		if (GenericTypeValidator.formatShort(value) == null) {
			rejectValue(errors, field, va, bean);
			return false;
		}
		return true;
	}

	public boolean validateInteger(Object bean, Map<String, Object> param, ValidatorAction va,
			Field field, IValidationErrors errors) {
		// 検証
		String value = extractValue(bean, param, field);
		if (StringUtils.isEmpty(value)) {
			return true;
		}

		// 検証
		if (GenericTypeValidator.formatInt(value) == null) {
			rejectValue(errors, field, va, bean);
			return false;
		}
		return true;
	}

	public boolean validateLong(Object bean, Map<String, Object> param, ValidatorAction va, Field field,
			IValidationErrors errors) {
		// 検証値
		String value = extractValue(bean, param, field);
		if (StringUtils.isEmpty(value)) {
			return true;
		}

		// 検証
		if (GenericTypeValidator.formatLong(value) == null) {
			rejectValue(errors, field, va, bean);
			return false;
		}
		return true;
	}

	public boolean validateFloat(Object bean, Map<String, Object> param, ValidatorAction va, Field field,
			IValidationErrors errors) {
		// 検証値
		String value = extractValue(bean, param, field);
		if (StringUtils.isEmpty(value)) {
			return true;
		}

		// 検証
		if (GenericTypeValidator.formatFloat(value) == null) {
			rejectValue(errors, field, va, bean);
			return false;
		}
		return true;
	}

	public boolean validateDouble(Object bean, Map<String, Object> param, ValidatorAction va, Field field,
			IValidationErrors errors) {
		// 検証値
		String value = extractValue(bean, param, field);
		if (StringUtils.isEmpty(value)) {
			return true;
		}

		// 検証
		if (GenericTypeValidator.formatDouble(value) == null) {
			rejectValue(errors, field, va, bean);
			return false;
		}
		return true;
	}

	public boolean validateDate(Object bean, Map<String, Object> param, ValidatorAction va, Field field,
			IValidationErrors errors) throws ValidatorException {
		// 検証値
		String value = extractValue(bean, param, field);
		if (StringUtils.isEmpty(value)) {
			return true;
		}

		// フォーマット用の日付パターン
		String datePattern = field.getVarValue("datePattern");
		String datePatternStrict = field.getVarValue("datePatternStrict");

		// 検証
		Date result = null;
		try {
			result = ValidationUtil.toDate(value, datePattern,
					datePatternStrict);
		} catch (IllegalArgumentException e) {
			// 日付パターンが不正な場合
			String message = "Mistake on validation definition file. "
					+ "- datePattern or datePatternStrict is invalid. "
					+ "You'll have to check it over. ";
			log.error(message, e);
			throw new ValidatorException(message);
		}
		if (result == null) {
			rejectValue(errors, field, va, bean);
			return false;
		}
		return true;
	}

	public boolean validateIntRange(Object bean, Map<String, Object> param, ValidatorAction va,
			Field field, IValidationErrors errors) throws ValidatorException {
		// 検証値
		String value = extractValue(bean, param, field);
		if (StringUtils.isEmpty(value)) {
			return true;
		}

		// 検証値をintに変換 --- Integer型ではない場合、検証エラー。
		int intValue = 0;
		try {
			intValue = Integer.parseInt(value);
		} catch (NumberFormatException e) {
			rejectValue(errors, field, va, bean);
			return false;
		}

		// 範囲指定値 --- 設定値がInteger型ではない場合、例外。
		// 設定なしはデフォルト値を使用する。
		String strMin = field.getVarValue("intRangeMin");
		int min = Integer.MIN_VALUE;
		if (!GenericValidator.isBlankOrNull(strMin)) {
			try {
				min = Integer.parseInt(strMin);
			} catch (NumberFormatException e) {
				String message = "Mistake on validation definition file. "
						+ "- intRangeMin is not number. "
						+ "You'll have to check it over. ";
				log.error(message, e);
				throw new ValidatorException(message);
			}
		}
		String strMax = field.getVarValue("intRangeMax");
		int max = Integer.MAX_VALUE;
		if (!GenericValidator.isBlankOrNull(strMax)) {
			try {
				max = Integer.parseInt(strMax);
			} catch (NumberFormatException e) {
				String message = "Mistake on validation definition file. "
						+ "- intRangeMax is not number. "
						+ "You'll have to check it over. ";
				log.error(message, e);
				throw new ValidatorException(message);
			}
		}

		// 検証
		if (!GenericValidator.isInRange(intValue, min, max)) {
			rejectValue(errors, field, va, bean);
			return false;
		}
		return true;
	}

	public boolean validateDoubleRange(Object bean, Map<String, Object> param, ValidatorAction va,
			Field field, IValidationErrors errors) throws ValidatorException {
		// 検証値
		String value = extractValue(bean, param, field);
		if (StringUtils.isEmpty(value)) {
			return true;
		}

		// 検証値をdoubleに変換 --- Double型ではない場合、検証エラー。
		double dblValue = 0;
		try {
			dblValue = Double.parseDouble(value);
		} catch (NumberFormatException e) {
			rejectValue(errors, field, va, bean);
			return false;
		}

		// 範囲指定値 --- 設定値がDouble型ではない場合、例外。
		// 設定なしはデフォルト値を使用する。
		String strMin = field.getVarValue("doubleRangeMin");
		double min = Double.MIN_VALUE;
		if (!GenericValidator.isBlankOrNull(strMin)) {
			try {
				min = Double.parseDouble(strMin);
			} catch (NumberFormatException e) {
				String message = "Mistake on validation definition file. "
						+ "- doubleRangeMin is not number. "
						+ "You'll have to check it over. ";
				log.error(message, e);
				throw new ValidatorException(message);
			}
		}
		String strMax = field.getVarValue("doubleRangeMax");
		double max = Double.MAX_VALUE;
		if (!GenericValidator.isBlankOrNull(strMax)) {
			try {
				max = Double.parseDouble(strMax);
			} catch (NumberFormatException e) {
				String message = "Mistake on validation definition file. "
						+ "- doubleRangeMax is not number. "
						+ "You'll have to check it over. ";
				log.error(message, e);
				throw new ValidatorException(message);
			}
		}

		// 検証
		if (!GenericValidator.isInRange(dblValue, min, max)) {
			rejectValue(errors, field, va, bean);
			return false;
		}
		return true;
	}

	public boolean validateFloatRange(Object bean, Map<String, Object> param, ValidatorAction va,
			Field field, IValidationErrors errors) throws ValidatorException {
		// 検証値
		String value = extractValue(bean, param, field);
		if (StringUtils.isEmpty(value)) {
			return true;
		}

		// 検証値をfloatに変換 --- Float型ではない場合、検証エラー。
		float floatValue = 0;
		try {
			floatValue = Float.parseFloat(value);
		} catch (NumberFormatException e) {
			rejectValue(errors, field, va, bean);
			return false;
		}

		// 範囲指定値 --- 設定値がFloat型ではない場合、例外。
		// 設定なしはデフォルト値を使用する。
		String strMin = field.getVarValue("floatRangeMin");
		float min = Float.MIN_VALUE;
		if (!GenericValidator.isBlankOrNull(strMin)) {
			try {
				min = Float.parseFloat(strMin);
			} catch (NumberFormatException e) {
				String message = "Mistake on validation definition file. "
						+ "- floatRangeMin is not number. "
						+ "You'll have to check it over. ";
				log.error(message, e);
				throw new ValidatorException(message);
			}
		}
		String strMax = field.getVarValue("floatRangeMax");
		float max = Float.MAX_VALUE;
		if (!GenericValidator.isBlankOrNull(strMax)) {
			try {
				max = Float.parseFloat(strMax);
			} catch (NumberFormatException e) {
				String message = "Mistake on validation definition file. "
						+ "- floatRangeMax is not number. "
						+ "You'll have to check it over. ";
				log.error(message, e);
				throw new ValidatorException(message);
			}
		}

		// 検証
		if (!GenericValidator.isInRange(floatValue, min, max)) {
			rejectValue(errors, field, va, bean);
			return false;
		}
		return true;
	}

	public boolean validateMaxLength(Object bean, Map<String, Object> param, ValidatorAction va,
			Field field, IValidationErrors errors) throws ValidatorException {
		// 検証値
		String value = extractValue(bean, param, field);
		if (StringUtils.isEmpty(value)) {
			return true;
		}

		// 最大桁数
		int max = 0;
		try {
			max = Integer.parseInt(field.getVarValue("maxlength"));
		} catch (NumberFormatException e) {
			String message = "Mistake on validation definition file. "
					+ "- maxlength is not number. "
					+ "You'll have to check it over. ";
			log.error(message, e);
			throw new ValidatorException(message);
		}

		// 検証
		if (!GenericValidator.maxLength(value, max)) {
			rejectValue(errors, field, va, bean);
			return false;
		}
		return true;
	}

	public boolean validateMinLength(Object bean, Map<String, Object> param, ValidatorAction va,
			Field field, IValidationErrors errors) throws ValidatorException {
		// 検証値
		String value = extractValue(bean, param, field);
		if (StringUtils.isEmpty(value)) {
			return true;
		}

		// 最小桁数
		int min = 0;
		try {
			min = Integer.parseInt(field.getVarValue("minlength"));
		} catch (NumberFormatException e) {
			String message = "Mistake on validation definition file. "
					+ "- minlength is not number. "
					+ "You'll have to check it over. ";
			log.error(message, e);
			throw new ValidatorException(message);
		}

		// 検証
		if (!GenericValidator.minLength(value, min)) {
			rejectValue(errors, field, va, bean);
			return false;
		}
		return true;
	}
	
	public boolean validateAlphaNumericString(Object bean, Map<String, Object> param,
            ValidatorAction va, Field field, IValidationErrors errors) {
        // 検証値
		String value = extractValue(bean, param, field);
        if (StringUtils.isEmpty(value)) {
            return true;
        }

        // 検証
        if (!ValidationUtil.isAlphaNumericString(value)) {
            rejectValue(errors, field, va, bean);
            return false;
        }
        return true;
    }
	
	public boolean validateCapAlphaNumericString(Object bean, Map<String, Object> param,
            ValidatorAction va, Field field, IValidationErrors errors) {
        // 検証値
		String value = extractValue(bean, param, field);
        if (StringUtils.isEmpty(value)) {
            return true;
        }

        // 検証
        if (!ValidationUtil.isUpperAlphaNumericString(value)) {
            rejectValue(errors, field, va, bean);
            return false;
        }
        return true;
    }
	
	public boolean validateNumber(Object bean, Map<String, Object> param, ValidatorAction va,
            Field field, IValidationErrors errors) throws ValidatorException {
        // 検証値
		String value = extractValue(bean, param, field);
        if (StringUtils.isEmpty(value)) {
            return true;
        }

        // 検証値が半角ではない場合エラー。
        if (!ValidationUtil.isHankakuString(value)) {
            rejectValue(errors, field, va, bean);
            return false;
        }

        // 検証値をBigDecimalに変換
        BigDecimal number = null;
        try {
            number = new BigDecimal(value);
        } catch (NumberFormatException e) {
            rejectValue(errors, field, va, bean);
            return false;
        }

        // 整数部桁数取得
        int integerLength = Integer.MAX_VALUE;
        String integerLengthStr = field.getVarValue("integerLength");
        if (!GenericValidator.isBlankOrNull(integerLengthStr)) {
            try {
                integerLength = Integer.parseInt(integerLengthStr);
            } catch (NumberFormatException e) {
                String message = "Mistake on validation definition file. "
                    + "- integerLength is not number. "
                    + "You'll have to check it over. ";
                log.error(message, e);
                throw new ValidatorException(message);
            }
        }

        // 小数部桁数取得
        int scaleLength = Integer.MAX_VALUE;
        String scaleStr = field.getVarValue("scale");
        if (!GenericValidator.isBlankOrNull(scaleStr)) {
            try {
                scaleLength = Integer.parseInt(scaleStr);
            } catch (NumberFormatException e) {
                String message = "Mistake on validation definition file. "
                    + "- scale is not number. "
                    + "You'll have to check it over. ";
                log.error(message, e);
                throw new ValidatorException(message);
            }
        }

        // 整数桁数一致チェックか
        boolean isAccordedInteger =
            "true".equals(field.getVarValue("isAccordedInteger"));
        // 小数桁数一致チェックか
        boolean isAccordedScale =
            "true".equals(field.getVarValue("isAccordedScale"));

        // 検証
        if (!ValidationUtil.isNumber(
                number, integerLength, isAccordedInteger,
                scaleLength, isAccordedScale)) {
            rejectValue(errors, field, va, bean);
            return false;
        }

        return true;
    }
	
	public boolean validateHankakuKanaString(Object bean, Map<String, Object> param,
            ValidatorAction va, Field field, IValidationErrors errors) {
        // 検証値
		String value = extractValue(bean, param, field);
        if (StringUtils.isEmpty(value)) {
            return true;
        }

        // 検証
        if (!ValidationUtil.isHankakuKanaString(value)) {
            rejectValue(errors, field, va, bean);
            return false;
        }
        return true;
    }
	
	public boolean validateHankakuString(Object bean, Map<String, Object> param,
            ValidatorAction va, Field field, IValidationErrors errors) {
        // 検証値
		String value = extractValue(bean, param, field);
        if (StringUtils.isEmpty(value)) {
            return true;
        }

        // 検証
        if (!ValidationUtil.isHankakuString(value)) {
            rejectValue(errors, field, va, bean);
            return false;
        }
        return true;
    }
	
	public boolean validateZenkakuString(Object bean, Map<String, Object> param,
            ValidatorAction va, Field field, IValidationErrors errors) {
        // 検証値
		String value = extractValue(bean, param, field);
        if (StringUtils.isEmpty(value)) {
            return true;
        }

        // 検証
        if (!ValidationUtil.isZenkakuString(value)) {
            rejectValue(errors, field, va, bean);
            return false;
        }
        return true;
    }
	
	public boolean validateZenkakuKanaString(Object bean, Map<String, Object> param,
            ValidatorAction va, Field field, IValidationErrors errors) {
        // 検証値
		String value = extractValue(bean, param, field);
        if (StringUtils.isEmpty(value)) {
            return true;
        }

        // 検証
        if (!ValidationUtil.isZenkakuKanaString(value)) {
            rejectValue(errors, field, va, bean);
            return false;
        }
        return true;
    }
	
	public boolean validateProhibited(Object bean, Map<String, Object> param, ValidatorAction va,
            Field field, IValidationErrors errors)
            throws ValidatorException {
        // 検証値
		String value = extractValue(bean, param, field);
        if (StringUtils.isEmpty(value)) {
            return true;
        }

        // 入力禁止文字列
        String prohibitedStr = field.getVarValue("chars");

        // charsが取得できない場合はValidatorExceptionをスロー
        if (StringUtils.isEmpty(prohibitedStr)) {
            log.error("var[chars] must be specified.");
            throw new ValidatorException("var[chars] must be specified.");
        }

        // 検証
        if (!ValidationUtil.hasNotProhibitedChar(value, prohibitedStr)) {
            rejectValue(errors, field, va, bean);
            return false;
        }
        return true;
    }
	
	public boolean validateNumericString(Object bean, Map<String, Object> param,
            ValidatorAction va, Field field, IValidationErrors errors) {
        // 検証値
		String value = extractValue(bean, param, field);
        if (StringUtils.isEmpty(value)) {
            return true;
        }

        // 検証
        if (!ValidationUtil.isNumericString(value)) {
            rejectValue(errors, field, va, bean);
            return false;
        }
        return true;
    }
	
	public boolean validateStringLength(Object bean, Map<String, Object> param,
            ValidatorAction va, Field field, IValidationErrors errors)
            throws ValidatorException {
        // 検証値
		String value = extractValue(bean, param, field);
        if (StringUtils.isEmpty(value)) {
            return true;
        }

        // 文字列長
        int length = Integer.MAX_VALUE;
        String lengthStr = field.getVarValue("stringLength");

        try {
            length = Integer.valueOf(lengthStr).intValue();
        } catch (NumberFormatException e) {
            String message = "Mistake on validation definition file. "
                + "- stringLength is not number. "
                + "You'll have to check it over. ";
            log.error(message, e);
            throw new ValidatorException(message);
        }

        // 検証
        if (value.length() != length) {
            rejectValue(errors, field, va, bean);
            return false;
        }
        return true;
    }
	
	public boolean validateUrl(Object bean, Map<String, Object> param, ValidatorAction va,
            Field field, IValidationErrors errors) {
        // 検証値
		String value = extractValue(bean, param, field);
        if (StringUtils.isEmpty(value)) {
            return true;
        }

        // オプションの変数を取得する
        boolean allowallschemes =
            "true".equals(field.getVarValue("allowallschemes"));
        boolean allow2slashes =
            "true".equals(field.getVarValue("allow2slashes"));
        boolean nofragments =
            "true".equals(field.getVarValue("nofragments"));
        String schemesVar = allowallschemes ? null : field
                .getVarValue("schemes");

        // 検証
        if (!ValidationUtil.isUrl(
                value, allowallschemes, allow2slashes,
                nofragments, schemesVar)) {
            rejectValue(errors, field, va, bean);
            return false;
        }
        return true;
    }
	
	public boolean validateByteRange(Object bean, Map<String, Object> param,
            ValidatorAction va, Field field, IValidationErrors errors)
            throws ValidatorException {
        // 検証値
		String value = extractValue(bean, param, field);
        if (StringUtils.isEmpty(value)) {
            return true;
        }

        // エンコーディング
        String encoding = field.getVarValue("encoding");

        // 最小バイト列長
        int min = 0;
        String minStr = field.getVarValue("minByteLength");
        if (!GenericValidator.isBlankOrNull(minStr)) {
            try {
                min = Integer.parseInt(minStr);
            } catch (NumberFormatException e) {
                String message = "Mistake on validation definition file. "
                    + "- minByteLength is not number. "
                    + "You'll have to check it over. ";
                log.error(message, e);
                throw new ValidatorException(message);
            }
        }

        // 最大バイト列長
        int max = Integer.MAX_VALUE;
        String maxStr = field.getVarValue("maxByteLength");
        if (!GenericValidator.isBlankOrNull(maxStr)) {
            try {
                max = Integer.parseInt(maxStr);
            } catch (NumberFormatException e) {
                String message = "Mistake on validation definition file. "
                    + "- maxByteLength is not number. "
                    + "You'll have to check it over. ";
                log.error(message, e);
                throw new ValidatorException(message);
            }
        }

        // 検証
        try {
            if (!ValidationUtil.isByteInRange(value, encoding, min, max)) {
                rejectValue(errors, field, va, bean);
                return false;
            }
        } catch (IllegalArgumentException e) {
            log.error("encoding[" + encoding + "] is not supported.");
            throw new ValidatorException("encoding[" + encoding +
                    "] is not supported.");
        }
        return true;
    }
	
	public boolean validateDateRange(Object bean, Map<String, Object> param,
            ValidatorAction va, Field field, IValidationErrors errors)
            throws ValidatorException {
        // 検証値
		String value = extractValue(bean, param, field);
        if (StringUtils.isEmpty(value)) {
            return true;
        }

        // 日付入力パターン
        String datePattern = field.getVarValue("datePattern");
        String datePatternStrict = field.getVarValue("datePatternStrict");

        // 範囲指定する日付
        String startDateStr = field.getVarValue("startDate");
        String endDateStr = field.getVarValue("endDate");

        // 検証
        try {
            if (!ValidationUtil.isDateInRange(value, startDateStr, endDateStr,
                    datePattern, datePatternStrict)) {
                rejectValue(errors, field, va, bean);
                return false;
            }
        } catch (IllegalArgumentException e) {
            log.error(e.getMessage());
            throw new ValidatorException(e.getMessage());
        }
        return true;
    }
	
	public boolean validateDateCompared(Object bean, Map<String, Object> param,
            ValidatorAction va, Field field, IValidationErrors errors) throws ValidatorException {
		String datePattern = field.getVarValue("datePattern");
		if (StringUtils.isEmpty(datePattern)) {
			datePattern = DateUtils.FORMAT_YYYYMMDD_DASH;
		}
		
		String beforeDate = extractValue(bean, field.getVarValue("beforeDate"));
		String afterDate = extractValue(bean, field.getVarValue("afterDate"));
		
		if (StringUtils.isNotEmpty(field.getVarValue("beforeDate"))) {
			beforeDate = extractValue(bean, field.getVarValue("beforeDate"));
			afterDate = extractValue(bean, param, field);
		} else if (StringUtils.isNotEmpty(field.getVarValue("afterDate"))) {
			beforeDate = extractValue(bean, param, field);
			afterDate = extractValue(bean, field.getVarValue("afterDate"));
		} else {
			log.error("var[beforeDate] and var[afterDate] must be haved one.");
            throw new ValidatorException("var[beforeDate] and var[afterDate] must be haved one.");
		}
		
		boolean equals = "true".equals(field.getVarValue("equals"));
		
		if (StringUtils.isEmpty(beforeDate) || StringUtils.isEmpty(afterDate)) {
			return true;
		}
		
		try {
			Date beforeDateD = DateUtils.formatToDate(beforeDate, datePattern);
			Date afterDateD = DateUtils.formatToDate(afterDate, datePattern);
			int compared = beforeDateD.compareTo(afterDateD);
			if (compared > 0 || (!equals && compared == 0)) {
				rejectValue(errors, field, va, bean);
				return false;
			}
		} catch (SoftbankException e) {
			log.error(e.getMessage());
            throw new ValidatorException(e.getMessage());
		}
		
		return true;
    }
	
	public boolean isExist(Object bean, Map<String, Object> param,
            ValidatorAction va, Field field, IValidationErrors errors, IDbExecute dao)
            throws ValidatorException {
		return validateDao(bean, param, va, field, errors, dao, "isExist");
	}
	
	public boolean notExist(Object bean, Map<String, Object> param,
			ValidatorAction va, Field field, IValidationErrors errors, IDbExecute dao)
					throws ValidatorException {
		return validateDao(bean, param, va, field, errors, dao, "notExist");
	}
	
	public boolean validateCustomLogic(Object bean, Map<String, Object> param, ValidatorAction va, Field field, IValidationErrors errors) throws ValidatorException {
		try {
			HttpContext httpContext = (HttpContext)bean;
			final String logicName = ControlRequestMap.getInstance().getLogic(httpContext.getParam());
			final ApplicationContext wac = CustomLoaderListener.getApplicationContext();
			final Object logic = wac.getBean(logicName);
			if (logic instanceof AbstractBaseLogic) {
				AbstractBaseLogic baseLogic = ((AbstractBaseLogic)logic);
				final Class<? extends Object> clazz = logic.getClass();
				baseLogic.applicationInit(httpContext);
				Object result = null;
				if (param != null) {
					final String methodStr = field.getVarValue("method");
					final Method method = clazz.getMethod(methodStr, new Class[]{Map.class});
					result = method.invoke(logic, new Object[]{param});
				} else {
					final String methodStr = field.getVarValue("method");
					final Method method = clazz.getMethod(methodStr, new Class[]{});
					result = method.invoke(logic, new Object[]{});
				}
				if (result != null && result instanceof LogicBean) {
					LogicBean logicBean = (LogicBean)result;
					if (!logicBean.isResultFlg()) {
						rejectValue(errors, field, va, bean, logicBean.getResultCode());
						return false;
					}
				}
			}
		} catch (SoftbankException e) {
			log.error(e.getMessage());
            throw new ValidatorException(e.getMessage());
		} catch (NoSuchMethodException e) {
			log.error(e.getMessage());
            throw new ValidatorException(e.getMessage());
		} catch (SecurityException e) {
			log.error(e.getMessage());
            throw new ValidatorException(e.getMessage());
		} catch (IllegalAccessException e) {
			log.error(e.getMessage());
            throw new ValidatorException(e.getMessage());
		} catch (IllegalArgumentException e) {
			log.error(e.getMessage());
            throw new ValidatorException(e.getMessage());
		} catch (InvocationTargetException e) {
			log.error(e.getMessage());
            throw new ValidatorException(e.getMessage());
		}
		return true;
	}
	
	public boolean validateDao(Object bean, Map<String, Object> param,
            ValidatorAction va, Field field, IValidationErrors errors, IDbExecute dao, String type)
            throws ValidatorException {
		String sql = field.getVarValue("sql");
		
        try {
        	if (dao == null) {
        		log.error("methodParams[co.jp.softbank.qqmx.validator.IDao] must be specified.");
        		throw new ValidatorException("methodParams[co.jp.softbank.qqmx.validator.IDao] must be specified.");
        	}
        	
        	if (StringUtils.isEmpty(sql)) {
        		log.error("var[sql] must be specified.");
        		throw new ValidatorException("var[sql] must be specified.");
        	}
        	
        	String resultType = field.getVarValue("resultType");
        	if (StringUtils.isEmpty(resultType)) {
        		resultType = "list";
        	}
        	
        	// 検証値
        	String value = extractValue(bean, param, field);
        	if (StringUtils.isEmpty(value)) {
        		return true;
        	}
        	
        	Map<String, Object> conditions = Maps.newHashMap();
        	conditions.put(field.getProperty(), value);
        	
        	Object result = null;
        	if ("list".equals(resultType)) {
        		result = dao.querys(sql, conditions);
			} else {
				result = dao.query(sql, conditions);
			}
        	
        	if ("isExist".equals(type)) {
        		if (result == null) {
        			rejectValue(errors, field, va, bean);
        			return false;
        		} else {
        			if (result instanceof List) {
        				if (((List)result).size() == 0) {
        					rejectValue(errors, field, va, bean);
        					return false;
        				}
        			}
        		}
        	} else if ("notExist".equals(type)) {
        		if (result != null) {
        			if (result instanceof List) {
        				if (((List)result).size() > 0) {
        					rejectValue(errors, field, va, bean);
        					return false;
        				}
        			} else {
        				rejectValue(errors, field, va, bean);
        				return false;
        			}
        		}
        	}
        } catch (SecurityException e) {
        	e.printStackTrace();
        	throw new ValidatorException("SecurityException : " + sql);
		} catch (IllegalArgumentException e) {
			e.printStackTrace();
			throw new ValidatorException("IllegalArgumentException : " + sql);
		} catch (SoftbankException e) {
			e.printStackTrace();
			throw new ValidatorException("SoftbankException : " + sql);
		}
		return true;
	}
	
	protected String extractValue(Object bean, Map<String, Object> param, Field field) {
		String value = null;
		
		if (param != null) {
			value = StringUtils.toString(param.get(field.getProperty()));
		} else {
			if (bean == null) {
				return null;
			} else if (bean instanceof String) {
				value = (String) bean;
			} else if (bean instanceof Number || bean instanceof Boolean
					|| bean instanceof Character) {
				value = bean.toString();
			} else if (bean instanceof HttpContext) {
				value = ((HttpContext) bean).getParam().get(field.getProperty());
			} else {
				value = ValidatorUtils.getValueAsString(bean, field.getProperty());
			}
		}

		return value;
	}
	
	protected String[] extractListValue(Object bean, Map<String, Object> param, Field field) {
		String[] value = null;
		
		if (bean instanceof HttpContext) {
			value = ((HttpContext) bean).getParam().getList(field.getProperty());
		}
		
		return value;
	}
	
	protected String extractValue(Object bean, String key) {
		String value = null;
		
		if (!(bean instanceof HttpContext)) {
			return value;
		}
		
		value = ((HttpContext) bean).getParam().get(key);
		
		return value;
	}

}
