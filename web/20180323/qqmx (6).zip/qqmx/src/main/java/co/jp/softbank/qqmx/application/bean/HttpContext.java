package co.jp.softbank.qqmx.application.bean;

import java.io.File;
import java.io.UnsupportedEncodingException;
import java.util.Iterator;
import java.util.List;

import javax.servlet.ServletContext;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.apache.commons.fileupload.FileItem;
import org.apache.commons.fileupload.FileItemFactory;
import org.apache.commons.fileupload.FileUploadException;
import org.apache.commons.fileupload.disk.DiskFileItemFactory;
import org.apache.commons.fileupload.servlet.ServletFileUpload;

import co.jp.softbank.qqmx.exception.SoftbankException;
import co.jp.softbank.qqmx.exception.SoftbankExceptionType;
import co.jp.softbank.qqmx.logic.bean.LogicBean;
import co.jp.softbank.qqmx.logic.bean.Param;
import co.jp.softbank.qqmx.logic.bean.SessionData;
import co.jp.softbank.qqmx.util.ConstantsUtil;
import co.jp.softbank.qqmx.util.StringUtils;

import com.google.common.collect.Lists;

public class HttpContext {
	
	private static final String QQMX_LOCALE = "QQMX_LOCALE";
	
	private static final String FORWARD_URL_PATH = "FORWARD_URL_PATH";
	
	private HttpServletRequest request;
	
	private HttpServletResponse response;
	
	private ServletContext context;
	
	private Param param;
	
	private SessionData sessionData;
	
	private List<FileItem> uploadFileItems;
	
	private LogicBean resultBean;
	
	public HttpContext(ServletRequest request, ServletResponse response) throws FileUploadException, SoftbankException {
		if (request instanceof HttpServletRequest) {
			this.request = (HttpServletRequest)request;
		}
		if (response instanceof HttpServletResponse) {
			this.response = (HttpServletResponse)response;
		}
		resultBean = new LogicBean();
		this.param = new Param();
		if (ServletFileUpload.isMultipartContent(this.request)) {
			uploadFileItems = Lists.newArrayList();
			FileItemFactory factory = new DiskFileItemFactory();
			ServletFileUpload upload = new ServletFileUpload(factory);
			upload.setHeaderEncoding(ConstantsUtil.Frame.ENCODING);
			List items = upload.parseRequest(this.request);
			Iterator itr = items.iterator();
			while (itr.hasNext()) {
				FileItem item = (FileItem) itr.next();
				String fileName = item.getName();
				long fileSize = item.getSize();
				if (!item.isFormField()) {
					uploadFileItems.add(item);
				} else {
					try {
						this.param.set(item.getFieldName(), item.getString(ConstantsUtil.Frame.ENCODING));
					} catch (UnsupportedEncodingException e) {
						e.printStackTrace();
						throw new SoftbankException(SoftbankExceptionType.UnsupportedEncodingException, e);
					}
				}
			}
        }
		this.param.pickParameters(request);
	}
	
	public HttpServletRequest getRequest() {
		return request;
	}

	public void setRequest(HttpServletRequest request) {
		this.request = request;
	}

	public HttpServletResponse getResponse() {
		return response;
	}

	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}

	public ServletContext getContext() {
		return context;
	}

	public void setContext(ServletContext context) {
		this.context = context;
	}

	public Param getParam() {
		return param;
	}

	public void setParam(Param param) {
		this.param = param;
	}

	public SessionData getSessionData() {
		return sessionData;
	}

	public void setSessionData(SessionData sessionData) {
		this.sessionData = sessionData;
	}
	
	public String getLang() {
		if (this.sessionData != null && StringUtils.isNotEmpty(this.sessionData.get(QQMX_LOCALE))) {
			return this.sessionData.getString(QQMX_LOCALE);
		}
		return ConstantsUtil.Lang.JAPAN;
	}
	
	public void setLang(String lang) {
		if (this.sessionData != null) {
			this.sessionData.set(QQMX_LOCALE, lang);
		}
	}
	
	public void createSession() {
		HttpSession session = request.getSession(false);
		if (session == null) {
			session = request.getSession(true);
		}
		this.sessionData = (SessionData)session.getAttribute(SessionData.APPLICATION_SESSION_KEY);
		if (this.sessionData == null) {
			this.sessionData = new SessionData();
			session.setAttribute(SessionData.APPLICATION_SESSION_KEY, this.sessionData);
		}
	}

	public List<FileItem> getUploadFileItems() {
		return uploadFileItems;
	}

	public void setUploadFileItems(List<FileItem> uploadFileItems) {
		this.uploadFileItems = uploadFileItems;
	}

	public LogicBean getResultBean() {
		return resultBean;
	}

	public void setResultBean(LogicBean resultBean) {
		this.resultBean = resultBean;
	}
	
	public void setForwardUrlPath(String url) {
		if (this.sessionData != null) {
			sessionData.set(FORWARD_URL_PATH, url);
		}
	}
	
	public String getForwardUrlPath() {
		if (this.sessionData != null && this.sessionData.containsKey(FORWARD_URL_PATH)) {
			String forwardUrl = sessionData.getString(FORWARD_URL_PATH);
			sessionData.remove(FORWARD_URL_PATH);
			return forwardUrl;
		}
		return null;
	}
	
	public String getRealPath() {
		return context.getRealPath(File.separator);
	}
	
	public boolean isEngineTest() {
		if (param == null) {
			return false;
		}
		return param.isEngineTest();
	}

}
